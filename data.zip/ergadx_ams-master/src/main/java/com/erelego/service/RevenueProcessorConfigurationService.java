package com.erelego.service;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erelego.model.BankDetails;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.repository.BankDetailsRepository;
import com.erelego.repository.RevenueProcessorConfigurationRepository;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
@Service
public class RevenueProcessorConfigurationService {

			
	Logger LOGGER = LogManager.getLogger(AdsTxtService.class);
    @PersistenceContext
    private EntityManager entityManager;
    
    @Autowired
	private RevenueProcessorConfigurationRepository revenueProcessorConfigurationRepository;
	
    public List<RevenueProcessorConfiguration> listAll() {
        return revenueProcessorConfigurationRepository.findAll();
    }
    
    public RevenueProcessorConfiguration get(Integer id) {
        return revenueProcessorConfigurationRepository.findById(id).get();
    }
	     
}
