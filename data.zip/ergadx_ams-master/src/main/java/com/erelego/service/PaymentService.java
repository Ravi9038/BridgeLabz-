package com.erelego.service;
import com.erelego.model.Payment;
import com.erelego.model.UserWebsite;
import com.erelego.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Service;

import java.util.List;
import javax.transaction.Transactional;


@Service
@Transactional
public class PaymentService 
{
	@Autowired
	private PaymentRepository repo;
	public List<Payment> listAll() {
        return repo.findAll();
    }
     
    public void save(Payment payment) {
        repo.save(payment);
    }
     
    public Payment get(Integer id) {
        return repo.findById(id).get();
    }
    
    public List<Payment> getPaymentByUserID(Integer id) {
        return repo.findByUserId(id);
    }
    
    
     
    public void delete(Integer id) {
        repo.deleteById(id);
    }

}
