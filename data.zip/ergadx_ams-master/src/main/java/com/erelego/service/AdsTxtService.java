package com.erelego.service;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import javax.persistence.EntityManagerFactory;

import com.erelego.model.InvoiceItem;
import com.erelego.model.UserWebsite;
import com.erelego.util.Constants;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.apache.logging.log4j.Logger;
import org.jsoup.Jsoup;
import org.apache.logging.log4j.LogManager;

@Service
public class AdsTxtService {
	
	Logger LOGGER = LogManager.getLogger(AdsTxtService.class);
    @PersistenceContext
    private EntityManager entityManager;
    
    @Autowired
    private UserWebsiteService userWebsiteService;

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
		
	@Transactional(propagation=Propagation.REQUIRED)
    public void validateAdsTxtForAllWebsites()  {
    	List<UserWebsite> listUserWebsites = userWebsiteService.getAllWebsites();
    	for(UserWebsite lUserWebsite : listUserWebsites) {
    		LOGGER.debug("Starting validating ads.txt for website " + lUserWebsite.getHostURL());  
    		Long idStatus = null;
    		try {
				idStatus = insertAdsTxtStatus(lUserWebsite);
				validateAdsTxtRecords(lUserWebsite,idStatus.toString());
    		} catch (Exception e) {
				updateAdsTxtStatus(idStatus.toString(),Constants.STATUS_FAILURE,e.getMessage());
				lUserWebsite.setAdsTxtStatus(Constants.STATUS_FAILURE);
				lUserWebsite.setAdsTxtStatusDate(new Date());
				entityManager.persist(lUserWebsite);
			}
    		
    	}
    }
	
	@Transactional(propagation=Propagation.REQUIRED)
	public Set<Object> validateAdsTxtForWebsite(int idWebsite) throws Exception {
		Long idStatus = null;
		UserWebsite lUserWebsite = userWebsiteService.get(idWebsite);
		HashSet<Object> NotMatchedAdsTxt=null;
		ObjectMapper lObjectMapper = new ObjectMapper();
		ArrayNode lOutputNode = lObjectMapper.createArrayNode();
		try {
			
		 idStatus = insertAdsTxtStatus(lUserWebsite);
		 String myString = Long.toString(idStatus);
		 NotMatchedAdsTxt = (HashSet<Object>) validateAdsTxtRecords(lUserWebsite,myString);
		   
		
		} catch (Exception e) {
			updateAdsTxtStatus(idStatus.toString(),Constants.STATUS_FAILURE,e.getMessage());
			lUserWebsite.setAdsTxtStatus(Constants.STATUS_FAILURE);
			lUserWebsite.setAdsTxtStatusDate(new Date());
			lUserWebsite.setIdStatus(idStatus.toString());
			entityManager.persist(lUserWebsite);
		}
		return NotMatchedAdsTxt;
	}
	
	@Transactional(propagation = Propagation.NESTED)
    public long insertAdsTxtStatus(UserWebsite userWebsite) throws Exception{
    	LOGGER.debug("Inserting status row for website " + userWebsite.getHostURL());
    	long idStatusRow = System.currentTimeMillis();
	
    	 int insertedRowCount = this.entityManager.createNativeQuery("INSERT INTO ams_website_ads_txt_validation_request_status (id,id_website,start_date,status) VALUES (?,?,?,?)")
                .setParameter(1, idStatusRow)
    			.setParameter(2,userWebsite.getId() )
                .setParameter(3, new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime()))
                .setParameter(4,Constants.STATUS_INPROGRESS)
                .executeUpdate(); 
    	
    	if(insertedRowCount != 1) {
    		throw new Exception("Status row not inserted");
    	}
    	LOGGER.debug("Inserted status row for website " + userWebsite.getHostURL());
    	return idStatusRow;
    }
	
	@Transactional(propagation = Propagation.NESTED)
    public void updateAdsTxtStatus(String idStatusRow,String status,String comment){
		
		
    	int updatedRowCount = this.entityManager.createNativeQuery("UPDATE ams_website_ads_txt_validation_request_status set status = ? , end_date = ? , comment = ? where id = ?")
                .setParameter(1, status)
    			.setParameter(2,new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime()))
                .setParameter(3, comment)
                .setParameter(4,idStatusRow)
                .executeUpdate(); 
    	
    }

	@Transactional(propagation = Propagation.NESTED)
    public Set<Object> validateAdsTxtRecords(UserWebsite userWebsite, String idStatus) throws Exception {

		String lAdsTxt = "";

    		lAdsTxt = loadAdsTxtForWebsite(Constants.HTTP_PROTOCOL + "://" + userWebsite.getHostURL());
    	Map<String,String> lAdsTxtRecords = getAdsTxtRecords(lAdsTxt);
    	LOGGER.debug("Reterived ads.txt for website count : " + lAdsTxtRecords.size());
    	System.out.println(lAdsTxtRecords.size());
    	Query lQueryGetAdsTxtForWebsite = entityManager.createNativeQuery("select id,id_advertiser,exchange_domain_name,account_id,account_type,certification_auth_id from ams_advertiser_ads_txt where id_advertiser in(select id_advertiser from ams_website_advertiser_revenue_share where id_website=?)");
    	lQueryGetAdsTxtForWebsite.setParameter(1, userWebsite.getId());
    	List<?> lAdsTxtForWebsite = lQueryGetAdsTxtForWebsite.getResultList();
    	System.out.println(lAdsTxtForWebsite.size());
    	LOGGER.debug("Selected "+ lAdsTxtForWebsite.size() + " ads.txt for website " + userWebsite.getHostURL());
    	boolean allRecordsMatched = true;
    	int numberOfNotFoundRecords = 0;
    
    	 Set<Object> NotMatched = new HashSet<Object>();
    	
    
    	for(int i=0 ; i < lAdsTxtForWebsite.size() ; i++) {
        	Object[] lAdsTxtRecord  = (Object[]) lAdsTxtForWebsite.get(i);
        	StringBuilder lKey = new StringBuilder();
        	String exchangeDomain = lAdsTxtRecord[2].toString().toUpperCase().trim();
        	lKey.append(exchangeDomain);
        	lKey.append("_");
        	lKey.append(lAdsTxtRecord[3].toString().toUpperCase().trim());
        	lKey.append("_");
        	lKey.append(lAdsTxtRecord[4].toString().toUpperCase().trim());
        	lKey.append("_");
        	if(lAdsTxtRecord.length>5) {
        	if(lAdsTxtRecord[5]!=null) {
        		lKey.append(lAdsTxtRecord[5].toString().toUpperCase().trim());
        		lKey.append("_");
        	}
        	}
        	if(lAdsTxtRecords.containsKey(lKey.toString())) {
        		LOGGER.debug(" Website = " +userWebsite.getHostURL()+ " |  Found : " + lKey.toString() );
        		//updateAdsTxtRecordStatusOfWebsite(Constants.STATUS_SUCCESS,userWebsite.getId(),Integer.parseInt(lAdsTxtRecord[1].toString()));
        	}else {
        		allRecordsMatched = false;
        		numberOfNotFoundRecords++;
        		NotMatched.add(lAdsTxtRecord);
        	
        		Query lQueryGetNotMatchedAdsTxtForWebsite = entityManager.createNativeQuery("insert into ams_advertiser_not_found_ads_txt (id_advertiser,id_website,exchange_domain_name,account_id,account_type,certification_auth_id,idStatus)" + 
        				"values(?,?,?,?,?,?,?)");
                
        		lQueryGetNotMatchedAdsTxtForWebsite.setParameter(1, lAdsTxtRecord[1].toString().trim());
        		lQueryGetNotMatchedAdsTxtForWebsite.setParameter(2,userWebsite.getId() );
        		lQueryGetNotMatchedAdsTxtForWebsite.setParameter(3, lAdsTxtRecord[2].toString().trim());
        		lQueryGetNotMatchedAdsTxtForWebsite.setParameter(4, lAdsTxtRecord[3].toString().trim());
        		lQueryGetNotMatchedAdsTxtForWebsite.setParameter(5, lAdsTxtRecord[4].toString().trim());
        		
        		if( lAdsTxtRecord[5]!=null) {
        		lQueryGetNotMatchedAdsTxtForWebsite.setParameter(6, lAdsTxtRecord[5].toString().trim());
        		}
        	
            		lQueryGetNotMatchedAdsTxtForWebsite.setParameter(7, idStatus);
            		
        		lQueryGetNotMatchedAdsTxtForWebsite.executeUpdate();
        		}
        	
        	
        		//updateAdsTxtRecordStatusOfWebsite(Constants.STATUS_FAILURE,userWebsite.getId(),Integer.parseInt(lAdsTxtRecord[1].toString()));
        		LOGGER.debug(" Website = " +userWebsite.getHostURL()+ " |  Not Found : " + lKey.toString());
        		
        	  
        	
        	
    	}
    	userWebsite.setNoOfNotFoundAdsTxtRecords(numberOfNotFoundRecords);
    	if(allRecordsMatched && lAdsTxtForWebsite.size() > 0 && lAdsTxtRecords.size() > 0) {
    		
    		LOGGER.debug("Successfully validated for website - " + userWebsite.getHostURL());
    		userWebsite.setAdsTxtStatus(Constants.STATUS_SUCCESS);
    		userWebsite.setAdsTxtStatusDate(new Date());
    		userWebsite.setIdStatus(idStatus);
    	}else {
    		LOGGER.debug("Failed to  validate for website - " + userWebsite.getHostURL());
    		userWebsite.setAdsTxtStatus(Constants.STATUS_FAILURE); 
    		userWebsite.setAdsTxtStatusDate(new Date());
    		userWebsite.setIdStatus(idStatus);
    	}
    	entityManager.persist(userWebsite);
	
    	return NotMatched;
    }
    
	@Transactional(propagation = Propagation.NESTED)
    public void updateAdsTxtRecordStatusOfWebsite(String status,int idWebsite,int idAdvertiser) {
    	entityManager.createNativeQuery("UPDATE ams_website_adstxt_mapping_view set status = ? , validate_date = ? where id_advertiser = ? AND id_website = ?")
                .setParameter(1, status)
    			.setParameter(2,new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime()))
                .setParameter(3, idAdvertiser)
                .setParameter(4,idWebsite)
                .executeUpdate(); 
    }
    
    public Map<String,String> getAdsTxtRecords(String pAdsTxt){
    	String [] rows = pAdsTxt.split("\\r?\\n"); 
    	Map <String,String> mapAdsTxtRecords = new LinkedHashMap<String,String>();
		for(String row : rows) {
			if(row.trim() != "" ) {
				int commentStartIndex = row.indexOf("#");
				String rowWithoutComment = row;
				if(commentStartIndex > 0 ) 
					rowWithoutComment = row.substring(0, commentStartIndex);
				String[] splitRecord = rowWithoutComment.split(",");
				if(splitRecord.length > 1) {
					StringBuilder lMapKey = new StringBuilder();
					for(String lSplitRecord : splitRecord ) {
						lSplitRecord = lSplitRecord.trim();
						lMapKey.append(lSplitRecord.toUpperCase());
						lMapKey.append("_");
					}
					mapAdsTxtRecords.put(lMapKey.toString(), "Found");
				}
				
			}
		}
		return mapAdsTxtRecords;
    }
    public String loadAdsTxtForWebsite(String websiteUrl) throws Exception{
		LOGGER.debug("Reteriving ads.txt for website " + websiteUrl);
    	RestTemplate restTemplate = new RestTemplate();
    	Document document ;

     	String result;
    	try {
    		String url = websiteUrl+"/ads.txt";
    		document = Jsoup.connect(url).followRedirects(true).get();
    		  result=document.body().wholeText();
 	
    	}catch (Exception e) {
    		LOGGER.debug("Unable to retrieve records from website" + e.getMessage());
    		throw new Exception("Unable to retrieve from website - " + e.getMessage());
		}
    	LOGGER.debug("Reterived ads.txt for website " + result);
		
		if(result !=null) 
			
			return result;
		else
			return "";
    }

	public ArrayNode getAdsTxtRecordsForWebsite(Integer id) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
    	Query lQueryGetWebsiteAdsTxtRecords = entityManager.createNativeQuery("select id,id_advertiser,exchange_domain_name,account_id,account_type,certification_auth_id from ams_advertiser_ads_txt where id_advertiser in(select id_advertiser from ams_website_advertiser_revenue_share where id_website=?)");
    	lQueryGetWebsiteAdsTxtRecords.setParameter(1, id);
    	List<?> lAdsTxtRecords = lQueryGetWebsiteAdsTxtRecords.getResultList();
    	for(int i=0 ; i < lAdsTxtRecords.size() ; i++) {

    		ObjectNode lJsonNodeAdsTxtRecord = objectMapper.createObjectNode();
    		Object[] lArrayRevenueData  = (Object[]) lAdsTxtRecords.get(i);
    		lJsonNodeAdsTxtRecord.put("id",lArrayRevenueData[0].toString());
    		lJsonNodeAdsTxtRecord.put("id_advertiser",lArrayRevenueData[1].toString()); 
    		lJsonNodeAdsTxtRecord.put("exchange_domain_name",lArrayRevenueData[2].toString());
    		lJsonNodeAdsTxtRecord.put("account_id",lArrayRevenueData[3].toString());
    		lJsonNodeAdsTxtRecord.put("account_type",lArrayRevenueData[4].toString()); 
    		if(lArrayRevenueData[5]!=null) {
    		lJsonNodeAdsTxtRecord.put("certification_auth_id",lArrayRevenueData[5].toString());
    		}
    		arrayNode.add(lJsonNodeAdsTxtRecord);
    	}

		return arrayNode;
	}
	
	public ArrayNode getAdsTxtRecordsForAdvertiser(Integer id) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
    	Query lQueryGetWebsiteAdsTxtRecords = entityManager.createNativeQuery("select id,id_advertiser,exchange_domain_name,account_id,account_type,certification_auth_id from ams_advertiser_ads_txt where id_advertiser=?");
    	lQueryGetWebsiteAdsTxtRecords.setParameter(1, id);
    	List<?> lAdsTxtRecords = lQueryGetWebsiteAdsTxtRecords.getResultList();
    	for(int i=0 ; i < lAdsTxtRecords.size() ; i++) {

    		ObjectNode lJsonNodeAdsTxtRecord = objectMapper.createObjectNode();
    		Object[] lArrayRevenueData  = (Object[]) lAdsTxtRecords.get(i);
    		lJsonNodeAdsTxtRecord.put("id",lArrayRevenueData[0].toString());
    		lJsonNodeAdsTxtRecord.put("id_advertiser",lArrayRevenueData[1].toString()); 
    		lJsonNodeAdsTxtRecord.put("exchange_domain_name",lArrayRevenueData[2].toString());
    		lJsonNodeAdsTxtRecord.put("account_id",lArrayRevenueData[3].toString());
    		lJsonNodeAdsTxtRecord.put("account_type",lArrayRevenueData[4].toString());  
    		if(lArrayRevenueData[5]!=null) {
    		lJsonNodeAdsTxtRecord.put("certification_auth_id",lArrayRevenueData[5].toString());
    		}
    		arrayNode.add(lJsonNodeAdsTxtRecord);
    	}

		return arrayNode;
	}
    
	@Transactional
	public void insertAdsTxtRecordsForAdvertiser(JsonNode jsnNode) {

		int idWebsite = jsnNode.get("id_advertiser").asInt();
		System.out.println(idWebsite);
		LOGGER.debug("inserting ads.txt records from website :" + idWebsite);
		String adsTxtRecords = jsnNode.get("ads_txt_records").asText();
		System.out.println("adsTxtRecords");
		String [] rows = adsTxtRecords.split("\\r?\\n"); 
		for(String row : rows) {

			if(row.trim() != "" ) {
			
				int commentStartIndex = row.indexOf("#");
				String rowWithoutComment = row;
				if(commentStartIndex > 0 ) 
					rowWithoutComment = row.substring(0, commentStartIndex);
				LOGGER.debug("inserting ads.txt records from website :" + idWebsite + " record : " + rowWithoutComment);
				String[] splitRecord = rowWithoutComment.split(",");
				System.out.println(splitRecord);
				if(splitRecord.length > 1) {
					try {
					Query lQueryGetWebsiteAdsTxtRecords=null;
					if(splitRecord.length >3) {
					 lQueryGetWebsiteAdsTxtRecords = entityManager.createNativeQuery("insert into ams_advertiser_ads_txt(id_advertiser,exchange_domain_name,account_id,account_type,certification_auth_id) values (?,?,?,?,?)");
					lQueryGetWebsiteAdsTxtRecords.setParameter(1,idWebsite);
					if(splitRecord[0] != null) lQueryGetWebsiteAdsTxtRecords.setParameter(2,splitRecord[0]); else lQueryGetWebsiteAdsTxtRecords.setParameter(2,"");
					if(splitRecord[1] != null) lQueryGetWebsiteAdsTxtRecords.setParameter(3,splitRecord[1]); else lQueryGetWebsiteAdsTxtRecords.setParameter(3,"");
					if(splitRecord[2] != null) lQueryGetWebsiteAdsTxtRecords.setParameter(4,splitRecord[2]); else lQueryGetWebsiteAdsTxtRecords.setParameter(4,"");
					if(splitRecord[3] != null) lQueryGetWebsiteAdsTxtRecords.setParameter(5,splitRecord[3]); else lQueryGetWebsiteAdsTxtRecords.setParameter(5,"");
					}
					else {
						 lQueryGetWebsiteAdsTxtRecords = entityManager.createNativeQuery("insert into ams_advertiser_ads_txt(id_advertiser,exchange_domain_name,account_id,account_type,certification_auth_id) values (?,?,?,?,?)");
							lQueryGetWebsiteAdsTxtRecords.setParameter(1,idWebsite);
							if(splitRecord[0] != null) lQueryGetWebsiteAdsTxtRecords.setParameter(2,splitRecord[0]); else lQueryGetWebsiteAdsTxtRecords.setParameter(2,"");
							if(splitRecord[1] != null) lQueryGetWebsiteAdsTxtRecords.setParameter(3,splitRecord[1]); else lQueryGetWebsiteAdsTxtRecords.setParameter(3,"");
							if(splitRecord[2] != null) lQueryGetWebsiteAdsTxtRecords.setParameter(4,splitRecord[2]); else lQueryGetWebsiteAdsTxtRecords.setParameter(4,"");
						 lQueryGetWebsiteAdsTxtRecords.setParameter(5,"");
					}
					int iRecordCount = lQueryGetWebsiteAdsTxtRecords.executeUpdate();
				
					}catch(Exception e) {
						LOGGER.debug("Duplicate ads.txt e");
					}
									
				}
			}
		}
				
	}
	


	public ArrayNode getAll() {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
    	Query lQueryGetWebsiteAdsTxtRecords = entityManager.createNativeQuery("select id,id_advertiser,exchange_domain_name,account_id,account_type,certification_auth_id from ams_website_adstxt_mapping_view ");
    
    	List<?> lAdsTxtRecords = lQueryGetWebsiteAdsTxtRecords.getResultList();
    	for(int i=0 ; i < lAdsTxtRecords.size() ; i++) {
    	
    		ObjectNode lJsonNodeAdsTxtRecord = objectMapper.createObjectNode();
    		Object[] lArrayRevenueData  = (Object[]) lAdsTxtRecords.get(i);
    		
    		lJsonNodeAdsTxtRecord.put("id",lArrayRevenueData[0].toString());
    		lJsonNodeAdsTxtRecord.put("id_advertiser",lArrayRevenueData[1].toString()); 
    		lJsonNodeAdsTxtRecord.put("exchange_domain_name",lArrayRevenueData[2].toString());
    		lJsonNodeAdsTxtRecord.put("account_id",lArrayRevenueData[3].toString());
    		lJsonNodeAdsTxtRecord.put("account_type",lArrayRevenueData[4].toString());    
    		if(lArrayRevenueData[5]!=null) {
    		lJsonNodeAdsTxtRecord.put("certification_auth_id",lArrayRevenueData[5].toString());}
    		arrayNode.add(lJsonNodeAdsTxtRecord);
    	}
       		return arrayNode;
	}
	
	public ArrayNode getAllForAdvertiser() {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
    	Query lQueryGetWebsiteAdsTxtRecords = entityManager.createNativeQuery("select id,id_advertiser,exchange_domain_name,account_id,account_type,certification_auth_id from ams_advertiser_ads_txt ");
    
    	List<?> lAdsTxtRecords = lQueryGetWebsiteAdsTxtRecords.getResultList();
    	for(int i=0 ; i < lAdsTxtRecords.size() ; i++) {
    	
    		ObjectNode lJsonNodeAdsTxtRecord = objectMapper.createObjectNode();
    		Object[] lArrayRevenueData  = (Object[]) lAdsTxtRecords.get(i);
    		
    		lJsonNodeAdsTxtRecord.put("id",lArrayRevenueData[0].toString());
    		lJsonNodeAdsTxtRecord.put("id_advertiser",lArrayRevenueData[1].toString()); 
    		lJsonNodeAdsTxtRecord.put("exchange_domain_name",lArrayRevenueData[2].toString());
    		lJsonNodeAdsTxtRecord.put("account_id",lArrayRevenueData[3].toString());
    		lJsonNodeAdsTxtRecord.put("account_type",lArrayRevenueData[4].toString());  
    		if(lArrayRevenueData[5]!=null) {
    		lJsonNodeAdsTxtRecord.put("certification_auth_id",lArrayRevenueData[5].toString());}
    		arrayNode.add(lJsonNodeAdsTxtRecord);
    		
    	}
       		return arrayNode;
	}

	public ArrayNode notMatchedAdsTxtRecords(Integer id,String idstatus) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
    	Query lQueryGetWebsiteAdsTxtRecords = entityManager.createNativeQuery("select id,id_advertiser,exchange_domain_name,account_id,account_type,certification_auth_id from ams_advertiser_not_found_ads_txt"
    			+ " where id_website = ? and idStatus=?");
    	lQueryGetWebsiteAdsTxtRecords.setParameter(1, id);
    	lQueryGetWebsiteAdsTxtRecords.setParameter(2, idstatus);
    	List<?> lAdsTxtRecords = lQueryGetWebsiteAdsTxtRecords.getResultList();
    	for(int i=0 ; i < lAdsTxtRecords.size() ; i++) {
    	
    		ObjectNode lJsonNodeAdsTxtRecord = objectMapper.createObjectNode();
    		Object[] lArrayRevenueData  = (Object[]) lAdsTxtRecords.get(i);
    		
    		lJsonNodeAdsTxtRecord.put("id",lArrayRevenueData[0].toString());
    		lJsonNodeAdsTxtRecord.put("id_advertiser",lArrayRevenueData[1].toString()); 
    		lJsonNodeAdsTxtRecord.put("exchange_domain_name",lArrayRevenueData[2].toString());
    		lJsonNodeAdsTxtRecord.put("account_id",lArrayRevenueData[3].toString());
    		lJsonNodeAdsTxtRecord.put("account_type",lArrayRevenueData[4].toString());    
    		if(lArrayRevenueData[5]!=null) {
    		lJsonNodeAdsTxtRecord.put("certification_auth_id",lArrayRevenueData[5].toString());}
    		arrayNode.add(lJsonNodeAdsTxtRecord);
    	}
       		return arrayNode;
		
	}
}
