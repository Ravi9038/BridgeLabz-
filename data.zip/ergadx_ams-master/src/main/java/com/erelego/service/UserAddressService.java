package com.erelego.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erelego.exception.RecordNotFoundException;
import com.erelego.model.Status;
import com.erelego.model.UserAddress;
import com.erelego.repository.UserAddressRepository;

/**
 * 
 * @author Vikas M Gowda
 *
 */

@Service
public class UserAddressService {

	@Autowired
	private UserAddressRepository userAddreRepository;

	public List<UserAddress> getAllUserAddress() {

		try {
			//List<UserAddress> userAddress = userAddreRepository.findByStatus(Status.ACTIVE);
			List<UserAddress> userAddress = userAddreRepository.findAll();
			if (!userAddress.isEmpty() && userAddress.size() > 0) {
				return userAddress;
			} else
				return new ArrayList<UserAddress>();
		} catch (Exception e) {
			return new ArrayList<UserAddress>();
		}
	}

	public UserAddress getUserAddressById(int id) throws RecordNotFoundException {
		Optional<UserAddress> userAddress = userAddreRepository.findById(id);

		if (userAddress.isPresent() && userAddress != null)
			return userAddress.get();
		else
			throw new RecordNotFoundException("User Address not found for given id", id);

	}

	public UserAddress createOrUpdateUserAddress(UserAddress editUserAddress) {

		if (editUserAddress.getId() != 0) {

			Optional<UserAddress> existingUserAddress = userAddreRepository.findById(editUserAddress.getId());

			if (existingUserAddress.isPresent()) {
				UserAddress newUserAddress = existingUserAddress.get();
				newUserAddress.setAddress(editUserAddress.getAddress());
				newUserAddress.setCity(editUserAddress.getCity());
				newUserAddress.setContactEmailid(editUserAddress.getContactEmailid());
				newUserAddress.setContactPersonName(editUserAddress.getContactPersonName());
				newUserAddress.setContactPersonNumber(editUserAddress.getContactPersonNumber());
				newUserAddress.setCountry(editUserAddress.getCountry());
				newUserAddress.setPincode(editUserAddress.getPincode());
				newUserAddress.setState(editUserAddress.getState());
				newUserAddress.setType(editUserAddress.getType());
				newUserAddress.setIdUser(editUserAddress.getIdUser());
				//newUserAddress.setStatus(editUserAddress.getStatus());
				return userAddreRepository.save(newUserAddress);
			} else {
				return userAddreRepository.save(editUserAddress);
			}

		} else {
			return userAddreRepository.save(editUserAddress);
		}

	}

	public void deleteUserAddressById(int id) throws RecordNotFoundException {

		Optional<UserAddress> existingUserAddress = userAddreRepository.findById(id);

		if (existingUserAddress.isPresent()) {
			UserAddress newUserAddress = existingUserAddress.get();
			//newUserAddress.setStatus(Status.INACTIVE);
			//newUserAddress.setStatus(0);
			userAddreRepository.save(newUserAddress);
		} else {
			throw new RecordNotFoundException("Not able to find User for given id", id);
		}
	}

	public List<UserAddress> getUserAddressByUserId(int idUser) {
		try {
			List<UserAddress> usersAddress = userAddreRepository.findByIdUser(idUser);
			if (!usersAddress.isEmpty() && usersAddress.size() > 0)
				return usersAddress;
			else
				return new ArrayList<UserAddress>();
		} catch (Exception e) {
			return new ArrayList<UserAddress>();
		}
	}
}
