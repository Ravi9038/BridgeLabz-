package com.erelego.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.erelego.exception.RecordNotFoundException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * 
 * @author Vikas M Gowda
 *
 */

@Service
@Transactional
public class PublisherDataService {

	@PersistenceContext
	private EntityManager entityManager;

	public JsonNode getPublisherData(Long publisherId) throws RecordNotFoundException {
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDateTime now = LocalDateTime.now();

			Query todayData = entityManager
					.createNativeQuery("select sum(amount) as totalAmount from ams_website_advertiser_revenue\r\n"
							+ " where id_website in( select id from ams_user_websites where id_user = ?) and date = ?")
					.setParameter(1, publisherId).setParameter(2, dtf.format(now));

			LocalDateTime thenSevenDays = now.minusDays(7);

			LocalDateTime thenMonth = now.minusDays(30);

			Query lastSevenDaysData = entityManager
					.createNativeQuery("select sum(amount) as totalAmount from ams_website_advertiser_revenue\r\n"
							+ " where id_website in( select id from ams_user_websites where id_user = ?) and date between ? and ?")
					.setParameter(1, publisherId).setParameter(2, dtf.format(now))
					.setParameter(3, dtf.format(thenSevenDays));

			Query monthData = entityManager
					.createNativeQuery("select sum(amount) as totalAmount from ams_website_advertiser_revenue\r\n"
							+ " where id_website in( select id from ams_user_websites where id_user = ?) and date between ? and ?")
					.setParameter(1, publisherId).setParameter(2, dtf.format(thenMonth))
					.setParameter(3, dtf.format(now));

			ObjectMapper objectMapper = new ObjectMapper();
			ObjectNode parentNode = objectMapper.createObjectNode();
			double todaysRevenue = (double) (todayData.getResultList().get(0) != null ? todayData.getResultList().get(0)
					: 0.0);

			parentNode.put("todaysRevenue", todaysRevenue);

			double lastSevenDaysRevenue = (double) (lastSevenDaysData.getResultList().get(0) != null
					? lastSevenDaysData.getResultList().get(0)
					: 0.0);
			parentNode.put("lastSevenDaysRevenue", lastSevenDaysRevenue);
			double monthsRevenue = (double) (monthData.getResultList().get(0) != null ? monthData.getResultList().get(0)
					: 0.0);
			parentNode.put("monthsRevenue", monthsRevenue);

			return parentNode;
		} catch (Exception e) {
			throw new RecordNotFoundException(e.getMessage());
		}
	}

	public List<JsonNode> getRevenueByWebsiteForParticularDuration(String fromDate, String toDate)
			throws RecordNotFoundException {

		try {
			Query revenueData = entityManager.createNativeQuery(
					"select id_website, sum(amount) as totalAmount, currency, sum(impressions) as impressions, sum(cpm) as cpm from ams_website_advertiser_revenue where date between ? and ? group by id_website")
					.setParameter(1, fromDate).setParameter(2, toDate);

			List<?> data = revenueData.getResultList();

			if (!data.isEmpty() && data != null) {
				ObjectMapper objectMapper = new ObjectMapper();
				List<JsonNode> requiredData = new ArrayList<>();
				for (int i = 0; i < data.size(); i++) {
					Object[] individualData = (Object[]) data.get(i);
					ObjectNode parentNode = objectMapper.createObjectNode();
					parentNode.put("idWebsite", (int) individualData[0]);
					Query websiteName = entityManager
							.createNativeQuery("select name from ams_user_websites where id = ?")
							.setParameter(1, (int) individualData[0]);
					parentNode.put("websiteName", (String) websiteName.getResultList().get(0));

					parentNode.put("totalAmount", (double) individualData[1]);
					parentNode.put("currency", (String) individualData[2]);
					parentNode.put("impressions", (double) individualData[3]);
					parentNode.put("cpm", (double) individualData[4]);
					requiredData.add(parentNode);
				}
				return requiredData;
			} else {
				throw new RecordNotFoundException("Revenue data not found");
			}
		} catch (Exception e) {
			throw new RecordNotFoundException(e.getMessage());
		}
	}
}
