package com.erelego.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.erelego.util.Constants;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

@Service
public class ReportService {
	Logger LOGGER = LogManager.getLogger(ReportService.class);
    @PersistenceContext
    private EntityManager entityManager;
    
	public ResponseEntity<JsonNode> fetchReportData(JsonNode jsonNode) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

	public ResponseEntity<ByteArrayInputStream> downloadReportData(JsonNode jsonNode) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
