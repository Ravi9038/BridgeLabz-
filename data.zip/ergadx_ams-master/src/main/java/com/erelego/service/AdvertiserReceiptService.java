package com.erelego.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.erelego.model.AdvertiserReceipt;

import com.erelego.model.User;
import com.erelego.repository.AdvertiserReceiptRepository;
import com.erelego.util.DateUtil;


@Service
@Transactional
public class AdvertiserReceiptService {
	Logger LOGGER = LogManager.getLogger(InvoiceDetailsService.class);
	@Autowired
	private AdvertiserReceiptRepository repoistory;
	

	@Autowired
	private UserService userService;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public List<AdvertiserReceipt> listAll() {
		return repoistory.findAll();
	}

	public void save(AdvertiserReceipt invoicedetails) {
		repoistory.save(invoicedetails);
	}

	public AdvertiserReceipt get(Integer id) {
		return  repoistory.findById(id).get();
	}

	public List<AdvertiserReceipt> getInvoiceByAdveritser(Integer id) {
		return repoistory.findByUserId(id);
	}

	public void delete(Integer id) {
		repoistory.deleteById(id);
	}
	public List generateInvoicesForAdvertiser() {
		List<User> lAdvertiserList = userService.getAllAdvertiser();
		List<Double> lrevenue = new ArrayList<>();
		LOGGER.debug("Starting automation invoice process");
		// For each user
		for (User user : lAdvertiserList) {
			int lUserId = user.getId();

	
			Date startDateOfPreviousMonth = DateUtil.getStartDateForMonth();
			Date lastDateOfPreviousMonth = DateUtil.getEndDateForMonth();
			
			this.createReceiptForAdvertiser(startDateOfPreviousMonth,lastDateOfPreviousMonth,user,lUserId);


			
		}
		return lrevenue;
	}
	
	private void createReceiptForAdvertiser(Date pStartDate,Date pEndDate,User pUser,int idAdvertiser) {
		
		
		java.sql.Date lstartDate = new java.sql.Date(pStartDate.getTime());

		java.sql.Date lEndDate = new java.sql.Date(pEndDate.getTime());
       
		Double netAmount=null;
		Double tax=null;
		AdvertiserReceipt lAdvertiserReceipt = new AdvertiserReceipt();
		
        
		String lUserCompanyName = pUser.getCompanyName();
		String lCompanyGSTIn = pUser.getGstin();
		String lAddressLine1 = pUser.getAddressLineOne();
		String lAddressLine2 = pUser.getAddressLineTwo();
		String lPostOffice = pUser.getPostOffice();
		String lTaluku = pUser.getTaluk();
		String lDistrict = pUser.getDistrict();
		String lState = pUser.getState();
		BigDecimal lImpression =BigDecimal.ZERO;
	
			
			Double lamounts = null;
			javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(amount),sum(impressions) from ams_website_advertiser_revenue where id_advertiser= ?  AND date>= ? and date<= ?");
			lQueryGetWebsiteRevenueData.setParameter(1, idAdvertiser);
			lQueryGetWebsiteRevenueData.setParameter(2, lstartDate);
			lQueryGetWebsiteRevenueData.setParameter(3, lEndDate);
//			lResult = (Double) lQueryGetWebsiteRevenueData.getSingleResult();
			 List result = lQueryGetWebsiteRevenueData.getResultList();
			 String amount="";
			 String impression="";
			for(int i=0;i<result.size();i++) {
				Object[]  invoice =  (Object[]) result.get(i);
				if(invoice[0]!=null && invoice[1]!=null  ) {
				 amount = invoice[0].toString();
				 impression = invoice[1].toString();
				}
			}
			 if(amount!="") {
				lamounts=Double.parseDouble(amount);
			 }
			 if(impression!="") {
				 lImpression = new BigDecimal(impression);
			 }
			float lAmount = 0.0f;
		
			if (lamounts != null )
			lAmount = Float.parseFloat(lamounts.toString());
			netAmount= (lAmount/1.18);
			tax=lAmount-netAmount;
			
		

		lAdvertiserReceipt.setUserId(pUser.getId());
		lAdvertiserReceipt.setCompanyName(lUserCompanyName);
		lAdvertiserReceipt.setUserGstIn(lCompanyGSTIn);
		lAdvertiserReceipt.setStartDate(lstartDate);
		lAdvertiserReceipt.setEndDate(lEndDate);
		lAdvertiserReceipt.setUserAddressLine1(lAddressLine1);
		lAdvertiserReceipt.setUserAddressLine2(lAddressLine2);
		lAdvertiserReceipt.setUserPostOffice(lPostOffice);
		lAdvertiserReceipt.setUserDistrict(lDistrict);
		lAdvertiserReceipt.setUserTaluku(lTaluku);
		lAdvertiserReceipt.setCurrency("USD");
		lAdvertiserReceipt.setStatus("DRAFT");
		lAdvertiserReceipt.setImpression(lImpression);
		lAdvertiserReceipt.setUserState(lState);
		lAdvertiserReceipt.setAmount(lAmount);
 
		lAdvertiserReceipt.setNetAmount(netAmount);
		
	
		lAdvertiserReceipt.setTax(tax);
		lAdvertiserReceipt.setPayCycleId(1);
	
		Session session = this.entityManager.unwrap(Session.class);
		session.saveOrUpdate(lAdvertiserReceipt);
	}

	public void update(AdvertiserReceipt advertiserReceipt,Integer id) {
		AdvertiserReceipt existInvoicedetails = (AdvertiserReceipt) this.get(id);
		existInvoicedetails.setReceivedAmount(advertiserReceipt.getReceivedAmount());
		existInvoicedetails.setReceivedDate(advertiserReceipt.getReceivedDate());
		existInvoicedetails.setStatus(advertiserReceipt.getStatus());
		Session session = this.entityManager.unwrap(Session.class);
		session.saveOrUpdate(existInvoicedetails);
	
	}
}
