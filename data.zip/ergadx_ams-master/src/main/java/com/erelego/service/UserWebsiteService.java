
package com.erelego.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.model.AmsPublisherContact;
import com.erelego.model.BankDetails;
import com.erelego.model.InvoiceDetails;
import com.erelego.model.UserWebsite;
import com.erelego.repository.*;
import com.erelego.util.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jettison.json.JSONException;
import org.json.JSONObject;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.PropertyMapper.SourceOperator;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

@Transactional
@Service
public class UserWebsiteService {
	
	private static Logger logger = LogManager.getLogger(UserWebsiteService.class);

	@Autowired
	private UserWebsiteRepository repo;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;

	private String id;

	public List<UserWebsite> getAllWebsites() {
		return repo.findAll();
	}

	public Map<String, UserWebsite> getAllWebsiteMapWithURLAsId() {
		Map<String, UserWebsite> mapWebsite = new HashMap<String, UserWebsite>();
		List<UserWebsite> lstUserWebsite = this.getAllWebsites();
		for (UserWebsite lUserWebsite : lstUserWebsite) {
			mapWebsite.put(lUserWebsite.getHostURL(), lUserWebsite);
		}
		return mapWebsite;
	}

	public void save(UserWebsite userwebsite) {
		repo.save(userwebsite);
	}

	public UserWebsite get(Integer id) {
		return repo.findById(id).get();
	}

	public List<UserWebsite> getWebsiteByUserID(Integer id) {
		return repo.findByUserId(id);
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}

	public List<Integer> getMappedAdvertisersForWebsite(int idWebsite) {
		List<Integer> mappedAdvertisersIds = new ArrayList<Integer>();
		Query getMappedAdvertisersForWebsite = entityManager
				.createNativeQuery("select * from ams_website_advertiser_mapping where id_website = ?")
				.setParameter(1, idWebsite);
		List lMappedAdvertisers = getMappedAdvertisersForWebsite.getResultList();
		for (int i = 0; i < lMappedAdvertisers.size(); i++) {
			Object[] lMappedAdvertiser = (Object[]) lMappedAdvertisers.get(i);
			mappedAdvertisersIds.add(Integer.parseInt(lMappedAdvertiser[1].toString()));
		}

		return mappedAdvertisersIds;
	}

	public void insertWebsiteAdvertiserMapping(JsonNode jsonNode) throws JsonMappingException, JsonProcessingException {

		System.out.println("Vlaue of jsonNode : " + jsonNode);
		ArrayNode arrayNode = (ArrayNode) jsonNode.get("id_users");// (ArrayNode)
																	// mapper.readTree(jsonNodeStr).get("id_users");
		System.out.println("Vlaue of arrayNode : " + arrayNode);
		if (arrayNode.isArray()) {
			for (JsonNode jsonNode1 : arrayNode) {
				System.out.println("Id :" + jsonNode1 + "Web Site Id " + jsonNode.get("id_website"));
				entityManager.createNativeQuery(
						"INSERT INTO ams_website_advertiser_mapping (id_website,id_advertiser,status,created_date,created_by,modified_date,modified_by) VALUES (?,?,?,?,?,?,?)")
						.setParameter(1, jsonNode.get("id_website").asInt()).setParameter(2, jsonNode1.asInt())
						.setParameter(3, 1).setParameter(4, new Date()).setParameter(5, 1).setParameter(6, new Date())
						.setParameter(7, 1).executeUpdate();
			}
		}

	}

	public void insertAdvertiserRevenue(JsonNode jsonNode) {

		for (JsonNode jsonNodeObj : jsonNode) {
			entityManager.createNativeQuery(
					"INSERT INTO website_advertiser_revenue (id_website,id_advertiser,date,amount,currency,impressions,cpm) VALUES (?,?,?,?,?,?,?)")
					.setParameter(1, jsonNodeObj.get("id_website").asInt())
					.setParameter(2, jsonNodeObj.get("id_user").asInt())
					.setParameter(3, jsonNodeObj.get("date").asText())
					.setParameter(4, jsonNodeObj.get("amount").asDouble())
					.setParameter(5, jsonNodeObj.get("currency").asText())
					.setParameter(6, jsonNodeObj.get("impressions").asInt())
					.setParameter(7, jsonNodeObj.get("cpm").asDouble()).executeUpdate();
		}

	}

	public void excelToDB() {
		String excelFilePath = "C:\\Users\\anupama\\Desktop\\New folder\\Data.xlsx";
		int batchSize = 20;
		Double id = 0.0;
		String name = "";
		try {
			long start = System.currentTimeMillis();
			FileInputStream inputStream = new FileInputStream(excelFilePath);
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet firstSheet = workbook.getSheetAt(0);
			Iterator<Row> rowIterator = firstSheet.iterator();
			int count = 0;
			rowIterator.next(); // skip the header row
			while (rowIterator.hasNext()) {
				Row nextRow = rowIterator.next();
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();
					switch (columnIndex) {
					case 0:
						id = nextCell.getNumericCellValue();
						break;
					case 1:
						name = nextCell.getStringCellValue();
					}

				}

				entityManager.createNativeQuery("INSERT INTO demo_table(id,name) VALUES (?,?)").setParameter(1, id)
						.setParameter(2, name).executeUpdate();

			}

			workbook.close();

		} catch (IOException ex1) {
			System.out.println("Error reading file");
			ex1.printStackTrace();
		}

	}

	public ArrayNode getWebsiteRevenueData(JsonNode jsonNode) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode lRevenueData = objectMapper.createArrayNode();
		String strWebSiteIds = jsonNode.get("website_ids").asText();
		String[] arrWebsiteIds = strWebSiteIds.split(",");
		List<String> lstWebsiteIds = new ArrayList<String>();
		for (String s : arrWebsiteIds) {
			lstWebsiteIds.add(s);
		}
		String strAdvertiserIds = jsonNode.get("advertiser_ids").asText();
		String[] arrAdvertiserIds = strAdvertiserIds.split(",");
		List<String> lstAdvertiserIds = new ArrayList<String>();
		for (String s : arrAdvertiserIds) {
			lstAdvertiserIds.add(s);
		}

		String strGroupBy = jsonNode.get("groupBy").asText();
		String[] arrGroupBy = strGroupBy.split(",");

		List<String> lGroupBy = new ArrayList<String>();
		for (String s : arrGroupBy) {
			lGroupBy.add(s);
		}

		String SELECT_HOST_URL = " a.host_url";
		String SELECT_DATE = " DATE_FORMAT(b.date \"%d-%m-%Y\")";
		String SELECT_ADVERTISER = " c.company_name";

		String SELECT_CLAUSE = "";

		Boolean order = false;
		if (strGroupBy.contains("id_advertiser")) {// advertiser_name
			SELECT_CLAUSE = SELECT_CLAUSE + SELECT_ADVERTISER;

		}

		if (strGroupBy.contains("host_url")) {// website_url
			SELECT_CLAUSE = SELECT_CLAUSE + SELECT_HOST_URL;

		}

		if (strGroupBy.contains("Date")) {// website_url
			SELECT_CLAUSE = SELECT_CLAUSE + SELECT_DATE;
			order = true;
		}

		System.out.println(SELECT_CLAUSE);
		String AddingComma = SELECT_CLAUSE.replaceAll("\\s+", ",");
		System.out.println(AddingComma);
		String selectionClause = AddingComma.replaceAll(",$", "");
		System.out.println(selectionClause);

		String startDate = jsonNode.get("start_date").asText();
		String endDate = jsonNode.get("end_date").asText();
		String query = "";
		if (order && !strWebSiteIds.equalsIgnoreCase("") && !strAdvertiserIds.equalsIgnoreCase("")) {
			query = " select sum(b.amount), sum(b.pub_amount),sum(b.erg_amount),sum(b.impressions),avg(b.cpm) as ecpm "
					+ selectionClause
					+ " from  ams_user_websites a INNER JOIN  ams_website_advertiser_revenue b ON  a.id=b.id_website INNER JOIN  ams_users c ON b.id_advertiser =c.id where a.id in (:website_ids) and c.id in(:advetiser_ids) and b.date >= :start_date AND b.date <= :end_date "
					+ " group by " + strGroupBy + " order by date ";
		} else if (order && strWebSiteIds.equalsIgnoreCase("") && strAdvertiserIds.equalsIgnoreCase("")) {
			query = " select sum(b.amount), sum(b.pub_amount),sum(b.erg_amount),sum(b.impressions),avg(b.cpm) as ecpm "
					+ selectionClause
					+ " from  ams_user_websites a INNER JOIN  ams_website_advertiser_revenue b ON  a.id=b.id_website INNER JOIN  ams_users c ON b.id_advertiser =c.id where  b.date >= :start_date AND b.date <= :end_date "
					+ " group by " + strGroupBy + " order by date ";
		} else if (order && strWebSiteIds.equalsIgnoreCase("") && !strAdvertiserIds.equalsIgnoreCase("")) {
			query = " select sum(b.amount), sum(b.pub_amount),sum(b.erg_amount),sum(b.impressions),avg(b.cpm) as ecpm "
					+ selectionClause
					+ " from  ams_user_websites a INNER JOIN  ams_website_advertiser_revenue b ON  a.id=b.id_website INNER JOIN  ams_users c ON b.id_advertiser =c.id where  c.id in(:advetiser_ids) and b.date >= :start_date AND b.date <= :end_date "
					+ " group by " + strGroupBy + " order by date ";
		} else if (order && !strWebSiteIds.equalsIgnoreCase("") && strAdvertiserIds.equalsIgnoreCase("")) {
			query = " select sum(b.amount), sum(b.pub_amount),sum(b.erg_amount),sum(b.impressions),avg(b.cpm) as ecpm "
					+ selectionClause
					+ " from  ams_user_websites a INNER JOIN  ams_website_advertiser_revenue b ON  a.id=b.id_website INNER JOIN  ams_users c ON b.id_advertiser =c.id where a.id in (:website_ids)  and b.date >= :start_date AND b.date <= :end_date "
					+ " group by " + strGroupBy + " order by date ";
		}

		if (!order && !strWebSiteIds.equalsIgnoreCase("") && !strAdvertiserIds.equalsIgnoreCase("")) {
			query = " select sum(b.amount), sum(b.pub_amount),sum(b.erg_amount),sum(b.impressions),avg(b.cpm) as ecpm "
					+ selectionClause
					+ " from  ams_user_websites a INNER JOIN  ams_website_advertiser_revenue b ON  a.id=b.id_website INNER JOIN  ams_users c ON b.id_advertiser =c.id where a.id in (:website_ids) and c.id in(:advetiser_ids) and b.date >= :start_date AND b.date <= :end_date "
					+ " group by " + strGroupBy;
		} else if (!order && strWebSiteIds.equalsIgnoreCase("") && strAdvertiserIds.equalsIgnoreCase("")) {
			query = " select sum(b.amount), sum(b.pub_amount),sum(b.erg_amount),sum(b.impressions),avg(b.cpm) as ecpm "
					+ selectionClause
					+ " from  ams_user_websites a INNER JOIN  ams_website_advertiser_revenue b ON  a.id=b.id_website INNER JOIN  ams_users c ON b.id_advertiser =c.id where  b.date >= :start_date AND b.date <= :end_date "
					+ " group by " + strGroupBy;
		} else if (!order && strWebSiteIds.equalsIgnoreCase("") && !strAdvertiserIds.equalsIgnoreCase("")) {
			query = " select sum(b.amount), sum(b.pub_amount),sum(b.erg_amount),sum(b.impressions),avg(b.cpm) as ecpm "
					+ selectionClause
					+ " from  ams_user_websites a INNER JOIN  ams_website_advertiser_revenue b ON  a.id=b.id_website INNER JOIN  ams_users c ON b.id_advertiser =c.id where  c.id in(:advetiser_ids) and b.date >= :start_date AND b.date <= :end_date "
					+ " group by " + strGroupBy;
		} else if (!order && !strWebSiteIds.equalsIgnoreCase("") && strAdvertiserIds.equalsIgnoreCase("")) {
			query = " select sum(b.amount), sum(b.pub_amount),sum(b.erg_amount),sum(b.impressions),avg(b.cpm) as ecpm "
					+ selectionClause
					+ " from  ams_user_websites a INNER JOIN  ams_website_advertiser_revenue b ON  a.id=b.id_website INNER JOIN  ams_users c ON b.id_advertiser =c.id where a.id in (:website_ids)  and b.date >= :start_date AND b.date <= :end_date "
					+ " group by " + strGroupBy;
		}

		Query lQueryWebsiteRevenue = entityManager.createNativeQuery(query);
		if (!strWebSiteIds.equalsIgnoreCase("")) {
			lQueryWebsiteRevenue.setParameter("website_ids", lstWebsiteIds);
		}
		if (!strAdvertiserIds.equalsIgnoreCase("")) {
			lQueryWebsiteRevenue.setParameter("advetiser_ids", lstAdvertiserIds);
		}
		lQueryWebsiteRevenue.setParameter("start_date", startDate);
		lQueryWebsiteRevenue.setParameter("end_date", endDate);
		List lListWebsiteRevenue = lQueryWebsiteRevenue.getResultList();
		for (int i = 0; i < lListWebsiteRevenue.size(); i++) {
			ArrayNode lJsonNodeAdsTxtRecord = objectMapper.createArrayNode();
			ObjectNode lobjectNode = objectMapper.createObjectNode();
			Object[] lArrayRevenueData = (Object[]) lListWebsiteRevenue.get(i);
			for (int j = 0; j < lArrayRevenueData.length; j++) {
//   		lJsonNodeAdsTxtRecord.add(lArrayRevenueData[i].toString());
				lobjectNode.put("revenue", lArrayRevenueData[0].toString());
				if (lArrayRevenueData[1] != null) {
					lobjectNode.put("pubRevenue", lArrayRevenueData[1].toString());
				}
				if (lArrayRevenueData[2] != null) {
					lobjectNode.put("ergRevenue", lArrayRevenueData[2].toString());
				}
				lobjectNode.put("Impressions", lArrayRevenueData[3].toString());
				if (lArrayRevenueData[4] != null) {
					lobjectNode.put("ecpm", lArrayRevenueData[4].toString());
				}
				if (arrGroupBy.length == 1) {
					if (selectionClause.equalsIgnoreCase(",a.host_url")) {
						lobjectNode.put("website", lArrayRevenueData[5].toString());
					} else if (selectionClause.equalsIgnoreCase(",DATE_FORMAT(b.date,\"%d-%m-%Y\")")) {
						lobjectNode.put("Date", lArrayRevenueData[5].toString());
					} else if (selectionClause.equalsIgnoreCase(",c.company_name")) {
						lobjectNode.put("id_advertiser", lArrayRevenueData[5].toString());
					}
				} else if (arrGroupBy.length == 2) {
					if (selectionClause.equalsIgnoreCase(",a.host_url,DATE_FORMAT(b.date,\"%d-%m-%Y\")")) {
						lobjectNode.put("website", lArrayRevenueData[5].toString());
						lobjectNode.put("Date", lArrayRevenueData[6].toString());

					}

					else if (selectionClause.equalsIgnoreCase(",c.company_name,DATE_FORMAT(b.date,\"%d-%m-%Y\")")) {
						lobjectNode.put("id_advertiser", lArrayRevenueData[5].toString());
						lobjectNode.put("Date", lArrayRevenueData[6].toString());

					} else if (selectionClause.equalsIgnoreCase(",c.company_name,a.host_url")) {
						lobjectNode.put("id_advertiser", lArrayRevenueData[5].toString());
						lobjectNode.put("website", lArrayRevenueData[6].toString());

					}
				} else {
					lobjectNode.put("website", lArrayRevenueData[6].toString());
					lobjectNode.put("Date", lArrayRevenueData[7].toString());
					lobjectNode.put("id_advertiser", lArrayRevenueData[5].toString());

				}
			}
			lRevenueData.add(lobjectNode);
//    		lRevenueData.add(lJsonNodeAdsTxtRecord);
		}
		return lRevenueData;
	}

	public ByteArrayInputStream generateExcelReport(JsonNode jsonNode) throws IOException {

		ArrayNode lArrRevenueData = getWebsiteRevenueData(jsonNode);
		String strGroupBy = jsonNode.get("groupBy").asText();
		List<String> lGroupBy = new ArrayList<String>();
		String[] arrGroupBy = strGroupBy.split(",");
		for (String s : arrGroupBy) {
			lGroupBy.add(s);
		}

		System.out.println(strGroupBy);
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet("Report");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.BLUE.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			// Row for Header
			Row headerRow = sheet.createRow(0);
			if (arrGroupBy.length == 3) {
				if (strGroupBy.equalsIgnoreCase("host_url,Date,id_advertiser")) {
					String[] COLUMNs = { "Website", "Advertiser", "Date", "Impressions", "CPM", "Pub Revenue",
							"Erg Revenue" };
					for (int col = 0; col < COLUMNs.length; col++) {
						Cell cell = headerRow.createCell(col);
						cell.setCellValue(COLUMNs[col]);
						cell.setCellStyle(headerCellStyle);
					}
					int rowIdx = 1;
					for (int i = 0; i < lArrRevenueData.size(); i++) {
						Row row = sheet.createRow(rowIdx++);
						JsonNode jsnNOde = lArrRevenueData.get(i);
						row.createCell(0).setCellValue(jsnNOde.get("website").asText());
						row.createCell(1).setCellValue(jsnNOde.get("id_advertiser").asText());
						row.createCell(2).setCellValue(jsnNOde.get("Date").asText());
						row.createCell(3).setCellValue(jsnNOde.get("Impressions").asText());
						row.createCell(4).setCellValue(jsnNOde.get("ecpm").asText());
						row.createCell(5).setCellValue(jsnNOde.get("pubRevenue").asText());
						row.createCell(6).setCellValue(jsnNOde.get("ergRevenue").asText());
					}
				}
			} else if (arrGroupBy.length == 2) {
				if (strGroupBy.equalsIgnoreCase("Date,id_advertiser")) {
					String[] COLUMNs = { "Advertiser", "Date", "Impressions", "CPM", "Pub Revenue", "Erg Revenue" };
					for (int col = 0; col < COLUMNs.length; col++) {
						Cell cell = headerRow.createCell(col);
						cell.setCellValue(COLUMNs[col]);
						cell.setCellStyle(headerCellStyle);
					}
					int rowIdx = 1;
					for (int i = 0; i < lArrRevenueData.size(); i++) {
						Row row = sheet.createRow(rowIdx++);
						JsonNode jsnNOde = lArrRevenueData.get(i);
						row.createCell(0).setCellValue(jsnNOde.get("id_advertiser").asText());
						row.createCell(1).setCellValue(jsnNOde.get("Date").asText());
						row.createCell(2).setCellValue(jsnNOde.get("Impressions").asText());
						row.createCell(3).setCellValue(jsnNOde.get("ecpm").asText());
						row.createCell(4).setCellValue(jsnNOde.get("pubRevenue").asText());
						row.createCell(5).setCellValue(jsnNOde.get("ergRevenue").asText());
					}
				} else if (strGroupBy.equalsIgnoreCase("host_url,Date")) {
					String[] COLUMNs = { "Websites", "Date", "Impressions", "CPM", "Pub Revenue", "Erg Revenue" };
					for (int col = 0; col < COLUMNs.length; col++) {
						Cell cell = headerRow.createCell(col);
						cell.setCellValue(COLUMNs[col]);
						cell.setCellStyle(headerCellStyle);
					}
					int rowIdx = 1;
					for (int i = 0; i < lArrRevenueData.size(); i++) {
						Row row = sheet.createRow(rowIdx++);
						JsonNode jsnNOde = lArrRevenueData.get(i);
						row.createCell(0).setCellValue(jsnNOde.get("website").asText());
						row.createCell(1).setCellValue(jsnNOde.get("Date").asText());
						row.createCell(2).setCellValue(jsnNOde.get("Impressions").asText());
						row.createCell(3).setCellValue(jsnNOde.get("ecpm").asText());
						row.createCell(4).setCellValue(jsnNOde.get("pubRevenue").asText());
						row.createCell(5).setCellValue(jsnNOde.get("ergRevenue").asText());
					}
				} else if (strGroupBy.equalsIgnoreCase("host_url,id_advertiser")) {
					String[] COLUMNs = { "Websites", "Advertiser", "Impressions", "CPM", "Pub Revenue", "Erg Revenue" };
					for (int col = 0; col < COLUMNs.length; col++) {
						Cell cell = headerRow.createCell(col);
						cell.setCellValue(COLUMNs[col]);
						cell.setCellStyle(headerCellStyle);
					}
					int rowIdx = 1;
					for (int i = 0; i < lArrRevenueData.size(); i++) {
						Row row = sheet.createRow(rowIdx++);
						JsonNode jsnNOde = lArrRevenueData.get(i);
						row.createCell(0).setCellValue(jsnNOde.get("website").asText());
						row.createCell(1).setCellValue(jsnNOde.get("id_advertiser").asText());
						row.createCell(2).setCellValue(jsnNOde.get("Impressions").asText());
						row.createCell(3).setCellValue(jsnNOde.get("ecpm").asText());
						row.createCell(4).setCellValue(jsnNOde.get("pubRevenue").asText());
						row.createCell(5).setCellValue(jsnNOde.get("ergRevenue").asText());
					}
				}
			} else {
				if (strGroupBy.equalsIgnoreCase("host_url")) {
					String[] COLUMNs = { "Websites", "Impressions", "CPM", "Pub Revenue", "Erg Revenue" };
					for (int col = 0; col < COLUMNs.length; col++) {
						Cell cell = headerRow.createCell(col);
						cell.setCellValue(COLUMNs[col]);
						cell.setCellStyle(headerCellStyle);
					}
					int rowIdx = 1;
					for (int i = 0; i < lArrRevenueData.size(); i++) {
						Row row = sheet.createRow(rowIdx++);
						JsonNode jsnNOde = lArrRevenueData.get(i);
						row.createCell(0).setCellValue(jsnNOde.get("website").asText());
						row.createCell(1).setCellValue(jsnNOde.get("Impressions").asText());
						row.createCell(2).setCellValue(jsnNOde.get("ecpm").asText());
						row.createCell(3).setCellValue(jsnNOde.get("pubRevenue").asText());
						row.createCell(4).setCellValue(jsnNOde.get("ergRevenue").asText());
					}
				} else if (strGroupBy.equalsIgnoreCase("id_advertiser")) {
					String[] COLUMNs = { "Advertiser", "Impressions", "CPM", "Pub Revenue", "Erg Revenue" };
					for (int col = 0; col < COLUMNs.length; col++) {
						Cell cell = headerRow.createCell(col);
						cell.setCellValue(COLUMNs[col]);
						cell.setCellStyle(headerCellStyle);
					}
					int rowIdx = 1;
					for (int i = 0; i < lArrRevenueData.size(); i++) {
						Row row = sheet.createRow(rowIdx++);
						JsonNode jsnNOde = lArrRevenueData.get(i);
						row.createCell(0).setCellValue(jsnNOde.get("id_advertiser").asText());
						row.createCell(1).setCellValue(jsnNOde.get("Impressions").asText());
						row.createCell(2).setCellValue(jsnNOde.get("ecpm").asText());
						row.createCell(3).setCellValue(jsnNOde.get("pubRevenue").asText());
						row.createCell(4).setCellValue(jsnNOde.get("ergRevenue").asText());
					}
				} else if (strGroupBy.equalsIgnoreCase("Date")) {
					String[] COLUMNs = { "Date", "Impressions", "CPM", "Pub Revenue", "Erg Revenue" };
					for (int col = 0; col < COLUMNs.length; col++) {
						Cell cell = headerRow.createCell(col);
						cell.setCellValue(COLUMNs[col]);
						cell.setCellStyle(headerCellStyle);
					}
					int rowIdx = 1;
					for (int i = 0; i < lArrRevenueData.size(); i++) {
						Row row = sheet.createRow(rowIdx++);
						JsonNode jsnNOde = lArrRevenueData.get(i);
						row.createCell(0).setCellValue(jsnNOde.get("Date").asText());
						row.createCell(1).setCellValue(jsnNOde.get("Impressions").asText());
						row.createCell(2).setCellValue(jsnNOde.get("ecpm").asText());
						row.createCell(3).setCellValue(jsnNOde.get("pubRevenue").asText());
						row.createCell(4).setCellValue(jsnNOde.get("ergRevenue").asText());
					}
				}
			}
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());

		}
	}

	public ArrayNode setWebsiteRevenueData(JsonNode jsonNode) {
		System.out.println(jsonNode);
		String idWebsite = "id_website";
		String idAdvertiser = "id_advertiser";
		String pubShare = "pub_share";
		String ergShare = "erg_share";
		ArrayNode arrayNode = (ArrayNode) jsonNode;
		for (JsonNode jsonNodeObj : arrayNode) {
			System.out.println(jsonNodeObj.get(pubShare).asDouble());
			System.out.println(jsonNodeObj.get(ergShare).asDouble());
			System.out.println(jsonNodeObj.get(idWebsite).asInt());
			System.out.println(jsonNodeObj.get(idAdvertiser).asInt());
			Query query = entityManager.createNativeQuery(
					"update ams_website_advertiser_revenue_share Set pub_share= ? , erg_share=? where id_website =? and id_advertiser=?");
			query.setParameter(1, jsonNodeObj.get(pubShare).asDouble());
			query.setParameter(2, jsonNodeObj.get(ergShare).asDouble());
			query.setParameter(3, jsonNodeObj.get(idWebsite).asInt());
			query.setParameter(4, jsonNodeObj.get(idAdvertiser).asInt());
			query.executeUpdate();

		}
		websiteRevenueShareService.reloadWebsiteRevShareData();
		return arrayNode;
	}

	public ResponseEntity<?> updateForId(JsonNode jsonNode) {

		for (JsonNode lwebsiteDetails : jsonNode) {
			System.out.println(lwebsiteDetails);
			Integer websiteid = lwebsiteDetails.get("id").asInt();
			System.out.println(websiteid);
			Optional<UserWebsite> existingBank = repo.findById(websiteid);
			UserWebsite lexistingBank = existingBank.get();
			System.out.println(lexistingBank);
			lexistingBank.setHostURL(lwebsiteDetails.get("hostURL").asText());
			lexistingBank.setBankId(lwebsiteDetails.get("bankId").asInt());
			repo.save(lexistingBank);
		}
		return null;
	}

	public void updateWebsiteForProfile(List<UserWebsite> userWebsite) {
		for (UserWebsite pWebsiteDetail : userWebsite) {
			if (pWebsiteDetail.getId() != null && pWebsiteDetail.getId() != 0) {

				// Optional<UserWebsite> existingWebsite =
				// this.findById(pWebsiteDetail.getId());
				// Optional<UserWebsite> existingWebsite =
				// this.findById(pWebsiteDetail.getId());
				// UserWebsite lexistingWebsite = existingWebsite.get();
				// lexistingWebsite.setName(pWebsiteDetail.getName());
				// lexistingWebsite.setHostURL(pWebsiteDetail.getHostURL());

				// lexistingContact.setContactNumberTwo(pContactDetail.getContactNumberTwo());
				// lexistingContact.setEmail(pContactDetail.getEmail());
				// lexistingContact.setIdReportingUserName(pContactDetail.
			} else {
				repo.save(pWebsiteDetail);
			}
		}
	}

	public void saveForList(List<UserWebsite> userWebsites) {
		repo.saveAll(userWebsites);
	}

	public ArrayNode getNumberOfWebsitesForUserId() {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		Query query = entityManager
				.createNativeQuery("SELECT id_user, count(id) " + " FROM ams_user_websites" + " GROUP BY id_user");
		List lresult = query.getResultList();
		for (int i = 0; i < lresult.size(); i++) {
			ObjectNode lobjectNode = objectMapper.createObjectNode();
			Object[] lArrayRevenueData = (Object[]) lresult.get(i);
			lobjectNode.putPOJO("id_user", lArrayRevenueData[0].toString());
			lobjectNode.putPOJO("NumberOfWebsite", lArrayRevenueData[1].toString());
			arrayNode.add(lobjectNode);
		}
		return arrayNode;
	}

	public ArrayNode addWebsiteRevenueData(JsonNode jsonNode) {
		System.out.println(jsonNode);
		String idWebsite = "id_website";
		String idAdvertiser = "id_advertiser";
		String pubShare = "pub_share";
		String ergShare = "erg_share";
		ArrayNode arrayNode = (ArrayNode) jsonNode;
		for (JsonNode jsonNodeObj : arrayNode) {
			System.out.println(jsonNodeObj);
			System.out.println(jsonNodeObj.get(pubShare).asDouble());
			System.out.println(jsonNodeObj.get(ergShare).asDouble());
			System.out.println(jsonNodeObj.get(idWebsite).asInt());
			System.out.println(jsonNodeObj.get(idAdvertiser).asInt());
			Query query = entityManager.createNativeQuery(
					"insert into ams_website_advertiser_revenue_share(id_website,id_advertiser,pub_share,erg_share,cut_share) "
							+ "values(?,?,?,?,?)");
			query.setParameter(1, jsonNodeObj.get(idWebsite).asInt());
			query.setParameter(2, jsonNodeObj.get(idAdvertiser).asInt());
			query.setParameter(3, jsonNodeObj.get(pubShare).asDouble());
			query.setParameter(4, jsonNodeObj.get(ergShare).asDouble());
			query.setParameter(5, 0.00);
			query.executeUpdate();

		}
		websiteRevenueShareService.reloadWebsiteRevShareData();
		return arrayNode;
	}

	public void purgeUrl(Integer id) throws Exception {
			
				final String cloudFlareEndPoint = "https://api.cloudflare.com/client/v4/zones/9c6a64660b96825020e7bf6f56fac671/purge_cache";
				final String apiKey = "7235667f8c419e32e6068a63809e3524e86c1";
		    String zoneID = "9c6a64660b96825020e7bf6f56fac671";
		    final String email = "hosting@erelego.com";

		    final String authHeaderValue = apiKey;

		    final HttpHeaders requestHeaders = new HttpHeaders();
		    requestHeaders.set("Authorization", authHeaderValue);
		    requestHeaders.set("X-Auth-Email", email);
		    requestHeaders.set("X-Auth-Key", apiKey);
		    requestHeaders.set("Content-Type","application/json");
		    requestHeaders.setContentType(MediaType.APPLICATION_JSON);
		    Map<String,String> requestHeaderMap = new HashMap<String,String>();
		    requestHeaderMap.put("Authorization", authHeaderValue);
		    requestHeaderMap.put("X-Auth-Email", email);
		    requestHeaderMap.put("X-Auth-Key", apiKey);
		    requestHeaderMap.put("Content-Type","application/json");

		    JSONArray urlList = new JSONArray();
		    urlList.put("http://cdn.ergadx.com/js/"+ id +"/ads.js");
		    urlList.put("https://cdn.ergadx.com/js/"+ id +"/ads.js");
		    JSONObject requestData = new JSONObject();
		    requestData.put("files", urlList);
		    
		    ObjectMapper mapper = new ObjectMapper();
		    ArrayNode arrayNode = mapper.createArrayNode();
		    ObjectNode lObjectNode = mapper.createObjectNode();

		    arrayNode.add("http://cdn.ergadx.com/js/"+ id +"/ads.js");
		    arrayNode.add("https://cdn.ergadx.com/js/"+ id +"/ads.js");
		    lObjectNode.put("files", arrayNode);

		    RestTemplate rest = new RestTemplate();
		    rest.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		    HttpEntity<ObjectNode> httpEntity = new HttpEntity<ObjectNode>(lObjectNode,requestHeaders);
		    Map<String, String> params = new HashMap<String, String>();
		    
		    ResponseEntity<String> response = rest.exchange(cloudFlareEndPoint,HttpMethod.DELETE,httpEntity,String.class,params);
		    logger.info(response);
		    
		    
	}

	public List<Integer> getWebsiteForIdRole(Integer idrole) {
		// TODO Auto-generated method stub

		Query getMappedAdvertisersForWebsite = entityManager
				.createNativeQuery("SELECT * FROM ams_user_websites inner join ams_users"
						+ "on ams_users.id=ams_user_websites.id_user" + "where ams_users.id_role=?")
				.setParameter(1, idrole);
		List lMappedAdvertisers = getMappedAdvertisersForWebsite.getResultList();

		return lMappedAdvertisers;

	}

	public ArrayNode setWebsiteRevenue(JsonNode jsonNode, Integer id) {
		System.out.println(jsonNode);
		Integer idWebsite = id;
		String idAdvertiser = "id_advertiser";
		String pubShare = "pub_share";
		String ergShare = "erg_share";
		ArrayNode arrayNode = (ArrayNode) jsonNode;
		for (JsonNode jsonNodeObj : arrayNode) {
			System.out.println(jsonNodeObj.get(pubShare).asDouble());
			System.out.println(jsonNodeObj.get(ergShare).asDouble());

			System.out.println(jsonNodeObj.get(idAdvertiser).asInt());
			Query query = entityManager.createNativeQuery(
					"update ams_website_advertiser_revenue_share Set pub_share= ? , erg_share=? where id_website =? and id_advertiser=?");
			query.setParameter(1, jsonNodeObj.get(pubShare).asDouble());
			query.setParameter(2, jsonNodeObj.get(ergShare).asDouble());
			query.setParameter(3, idWebsite);
			query.setParameter(4, jsonNodeObj.get(idAdvertiser).asInt());
			query.executeUpdate();

		}
		websiteRevenueShareService.reloadWebsiteRevShareData();
		return arrayNode;
	}
	

	


	
	public ResponseEntity<?> updateAccountforUserId(JsonNode userwebsite) {
		// TODO Auto-generated method stub
		
		for (JsonNode lwebsiteDetails : userwebsite) {
			logger.info(lwebsiteDetails);
			Integer websiteid = lwebsiteDetails.get("id").asInt();
			logger.info(websiteid);
			Optional<UserWebsite> existingBank = repo.findById(websiteid);
			UserWebsite lexistingBank = existingBank.get();
			logger.info(lexistingBank);
			lexistingBank.setHostURL(lwebsiteDetails.get("hostURL").asText());
			lexistingBank.setManagerId(lwebsiteDetails.get("managerId").asInt());
			repo.save(lexistingBank);

		}
		
		return null;
	}

	public ArrayNode ViewAdvertiserWebsiteMapping(Integer id2) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		Query query = entityManager.createNativeQuery(
				"select r.id_advertiser,r.pub_share,r.erg_share,website.host_url,user.company_name ,user.status from ams_website_advertiser_revenue_share r " + 
				" inner join ams_user_websites as website on r.id_website=website.id " + 
				" inner join ams_users as user on user.id=website.id_user where r.id_advertiser =? ");
		query.setParameter(1, id2);
		List resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
			Object[] lArrayRevenueData = (Object[]) resultList.get(i);
			lJsonNodeRevenueData.put("id_advertiser", lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.put("pub_share", lArrayRevenueData[1].toString());
			lJsonNodeRevenueData.put("erg_share", lArrayRevenueData[2].toString());
			
			lJsonNodeRevenueData.put("website_url", lArrayRevenueData[3].toString());
			
			lJsonNodeRevenueData.put("company_name", lArrayRevenueData[4].toString());
			if(lArrayRevenueData[5]!=null) {
			lJsonNodeRevenueData.put("status", lArrayRevenueData[5].toString());
			}
			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;
	}

}