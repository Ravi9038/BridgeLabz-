package com.erelego.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.text.ParseException;

import java.util.Date;

import com.erelego.util.DateUtil;
import org.apache.commons.math3.util.Precision;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

@Service
public class ExcelService {
	
	public static final double      NaN = 0d / 0d;
	public ByteArrayInputStream generateExcelReport(ArrayNode dataRows , String[] COLUMNs) throws IOException, ParseException {
		try(
		        Workbook workbook = new XSSFWorkbook();
		        ByteArrayOutputStream out = new ByteArrayOutputStream();
		    ){
		      Sheet sheet = workbook.createSheet("Report");
		      sheet.autoSizeColumn(1);
		      Font headerFont = workbook.createFont();
		      headerFont.setBold(true);
		      headerFont.setColor(IndexedColors.BLUE.getIndex());
		   
		      CellStyle headerCellStyle = workbook.createCellStyle();
		      headerCellStyle.setFont(headerFont);
		  
		
		      // Row for Header
		      Row headerRow = sheet.createRow(0);
	
		      // Header
		      for (int col = 0; col < COLUMNs.length; col++) {
		        Cell cell = headerRow.createCell(col);
		        cell.setCellValue(COLUMNs[col]);
		        cell.setCellStyle(headerCellStyle);
	
		      }
   
		      int rowIdx = 1;
		      assert  Double.isNaN(NaN);
		      
		      ArrayNode lArrRevenueData = dataRows;
		      for(int i=0;i<lArrRevenueData.size();i++) {
		    	  Row row = sheet.createRow(rowIdx++);
		    	  JsonNode jsnNOde = lArrRevenueData.get(i);
		    	  row.createCell(0).setCellValue(jsnNOde.get(3).asText());
		    	  String date = jsnNOde.get(4).asText();
		    	  Date ldate = DateUtil.getDateFromStringFormat("yyyy-MM-dd",date);
		    	  String DATE = DateUtil.getFormattedDate(ldate, "dd-MM-YYYY");
		    	  row.createCell(1).setCellValue(DATE);
		    	  row.createCell(2).setCellValue(jsnNOde.get(0).asDouble());
		    	  row.createCell(3).setCellValue(jsnNOde.get(1).asDouble());
		    	  double impressions = jsnNOde.get(1).asDouble();
		    	  double revnue=jsnNOde.get(0).asDouble();
		    	  double ecpm=(revnue/(impressions/1000));
	    	  double cpm = Precision.round(ecpm, 2);
		    	  if(Double.isNaN(cpm)) {
		    		  row.createCell(4).setCellValue(0); 
		    	  }
		    	  else {
		    	  row.createCell(4).setCellValue(cpm);
		    	  }
		      }
		      sheet.autoSizeColumn(1);
		      sheet.autoSizeColumn(0);
		      sheet.autoSizeColumn(2);
		      sheet.autoSizeColumn(3);
		      sheet.autoSizeColumn(4);
			   workbook.write(out);
			
		      return new ByteArrayInputStream(out.toByteArray());
		    }
	}
	
	public ByteArrayInputStream generateExcelMediaReport(ArrayNode dataRows , String[] COLUMNs) throws IOException, ParseException {
		try(
		        Workbook workbook = new XSSFWorkbook();
		        ByteArrayOutputStream out = new ByteArrayOutputStream();
		    ){
		      Sheet sheet = workbook.createSheet("Report");
		      sheet.autoSizeColumn(0);
		      Font headerFont = workbook.createFont();
		      headerFont.setBold(true);
		      headerFont.setColor(IndexedColors.BLUE.getIndex());
		   
		      CellStyle headerCellStyle = workbook.createCellStyle();
		      headerCellStyle.setFont(headerFont);
		     
		      // Row for Header
		      Row headerRow = sheet.createRow(0);
		      assert  Double.isNaN(NaN);
		      // Header
		      for (int col = 0; col < COLUMNs.length; col++) {
		        Cell cell = headerRow.createCell(col);
		        cell.setCellValue(COLUMNs[col]);
		        cell.setCellStyle(headerCellStyle);
		      }
   
		      int rowIdx = 1;
		      ArrayNode lArrRevenueData = dataRows;
		      for(int i=0;i<lArrRevenueData.size();i++) {
		    	  Row row = sheet.createRow(rowIdx++);
		    	  JsonNode jsnNOde = lArrRevenueData.get(i);
		    	  row.createCell(0).setCellValue(jsnNOde.get(3).asText());
		    	  String date = jsnNOde.get(4).asText();
		    	  Date ldate = DateUtil.getDateFromStringFormat("yyyy-MM-dd",date);
		    	  String DATE = DateUtil.getFormattedDate(ldate, "dd-MM-YYYY");
		    	  row.createCell(1).setCellValue(DATE);
		    	  row.createCell(2).setCellValue(jsnNOde.get(0).asText());
		    	  row.createCell(3).setCellValue(jsnNOde.get(1).asText());
		    	  double impressions = jsnNOde.get(1).asDouble();
		    	  double revnue=jsnNOde.get(0).asDouble();
		    	  double ecpm=(revnue/(impressions/1000));
		    	  double cpm = Precision.round(ecpm, 2);
		    	
		    	  if(Double.isNaN(cpm)) {
		    		  row.createCell(4).setCellValue(0); 
		    	  }
		    	  else {
		    	  row.createCell(4).setCellValue(cpm);
		    	  }
		    	 
		    	  row.createCell(5).setCellValue(jsnNOde.get(5).asText());
		      }
		      sheet.autoSizeColumn(1);
		      sheet.autoSizeColumn(0);
		      sheet.autoSizeColumn(2);
		      sheet.autoSizeColumn(3);
		      sheet.autoSizeColumn(4);
		      sheet.autoSizeColumn(5);
			   workbook.write(out);
		      return new ByteArrayInputStream(out.toByteArray());
		    }
	}
	public ByteArrayInputStream generateExcelReportDateWise(ArrayNode dataRows , String[] COLUMNs) throws IOException, ParseException {
		try(
		        Workbook workbook = new XSSFWorkbook();
		        ByteArrayOutputStream out = new ByteArrayOutputStream();
		    ){
		      Sheet sheet = workbook.createSheet("Report");
		     
		      Font headerFont = workbook.createFont();
		      headerFont.setBold(true);
		      headerFont.setColor(IndexedColors.BLUE.getIndex());
		   
		      CellStyle headerCellStyle = workbook.createCellStyle();
		      headerCellStyle.setFont(headerFont);
		 
		
		      // Row for Header
		      Row headerRow = sheet.createRow(0);
		      assert  Double.isNaN(NaN);
		      // Header
		      for (int col = 0; col < COLUMNs.length; col++) {
		        Cell cell = headerRow.createCell(col);
		        cell.setCellValue(COLUMNs[col]);
		        cell.setCellStyle(headerCellStyle);
		      }
   
		      int rowIdx = 1;
		      ArrayNode lArrRevenueData = dataRows;
		      for(int i=0;i<lArrRevenueData.size();i++) {
		    	  Row row = sheet.createRow(rowIdx++);
		    	  JsonNode jsnNOde = lArrRevenueData.get(i);
		
		    	  String date = jsnNOde.get(3).asText();
		    	  Date ldate = DateUtil.getDateFromStringFormat("yyyy-MM-dd",date);
		    	  String DATE = DateUtil.getFormattedDate(ldate, "dd-MM-YYYY");
		    	  row.createCell(0).setCellValue(DATE);
		    	  row.createCell(1).setCellValue(jsnNOde.get(0).asText());
		    	  row.createCell(2).setCellValue(jsnNOde.get(1).asText());
		    	  double impressions = jsnNOde.get(1).asDouble();
		    	  double revnue=jsnNOde.get(0).asDouble();
		    	  double ecpm=(revnue/(impressions/1000));
		    	  double cpm = Precision.round(ecpm, 2);

		    	  if(Double.isNaN(cpm)) {
		    		  row.createCell(3).setCellValue(0); 
		    	  }
		    	  else {
		    	  row.createCell(3).setCellValue(cpm);
		    	  }
		    	 
		    	  
		      }
		      sheet.autoSizeColumn(1);
		      sheet.autoSizeColumn(0);
		      sheet.autoSizeColumn(2);
		      sheet.autoSizeColumn(3);
		     
			   workbook.write(out);
		      return new ByteArrayInputStream(out.toByteArray());
		    }
	}
	
}
