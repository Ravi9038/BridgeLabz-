
package com.erelego.service;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
//import javax.transaction.Transactional;
import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;

import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.AmsAdvertiserRevenueStatus;
import com.erelego.model.BankDetails;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.repository.WebsiteAdvertiserRevenueShareRepository;
import com.erelego.revenueprocessor.AdvertiserRevenueFactory;
import com.erelego.revenueprocessor.DFPAdvertiserRevenueProcessor;
import com.erelego.util.Constants;
import com.erelego.util.DateUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.joda.time.Interval;
import org.joda.time.Period;
import org.apache.logging.log4j.LogManager;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service

public class RevenueProcessorService {

	private static Logger LOGGER = LogManager.getLogger(RevenueProcessorService.class);

	@Autowired
	RevenueProcessorConfigurationService revenueProcessorConfigurationService;

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;

	@Autowired
	UserWebsiteService userWebsiteService;

	@Autowired
	UserService userService;

	@Autowired
	AdvertiserRevenueFactory advertiserRevenueFactory;

	@Autowired
	WebsiteAdvertiserRevenueShareRepository revenueRepository;

	@Transactional(propagation = Propagation.REQUIRED)
	public void fetchRevenueForAdvertiser(RevenueProcessorConfiguration revenueProcessorConfiguration, Date pStartDate,
			Date pEndDate) throws Exception {
		IAdvertiserRevenueProcessor iAdvertiserRevenueProcessor = this
				.getRevenueProcessorForType(revenueProcessorConfiguration.getType());
		EntityManager entityManager = this.entityManagerFactory.createEntityManager();
		EntityTransaction lTransaction = entityManager.getTransaction();
		java.text.SimpleDateFormat ms_SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String start = ms_SDF.format(new Date());
		Date startDateTime = ms_SDF.parse(start);
		try {
			lTransaction.begin();
			// java.util.Date
			LOGGER.debug(
					"Starting revenue fetching for advertiser  id=" + revenueProcessorConfiguration.getIdAdvertiser()
							+ " type = " + revenueProcessorConfiguration.getType());
			iAdvertiserRevenueProcessor.loadConfigurationData(revenueProcessorConfiguration);
			iAdvertiserRevenueProcessor.doAuthentication();
			iAdvertiserRevenueProcessor.fetchData(pStartDate, pEndDate);
			iAdvertiserRevenueProcessor.processData();
			LOGGER.debug(
					"Finished revenue fetching for advertiser  id=" + revenueProcessorConfiguration.getIdAdvertiser()
							+ " type = " + revenueProcessorConfiguration.getType());
			int id = revenueProcessorConfiguration.getIdAdvertiser();
			String advertiserName = userService.getUserById(id).getCompanyName();
			String end = ms_SDF.format(new Date());
			System.out.println("Start:" + start + "\t Stop:" + end);
			System.out.println(advertiserName);
			String status = "success";
			String Message = "Finished revenue fetching";

			Date endDateTime = ms_SDF.parse(end);
			Interval interval = new org.joda.time.Interval(startDateTime.getTime(), endDateTime.getTime());
			int hour = interval.toPeriod().getHours();
			int min = interval.toPeriod().getMinutes();
			int sec = interval.toPeriod().getSeconds();
			int millisec = interval.toPeriod().getMillis();
			String duration = hour + ":" + min + ":" + ":" + sec + ":" + millisec;
			System.out.println(duration);

			Query query = entityManager.createNativeQuery(
					"insert into ams_advertiser_revenue_process_status (advertiser_name,start_date,end_date,execution_start_time,"
							+ "execution_end_time,duration,status,message) values(?,?,?,?,?,?,?,?)");
			query.setParameter(1, advertiserName);
			query.setParameter(2, pStartDate);
			query.setParameter(3, pEndDate);
			query.setParameter(4, startDateTime);
			query.setParameter(5, endDateTime);
			query.setParameter(6, duration);
			query.setParameter(7, status);
			query.setParameter(8, Message);
			query.executeUpdate();
			lTransaction.commit();

		} catch (Exception e) {

			int id = revenueProcessorConfiguration.getIdAdvertiser();
			String advertiserName = userService.getUserById(id).getCompanyName();
			String end = ms_SDF.format(new Date());
			System.out.println("Start:" + start + "\t Stop:" + end);
			System.out.println(advertiserName);
			String status = "failed";
			String Message = "";
			if(e.getMessage() != null)
				Message = e.getMessage().substring(0, 15);
			Date endDateTime = ms_SDF.parse(end);
			Interval interval = new org.joda.time.Interval(startDateTime.getTime(), endDateTime.getTime());
			int hour = interval.toPeriod().getHours();
			int min = interval.toPeriod().getMinutes();
			int sec = interval.toPeriod().getSeconds();
			int millisec = interval.toPeriod().getMillis();
			String duration = hour + ":" + min + ":" + ":" + sec + ":" + millisec;
			System.out.println(duration);
			Query query = entityManager.createNativeQuery(
					"insert into ams_advertiser_revenue_process_status (advertiser_name,start_date,end_date,execution_start_time,"
							+ "execution_end_time,duration,status,message) values(?,?,?,?,?,?,?,?)");
			query.setParameter(1, advertiserName);
			query.setParameter(2, pStartDate);
			query.setParameter(3, pEndDate);
			query.setParameter(4, startDateTime);
			query.setParameter(5, endDateTime);
			query.setParameter(6, duration);
			query.setParameter(7, status);
			query.setParameter(8, Message);
			query.executeUpdate();
			lTransaction.commit();
			LOGGER.error("Failed revenue fetching for advertiser  id=" + revenueProcessorConfiguration.getIdAdvertiser()
					+ " type = " + revenueProcessorConfiguration.getType() + e.getMessage());
			LOGGER.error(e);
		}
		entityManager.close();
	}

	public void fetchRevenueForAllAdvertisers(JsonNode pJsonNode) throws Exception {
		Date lStartDate = null;
		Date lEndDate = null;
		if (pJsonNode.has("duration")) {
			String lDuration = pJsonNode.get("duration").asText();
			if (lDuration.equalsIgnoreCase("Today")) {
				lStartDate = new Date();
				lEndDate = new Date();
			} else if (lDuration.equalsIgnoreCase("Yesterday")) {
				lStartDate = DateUtil.getDateFromToday(-1);
				lEndDate = DateUtil.getDateFromToday(-1);
			} else {
				lStartDate = DateUtil.getDateFromStringFormat("yyyy-MM-dd", pJsonNode.get("start_date").asText());
				lEndDate = DateUtil.getDateFromStringFormat("yyyy-MM-dd", pJsonNode.get("end_date").asText());
			}
			List<RevenueProcessorConfiguration> lstRevenueProcessorConfigs = revenueProcessorConfigurationService
					.listAll();
			for (RevenueProcessorConfiguration lRevenueProcessorConfiguration : lstRevenueProcessorConfigs) {
				this.fetchRevenueForAdvertiser(lRevenueProcessorConfiguration, lStartDate, lEndDate);
			}
		}

	}

	public void fetchRevenueForAdvertiser(int idAdvertiser, JsonNode pJsonNode) throws Exception {
		Date lStartDate = null;
		Date lEndDate = null;
		if (pJsonNode.has("duration")) {
			String lDuration = pJsonNode.get("duration").asText();
			if (lDuration.equalsIgnoreCase("Today")) {
				lStartDate = new Date();
				lEndDate = new Date();
			} else if (lDuration.equalsIgnoreCase("Yesterday")) {
				lStartDate = DateUtil.getDateFromToday(-1);
				lEndDate = DateUtil.getDateFromToday(-1);
			} else {
				lStartDate = DateUtil.getDateFromStringFormat("yyyy-MM-dd", pJsonNode.get("start_date").asText());
				lEndDate = DateUtil.getDateFromStringFormat("yyyy-MM-dd", pJsonNode.get("end_date").asText());
			}
			LOGGER.debug("Fetching revenue data for advertiser " + idAdvertiser + "duration : " + lDuration
					+ "  startDate : " + lStartDate.toString() + " endDate : " + lEndDate.toString());
			RevenueProcessorConfiguration lRevenueProcessorConfiguration = revenueProcessorConfigurationService
					.get(idAdvertiser);
			this.fetchRevenueForAdvertiser(lRevenueProcessorConfiguration, lStartDate, lEndDate);
		}
	}

	public IAdvertiserRevenueProcessor getRevenueProcessorForType(String type) {
		IAdvertiserRevenueProcessor iAdvertiserRevenueProcessor = null;
		if (type.equalsIgnoreCase("DFP")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getDFPAdvertiserRevenueProcessor();
		} else if (type.equalsIgnoreCase("Adsense")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getAdsenseRevenueProcessor();
		} else if (type.equalsIgnoreCase("Excel")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getExcelRevenueProcessor();
		} else if (type.equalsIgnoreCase("CSV")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getCSVRevenueProcessor();
		} else if (type.equalsIgnoreCase("MGID")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getMGIDRevenueProcessor();
		} else if (type.equalsIgnoreCase("AndBeyondMedia")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getAndBeyondRevenueProcessor();
		} else if (type.equalsIgnoreCase("CTN")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getCTNRevenueProcessor();
		} else if (type.equalsIgnoreCase("Adsolut")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getAdsolutRevenueProcessor();
		}else if (type.equalsIgnoreCase("AdapMX")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getAdaptMXRevenueProcessor();
		}else if (type.equalsIgnoreCase("CTNbackfill")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getCTNBackfillRevenueProcessor();
		} else if (type.equalsIgnoreCase("Aniview")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getAniviewCSVRevnueProcessor();
		} else if( type.equalsIgnoreCase("Rubicon")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getRubiconRevenueProcessor();
		} else if( type.equalsIgnoreCase("Openx")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getOpenxRevenueProcessor();
		} else if( type.equalsIgnoreCase("Verizon")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getVerizonRevenueProcessor();
		}else if( type.equalsIgnoreCase("Outbrain")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getOutbrainRevenueProcessor();
		}else if( type.equalsIgnoreCase("Unibots")) {
			iAdvertiserRevenueProcessor = advertiserRevenueFactory.getUnibotsRevenueProcessor();
		}
		
			
		return iAdvertiserRevenueProcessor;
	}

	public JsonNode fetchQueryData(JsonNode jsonNode) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode lOutputData = objectMapper.createArrayNode();
		String queryId = jsonNode.get("query_id").asText();
		ArrayNode lParamData = (ArrayNode) jsonNode.get("param_data");
		EntityManager entityManager = this.entityManagerFactory.createEntityManager();

		Query lGetQueryId = entityManager
				.createNativeQuery("select query_label,sql_query from ams_data_queries where query_label = ?");
		lGetQueryId.setParameter(1, queryId);
		List lQueryIdResultSet = lGetQueryId.getResultList();
		Object[] lDataQueryResultObject = (Object[]) lQueryIdResultSet.get(0);

		String lDataQuery = lDataQueryResultObject[1].toString();
		// Query lGetDataQuery = entityManager.createNativeQuery("select
		// b.amount,b.impressions,b.cpm,a.host_url,b.date from ams_user_websites a ,
		// ams_website_advertiser_revenue b where a.id=b.id_website and b.date >= ? AND
		// b.date <= ? order by date DESC");
		Query lGetDataQuery = entityManager.createNativeQuery(lDataQuery);
		for (int index = 0; index < lParamData.size(); index++) {
			JsonNode lParam = lParamData.get(index);
			String lDataType = lParam.get("type").asText();
			if (lDataType.equalsIgnoreCase("int"))
				lGetDataQuery.setParameter(index + 1, lParam.get("value").asInt());
			else if (lDataType.equalsIgnoreCase("string"))
				lGetDataQuery.setParameter(index + 1, lParam.get("value").asText());
		}
		List lGetDataQuerySet = lGetDataQuery.getResultList();
		for (int i = 0; i < lGetDataQuerySet.size(); i++) {
			// ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
			ArrayNode lJsonNodeRevenueData = objectMapper.createArrayNode();
			Object[] lArrayRevenueData = (Object[]) lGetDataQuerySet.get(i);
			for (int k = 0; k < lArrayRevenueData.length; k++) {
				lJsonNodeRevenueData.add(lArrayRevenueData[k].toString());
			}
			lOutputData.add(lJsonNodeRevenueData);
		}
		entityManager.close();
		return lOutputData;
	}

	public JsonNode getRevenueByuserId(Integer id) {
		ObjectMapper lObjectMapper = new ObjectMapper();
		ObjectNode lOutputNode = lObjectMapper.createObjectNode();
		EntityManager entityManager = this.entityManagerFactory.createEntityManager();

		javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
				"select revenue.pub_share,revenue.erg_share,revenue.id_advertiser,website.host_url,user1.company_name ,user.id as userid, website.id as websiteid from ams_website_advertiser_revenue_share  revenue INNER JOIN ams_user_websites website ON website.id=revenue.id_website INNER JOIN ams_users user ON user.id=website.id_user INNER JOIN ams_users user1 ON user1.id=revenue.id_advertiser where user.id = ?");
		lQueryGetWebsiteRevenueData.setParameter(1, id);
		List<Object[]> lWebsiteRevenueshareData = lQueryGetWebsiteRevenueData.getResultList();

		for (int i = 0; i < lWebsiteRevenueshareData.size(); i++) {
			Object[] lRevShareObject = lWebsiteRevenueshareData.get(i);
			String lWebsiteId = lRevShareObject[6].toString();
			if (lOutputNode.has(lWebsiteId)) {
				ArrayNode lArrayData = (ArrayNode) lOutputNode.get(lWebsiteId);
				ObjectNode lObjectData = lObjectMapper.createObjectNode();
				lObjectData.put("id_advertiser", lRevShareObject[2].toString());
				lObjectData.put("advertiser_name", lRevShareObject[4].toString());
				lObjectData.put("pub_share", lRevShareObject[0].toString());
				lObjectData.put("erg_share", lRevShareObject[1].toString());
				lObjectData.put("id_website", lRevShareObject[6].toString());
				lObjectData.put("website_name", lRevShareObject[3].toString());
				lArrayData.add(lObjectData);

				lOutputNode.put(lWebsiteId, lArrayData);
			} else {
				ArrayNode lArrayData = lObjectMapper.createArrayNode();
				ObjectNode lObjectData = lObjectMapper.createObjectNode();
				lObjectData.put("id_advertiser", lRevShareObject[2].toString());
				lObjectData.put("advertiser_name", lRevShareObject[4].toString());
				lObjectData.put("pub_share", lRevShareObject[0].toString());
				lObjectData.put("erg_share", lRevShareObject[1].toString());
				lObjectData.put("id_website", lRevShareObject[6].toString());
				lObjectData.put("website_name", lRevShareObject[3].toString());
				lOutputNode.put(lWebsiteId, lArrayData);
			}

		}

		return lOutputNode;

		/*
		 * List<WebsiteAdvertiserRevenueShare> lwebsiteRevenueshare =
		 * revenueRepository.findByWebsiteAdvertiserRevenueShareIdWebsiteId(id);
		 * List<WebsiteAdvertiserRevenueShare> lwebsiterevenueshareforWebId
		 * =this.getAdvertiserByWebsiteId(id); return lwebsiterevenueshareforWebId;
		 */

	}

	public JsonNode getAvgRevenueForWebId(Integer id) {
		ObjectMapper lObjectMapper = new ObjectMapper();
		ObjectNode lOutputNode = lObjectMapper.createObjectNode();
		EntityManager entityManager = this.entityManagerFactory.createEntityManager();

		javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
				"select round(avg(revenue.pub_share),2) as avg_pub_share,round(avg(revenue.erg_share),2) as avg_erg_share, "
						+ "users.id as userid, website.id as websiteid ,website.name as websitename "
						+ "from ams_website_advertiser_revenue_share  revenue "
						+ "INNER JOIN ams_user_websites website ON website.id=revenue.id_website INNER JOIN ams_users users ON "
						+ "users.id=website.id_user  where users.id = ? " + "group by  websiteid");
		lQueryGetWebsiteRevenueData.setParameter(1, id);
		List<Object[]> lWebsiteRevenueshareData = lQueryGetWebsiteRevenueData.getResultList();
		for (int i = 0; i < lWebsiteRevenueshareData.size(); i++) {
			Object[] lRevShareObject = lWebsiteRevenueshareData.get(i);
			String lWebsiteId = lRevShareObject[3].toString();
			if (lOutputNode.has(lWebsiteId)) {
				ArrayNode lArrayData = (ArrayNode) lOutputNode.get(lWebsiteId);
				ObjectNode lObjectData = lObjectMapper.createObjectNode();
				String ergShare = lRevShareObject[1].toString().substring(2);
				String pubShare = lRevShareObject[0].toString().substring(2);
				String revenueShare = pubShare + ":" + ergShare;
				lObjectData.put("id_advertiser", lRevShareObject[2].toString());
				lObjectData.put("id_website", lRevShareObject[3].toString());
				lObjectData.put("website_name", lRevShareObject[4].toString());
				lObjectData.put("revenue_share", revenueShare);
				lObjectData.put("pub_share", lRevShareObject[0].toString());
				lObjectData.put("erg_share", lRevShareObject[1].toString());

				lArrayData.add(lObjectData);
				lOutputNode.put(lWebsiteId, lArrayData);
				System.out.println(lArrayData);
			} else {
				ArrayNode lArrayData = lObjectMapper.createArrayNode();
				ObjectNode lObjectData = lObjectMapper.createObjectNode();
				lObjectData.put("id_advertiser", lRevShareObject[2].toString());
				String ergShare = lRevShareObject[1].toString().substring(2);
				String pubShare = lRevShareObject[0].toString().substring(2);
				String revenueShare = pubShare + ":" + ergShare;
				lObjectData.put("id_website", lRevShareObject[3].toString());
				lObjectData.put("website_name", lRevShareObject[4].toString());
				lObjectData.put("revenue_share", revenueShare);
				lObjectData.put("pub_share", lRevShareObject[0].toString());
				lObjectData.put("erg_share", lRevShareObject[1].toString());

				lOutputNode.put(lWebsiteId, lArrayData);
				lArrayData.add(lObjectData);
				System.out.println(lArrayData);
			}

		}
		return lOutputNode;
	}

	public JsonNode getRevenueByWebsiteId(Integer id) {
		ObjectMapper lObjectMapper = new ObjectMapper();

		ObjectNode lOutputNode = lObjectMapper.createObjectNode();
		ArrayNode lArrayNode = lOutputNode.arrayNode();
		EntityManager entityManager = this.entityManagerFactory.createEntityManager();

		javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
				"select revenue.pub_share,revenue.erg_share,revenue.id_advertiser,website.host_url,user1.company_name ,"+
				 " website.id as websiteid from ams_website_advertiser_revenue_share  revenue "+
				"INNER JOIN ams_user_websites website ON website.id=revenue.id_website INNER JOIN ams_users user ON user.id=website.id_user INNER JOIN ams_users user1 ON user1.id=revenue.id_advertiser"+
				" where website.id = ?");
		lQueryGetWebsiteRevenueData.setParameter(1, id);
		List<Object[]> lWebsiteRevenueshareData = lQueryGetWebsiteRevenueData.getResultList();
	
		for (int i = 0; i < lWebsiteRevenueshareData.size(); i++) {
			Object[] lRevShareObject = lWebsiteRevenueshareData.get(i);
				ObjectNode lObjectData = lObjectMapper.createObjectNode();
				lObjectData.put("id_advertiser", lRevShareObject[2].toString());
		
				lObjectData.put("website_name", lRevShareObject[3].toString());
				lObjectData.put("Advertiser_name", lRevShareObject[4].toString());
		
				lObjectData.put("pub_share", lRevShareObject[0].toString());
				lObjectData.put("erg_share", lRevShareObject[1].toString());

				lArrayNode.add(lObjectData);
		}
		return lArrayNode;
	}
}