package com.erelego.service;
import org.springframework.stereotype.Service;

import com.erelego.model.InvoiceDetails;
import com.erelego.model.InvoiceItem;
import com.erelego.model.UserWebsite;
import com.erelego.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

@Service
@Transactional
public class InvoiceItemService 
{
	@Autowired
	private InvoiceItemRepository repo;
	
	@Autowired
	private UserWebsiteService websiteService;
	
	  @PersistenceContext
	    private EntityManager entityManager;
	@Autowired
	private InvoiceDetailsService invoiceService;
	
	public List<InvoiceItem> listAll() {
        return repo.findAll();
    }
     
    public void save(InvoiceItem invoiceItem) {
        repo.save(invoiceItem);
    }
     
    public InvoiceItem get(Integer id) {
        return repo.findById(id).get();
    }
    
    
     
    public void delete(Integer id) {
        repo.deleteById(id);
    }

//	public List<Integer> generateInvoiceItem() {
//		List<UserWebsite> website=websiteService.getAllWebsites();
//		List<Integer> websiteIds= new ArrayList<>();
//		for (UserWebsite websiteId : website) {
//			int id=websiteId.getId();
//			websiteIds.add(id);	
//			float lResult = 0f;
//			
//			String pattern = "yyyy-MM-dd";
//		 	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
//
//		 	String date = simpleDateFormat.format(new Date());
//		 	System.out.println(date);
//	  
//		 javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery("select sum(amount) from ams_website_advertiser_revenue where id_website = ?1");
//	 		    	lQueryGetWebsiteRevenueData.setParameter(1, id);
//		 		    	
//		 		    	  lResult = (float) lQueryGetWebsiteRevenueData.getSingleResult();
//		 		    	System.out.println(lResult);
//
//		 		    	
//		 		    	InvoiceItem lInvoiceItem=new InvoiceItem();
//		 		    	lInvoiceItem.setIdWebSite(id);
//		 		    	lInvoiceItem.setAmount(lResult);
//		 		    	
//		 		    	
//	}
//    
//   return websiteIds;
//	}

}
//	javax.persistence.Query insertData=entityManager.createNativeQuery("insert into ams_user_invoice_item (id_website,amount, created_by, created_date, modified_date, modified_by, id_invoice) values(?,?,?,?,?,?,?) ");
//	insertData.setParameter(1, id);
//	insertData.setParameter(2, lResult);
//	insertData.setParameter(3, 1);
//	insertData.setParameter(4, date);
//	insertData.setParameter(5, date);
//	insertData.setParameter(6, 1);
//	insertData.setParameter(7, 1);	
//	insertData.executeUpdate();