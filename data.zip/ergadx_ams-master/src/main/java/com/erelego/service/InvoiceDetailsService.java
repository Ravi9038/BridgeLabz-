package com.erelego.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.UrlResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.erelego.model.InvoiceDetails;
import com.erelego.model.InvoiceItem;
import com.erelego.model.User;
import com.erelego.model.UserWebsite;
import com.erelego.repository.InvoiceDetailsRepository;
import com.erelego.util.DateUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.api.client.http.HttpHeaders;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import io.opencensus.resource.Resource;

import org.apache.logging.log4j.Logger;
import org.apache.tomcat.jni.FileInfo;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
@Service
@Transactional
public class InvoiceDetailsService {
	Logger LOGGER = LogManager.getLogger(InvoiceDetailsService.class);
	@Autowired
	private InvoiceDetailsRepository repo;

	@Autowired
	private UserService userService;

	@Autowired
	private UserWebsiteService websiteService;
	
	@Value("${invoicePath}")
	private String invoiceStoragePath;

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	  ServletContext context;

	public List<InvoiceDetails> listAll() {
		return repo.findAll();
	}

	public void save(InvoiceDetails invoicedetails) {
		repo.save(invoicedetails);
	}

	public InvoiceDetails get(Integer id) {
		return  repo.findById(id).get();
	}

	public List<InvoiceDetails> getInvoiceByAdveritser(Integer id) {
		return repo.findByUserId(id);
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}

	public List generateInvoices() throws ParseException {
		List<User> lPublisherList = userService.getAllPublishers();
		List<Double> lrevenue = new ArrayList<>();
		LOGGER.debug("Starting automation invoice process");
		// For each user
		for (User user : lPublisherList) {
			int lUserId = user.getId();

			List<UserWebsite> lLstUserWebsites = websiteService.getWebsiteByUserID(lUserId);
			Date startDateOfPreviousMonth = DateUtil.getStartDateForMonth();
			Date lastDateOfPreviousMonth = DateUtil.getEndDateForMonth();
			
			this.createInvoice(startDateOfPreviousMonth,lastDateOfPreviousMonth,user,lLstUserWebsites);


			
		}
		return lrevenue;
	}
	
	public void generateInvoiceForUserForSpecifiedDate(int pUserId,Date pStartDate,Date pEndDate) {
		User lUser = userService.getUserById(pUserId);
		List<UserWebsite> lLstUserWebsites = websiteService.getWebsiteByUserID(lUser.getId());
		this.createInvoice(pStartDate,pEndDate,lUser,lLstUserWebsites);
	}
	
	private void createInvoice(Date pStartDate,Date pEndDate,User pUser,List<UserWebsite> pUserWebsite) {
		
	
		java.sql.Date lstartDate = new java.sql.Date(pStartDate.getTime());

		java.sql.Date lEndDate = new java.sql.Date(pEndDate.getTime());
        BigDecimal totalImpression = BigDecimal.ZERO;
		float lTotalAmount = 0.0f;
		Double netAmount=null;
		Double tax=null;
		InvoiceDetails lInvoiceDetails = new InvoiceDetails();
		Set<InvoiceItem> lSetInvoiceItems = new HashSet<InvoiceItem>();
        
		String lUserCompanyName = pUser.getCompanyName();
		String lCompanyGSTIn = pUser.getGstin();
		String lAddressLine1 = pUser.getAddressLineOne();
		String lAddressLine2 = pUser.getAddressLineTwo();
		String lPostOffice = pUser.getPostOffice();
		String lTaluku = pUser.getTaluk();
		String lDistrict = pUser.getDistrict();
		String lState = pUser.getState();
		BigDecimal lImpression =BigDecimal.ZERO;
		for (UserWebsite userweb : pUserWebsite) {
			int lWebsiteId = userweb.getId();
			Double lamounts = null;
			javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(pub_amount),sum(impressions) from ams_website_advertiser_revenue where id_website = ?  AND date>= ? and date<= ?");
			lQueryGetWebsiteRevenueData.setParameter(1, lWebsiteId);
			lQueryGetWebsiteRevenueData.setParameter(2, lstartDate);
			lQueryGetWebsiteRevenueData.setParameter(3, lEndDate);
//			lResult = (Double) lQueryGetWebsiteRevenueData.getSingleResult();
			 List result = lQueryGetWebsiteRevenueData.getResultList();
			 String amount="";
			 String impression="";
			for(int i=0;i<result.size();i++) {
				Object[]  invoice =  (Object[]) result.get(i);
				if(invoice[0]!=null && invoice[1]!=null  ) {
				 amount = invoice[0].toString();
				 impression = invoice[1].toString();
				}
			}
			 if(amount!="") {
				lamounts=Double.parseDouble(amount);
			 }
			 if(impression!="") {
				 lImpression = new BigDecimal(impression);
			 }
			float lAmount = 0.0f;
		
			if (lamounts != null )
			lAmount = Float.parseFloat(lamounts.toString());
			InvoiceItem lInvoiceItem = new InvoiceItem();
			lInvoiceItem.setIdWebSite(lWebsiteId);
			lInvoiceItem.setAmount(lAmount);
			lInvoiceItem.setCurrency("USD");
			lInvoiceItem.setLabel(userweb.getHostURL());
			lInvoiceItem.setInvoiceDetails(lInvoiceDetails);
			lInvoiceItem.setImpression(lImpression);
			long impressions = lImpression.longValue();
			 if(lImpression!=null) {
				 totalImpression=totalImpression.add(new BigDecimal(impressions));
			
			 }
			 
			lSetInvoiceItems.add(lInvoiceItem);
			lTotalAmount += lAmount;
			netAmount= (lTotalAmount/1.18);
			tax=lTotalAmount-netAmount;
			
		}

		lInvoiceDetails.setUserId(pUser.getId());
		lInvoiceDetails.setCompanyName(lUserCompanyName);
		lInvoiceDetails.setUserGstIn(lCompanyGSTIn);
		lInvoiceDetails.setStartDate(lstartDate);
		lInvoiceDetails.setEndDate(lEndDate);
		lInvoiceDetails.setUserAddressLine1(lAddressLine1);
		lInvoiceDetails.setUserAddressLine2(lAddressLine2);
		lInvoiceDetails.setUserPostOffice(lPostOffice);
		lInvoiceDetails.setUserDistrict(lDistrict);
		lInvoiceDetails.setUserTaluku(lTaluku);
		lInvoiceDetails.setCurrency("USD");
		lInvoiceDetails.setStatus("DRAFT");
		lInvoiceDetails.setImpression(totalImpression);
		lInvoiceDetails.setUserState(lState);
		lInvoiceDetails.setAmount(lTotalAmount);
 
		lInvoiceDetails.setNetAmount(netAmount);
		
	
		lInvoiceDetails.setTax(tax);
		lInvoiceDetails.setPayCycleId(1);
		lInvoiceDetails.setInvoiceItem(lSetInvoiceItems);
		Session session = this.entityManager.unwrap(Session.class);
		session.saveOrUpdate(lInvoiceDetails);
	}
	
	
	
	
	
	public InvoiceDetails generateInvoicePdf(Integer pInvoiceId) throws FileNotFoundException, DocumentException {
	InvoiceDetails list=this.get(pInvoiceId);
		String lFileName="D:\\invoce1.pdf";
		Document document = new Document(PageSize.A4, 50, 50, 50, 50);
		PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(lFileName));
		document.open();
		 Paragraph paragraph1 = new Paragraph();
		 paragraph1.setAlignment(Element.ALIGN_CENTER);
		 paragraph1.add("Invoice");
		 document.add(paragraph1);
		 
		 PdfPTable table = new PdfPTable(5);
		 table.setWidthPercentage(80);
		table.setWidths(new int[] { 4, 4, 4 ,4,4});

			
			PdfPCell hcell=new PdfPCell();
			hcell.setPhrase(new Phrase("Comany name"));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);
			hcell.setPhrase(new Phrase("Start date"));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);
			hcell.setPhrase(new Phrase("end date"));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);
			hcell.setPhrase(new Phrase("amount"));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);
			hcell.setPhrase(new Phrase("currency"));
			hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(hcell);
			PdfPCell mcell=new PdfPCell();
			mcell.setPhrase(new Phrase(list.getCompanyName()));
			mcell.setPaddingLeft(5);
     		mcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			mcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(mcell);
			mcell.setPhrase(new Phrase(String.valueOf(list.getStartDate())));
			mcell.setPaddingLeft(5);
     		mcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			mcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(mcell);
			mcell.setPhrase(new Phrase(String.valueOf(list.getEndDate())));
			mcell.setPaddingLeft(5);
     		mcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			mcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(mcell);
			mcell.setPhrase(new Phrase(String.valueOf(list.getAmount())));
			mcell.setPaddingLeft(5);
     		mcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			mcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(mcell);
			mcell.setPhrase(new Phrase((list.getCurrency())));
			mcell.setPaddingLeft(5);
     		mcell.setVerticalAlignment(Element.ALIGN_MIDDLE);
			mcell.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(mcell);

			
		 document.add(table);
		 document.close();
		 return list;

	}
	
	


	public ResponseEntity<InvoiceDetails> addAttachmentName(MultipartFile file, String invoiceNumber, Integer id) throws IllegalStateException, IOException {
	
		if (null == file.getOriginalFilename()) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		try {
			byte[] bytes = file.getBytes();
			String Name=file.getOriginalFilename();
			String extension = "";

			int i = Name.lastIndexOf('.');
			if (i > 0) {
			    extension = Name.substring(i+1);
			}
			System.out.println(extension);
			InvoiceDetails existingInvoice = this.get(id);
			   int idUser =existingInvoice.getUserId();
			   System.out.println(idUser);
			   String fileName=  id+"."+extension;
			   String directoryName = this.invoiceStoragePath + File.separator +idUser;
		        Path newpath = Paths.get(directoryName);
		        if (!Files.exists(newpath)) {
		            
		            Files.createDirectory(newpath);
		           System.out.println("Directory Created");
		            LOGGER.debug("Directory Created");
		            
		        } else {
		            
		            System.out.println("Directory already exists");
		            LOGGER.debug("Directory already exists");
		        }
		    
			Path path = Paths.get(directoryName,fileName);
			Files.write(path, bytes);
			String name=path.getFileName().toString();
			System.out.println(name);
			existingInvoice.setAttachedFileName(fileName);
			existingInvoice.setInvoiceNumber(invoiceNumber);
			existingInvoice.setStatus("RECIVED");
			Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(existingInvoice);
			
			
		} catch (IOException e) {
			
		LOGGER.error("Invoice  is not get attached",e.getMessage());
		}
		return new ResponseEntity<InvoiceDetails>(HttpStatus.OK);
	  
	}

	

			
}
	
//+  file.getOriginalFilename()
