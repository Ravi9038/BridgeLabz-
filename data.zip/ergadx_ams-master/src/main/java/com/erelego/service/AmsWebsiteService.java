package com.erelego.service;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.nio.file.Paths;
import com.erelego.util.FileUtil;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.commons.io.FileUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.hibernate.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.erelego.model.AmsWebsiteAdUnit;
import com.erelego.model.AmsWebsitePages;


import com.erelego.repository.AmsWebsiteRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;


@Service
@Transactional
public class AmsWebsiteService {
	Logger LOGGER = LogManager.getLogger(AmsWebsiteService.class);
	@Autowired
	private AmsWebsiteRepository repo;
	
	@Value("${jsfilePath}")
	private String jsfileStoragePath;
	
	@Value("${jscommonfile1}")
	private String jscommonfile1;
	
	@Value("${jscommonfile2}")
	private String jscommonfile2;
	
	
	
	@Autowired
	private AmsWebsiteAdUnitService adunitService;
		
	
	@PersistenceContext
	private EntityManager entityManager;
	

	public List<AmsWebsitePages> listAll() {
		return repo.findAll();
	}

	public void save(AmsWebsitePages amsWebsitePages) {
		repo.save(amsWebsitePages);
	}

	public AmsWebsitePages get(Integer id) {
		return repo.findById(id).get();
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}

	
	public List addDetails() {
		Set<AmsWebsiteAdUnit> amsWebsiteAdUnits = new HashSet<>();
		Set<AmsWebsitePages> amsWebsitePages = new HashSet<>();
		AmsWebsitePages lAmsWebsitePages=new AmsWebsitePages();
		lAmsWebsitePages.setIdWebsite(1);
		lAmsWebsitePages.setExpression("success");
		lAmsWebsitePages.setLabel("1");
		amsWebsitePages.add(lAmsWebsitePages);
		
		AmsWebsiteAdUnit lAmsWebsiteAdUnit=new AmsWebsiteAdUnit();
	
		lAmsWebsiteAdUnit.setName("company");
	
		lAmsWebsiteAdUnit.setAmsWebsitePages(amsWebsitePages);
		amsWebsiteAdUnits.add(lAmsWebsiteAdUnit);
		lAmsWebsitePages.setAmsWebsiteAdUnits(amsWebsiteAdUnits);
		Session session1 = this.entityManager.unwrap(Session.class);
		session1.saveOrUpdate(lAmsWebsitePages);

		return null;
	}
	
	public List<AmsWebsitePages> lgetDataForWebsiteId(Integer idWebsite) {
		return repo.findByIdWebsite(idWebsite);
		
		
	}
	public static String unEscapeString(String s){
	    StringBuilder sb = new StringBuilder();
	    for (int i=0; i<s.length(); i++)
	        switch (s.charAt(i)){
	            case '\n': sb.append("\\n"); break;
	            case '\t': sb.append("\\t"); break;
	            // ... rest of escape characters
	            default: sb.append(s.charAt(i));
	        }
	    return sb.toString();
	}
	public ArrayNode getpageData(Integer id) throws JsonMappingException, JsonProcessingException, JSONException {
		ObjectMapper lObjectMapper = new ObjectMapper();
		ObjectMapper mapper = new ObjectMapper();
		ArrayNode arrayNode = lObjectMapper.createArrayNode();
		javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
				"select label,page_check_type,page_check_value,devices,id from ams_website_pages where id_website=?");
		lQueryGetWebsiteRevenueData.setParameter(1,id);
		List result = lQueryGetWebsiteRevenueData.getResultList();
		for (int i = 0; i < result.size(); i++) {
			Object[] lArrayData =  (Object[]) result.get(i);
			ObjectNode arraynode = lObjectMapper.createObjectNode();
			arraynode.put("page_name", lArrayData[0].toString());
			arraynode.put("page_check", lArrayData[1].toString());
//			String unescape = this.unEscapeString(lArrayData[2].toString());
//			String pageCheckValue = StringEscapeUtils.unescapeJava( lArrayData[2].toString());
//			String unescape=StringEscapeUtils.escapeJava(lArrayData[2].toString());
			arraynode.put("page_check_value",  lArrayData[2].toString());
		
			 String device = lArrayData[3].toString();
			  JsonNode deviceNode = mapper.readTree(device);
			  ArrayNode devciearrayNode = lObjectMapper.createArrayNode();

				 if(deviceNode.get("mobile").toString().equalsIgnoreCase("true")) {
					 arraynode.put("isMobile", true);
					 devciearrayNode.add("Mobile");
				 }
				 else {
					 arraynode.put("isMobile", false);
				 }
				 if(deviceNode.get("tablet").toString().equalsIgnoreCase("true")) {
					 arraynode.put("isTablet", true);
					 devciearrayNode.add("Tablet");
				 }
				 else {
					 arraynode.put("isTablet", false);
				 }
				 if(deviceNode.get("desktop").toString().equalsIgnoreCase("true")) {
					 arraynode.put("isDesktop", true);
					 devciearrayNode.add("Desktop");
				 }
				 else {
					 arraynode.put("isDesktop", false);
				 }
			
			  arraynode.putPOJO("devices", devciearrayNode);
			  String idpage = lArrayData[4].toString();
				 Integer idToPass=Integer.parseInt(idpage);
					javax.persistence.Query query = entityManager.createNativeQuery(
							"select id_ad_unit from ams_page_ad_units where  id_page = ? ");
					query.setParameter(1,idToPass);
					List idPageForWebsite = query.getResultList();
				ArrayNode adunit = null;
				for (int j = 0; j < idPageForWebsite.size(); j++) {
					 String idwebsite = idPageForWebsite.get(j).toString();
					
					  adunit = adunitService.getAdPage(idToPass);
				}
				
				  arraynode.putPOJO("ad_unit", adunit);
			  arrayNode.add(arraynode);
		}
		return arrayNode;
	}

	public void createJSFile(ArrayNode lAdRecords, Integer id) throws IOException {
		
		   String directoryName = this.jsfileStoragePath + File.separator +id;
		   String fileName=  "ads.js";
	     
	        FileUtil.createDirectory(directoryName, fileName);
	        Path path = Paths.get(directoryName,fileName);
	        File source = new File(jscommonfile1);

	       String destinationpath=this.jsfileStoragePath + File.separator +id +  File.separator+"ads.js";
	      
	        FileUtil.copyfile(destinationpath, path, source);
	     
			      ObjectMapper mapper = new ObjectMapper();
			      Writer output;
			      output = new BufferedWriter(new FileWriter(destinationpath,true));  
//			      String newLine = mapper.writeValueAsString(lAdRecords);
			      String newLine = lAdRecords.toPrettyString();
			      output.append( newLine);
			    
			      Scanner sc = new Scanner(new File(jscommonfile2));
					 StringBuffer  buffer = new StringBuffer();
					   while (sc.hasNextLine()) {
					         buffer.append(sc.nextLine()+System.lineSeparator());
					      }
					   output.append(buffer);
					   output.flush();
	}
	
} 










