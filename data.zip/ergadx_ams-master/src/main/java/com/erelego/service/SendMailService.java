package com.erelego.service;

import java.io.File;
import java.util.Date;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import org.springframework.stereotype.Service;


import com.erelego.model.MailConfirmationDetails;
import com.erelego.repository.MailRepository;

@Service

public class SendMailService {
	
	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
    private MailRepository mailRepo;

	 

	public void sendMailWithAttachment( String from, String[] to, String[] cc, String[] bcc, String subject, String body,
			File[] attachment) throws MessagingException  {

		
			try {
		   MimeMessage mimeMessage = mailSender.createMimeMessage();
		   MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
		   mimeMessage.setFrom(new InternetAddress(from));
		   
			InternetAddress[] toAddress = new InternetAddress[to.length];
			// To get the array of toaddresses
			for (int i = 0; i < to.length; i++) {
				toAddress[i] = new InternetAddress(to[i]);
			}
	
			// Set To: header field of the header.
			for (int i = 0; i < toAddress.length; i++) {
				mimeMessage.addRecipient(Message.RecipientType.TO, toAddress[i]);
			}
	
			InternetAddress[] ccAddress = new InternetAddress[cc.length];
	
			// To get the array of ccaddresses
			for (int i = 0; i < cc.length; i++) {
				ccAddress[i] = new InternetAddress(cc[i]);
			}
	
			// Set cc: header field of the header.
			for (int i = 0; i < ccAddress.length; i++) {
				mimeMessage.addRecipient(Message.RecipientType.CC, ccAddress[i]);
			}
	
			InternetAddress[] bccAddress = new InternetAddress[bcc.length];
	
			// To get the array of Bcc addresses
			for (int i = 0; i < bcc.length; i++) {
				bccAddress[i] = new InternetAddress(bcc[i]);
			}
	
			// Set bcc: header field of the header.
			for (int i = 0; i < bccAddress.length; i++) {
				mimeMessage.addRecipient(Message.RecipientType.BCC, bccAddress[i]);
			}
	
			for (File file : attachment) {
				FileSystemResource fr = new FileSystemResource(file);
				helper.addAttachment(file.getName(), fr);
			}
//	        helper.setFrom(from);
			helper.setSentDate(new Date());
			helper.setSubject(subject);
			helper.setText(body, true);
			
			mailSender.send(mimeMessage);
			//save with status as success
     		this.sendData(to, cc, bcc, subject, body, "success");
		 
			}
	
			catch(Exception e) {
				this.sendData(to, cc, bcc, subject, body, "failure");
			}
	}


	public void sendData(String[] to, String[] cc, String[] bcc, String subject, String body,String status) {
		MailConfirmationDetails lMailConfirmationDetails = new MailConfirmationDetails();
		lMailConfirmationDetails.setSubject(subject);
		lMailConfirmationDetails.setBody(body);
		lMailConfirmationDetails.setStatus(status);
		String ltoreslut = "";
		if (to.length > 0) {
			StringBuilder sb = new StringBuilder();

			for (String lto : to) {
				sb.append(lto).append(",");

			}
			ltoreslut = sb.deleteCharAt(sb.length() - 1).toString();
			System.out.println(ltoreslut);
			lMailConfirmationDetails.setTo(ltoreslut);
		}
		String lccreslut = "";
		if (cc.length > 0) {
			StringBuilder sb = new StringBuilder();
			for (String lcc : cc) {
				sb.append(lcc).append(",");
			}
			lccreslut = sb.deleteCharAt(sb.length() - 1).toString();
			System.out.println(lccreslut);
			lMailConfirmationDetails.setCc(lccreslut);
		}
			
		String lBccreslut = "";
		if (bcc.length > 0) {
			StringBuilder sb = new StringBuilder();
			for (String lbcc : bcc) {
				sb.append(lbcc).append(",");
			}
			lBccreslut = sb.deleteCharAt(sb.length() - 1).toString();
			System.out.println(lBccreslut);
			lMailConfirmationDetails.setBcc(lBccreslut);
		}
			
			
	mailRepo.save(lMailConfirmationDetails);
	}
	
}
