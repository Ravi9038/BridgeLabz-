package com.erelego.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;


@Service
@Transactional
public class FileTransferProtocolService {

	private static Logger logger = LogManager.getLogger(FileTransferProtocolService.class);

	public void uploadFileRemoteServer(JSONObject pJsnFtpConfigData) throws Exception {
		try {

			String lFtpType = pJsnFtpConfigData.getString("ftp_type");
			if(lFtpType.equalsIgnoreCase("FTP")) {
				this.uploadToFTPServer(pJsnFtpConfigData);	
			}else if(lFtpType.equalsIgnoreCase("SFTP")) {
				this.uploadToSFTPServer(pJsnFtpConfigData);
			}

		}catch(Exception e) {

			logger.info("FTP Type is not found");
		}

	}

	 public void uploadToSFTPServer(JSONObject pJsnFtpConfigData) throws Exception{

		 String lStrSftpServerUrl = pJsnFtpConfigData.getString("server"); 

		 int lSftpPort = pJsnFtpConfigData.getInt("port"); 
		 String lStrSftpUserName = pJsnFtpConfigData.getString("user"); 
		 String lStrSftpPassword = pJsnFtpConfigData.getString("pass"); 
		 String lStrSftpRemoteDirPath =  pJsnFtpConfigData.getString("remoteDirPath");
		 String lFileName = pJsnFtpConfigData.getString("lFileName");
		 Session session = null; ChannelSftp channel = null;
		 logger.info("preparing the host information for sftp.");


		 String rDirectoryName = null;

		 try {
			 JSch jsch = new JSch();
			 session = jsch.getSession(lStrSftpUserName, lStrSftpServerUrl, lSftpPort); 
			 session.setPassword(lStrSftpPassword);
			 java.util.Properties config = new java.util.Properties();
			 config.put("StrictHostKeyChecking", "no"); 
			 session.setConfig(config);
			 session.connect(); 
			 logger.info("Host connected.");

			 channel = (ChannelSftp) session.openChannel("sftp"); channel.connect();
			 rDirectoryName = lStrSftpRemoteDirPath;			 	  
			 channel.mkdir(rDirectoryName);
			 logger.info("Created directory successfully "+rDirectoryName);

		 } catch (Exception ex) {
			 logger.info("Directory already exists");
		 } 		  
		 channel.cd(rDirectoryName);
		 File f = new File(lFileName); 
		 channel.put(new FileInputStream(f), f.getName());
		 channel.exit(); 
		 logger.info("sftp Channel exited.");
		 channel.disconnect(); 
		 logger.info("Channel disconnected.");
		 session.disconnect(); 
		 logger.info("Host Session disconnected."); 

	 }

	 public void uploadToFTPServer(JSONObject pJsnFtpConfigData) throws Exception{

		 String lStrFtpServerUrl = pJsnFtpConfigData.getString("server");
		 int lFtpPort = pJsnFtpConfigData.getInt("port");
		 String user = pJsnFtpConfigData.getString("user");
		 String pass = pJsnFtpConfigData.getString("pass");
		 String localDirPath = pJsnFtpConfigData.getString("localDirPath");
		 String remoteDirPath = pJsnFtpConfigData.getString("remoteDirPath");
		 String lFileName = pJsnFtpConfigData.getString("lFileName");
		 FTPClient pFtpClient = new FTPClient();
		 pFtpClient.connect(lStrFtpServerUrl, lFtpPort); 
		 pFtpClient.login(user, pass);
		 pFtpClient.enterLocalPassiveMode();


		 File localFile = new File(localDirPath);			 
		 InputStream inputStream = new FileInputStream(localFile);

		 pFtpClient.makeDirectory(remoteDirPath);
		 boolean directoryExist = true;

		 if(!directoryExist) {
			 pFtpClient.changeWorkingDirectory(remoteDirPath);
			 int returnCode = pFtpClient.getReplyCode();
		 }
		 File remoteData = new File(lFileName);
		 String RemoteData = remoteData.getName();
		 String RemoteData1 = new File(remoteDirPath, RemoteData).toString();
		 try {

			 pFtpClient.setFileType(FTP.BINARY_FILE_TYPE);
			 pFtpClient.storeFile(RemoteData1, inputStream);
		 }finally {
			 inputStream.close(); 

		 }

	 }

}

