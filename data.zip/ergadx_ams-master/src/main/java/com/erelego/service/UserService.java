package com.erelego.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.erelego.exception.RecordNotFoundException;
import com.erelego.exception.UserAlreadyExistException;
import com.erelego.model.AmsPublisherContact;
import com.erelego.model.BankDetails;
import com.erelego.model.Status;
import com.erelego.model.User;
import com.erelego.model.UserWebsite;
import com.erelego.repository.UserRepository;
import com.erelego.util.Constants;
import com.erelego.util.DateUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.apache.logging.log4j.LogManager;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * 
 * @author Vikas M Gowda
 *
 */

@Service
public class UserService implements UserDetailsService {

	Logger LOGGER = LogManager.getLogger(UserService.class);
	@Autowired
	private UserRepository userRepository;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	RevenueProcessorService revenueProcessorService;

	@Autowired
	private UserWebsiteService websiteService;

	@Autowired
	private BankDetailsService bankService;

	@Autowired
	private AmsPublisherContactService contactService;

	@Autowired
	private ExcelService excelService;

	public List<User> getAllUser() {

		try {

			List<User> listUsers = userRepository.findAll();// userRepository.findByStatus(Status.ACTIVE);
			return listUsers;
		} catch (Exception e) {
			return new ArrayList<User>();
		}
	}

	public List<User> getAllAdvertiser() {

		try {
			List<User> listUsers = userRepository.findByIdRole(2);// userRepository.findByStatus(Status.ACTIVE);
			return listUsers;
		} catch (Exception e) {
			return new ArrayList<User>();
		}
	}

	public List<User> getAllPublishers() {

		try {
			List<User> listUsers = userRepository.findByIdRole(3);// userRepository.findByStatus(Status.ACTIVE);
			return listUsers;
		} catch (Exception e) {
			return new ArrayList<User>();
		}
	}

	public User getUserById(int id) throws RecordNotFoundException {
		Optional<User> user = userRepository.findById(id);
		if (user.isPresent() && user != null)
			return user.get();
		else
			throw new RecordNotFoundException("user not found for given id", id);

	}

	public User createOrUpdateUser(User editUser) throws Exception {

		if (editUser.getId() != 0) {

			Optional<User> existingUser = userRepository.findById(editUser.getId());

			if (existingUser.isPresent()) {
				User newUser = existingUser.get();
				newUser.setEmail(editUser.getEmail());
				newUser.setCompanyName(editUser.getCompanyName());
				newUser.setContactPersonName(editUser.getContactPersonName());
				newUser.setContactPersonNumber(editUser.getContactPersonNumber());
				newUser.setGstin(editUser.getGstin());
				newUser.setIdRole(editUser.getIdRole());
				newUser.setStatus(editUser.getStatus());
				newUser.setAddressLineOne(editUser.getAddressLineOne());
				newUser.setAddressLineTwo(editUser.getAddressLineTwo());
				newUser.setPostOffice(editUser.getPostOffice());
				newUser.setTaluk(editUser.getTaluk());
				newUser.setDistrict(editUser.getDistrict());
				newUser.setState(editUser.getState());
				return userRepository.save(newUser);
			} else {
				/*
				 * User newUser = new User(); String password = editUser.getPassword(); String
				 * encryptedPassword = this.passwordEncryption(password);
				 * newUser.setCompanyName(editUser.getCompanyName());
				 * newUser.setAddressLineOne(editUser.getAddressLineOne());
				 * newUser.setAddressLineTwo(editUser.getAddressLineTwo());
				 * newUser.setContactPersonName(editUser.getContactPersonName());
				 * newUser.setContactPersonNumber(editUser.getContactPersonNumber());
				 * newUser.setEmail(editUser.getEmail());
				 * newUser.setPassword(encryptedPassword);
				 * newUser.setGstin(editUser.getGstin());
				 * newUser.setDistrict(editUser.getDistrict());
				 * newUser.setIdRole(editUser.getIdRole());
				 * newUser.setPostOffice(editUser.getPostOffice());
				 * newUser.setTaluk(editUser.getTaluk()); newUser.setState(editUser.getState());
				 */
				return userRepository.save(editUser);
			}
		} else {
			/*
			 * User newUser = new User(); String password = editUser.getPassword(); String
			 * encryptedPassword = this.passwordEncryption(password);
			 * newUser.setCompanyName(editUser.getCompanyName());
			 * newUser.setAddressLineOne(editUser.getAddressLineOne());
			 * newUser.setAddressLineTwo(editUser.getAddressLineTwo());
			 * newUser.setContactPersonName(editUser.getContactPersonName());
			 * newUser.setContactPersonNumber(editUser.getContactPersonNumber());
			 * newUser.setEmail(editUser.getEmail());
			 * newUser.setPassword(encryptedPassword);
			 * newUser.setGstin(editUser.getGstin());
			 * newUser.setDistrict(editUser.getDistrict());
			 * newUser.setIdRole(editUser.getIdRole());
			 * newUser.setPostOffice(editUser.getPostOffice());
			 * newUser.setTaluk(editUser.getTaluk()); newUser.setState(editUser.getState());
			 */

			User user = userRepository.findByEmailAndCompanyName(editUser.getEmail(), editUser.getCompanyName());

			if (user != null) {
				System.out.println("User Already exist");
				throw new UserAlreadyExistException("User already exist");
			}
			else {
				return userRepository.save(editUser);
			}
		}
	}

	public void deleteUserById(int id) throws RecordNotFoundException {

		Optional<User> existingUser = userRepository.findById(id);

		if (existingUser.isPresent()) {
			User newUser = existingUser.get();
			newUser.setStatus("INACTIVE");
			userRepository.save(newUser);
		} else {
			throw new RecordNotFoundException("Not able to find User for given id", id);
		}
	}

	public UserDetails loadUserByUsernameAndPassword(String username, String password)
			throws UsernameNotFoundException {

		User user = userRepository.findByEmailAndPassword(username, password);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
				new ArrayList<>());

		// return new org.springframework.security.core.userdetails.User("abc",
		// "abc",new ArrayList<>());
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		LOGGER.debug("load user by username : " + username);
		User user = userRepository.findByEmail(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}

		LOGGER.debug("load user by username : " + user.getEmail() + "-" + user.getPassword());
		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
				new ArrayList<>());

		// return new org.springframework.security.core.userdetails.User("abc",
		// "abc",new ArrayList<>());
	}

	public User getByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByEmail(username);
		return user;
	}

	public List<User> getUserByRole(int idRole) {
		try {
			List<User> users = userRepository.findByIdRole(idRole);
			if (!users.isEmpty() && users.size() > 0)
				return users;
			else
				return new ArrayList<User>();
		} catch (Exception e) {
			return new ArrayList<User>();
		}
	}

	public JsonNode getDashboardDataForUser(Integer id, String userType) {
		ObjectMapper objectMapper = new ObjectMapper();
		ObjectNode objectNode = objectMapper.createObjectNode();
		JsonNode lRevenueData = getRevenueSummaryForUser(id, userType);
		objectNode.set("revenue_data", lRevenueData);

		/*
		 * JsonNode lTodaysRevenueData =
		 * getRevenueWebsiteWiseForUser(id,todayDate,todayDate,userType); JsonNode
		 * lYesterdaysRevenueData =
		 * getRevenueWebsiteWiseForUser(id,DateUtil.subtractDays(todayDate, 1),
		 * DateUtil.subtractDays(todayDate, 1),userType); JsonNode lLast7DaysRevenueData
		 * = getRevenueWebsiteWiseForUser(id,DateUtil.subtractDays(todayDate, 6)
		 * ,todayDate ,userType); JsonNode lLast30DaysRevenueData =
		 * getRevenueWebsiteWiseForUser(id,DateUtil.subtractDays(todayDate, 29),
		 * todayDate,userType);
		 * 
		 * 
		 * 
		 * objectNode.set("today_revenue_data", lTodaysRevenueData);
		 * objectNode.set("yesterday_revenue_data", lYesterdaysRevenueData);
		 * objectNode.set("last7days_revenue_data", lLast7DaysRevenueData);
		 * objectNode.set("last30days_revenue_data", lLast30DaysRevenueData);
		 *
		 * 
		 * * JsonNode lDateWiseRevenue =
		 * getRevenueDateWiseForUser(id,DateUtil.subtractDays(todayDate, 6) ,todayDate
		 * ,userType);
		 * 
		 * 
		 * if(userType.equalsIgnoreCase(Constants.USER_TYPE_ADMIN)) { JsonNode
		 * lTodaysRevenueDataAdvertiserWise =
		 * getRevenueAdvertiserWiseForUser(id,todayDate,todayDate,userType); JsonNode
		 * lYesterdaysRevenueDataAdvertiserWise =
		 * getRevenueAdvertiserWiseForUser(id,DateUtil.subtractDays(todayDate, 1),
		 * DateUtil.subtractDays(todayDate, 1),userType); JsonNode
		 * lLast7DaysRevenueDataAdvertiserWise =
		 * getRevenueAdvertiserWiseForUser(id,DateUtil.subtractDays(todayDate, 6)
		 * ,todayDate ,userType); JsonNode lLast30DaysRevenueDataAdvertiserWise =
		 * getRevenueAdvertiserWiseForUser(id,DateUtil.subtractDays(todayDate, 29),
		 * todayDate,userType);
		 * 
		 * objectNode.set("today_revenue_data_advertiser",
		 * lTodaysRevenueDataAdvertiserWise);
		 * objectNode.set("yesterday_revenue_data_advertiser",
		 * lYesterdaysRevenueDataAdvertiserWise);
		 * objectNode.set("last7days_revenue_data_advertiser",
		 * lLast7DaysRevenueDataAdvertiserWise);
		 * objectNode.set("last30days_revenue_data_advertiser",
		 * lLast30DaysRevenueDataAdvertiserWise);
		 * 
		 * 
		 * JsonNode lTodaysRevenueDataPublisherWise =
		 * getRevenuePublisherWiseForUser(id,todayDate,todayDate,userType); JsonNode
		 * lYesterdaysRevenueDataPublisherWise =
		 * getRevenuePublisherWiseForUser(id,DateUtil.subtractDays(todayDate, 1),
		 * DateUtil.subtractDays(todayDate, 1),userType); JsonNode
		 * lLast7DaysRevenueDataPublisherWise =
		 * getRevenuePublisherWiseForUser(id,DateUtil.subtractDays(todayDate, 6)
		 * ,todayDate ,userType); JsonNode lLast30DaysRevenueDataPublisherWise =
		 * getRevenuePublisherWiseForUser(id,DateUtil.subtractDays(todayDate, 29),
		 * todayDate,userType);
		 * 
		 * objectNode.set("today_revenue_data_publisher",
		 * lTodaysRevenueDataPublisherWise);
		 * objectNode.set("yesterday_revenue_data_publisher",
		 * lYesterdaysRevenueDataPublisherWise);
		 * objectNode.set("last7days_revenue_data_publisher",
		 * lLast7DaysRevenueDataPublisherWise);
		 * objectNode.set("last30days_revenue_data_publisher",
		 * lLast30DaysRevenueDataPublisherWise);
		 * 
		 * 
		 * } objectNode.set("dateWiseRevenue", lDateWiseRevenue);
		 */
		return objectNode;
	}

	public JsonNode getRevenueSummaryForUser(Integer id, String userType) {
		ObjectMapper objectMapper = new ObjectMapper();
		ObjectNode lRevenueData = objectMapper.createObjectNode();
		Date todayDate = new Date();
		String todayRevenue = getSumForUserForDuration(id, todayDate, todayDate, userType);
		String yesterdayRevenue = getSumForUserForDuration(id, DateUtil.subtractDays(todayDate, 1),
				DateUtil.subtractDays(todayDate, 1), userType);
		String lastWeekSameDayRevenue = getSumForUserForDuration(id, DateUtil.subtractDays(todayDate, 8),
				DateUtil.subtractDays(todayDate, 8), userType);

		String current7DaysRevenue = getSumForUserForDuration(id, DateUtil.subtractDays(todayDate, 6), todayDate,
				userType);

		String last7DaysRevenue = getSumForUserForDuration(id, DateUtil.subtractDays(todayDate, 13),
				DateUtil.subtractDays(todayDate, 7), userType);

		String current30DaysRevenue = getSumForUserForDuration(id, DateUtil.getMonthStartDate(0), todayDate, userType);
		String last30DaysRevenue = getSumForUserForDuration(id, DateUtil.getMonthStartDate(-1),
				DateUtil.getMonthEndDate(-1), userType);

		lRevenueData.put("today", todayRevenue);
		lRevenueData.put("yesterday", yesterdayRevenue);
		lRevenueData.put("lastweek_sameday", lastWeekSameDayRevenue);

		lRevenueData.put("current7day", current7DaysRevenue);
		lRevenueData.put("last7day", last7DaysRevenue);

		lRevenueData.put("current30day", current30DaysRevenue);
		lRevenueData.put("last30day", last30DaysRevenue);

		return lRevenueData;
	}

	public String getSumForUserForDuration(Integer id, Date startDate, Date endDate, String userType) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Object lResult = null;
		if (userType.equals(Constants.USER_TYPE_PUBLISHER)) {
			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(pub_amount) from ams_website_advertiser_revenue where id_website in (select id from ams_user_websites where id_user = ?) AND date >= ? AND date <= ?");
			lQueryGetWebsiteRevenueData.setParameter(1, id);
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(startDate));
			lQueryGetWebsiteRevenueData.setParameter(3, formatter.format(endDate));
			lResult = lQueryGetWebsiteRevenueData.getSingleResult();
		} else {
			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(amount) from ams_website_advertiser_revenue where date >= ? AND date <= ?");
			lQueryGetWebsiteRevenueData.setParameter(1, formatter.format(startDate));
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(endDate));
			lResult = lQueryGetWebsiteRevenueData.getSingleResult();
		}

		if (lResult != null)
			return lResult.toString();
		else
			return "0.0";
	}

	public JsonNode getRevenueAdvertiserWiseForUser(Integer id, Date startDate, Date endDate, String userType) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		List lRevenueWebsiteData = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		if (userType.equals(Constants.USER_TYPE_ADMIN)) {
			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(b.amount) as totalAmount,sum(b.impressions) as totalImpressions ,AVG(b.cpm) as avgCpm,a.company_name from  ams_users a , ams_website_advertiser_revenue b where a.id=b.id_advertiser AND b.date >= ? AND b.date <= ? group by company_name order by totalAmount DESC");
			lQueryGetWebsiteRevenueData.setParameter(1, formatter.format(startDate));
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(endDate));
			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
		}

		for (int i = 0; i < lRevenueWebsiteData.size(); i++) {
			// ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
			ArrayNode lJsonNodeRevenueData = objectMapper.createArrayNode();
			Object[] lArrayRevenueData = (Object[]) lRevenueWebsiteData.get(i);
			lJsonNodeRevenueData.add(lArrayRevenueData[3].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[1].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[2].toString());
			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;
	}

	public JsonNode getRevenueDateWiseForUser(Integer id, Date startDate, Date endDate, String userType) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		List lRevenueWebsiteData = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		if (userType.equals(Constants.USER_TYPE_PUBLISHER)) {

			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(b.amount),sum(b.impressions),AVG(b.cpm),b.date from  ams_user_websites a , ams_website_advertiser_revenue b where a.id=b.id_website AND a.id in ( select id from ams_user_websites where id_user = ?) and b.date >= ? AND b.date <= ? group by date order by date DESC");
			lQueryGetWebsiteRevenueData.setParameter(1, id);
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(startDate));
			lQueryGetWebsiteRevenueData.setParameter(3, formatter.format(endDate));
			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
		} else {
			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(b.amount),sum(b.impressions),AVG(b.cpm),b.date from  ams_user_websites a , ams_website_advertiser_revenue b where a.id=b.id_website AND b.date >= ? AND b.date <= ? group by date order by date DESC");
			lQueryGetWebsiteRevenueData.setParameter(1, formatter.format(startDate));
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(endDate));
			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
		}

		for (int i = 0; i < lRevenueWebsiteData.size(); i++) {
			ArrayNode lJsonNodeRevenueData = objectMapper.createArrayNode();
			Object[] lArrayRevenueData = (Object[]) lRevenueWebsiteData.get(i);
			lJsonNodeRevenueData.add(lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[1].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[2].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[3].toString());

			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;
	}

	public JsonNode getRevenueWebsiteWiseForUser(Integer id, Date startDate, Date endDate, String userType) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		List lRevenueWebsiteData = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		if (userType.equals(Constants.USER_TYPE_PUBLISHER)) {

			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(b.amount) as totalAmount ,sum(b.impressions) as totalImpressions,AVG(b.cpm) avgCpm,a.host_url from  ams_user_websites a , ams_website_advertiser_revenue b where a.id=b.id_website AND a.id in ( select id from ams_user_websites where id_user = ?) and b.date >= ? AND b.date <= ? group by host_url order by totalAmount");
			lQueryGetWebsiteRevenueData.setParameter(1, id);
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(startDate));
			lQueryGetWebsiteRevenueData.setParameter(3, formatter.format(endDate));
			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
		} else {
			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(b.amount) as totalAmount ,sum(b.impressions) as totalImpressions ,AVG(b.cpm) as avgCpm,a.host_url from  ams_user_websites a , ams_website_advertiser_revenue b where a.id=b.id_website AND b.date >= ? AND b.date <= ? group by host_url order by totalAmount");
			lQueryGetWebsiteRevenueData.setParameter(1, formatter.format(startDate));
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(endDate));
			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
		}

		for (int i = 0; i < lRevenueWebsiteData.size(); i++) {
			// ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
			ArrayNode lJsonNodeRevenueData = objectMapper.createArrayNode();
			Object[] lArrayRevenueData = (Object[]) lRevenueWebsiteData.get(i);
			lJsonNodeRevenueData.add(lArrayRevenueData[3].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[1].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[2].toString());
			lJsonNodeRevenueData.add("");

			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;
	}

	public JsonNode getRevenuePublisherWiseForUser(Integer id, Date startDate, Date endDate, String userType) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		List lRevenueWebsiteData = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		if (userType.equals(Constants.USER_TYPE_ADMIN)) {

			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select SUM(a.amount) as totalAmount,sum(a.impressions) as totalImpressions,AVG(a.cpm) as avgCpm,c.company_name from ams_website_advertiser_revenue a  , ams_user_websites b , ams_users c where a.id_website = b.id AND b.id_user = c.id  AND a.date >= ? AND a.date <= ?  group by company_name order by totalAmount DESC");
			lQueryGetWebsiteRevenueData.setParameter(1, formatter.format(startDate));
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(endDate));
			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
			for (int i = 0; i < lRevenueWebsiteData.size(); i++) {
				// ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
				ArrayNode lJsonNodeRevenueData = objectMapper.createArrayNode();
				Object[] lArrayRevenueData = (Object[]) lRevenueWebsiteData.get(i);
				lJsonNodeRevenueData.add(lArrayRevenueData[3].toString());
				lJsonNodeRevenueData.add(lArrayRevenueData[0].toString());
				lJsonNodeRevenueData.add(lArrayRevenueData[1].toString());
				lJsonNodeRevenueData.add(lArrayRevenueData[2].toString());
				lJsonNodeRevenueData.add("");

				arrayNode.add(lJsonNodeRevenueData);
			}
		}
		return arrayNode;
	}

	public JsonNode getWebSiteWiseReport(Integer id, String userType, JsonNode jsnNode) {
		ObjectMapper objectMapper = new ObjectMapper();
		String lReportDuration = jsnNode.get("reportDuration").asText();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		Date startDate = new Date();
		List lRevenueWebsiteData = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		if (userType.equals(Constants.USER_TYPE_PUBLISHER)) {
			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select b.amount,b.impressions,b.cpm,a.host_url,b.date from  ams_user_websites a , ams_website_advertiser_revenue b where a.id=b.id_website AND a.id in ( select id from ams_user_websites where id_user = ?) and b.date >= ? AND b.date <= ? order by date DESC");
			lQueryGetWebsiteRevenueData.setParameter(1, id);
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(DateUtil.subtractDays(startDate, 29)));
			lQueryGetWebsiteRevenueData.setParameter(3, formatter.format(startDate));

			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
		}

		for (int i = 0; i < lRevenueWebsiteData.size(); i++) {
			// ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
			ArrayNode lJsonNodeRevenueData = objectMapper.createArrayNode();
			Object[] lArrayRevenueData = (Object[]) lRevenueWebsiteData.get(i);
			lJsonNodeRevenueData.add(lArrayRevenueData[3].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[4].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[1].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[2].toString());

			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;
	}

	public JsonNode getDateWiseRevenueReport(Integer id, String userType, JsonNode jsnNode) {
		ObjectMapper objectMapper = new ObjectMapper();
		String lReportDuration = jsnNode.get("reportDuration").asText();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		Date startDate = new Date();
		List lRevenueWebsiteData = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		if (userType.equals(Constants.USER_TYPE_PUBLISHER)) {
			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"select sum(b.amount),sum(b.impressions),AVG(b.cpm),b.date from  ams_user_websites a , ams_website_advertiser_revenue b where a.id=b.id_website AND a.id in ( select id from ams_user_websites where id_user = ?) and b.date >= ? AND b.date <= ? group by date order by date DESC");
			lQueryGetWebsiteRevenueData.setParameter(1, id);
			lQueryGetWebsiteRevenueData.setParameter(2, formatter.format(DateUtil.subtractDays(startDate, 29)));
			lQueryGetWebsiteRevenueData.setParameter(3, formatter.format(startDate));
			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
		}

		for (int i = 0; i < lRevenueWebsiteData.size(); i++) {
			ArrayNode lJsonNodeRevenueData = objectMapper.createArrayNode();
			Object[] lArrayRevenueData = (Object[]) lRevenueWebsiteData.get(i);
			lJsonNodeRevenueData.add(lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[1].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[2].toString());
			lJsonNodeRevenueData.add(lArrayRevenueData[3].toString());
			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;
	}

	public ByteArrayInputStream downloadWebSiteWiseReport(Integer id, String userTypePublisher, JsonNode jsonNode)
			throws IOException, ParseException {
		//JsonNode revenueData = this.getWebSiteWiseReport(id, userTypePublisher, jsonNode);
		JsonNode lData = revenueProcessorService.fetchQueryData(jsonNode);
		String[] columns = { "Website", "Date", "Revenue($)", "Impressions", "CPM" };
		return excelService.generateExcelReport((ArrayNode) lData, columns);

	}

	public ByteArrayInputStream downloadMediaWiseReport(Integer id, String userTypePublisher, JsonNode jsonNode)

			throws IOException, ParseException {
		//JsonNode revenueData = this.getWebSiteWiseReport(id, userTypePublisher, jsonNode);
		JsonNode lData = revenueProcessorService.fetchQueryData(jsonNode);
		String[] columns = { "Website", "Date", "Revenue($)", "Impressions", "CPM" ,"adType"};
		return excelService.generateExcelMediaReport((ArrayNode) lData, columns);

	}

	public ByteArrayInputStream downloadDateWiseRevenueReport(Integer id, String userTypePublisher, JsonNode jsonNode)
			throws IOException, ParseException {
//		JsonNode revenueData = this.getDateWiseRevenueReport(id, userTypePublisher, jsonNode);
		JsonNode lData = revenueProcessorService.fetchQueryData(jsonNode);

		String[] columns = {  "Date","Revenue($)", "Impressions", "CPM", };
		return excelService.generateExcelReportDateWise((ArrayNode) lData, columns);

	}

	public ByteArrayInputStream downloadAdvertiserWiseReport(Integer id, String userTypePublisher, JsonNode jsonNode)
			throws IOException, ParseException {
//		JsonNode revenueData = this.getDateWiseRevenueReport(id, userTypePublisher, jsonNode);
		JsonNode lData = revenueProcessorService.fetchQueryData(jsonNode);


		String[] columns = { "Advertiser", "Date","Revenue($)", "Impressions", "CPM", };

		return excelService.generateExcelReport((ArrayNode) lData, columns);

	}

	public ByteArrayInputStream downloadPublisherWiseReport(Integer id, String userTypePublisher, JsonNode jsonNode)
			throws IOException, ParseException {
//		JsonNode revenueData = this.getDateWiseRevenueReport(id, userTypePublisher, jsonNode);
		JsonNode lData = revenueProcessorService.fetchQueryData(jsonNode);

		String[] columns = { "Publisher", "Date","Revenue($)", "Impressions", "CPM", };

		return excelService.generateExcelReport((ArrayNode) lData, columns);

	}

	public JsonNode getAllPublisherDetails(Integer id) throws JSONException, JsonProcessingException {
		ObjectMapper lobjectMapper = new ObjectMapper();
		ObjectNode lobjectNode = lobjectMapper.createObjectNode();
		Optional<User> lprofile = userRepository.findById(id);
		List<AmsPublisherContact> luser = contactService.findByUserId(id);
		List<UserWebsite> lwebsites = websiteService.getWebsiteByUserID(id);
		List<BankDetails> lBankDetails = bankService.getBankListByUserId(id);
		lobjectNode.putPOJO("profileDetails", lprofile);
		lobjectNode.putPOJO("contactDetails", luser);
		lobjectNode.putPOJO("bankDetails", lBankDetails);
		lobjectNode.putPOJO("websiteDetails", lwebsites);

		return lobjectNode;

	}

	public User updateDetails(User user, User exsistingUser) {
		exsistingUser.setCompanyName(user.getCompanyName());
		exsistingUser.setGstin(user.getGstin());
		exsistingUser.setAddressLineOne(user.getAddressLineOne());
		exsistingUser.setAddressLineTwo(user.getAddressLineTwo());
		exsistingUser.setPostOffice(user.getPostOffice());
		exsistingUser.setTaluk(user.getTaluk());
		exsistingUser.setDistrict(user.getDistrict());
		exsistingUser.setState(user.getState());
		return userRepository.save(exsistingUser);

	}

	public ByteArrayInputStream generateExcelAdvertiserDetails() throws IOException {
		String[] COLUMNs = { "Advertiser Name", "GSTIN	", "Contact Person", "Contact Number", "Email","Publisher Name","Website_Url","pubShare","ergShare","Status" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet("Report");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.BLUE.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			int rowIdx = 1;
			List<User> advertiserDetails = this.getAllAdvertiser();
			
			for (User lUser : advertiserDetails) {
				
				ArrayNode AllDetails = websiteService.ViewAdvertiserWebsiteMapping(lUser.getId());
				for (JsonNode User : AllDetails) {
					Row row = sheet.createRow(rowIdx++);
				row.createCell(0).setCellValue(lUser.getCompanyName());
				row.createCell(1).setCellValue(lUser.getGstin());
				row.createCell(2).setCellValue(lUser.getContactPersonName());
				row.createCell(3).setCellValue(lUser.getContactPersonNumber());
				row.createCell(4).setCellValue(lUser.getEmail());
				row.createCell(5).setCellValue( User.get("company_name").asText());
				row.createCell(6).setCellValue( User.get("website_url").asText());
				 String pubshare = User.get("pub_share").asDouble()*100 +"%";
				
				row.createCell(7).setCellValue(pubshare);
				 String ergshare = User.get("erg_share").asDouble()*100 +"%";
				row.createCell(8).setCellValue(ergshare);
				if(User.get("status")!=null) {
				row.createCell(9).setCellValue( User.get("status").asText());
				}
				}
			}
  
			sheet.autoSizeColumn(1);
		      sheet.autoSizeColumn(0);
		      sheet.autoSizeColumn(2);
		      sheet.autoSizeColumn(3);
		      sheet.autoSizeColumn(4);
		      sheet.autoSizeColumn(5);
		      sheet.autoSizeColumn(6);
		      sheet.autoSizeColumn(7);
		      sheet.autoSizeColumn(8);
		      sheet.autoSizeColumn(9);
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public ByteArrayInputStream generateExcelPublisherDetails() throws IOException {
		String[] COLUMNs = { "Publisher Name", "GSTIN	", "Contact Person", "Contact Number", "Email" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet("Report");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.BLUE.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			int rowIdx = 1;
			List<User> PublisherDetails = this.getAllPublishers();

			for (User lUser : PublisherDetails) {
				Row row = sheet.createRow(rowIdx++);

				row.createCell(0).setCellValue(lUser.getCompanyName());
				row.createCell(1).setCellValue(lUser.getGstin());
				row.createCell(2).setCellValue(lUser.getContactPersonName());
				row.createCell(3).setCellValue(lUser.getContactPersonNumber());
				row.createCell(4).setCellValue(lUser.getEmail());
			}

			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public JsonNode getPublisherRevenueWebsite() throws JSONException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		Query query = entityManager.createNativeQuery(
				"SELECT  website.id_user, count(distinct(website.id)) as website_count ,user.company_name, user.status,"
						+ "round(avg(pub_share), 2) as avg_revenue " + "FROM ams_users as user "
						+ "INNER JOIN ams_user_websites as website " + "ON user.id = website.id_user "
						+ "INNER JOIN ams_website_advertiser_revenue_share as revenue "
						+ "ON website.id =revenue.id_website " + "GROUP BY id_user;");
		List resultList = query.getResultList();

		for (int i = 0; i < resultList.size(); i++) {
			ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
//    		ArrayNode lJsonNodeRevenueData = objectMapper.createArrayNode();
			Object[] lArrayRevenueData = (Object[]) resultList.get(i);
			lJsonNodeRevenueData.put("id", lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.put("website_Count", lArrayRevenueData[1].toString());
			lJsonNodeRevenueData.put("company_name", lArrayRevenueData[2].toString());
			if (lArrayRevenueData[3] != null) {
				lJsonNodeRevenueData.put("status", lArrayRevenueData[3].toString());
			}
			lJsonNodeRevenueData.put("avg_pub_share", lArrayRevenueData[4].toString().substring(2));

			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;

	}

	public ByteArrayInputStream getPublisherRevenueDetailExcel() throws IOException, JSONException {
		String[] COLUMNs = { "id", "Publisher Name", "Number Of Website	", "Publisher Share" };
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
			Sheet sheet = workbook.createSheet("Report");

			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.BLUE.getIndex());

			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			// Row for Header
			Row headerRow = sheet.createRow(0);

			// Header
			for (int col = 0; col < COLUMNs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(COLUMNs[col]);
				cell.setCellStyle(headerCellStyle);
			}

			int rowIdx = 1;
			JsonNode PublisherDetails = this.getPublisherRevenueWebsite();

			for (JsonNode lUser : PublisherDetails) {
				Row row = sheet.createRow(rowIdx++);

				row.createCell(0).setCellValue(lUser.get("id").asText());
				row.createCell(2).setCellValue(lUser.get("website_Count").asText());
				row.createCell(1).setCellValue(lUser.get("company_name").asText());
				row.createCell(3).setCellValue(lUser.get("avg_pub_share").asText());

			}

			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
	}

	public ArrayNode getUserDetailsForAds() {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		Query query = entityManager.createNativeQuery(
				"select a.company_name, a.email , b.host_url,b.id as id_website,b.ads_txt_status ,b.ads_txt_status_date,b.idStatus from ams_users a INNER JOIN ams_user_websites b ON a.id=b.id_user");
		List resultList = query.getResultList();
		for (int i = 0; i < resultList.size(); i++) {
			ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
//    		ArrayNode lJsonNodeRevenueData = objectMapper.createArrayNode();
			Object[] lArrayRevenueData = (Object[]) resultList.get(i);
			lJsonNodeRevenueData.put("id", lArrayRevenueData[3].toString());
			lJsonNodeRevenueData.put("website", lArrayRevenueData[2].toString());
			lJsonNodeRevenueData.put("company_name", lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.put("email", lArrayRevenueData[1].toString());
			if (lArrayRevenueData[4] != null) {
				lJsonNodeRevenueData.put("adsStatus", lArrayRevenueData[4].toString());
			}
			if (lArrayRevenueData[5] != null) {
				lJsonNodeRevenueData.put("adsStatusDate", lArrayRevenueData[5].toString());
			}
			if (lArrayRevenueData[6] != null) {
				lJsonNodeRevenueData.put("idStatus", lArrayRevenueData[6].toString());
			}
			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;
	}

	public String passwordEncryption(String password) throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
		keyGenerator.init(128);
		SecretKey secretKey = keyGenerator.generateKey();
		Cipher cipher = Cipher.getInstance("AES");
		byte[] plainTextByte = password.getBytes();
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedByte = cipher.doFinal(plainTextByte);
		Base64.Encoder encoder = Base64.getEncoder();
		String encryptedText = encoder.encodeToString(encryptedByte);
		return encryptedText;

//        String passwordToHash = password;
//     
//	        String generatedPassword = null;
//	        try {
//	            // Create MessageDigest instance for MD5
//	            MessageDigest md = MessageDigest.getInstance("MD5");
//	            //Add password bytes to digest
//	            md.update(passwordToHash.getBytes());
//	            //Get the hash's bytes 
//	            byte[] bytes = md.digest();
//	            //This bytes[] has bytes in decimal format;
//	            //Convert it to hexadecimal format
//	            StringBuilder sb = new StringBuilder();
//	            for(int i=0; i< bytes.length ;i++)
//	            {
//	                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
//	            }
//	            //Get complete hashed password in hex format
//	            generatedPassword = sb.toString();
//	        } 
//	        catch (NoSuchAlgorithmException e) 
//	        {
//	            e.printStackTrace();
//	        }
//	        System.out.println(generatedPassword);
//				return generatedPassword;
	}

}
