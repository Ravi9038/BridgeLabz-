package com.erelego.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erelego.model.AmsPublisherContact;
import com.erelego.model.AmsWebsiteAdUnit;
import com.erelego.model.BankDetails;
import com.erelego.repository.AmsPublisherContactRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

@Service
@Transactional
public class AmsPublisherContactService {

	@Autowired
	private AmsPublisherContactRepository contactRepository;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public List<AmsPublisherContact> listAll(){
		 return contactRepository.findAll();
	}

	public List<AmsPublisherContact> findByUserId(Integer id) {
		// TODO Auto-generated method stub
		return contactRepository.findByUserId(id);
	}

	public void save(List<AmsPublisherContact> amsPublisherContact) {
		for (AmsPublisherContact lamsPublisherContact : amsPublisherContact) {
			contactRepository.save(lamsPublisherContact);
		}
	
	}

	public Optional<AmsPublisherContact> findById(Integer id) {
		
		return  contactRepository.findById(id);
	
	}

	public void updateContactForProfile(List<AmsPublisherContact> amsPublisherContact) {
		for(AmsPublisherContact pContactDetail : amsPublisherContact) {
			if(pContactDetail.getId() != null &&  pContactDetail.getId() != 0 ) {
				Optional<AmsPublisherContact> existingContact = this.findById(pContactDetail.getId());
			AmsPublisherContact lexistingContact = existingContact.get();
			lexistingContact.setName(pContactDetail.getName());
			lexistingContact.setDesignation(pContactDetail.getDesignation());
			lexistingContact.setContactNumberOne(pContactDetail.getContactNumberOne());
			lexistingContact.setContactNumberTwo(pContactDetail.getContactNumberTwo());
			lexistingContact.setEmail(pContactDetail.getEmail());
			lexistingContact.setIdReportingUserName(pContactDetail.getIdReportingUserName());
			}else {
				contactRepository.save(pContactDetail);
			}

		}
		
	}

	public void deleteContact(Integer id) {
		contactRepository.deleteById(id);
		
	}

	public ByteArrayInputStream generateExcelContactDetails(Integer id) throws IOException {
		String[] COLUMNs = {"Name","Designation	","Contact Number", "EmaiId", "ReportTo"};
		try(
		        Workbook workbook = new XSSFWorkbook();
		        ByteArrayOutputStream out = new ByteArrayOutputStream();
		    ){
		      Sheet sheet = workbook.createSheet("Report");
		   
		      Font headerFont = workbook.createFont();
		      headerFont.setBold(true);
		      headerFont.setColor(IndexedColors.BLUE.getIndex());
		   
		      CellStyle headerCellStyle = workbook.createCellStyle();
		      headerCellStyle.setFont(headerFont);
		   
		      // Row for Header
		      Row headerRow = sheet.createRow(0);
		   
		      // Header
		      for (int col = 0; col < COLUMNs.length; col++) {
		        Cell cell = headerRow.createCell(col);
		        cell.setCellValue(COLUMNs[col]);
		        cell.setCellStyle(headerCellStyle);
		      }
   
		      int rowIdx = 1;
              List<AmsPublisherContact> ContactDetails = this.findByUserId(id);
            
              for (AmsPublisherContact amsPublisherContact : ContactDetails) {
            	  Row row = sheet.createRow(rowIdx++);
            	  
            	  		    	  row.createCell(0).setCellValue(amsPublisherContact.getName());
            	  		    	  row.createCell(1).setCellValue(amsPublisherContact.getDesignation());
            	  		    	  row.createCell(2).setCellValue(amsPublisherContact.getContactNumberOne());
            	  		    	  row.createCell(3).setCellValue(amsPublisherContact.getEmail());
            	  		    	  row.createCell(4).setCellValue(amsPublisherContact.getIdReportingUserName());
			}

		     
			   workbook.write(out);
		      return new ByteArrayInputStream(out.toByteArray());
		    }
	}

	public Optional<AmsPublisherContact> UpdateByID(AmsPublisherContact amsPublisherContact, Integer id) {
		Optional<AmsPublisherContact> existingContact = this.findById(id);
		AmsPublisherContact lexistingContact = existingContact.get();
		lexistingContact.setName(amsPublisherContact.getName());
		lexistingContact.setDesignation(amsPublisherContact.getDesignation());
		lexistingContact.setContactNumberOne(amsPublisherContact.getContactNumberOne());
		lexistingContact.setContactNumberTwo(amsPublisherContact.getContactNumberTwo());
		lexistingContact.setEmail(amsPublisherContact.getEmail());
		return existingContact;
	}

//	public void updateContactForProfile(JsonNode jsonNode) {
//		
//		
//		for (JsonNode lamsPublisherContact : jsonNode) {
//			System.out.println(lamsPublisherContact);
//			Integer contactid = lamsPublisherContact.get("id").asInt();
//			System.out.println(contactid);
//			Optional<AmsPublisherContact> existingContact = this.findById(contactid);
//			AmsPublisherContact lexistingContact = existingContact.get();
//			System.out.println(lexistingContact);
//			lexistingContact.setContactNumberOne(lamsPublisherContact.get("contactNumberOne").asText());
//			lexistingContact.setContactNumberTwo(lamsPublisherContact.get("contactNumberTwo").asText());
//			lexistingContact.setName(lamsPublisherContact.get("name").asText());
//			lexistingContact.setDesignation(lamsPublisherContact.get("designation").asText());
//			lexistingContact.setEmail(lamsPublisherContact.get("email").asText());
//			lexistingContact.setIdReportingUserName(lamsPublisherContact.get("idReportingUserName").asText());
//
//			contactRepository.save(lexistingContact);
//
//		}
//
//}
	
}