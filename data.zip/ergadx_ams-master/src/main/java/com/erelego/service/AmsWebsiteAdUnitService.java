package com.erelego.service;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.tomcat.util.json.JSONParser;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.hibernate.Session;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.PropertyMapper.SourceOperator;
import org.springframework.stereotype.Service;

import com.erelego.model.AmsWebsiteAdUnit;
import com.erelego.repository.AmsWebsiteAdIUnitRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.api.client.util.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

@Service
@Transactional
public class AmsWebsiteAdUnitService {

	
	@Autowired
	private AmsWebsiteAdIUnitRepository  repo;
	
	@Autowired
	private UserWebsiteService websiteService;
	
	@Autowired
	private AmsWebsiteService service;

	@PersistenceContext
	private EntityManager entityManager;
	
	public List<AmsWebsiteAdUnit> listAll() {
		return repo.findAll();
	}

	public void save(AmsWebsiteAdUnit amsWebsiteAdUnit) {
		repo.save(amsWebsiteAdUnit);
	}

	public AmsWebsiteAdUnit get(Integer id) {
		return repo.findById(id).get();
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}

	public void update(AmsWebsiteAdUnit amsWebsiteAdUnit, Integer id) {
		 AmsWebsiteAdUnit existingObject = this.get(id);
		 existingObject.setName(amsWebsiteAdUnit.getName());
		 existingObject.setAdElementSector(amsWebsiteAdUnit.getAdElementSector());
		 existingObject.setElementSector(amsWebsiteAdUnit.getElementSector());
		 existingObject.setCss(amsWebsiteAdUnit.getCss());
		 existingObject.setAdFormat(amsWebsiteAdUnit.getAdFormat());
		 existingObject.setCustomJsData(amsWebsiteAdUnit.getCustomJsData());
		 existingObject.setDevice(amsWebsiteAdUnit.getDevice());
		 existingObject.setDfpAccountNo(amsWebsiteAdUnit.getDfpAccountNo());
		 existingObject.setRefreshDurtion(amsWebsiteAdUnit.getRefreshDurtion());
		 existingObject.setRefreshEnabled(amsWebsiteAdUnit.getRefreshEnabled());
		 existingObject.setSize(amsWebsiteAdUnit.getSize());
		 existingObject.setDivId(amsWebsiteAdUnit.getDivId());
		 existingObject.setOperation(amsWebsiteAdUnit.getOperation());
		 existingObject.setLayout(amsWebsiteAdUnit.getLayout());
		 Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(existingObject);
	}

	public List getSize() {
	
		javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
				"select size from ad_unit_size_data ");
    		List list = lQueryGetWebsiteRevenueData.getResultList();
		return list;
		
	}

	public List mappingAdPage(List<Integer> idAdUnit, Integer id) {
		for (Integer integer : idAdUnit) {
			
			javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"insert into ams_page_ad_units  (id_page , id_ad_unit ) values(?,?)");
			lQueryGetWebsiteRevenueData.setParameter(1,id);
			lQueryGetWebsiteRevenueData.setParameter(2, integer);
			lQueryGetWebsiteRevenueData.executeUpdate();
		}
				return idAdUnit;
	}

	public ArrayNode getmappingAdPage(Integer id) {
		ObjectMapper lObjectMapper = new ObjectMapper();
		ArrayNode arrayNode = lObjectMapper.createArrayNode();
		javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
				"select id, name , size from ams_website_ad_units where id in(select id_ad_unit from ams_page_ad_units where id_page=?)");
		lQueryGetWebsiteRevenueData.setParameter(1,id);
		List result = lQueryGetWebsiteRevenueData.getResultList();
		for (int i = 0; i < result.size(); i++) {
			Object[] lArrayData =  (Object[]) result.get(i);
			ObjectNode arraynode = lObjectMapper.createObjectNode();
			arraynode.put("id",lArrayData[0].toString());
			arraynode.put("name",lArrayData[1].toString());
			arrayNode.add(arraynode);
		}
		return arrayNode;
	}

	public List deletemappingAdPage(List<Integer> idAdUnit, Integer id) {
		
	for (Integer integer : idAdUnit) {
			
			javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
					"delete from  ams_page_ad_units  where id_page=? and id_ad_unit =?");
			lQueryGetWebsiteRevenueData.setParameter(1,id);
			lQueryGetWebsiteRevenueData.setParameter(2, integer);
			lQueryGetWebsiteRevenueData.executeUpdate();
		}
				return idAdUnit;
		
	}

	public ArrayNode getAdPage(Integer id) throws JSONException, JsonMappingException, JsonProcessingException {

		ObjectMapper lObjectMapper = new ObjectMapper();
		ObjectMapper mapper = new ObjectMapper(); 
		ArrayNode arrayNode = lObjectMapper.createArrayNode();
		javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
				"select  name , element_selector,css,type,ad_format,size,refresh_enabled,refresh_durtion,dfp_account_no,custom_js_data,device,operation,div_id,bidders from ams_website_ad_units where id in(select id_ad_unit from ams_page_ad_units where id_page=?)");
		lQueryGetWebsiteRevenueData.setParameter(1,id);
		List result = lQueryGetWebsiteRevenueData.getResultList();
		for (int i = 0; i < result.size(); i++) {
			Object[] lArrayData =  (Object[]) result.get(i);
			ObjectNode arraynode = lObjectMapper.createObjectNode();
			arraynode.put("slot_name", lArrayData[0].toString());
			arraynode.put("element_selector", lArrayData[1].toString());
			    String css = lArrayData[2].toString();
			    if(css.equals("")) {
			    	String empty="{}";
			    JsonNode newNode = mapper.readTree(empty);
		      arraynode.putPOJO("css", newNode);
			    }
			    else  {
			        JsonNode newNode = mapper.readTree(css);
				      arraynode.putPOJO("css", newNode);
			    }
			arraynode.put("type", lArrayData[3].toString());
			arraynode.put("ad_format", lArrayData[4].toString());
			    String s = lArrayData[5].toString();
			    String sizearray = s.replace("[", "").replace("]", "");
			    ArrayNode sizedarray = mapper.createArrayNode();
			    
			    Object[] list = sizearray.split(",");
			   
			    for (int j=0;j<list.length; j+=2){
			    	ArrayList<Object> cars = new ArrayList<Object>();
			    	 String first = list[j].toString().trim();
			    	 Integer firstInteger = Integer.parseInt(first);
			    	 String first1 = list[j+1].toString().trim();
			    	 Integer secondInteger = Integer.parseInt(first1);
			    	cars.add(firstInteger);
			    	cars.add(secondInteger);
			    	sizedarray.addPOJO(cars);
			    }
 
			arraynode.putPOJO("size", sizedarray);

			String refreshEnable = lArrayData[6].toString();
			if(refreshEnable.equalsIgnoreCase("Yes")) {
				arraynode.put("isRefreshEnabled",true );	
			}
			else if(refreshEnable.equalsIgnoreCase("No")) {
				arraynode.put("isRefreshEnabled",false );	
			}
			arraynode.put("refreshDuration", lArrayData[7].toString());
			if(lArrayData[8]!=null) {
			arraynode.put("dfpAccountNo", lArrayData[8].toString());
			}
			if(lArrayData[9]!=null) {
				
				 String js = lArrayData[9].toString();
				 if(js.equals("")) {
					 String empty="{}";
//				  JsonNode newNodes = mapper.readTree(empty);
			      arraynode.putPOJO("custom_js_tag", empty);
				 }
				 else {
//					  JsonNode newNodes = mapper.readTree(js);
				      arraynode.putPOJO("custom_js_tag", js);
				 }
				}
			 String device = lArrayData[10].toString();
			  JsonNode deviceNode = mapper.readTree(device);
			  ArrayNode devciearrayNode = lObjectMapper.createArrayNode();
			 
				 if(deviceNode.get("mobile").toString().equalsIgnoreCase("true")) {
					 arraynode.put("isMobile", true);
					 devciearrayNode.add("Mobile");
				 }
				 else {
					 arraynode.put("isMobile", false);
				 }
				 if(deviceNode.get("tablet").toString().equalsIgnoreCase("true")) {
					 arraynode.put("isTablet", true);
					 devciearrayNode.add("Tablet");
				 }
				 else {
					 arraynode.put("isTablet", false);
				 }
				 if(deviceNode.get("desktop").toString().equalsIgnoreCase("true")) {
					 arraynode.put("isDesktop", true);
					 devciearrayNode.add("Desktop");
				 }
				 else {
					 arraynode.put("isDesktop", false);
				 }
			
			  arraynode.putPOJO("devices", devciearrayNode);
			  arraynode.put("operation", lArrayData[11].toString());
			  if(lArrayData[12]!=null) {
			  arraynode.put("div_id", lArrayData[12].toString()); 
			  }
			  if(lArrayData[13]!=null) {
				  String bidders = lArrayData[13].toString();
				  if(bidders.equals("")) {
				    	String empty="{}";
				    JsonNode newNode = mapper.readTree(empty);
			      arraynode.putPOJO("bidder", newNode);
				    }
				    else  {
				        JsonNode newNode = mapper.readTree(bidders);
					      arraynode.putPOJO("bidders", newNode);
				    }
				 
				  }
				  
			arrayNode.add(arraynode);
		}
		return  arrayNode;
	}

	

	
	
}
