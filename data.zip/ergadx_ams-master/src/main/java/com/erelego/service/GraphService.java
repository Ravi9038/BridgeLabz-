package com.erelego.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Transactional
@Service
public class GraphService {

	@PersistenceContext
	private EntityManager entityManager;
	
	public ArrayNode getRevenueShare(JsonNode jsonNode, Integer id) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		List lRevenueWebsiteData = null;
		String startDate = jsonNode.get("start_date").asText();
		String endDate = jsonNode.get("end_date").asText();
	
			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
				"select sum(b.amount), sum(b.impressions),avg(b.cpm) as ecpm ,c.company_name,DATE_FORMAT(b.date, '%d-%m-%Y') as date ,c.id as id_advertiser from   ams_website_advertiser_revenue b " + 
				"INNER JOIN  ams_users c ON b.id_advertiser =c.id where  c.id =? and b.date >= ? AND b.date <= ?  group by date,id_advertiser order by date  "	);
			lQueryGetWebsiteRevenueData.setParameter(1, id);
			lQueryGetWebsiteRevenueData.setParameter(2, startDate);
			lQueryGetWebsiteRevenueData.setParameter(3, endDate);
			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
		

		for (int i = 0; i < lRevenueWebsiteData.size(); i++) {
			// ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
			ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
			Object[] lArrayRevenueData = (Object[]) lRevenueWebsiteData.get(i);
			lJsonNodeRevenueData.put("revenue",lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.put("impression",lArrayRevenueData[1].toString());
			lJsonNodeRevenueData.put("cpm",lArrayRevenueData[2].toString());
			lJsonNodeRevenueData.put("companyName",lArrayRevenueData[3].toString());
			lJsonNodeRevenueData.put("date",lArrayRevenueData[4].toString());
			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;
		
	}

	public ArrayNode getRevenueShareForAll(JsonNode jsonNode) {
		ObjectMapper objectMapper = new ObjectMapper();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		List lRevenueWebsiteData = null;
		String startDate = jsonNode.get("start_date").asText();
		String endDate = jsonNode.get("end_date").asText();
	
			Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery(
				"select sum(b.amount), sum(b.impressions),avg(b.cpm) as ecpm ,DATE_FORMAT(b.date, '%d-%m-%Y') as date  from   ams_website_advertiser_revenue b " + 
				" where  b.date >= ? AND b.date <= ?  group by date order by date  ");

			lQueryGetWebsiteRevenueData.setParameter(1, startDate);
			lQueryGetWebsiteRevenueData.setParameter(2, endDate);
			lRevenueWebsiteData = lQueryGetWebsiteRevenueData.getResultList();
		

		for (int i = 0; i < lRevenueWebsiteData.size(); i++) {
			// ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
			ObjectNode lJsonNodeRevenueData = objectMapper.createObjectNode();
			Object[] lArrayRevenueData = (Object[]) lRevenueWebsiteData.get(i);
			lJsonNodeRevenueData.put("revenue",lArrayRevenueData[0].toString());
			lJsonNodeRevenueData.put("impression",lArrayRevenueData[1].toString());
			lJsonNodeRevenueData.put("cpm",lArrayRevenueData[2].toString());
			
			lJsonNodeRevenueData.put("date",lArrayRevenueData[3].toString());
			arrayNode.add(lJsonNodeRevenueData);
		}
		return arrayNode;
		
	}
}
