package com.erelego.service;

import org.springframework.stereotype.Service;
import com.erelego.model.BankDetails;
import com.erelego.repository.*;
import com.fasterxml.jackson.databind.JsonNode;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.util.List;
import javax.transaction.Transactional;

@Service
@Transactional
public class BankDetailsService {
	@Autowired
	private BankDetailsRepository repo;

	public List<BankDetails> listAll() {
		return repo.findAll();
	}

	public BankDetails save(BankDetails bankdetails) {
		return repo.save(bankdetails);

	}

	public List<BankDetails> getBankListByUserId(Integer id) {
		return repo.findByUserId(id);
	}

	public BankDetails get(Integer id) {
		return repo.findById(id).get();
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}


	public void updateDataforId(List<BankDetails> pLstBankDetails) {
		
		for(BankDetails pBankDetail : pLstBankDetails) {
			if(pBankDetail.getId() != null &&  pBankDetail.getId() != 0 ) {
				BankDetails existBankDetail = this.get(pBankDetail.getId());
				existBankDetail.setAccountNumber(pBankDetail.getAccountNumber());
				
				existBankDetail.setPayeeName(pBankDetail.getPayeeName());
				existBankDetail.setIfscCode(pBankDetail.getIfscCode());
				existBankDetail.setIfscSwiftCode(pBankDetail.getIfscSwiftCode());
			}else {
				repo.save(pBankDetail);
			}

		}
		
	}

	public BankDetails saveAll(List<BankDetails> bankdetails) {
		for (BankDetails lbankDetails : bankdetails) {
			repo.save(lbankDetails);
		}
		return null;
	}
}
