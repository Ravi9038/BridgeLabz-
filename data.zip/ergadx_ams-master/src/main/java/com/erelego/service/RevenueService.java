package com.erelego.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erelego.model.InvoiceDetails;
import com.erelego.model.InvoiceItem;
import com.erelego.model.User;
import com.erelego.model.UserWebsite;

import com.erelego.repository.RevenueRepository;
import com.erelego.service.UserService;
import com.erelego.service.UserWebsiteService;

@Service
@Transactional
public class RevenueService {

	@Autowired
	private RevenueRepository repo;

	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	private UserService userService;
	@Autowired
	private UserWebsiteService websiteService;

	public List generateInvoices() throws ParseException {
			List<User> lPublisherList = userService.getAllPublishers();
			List<Double> lrevenue= new ArrayList<>();
			//For each user
			for (User user : lPublisherList) {
			 	int lUserId=user.getId();
			 	//System.out.println(id);
		 	List<UserWebsite> websiteId=websiteService.getWebsiteByUserID(lUserId);
			 	
		 	
			List<Integer> web=new ArrayList();
		        for (UserWebsite userweb : websiteId) {
		        	int lWebsiteId=userweb.getId();
		             web.add(lWebsiteId);
	}
		        System.out.println(web);

		        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); 
		         Calendar aCalendar = Calendar.getInstance(); aCalendar.set(Calendar.DATE, 1);
		         aCalendar.add(Calendar.DAY_OF_MONTH, -1); Date lastDateOfPreviousMonth =
		         aCalendar.getTime();
		         String endDate =formatter.format(lastDateOfPreviousMonth); // System.out.println(endDate);
		         aCalendar.set(Calendar.DATE, 1); Date firstDateOfPreviousMonth =
		         aCalendar.getTime(); String
		         startDate=formatter.format(firstDateOfPreviousMonth); //
		         Double lResult = null;
		       for(int i=0;i<web.size();i++) {
		    	   int lWebsiteId=web.get(i);
		    	   javax.persistence.Query lQueryGetWebsiteRevenueData = entityManager.createNativeQuery("select sum(amount) from ams_website_advertiser_revenue where id_website = ?  AND date between ? and ?" );
		    	      lQueryGetWebsiteRevenueData.setParameter(1, lWebsiteId);
		    			    lQueryGetWebsiteRevenueData.setParameter(2, startDate);
		    			    lQueryGetWebsiteRevenueData.setParameter(3, endDate); 
		    			    lResult = (Double)lQueryGetWebsiteRevenueData.getSingleResult();  
		    			    System.out.println(lResult);
		    	   
		       }
			}
			return null;
	}
}
/*
 * SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd"); Date lToday
 * = new Date(); String date = formatter.format(new Date()); java.sql.Date
 * day=new java.sql.Date(lToday.getTime());
 * 
 * 
 * Calendar aCalendar = Calendar.getInstance(); aCalendar.set(Calendar.DATE, 1);
 * aCalendar.add(Calendar.DAY_OF_MONTH, -1); Date lastDateOfPreviousMonth =
 * aCalendar.getTime(); String endDate
 * =formatter.format(lastDateOfPreviousMonth); // System.out.println(endDate);
 * aCalendar.set(Calendar.DATE, 1); Date firstDateOfPreviousMonth =
 * aCalendar.getTime(); String
 * startDate=formatter.format(firstDateOfPreviousMonth); //
 * System.out.println(startDate); float lTotalAmount = 0.0f; InvoiceDetails
 * lInvoiceDetails=new InvoiceDetails(); Set<InvoiceItem> lSetInvoiceItems = new
 * HashSet<InvoiceItem>();
 */

/*
 * Double lResult = null; javax.persistence.Query lQueryGetWebsiteRevenueData =
 * entityManager.
 * createNativeQuery("select sum(amount) from ams_website_advertiser_revenue where id_website = ?  AND date between ? and ?"
 * ); lQueryGetWebsiteRevenueData.setParameter(1, lWebsiteId);
 * lQueryGetWebsiteRevenueData.setParameter(2, startDate);
 * lQueryGetWebsiteRevenueData.setParameter(3, endDate); lResult = (Double)
 * lQueryGetWebsiteRevenueData.getSingleResult(); //lrevenue.add( lResult);
 * float lAmount = 0.0f; if(lResult != null) lAmount =
 * Float.parseFloat(lResult.toString()); InvoiceItem lInvoiceItem = new
 * InvoiceItem(); lInvoiceItem.setIdWebSite(lWebsiteId);
 * lInvoiceItem.setAmount(lAmount); lInvoiceItem.setLabel(userweb.getHostURL());
 * lInvoiceItem.setInvoiceDetails(lInvoiceDetails);
 * lSetInvoiceItems.add(lInvoiceItem); }
 * 
 * lInvoiceDetails.setUserId(lUserId); lInvoiceDetails.setAmount(lTotalAmount);
 * lInvoiceDetails.setPayCycleId(1); lInvoiceDetails.setDate(day);
 * lInvoiceDetails.setInvoiceItem(lSetInvoiceItems); Session session =
 * this.entityManager.unwrap(Session.class);
 * session.saveOrUpdate(lInvoiceDetails); } return lrevenue;
 */