package com.erelego.components;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.repository.WebsiteAdvertiserRevenueShareRepository;

@Component
@Scope(value=ConfigurableBeanFactory.SCOPE_SINGLETON)
public class WebsiteRevenueShareService {
	private Map<String,WebsiteAdvertiserRevenueShare> websiteRevShareData = new HashMap<String,WebsiteAdvertiserRevenueShare>();	
	
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private WebsiteAdvertiserRevenueShareRepository websiteAdvertiserRevenueShareRepository;
	
	public WebsiteRevenueShareService() {
		
	}
	
	public Map<String,WebsiteAdvertiserRevenueShare> getWebsiteRevShareData(){
		if(this.websiteRevShareData.size() == 0 ) {
			this.loadWebsiteRevShareData();
		}
		return this.websiteRevShareData;
	}
	
	public synchronized void loadWebsiteRevShareData() {
		List<WebsiteAdvertiserRevenueShare> lListWebsiteAdvertiserRevenueShare= websiteAdvertiserRevenueShareRepository.findAll();
		for(WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare : lListWebsiteAdvertiserRevenueShare) {
			String lKey = lWebsiteAdvertiserRevenueShare.getWebsiteAdvertiserRevenueShareId().getWebsiteId() + "-" + lWebsiteAdvertiserRevenueShare.getWebsiteAdvertiserRevenueShareId().getAdvertiserId();
			this.websiteRevShareData.put(lKey, lWebsiteAdvertiserRevenueShare);
		}
	}
	public synchronized void reloadWebsiteRevShareData() {
		Map<String,WebsiteAdvertiserRevenueShare> lWebsiteRevShareData = new HashMap<String,WebsiteAdvertiserRevenueShare>();
		List<WebsiteAdvertiserRevenueShare> lListWebsiteAdvertiserRevenueShare= websiteAdvertiserRevenueShareRepository.findAll();
		for(WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare : lListWebsiteAdvertiserRevenueShare) {
			String lKey = lWebsiteAdvertiserRevenueShare.getWebsiteAdvertiserRevenueShareId().getWebsiteId() + "-" + lWebsiteAdvertiserRevenueShare.getWebsiteAdvertiserRevenueShareId().getAdvertiserId();
			lWebsiteRevShareData.put(lKey, lWebsiteAdvertiserRevenueShare);
		}
		this.websiteRevShareData = lWebsiteRevShareData;
	}
}
