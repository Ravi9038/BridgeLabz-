package com.erelego.components;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value=ConfigurableBeanFactory.SCOPE_SINGLETON)
public class CurrencyRateService {
	private Map<String,Double> currencyRates = new HashMap<String,Double>();	
	@Autowired
	private EntityManager entityManager;
	
	public CurrencyRateService() {
	}
	public Map<String,Double> getCurrencyRates() {
		if(currencyRates.size() == 0) {
			this.loadCurrencyRates();
		}
		return this.currencyRates;
	}
	
	public synchronized void loadCurrencyRates() {
		Query lQueryGetAdsTxtForWebsite = entityManager.createNativeQuery("select src_currency_code,dest_currency_code,conv_rate from ams_currency_rates");
     	List<?> lResultSectionData = lQueryGetAdsTxtForWebsite.getResultList();
    	for(int i=0 ; i < lResultSectionData.size() ; i++) {
    		Object[] lRecordSectionData  = (Object[]) lResultSectionData.get(i);
    		String lKey = lRecordSectionData[0].toString() + "-" + lRecordSectionData[1].toString();
    		Double lConvRate = Double.parseDouble(lRecordSectionData[2].toString());
    		this.currencyRates.put(lKey,lConvRate);
    	}
	}
	public synchronized void reLoadCurrencyRates() {
		Map<String,Double> lCurrencyRates = new HashMap<String,Double>();
		Query lQueryGetAdsTxtForWebsite = entityManager.createNativeQuery("select src_currency_code,dest_currency_code,conv_rate from ams_currency_rates");
     	List<?> lResultSectionData = lQueryGetAdsTxtForWebsite.getResultList();
    	for(int i=0 ; i < lResultSectionData.size() ; i++) {
    		Object[] lRecordSectionData  = (Object[]) lResultSectionData.get(i);
    		String lKey = lRecordSectionData[0].toString() + "-" + lRecordSectionData[1].toString();
    		Double lConvRate = Double.parseDouble(lRecordSectionData[2].toString());
    		lCurrencyRates.put(lKey,lConvRate);
    	}
    	this.currencyRates = lCurrencyRates;
	}
	
	
}

