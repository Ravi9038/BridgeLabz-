package com.erelego.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Entity
@Table(name="ams_advertiser_revenue_processor_config")
public class RevenueProcessorConfiguration {
	@Id
	@Column(name="id_advertiser")
	private int idAdvertiser;
	
	@Column(name="type")
	private String type;
	
	@Column(name="skip_number_of_rows")
	private int skipNumberOfRows;
	
	@Column(name="file_path")
	private String filePath;
	
	@Column(name="ad_type")
	private String adType;
	
	@Column(name="platform_fee")
	private BigDecimal platformFee; 
	
	@Column(name="total_column_available")
	private String isTotalRowPresent;
	
	@Column(name="src_currency_code")
	private String srcCurrencyCode;
	
	@Column(name="dest_currency_code")
	private String decCurrencyCode;
	
	@Column(name="config_data" ,columnDefinition = "TEXT")
	private String configData;
	
	
	public String getAdType() {
		return adType;
	}

	public void setAdType(String adType) {
		this.adType = adType;
	}
	
	public String getSrcCurrencyCode() {
		return srcCurrencyCode;
	}

	public void setSrcCurrencyCode(String srcCurrencyCode) {
		this.srcCurrencyCode = srcCurrencyCode;
	}

	public String getDecCurrencyCode() {
		return decCurrencyCode;
	}

	public void setDecCurrencyCode(String decCurrencyCode) {
		this.decCurrencyCode = decCurrencyCode;
	}

	public int getIdAdvertiser() {
		return idAdvertiser;
	}

	public void setIdAdvertiser(int idAdvertiser) {
		this.idAdvertiser = idAdvertiser;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getSkipNumberOfRows() {
		return skipNumberOfRows;
	}

	public void setSkipNumberOfRows(int skipNumberOfRows) {
		this.skipNumberOfRows = skipNumberOfRows;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getConfigData() {
		return configData;
	}

	public void setConfigData(String configData) {
		
		this.configData = configData;
	}
	
	

	public JsonNode getJsnConfigData() throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readTree(this.configData);
		
	}

	public String getIsTotalRowPresent() {
		return isTotalRowPresent;
	}

	public void setIsTotalRowPresent(String isTotalRowPresent) {
		this.isTotalRowPresent = isTotalRowPresent;
	}

	public BigDecimal getPlatformFee() {
		return platformFee;
	}

	public void setPlatformFee(BigDecimal platformFee) {
		this.platformFee = platformFee;
	}

	
}
