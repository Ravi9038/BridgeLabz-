package com.erelego.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


@Entity
@EntityListeners(AuditingEntityListener.class)
@Audited
@Table(name = "ams_website_pages")
public class AmsWebsitePages extends Auditable<String> {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "id_website")
	private int idWebsite;

	@Column(name="label")
	private String label;
	
	@Column(name="expression")
	private String expression;
	
	@Column(name="page_check_type")
	private String pageCheckType;
	
	@Column(name="page_check_value")
	private String pageCheckValue;
	

   
    @Lob
	@Column(name="devices", columnDefinition="TEXT")
	private java.lang.String devices;
	
    
	
    
	 public String getPageCheckType() {
		return pageCheckType;
	}

	public void setPageCheckType(String pageCheckType) {
		this.pageCheckType = pageCheckType;
	}

	public String getPageCheckValue() {
		return pageCheckValue;
	}

	public void setPageCheckValue(String pageCheckValue) {
		this.pageCheckValue = pageCheckValue;
	}

	
	public java.lang.String getDevices() {
		return devices;
	}
	public void setDevices(java.lang.String devices) {
		this.devices = devices;
	}


	@ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
	 @JoinTable(name = "ams_page_ad_units",
     joinColumns = {
             @JoinColumn(name = "id_page", referencedColumnName = "id",
                     nullable = false, updatable = false)},
     inverseJoinColumns = {
             @JoinColumn(name = "id_ad_unit", referencedColumnName = "id",
                     nullable = false, updatable = false)})
      
	 private Set<AmsWebsiteAdUnit> amsWebsiteAdUnits;
	
	 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIdWebsite() {
		return idWebsite;
	}

	public void setIdWebsite(int idWebsite) {
		this.idWebsite = idWebsite;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getExpression() {
		return expression;
	}

	public void setExpression(String expression) {
		this.expression = expression;
	}

	public AmsWebsitePages() {
		
	}

	public Set<AmsWebsiteAdUnit> getAmsWebsiteAdUnits() {
		return amsWebsiteAdUnits;
	}

	public void setAmsWebsiteAdUnits(Set<AmsWebsiteAdUnit> amsWebsiteAdUnits) {
		this.amsWebsiteAdUnits = amsWebsiteAdUnits;
	}
	

	public AmsWebsitePages(int idWebsite, String label, String expression) {
		super();
		this.idWebsite = idWebsite;
		this.label = label;
		this.expression = expression;
	}

	

}
