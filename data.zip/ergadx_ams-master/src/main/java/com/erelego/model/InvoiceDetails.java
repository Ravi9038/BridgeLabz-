package com.erelego.model;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.erelego.model.*;
//import org.hibernate.annotations.CascadeType;


@Entity
@Table(name = "ams_user_invoice")
@Audited
public class InvoiceDetails extends Auditable<String>
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "id_user")
	private Integer userId;
	@Column(name="user_company_name")
	private String companyName;
	
	@Column(name="company_gstin")
	private String userGstIn;
	@Column(name="user_address_line1")
	private String userAddressLine1;
	@Column(name="user_address_line2")
	private String userAddressLine2;
	@Column(name="user_post_office")
	private String userPostOffice;
	@Column(name="user_taluku")
	private String userTaluku;
	@Column(name="user_district")
	private String userDistrict;
	@Column(name="user_state")
	private String userState;
	
	
	@Column(name = "id_pay_cycle")
	private Integer payCycleId;


	@Column(name = "amount")
	private float amount;
	@Column(name = "deduction")
	private float deduction ;
	@Column(name = "start_date")
	Date startDate;
	@Column(name = "end_date")
	Date endDate;
	@Column(name = "currency")
	private String currency;
	@Column(name = "status")
	private String status;
	
	@Column(name = "net_amount")
	private Double netAmount;
	
	@Column(name="impression")
	private BigDecimal impression;

	@Column(name="tax")
	private Double tax;
	
	
	
	public BigDecimal getImpression() {
		return impression;
	}
	public void setImpression(BigDecimal impression) {
		this.impression = impression;
	}
	@Column(name="attached_file_name")
	private String attachedFileName;
	
	@Column(name="invoice_number")
	private String invoiceNumber;
	
	@OneToMany(mappedBy = "invoiceDetails", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	private Set<InvoiceItem> invoiceItem;
	 
	
	
	public InvoiceDetails()
	{
		
	}
	public Double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(Double netAmount) {
		this.netAmount = netAmount;
	}

	public Double getTax() {
		return tax;
	}

	public void setTax(Double tax) {
		this.tax = tax;
	}
	
	public void setInvoiceItem(Set<InvoiceItem> invoiceItem) {
		this.invoiceItem = invoiceItem;
	}

	
	public Set<InvoiceItem> getInvoiceItem() {
	    return invoiceItem;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getPayCycleId() {
		return payCycleId;
	}
	public void setPayCycleId(Integer payCycleId) {
		this.payCycleId = payCycleId;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public float getDeduction() {
		return deduction;
	}
	public void setDeduction(float deduction) {
		this.deduction = deduction;
	}
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getUserGstIn() {
		return userGstIn;
	}

	public void setUserGstIn(String userGstIn) {
		this.userGstIn = userGstIn;
	}

	public String getUserAddressLine1() {
		return userAddressLine1;
	}

	public void setUserAddressLine1(String userAddressLine1) {
		this.userAddressLine1 = userAddressLine1;
	}

	public String getUserAddressLine2() {
		return userAddressLine2;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setUserAddressLine2(String userAddressLine2) {
		this.userAddressLine2 = userAddressLine2;
	}

	public String getUserPostOffice() {
		return userPostOffice;
	}

	public void setUserPostOffice(String userPostOffice) {
		this.userPostOffice = userPostOffice;
	}

	public String getUserTaluku() {
		return userTaluku;
	}

	public void setUserTaluku(String userTaluku) {
		this.userTaluku = userTaluku;
	}

	public String getUserDistrict() {
		return userDistrict;
	}

	public void setUserDistrict(String userDistrict) {
		this.userDistrict = userDistrict;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}
	
	public String getAttachedFileName() {
		return attachedFileName;
	}
	public void setAttachedFileName(String attachedFileName) {
		this.attachedFileName = attachedFileName;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}


	

	

	
	

}
