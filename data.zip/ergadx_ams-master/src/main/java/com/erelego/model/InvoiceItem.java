package com.erelego.model;
import java.math.BigDecimal;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "ams_user_invoice_item")
@Audited
public class InvoiceItem extends Auditable<String>
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	@Column(name = "id_website")
	private Integer idWebSite;
	@Column(name="label ")
	private String label ;
	@Column(name = "amount")
	private float amount;
	
	
	
	@Column(name="impression")
	private BigDecimal impression;
	
	public BigDecimal getImpression() {
		return impression;
	}

	public void setImpression(BigDecimal impression) {
		this.impression = impression;
	}
	@Column(name = "currency")
	private String currency;
	
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id_invoice")
	private InvoiceDetails invoiceDetails;
	
	public InvoiceItem()
	{
		
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getIdWebSite() {
		return idWebSite;
	}

	public void setIdWebSite(Integer idWebSite) {
		this.idWebSite = idWebSite;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}	
	public InvoiceDetails getInvoiceDetails() {
	    return invoiceDetails;
	}
	public void setInvoiceDetails(InvoiceDetails invoiceDetails) {
		this.invoiceDetails = invoiceDetails;
	}


}
