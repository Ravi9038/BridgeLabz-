package com.erelego.model;


import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;

import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Audited
@Table(name = "ams_website_ad_units")
public class AmsWebsiteAdUnit extends Auditable<String> {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	

	@Column(name="name")
	private String name;
	
	@Column(name="size")
	private String size;
	
	@Column(name="type")
	private String type;
	
	@Column(name="ad_format")
	private String adFormat;
	
	@Lob
	@Column(name="device" , columnDefinition = "TEXT")
	private String device;
	
	@Column(name="element_selector")
	private String 	elementSector;
	
	@Column(name="ad_element_selector")
	private String adElementSector;
	
	@Column(name="div_id")
	private String divId;
	
	@Column(name="operation")
	private String operation;
	
	@Column(name="layout")
	private String layout;
	
	@Lob
	@Column(name="css",columnDefinition = "TEXT")
	private String css;
	
	@Column(name="refresh_enabled")
	private String refreshEnabled;
	
	@Column(name="refresh_durtion")
	private Integer refreshDurtion;
	
	@Column(name="dfp_account_no")
	private String dfpAccountNo;
	
	@Lob
	@Column(name="custom_js_data" ,columnDefinition = "TEXT")
	private String customJsData;
	
	@Lob
	@Column(name="bidders" ,columnDefinition = "TEXT")
	private String bidders;
	
	@Column(name="is_active")
	private byte isActive;
	
	
	
     public String getBidders() {
		return bidders;
	}



	public void setBidders(String bidders) {
		this.bidders = bidders;
	}



	public byte getIsActive() {
		return isActive;
	}



	public void setIsActive(byte isActive) {
		this.isActive = isActive;
	}



	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}

   

	public String getDivId() {
		return divId;
	}



	public void setDivId(String divId) {
		this.divId = divId;
	}



	public String getOperation() {
		return operation;
	}



	public void setOperation(String operation) {
		this.operation = operation;
	}



	public String getLayout() {
		return layout;
	}



	public void setLayout(String layout) {
		this.layout = layout;
	}



	public String getAdFormat() {
		return adFormat;
	}



	public void setAdFormat(String adFormat) {
		this.adFormat = adFormat;
	}



	public String getDevice() {
		return device;
	}



	public void setDevice(String device) {
		this.device = device;
	}



	public String getElementSector() {
		return elementSector;
	}



	public String getSize() {
		return size;
	}



	public void setSize(String size) {
		this.size = size;
	}



	public void setElementSector(String elementSector) {
		this.elementSector = elementSector;
	}



	public String getAdElementSector() {
		return adElementSector;
	}



	public void setAdElementSector(String adElementSector) {
		this.adElementSector = adElementSector;
	}



	public String getCss() {
		return css;
	}



	public void setCss(String css) {
		this.css = css;
	}



	public String getRefreshEnabled() {
		return refreshEnabled;
	}



	public void setRefreshEnabled(String refreshEnabled) {
		this.refreshEnabled = refreshEnabled;
	}



	public Integer getRefreshDurtion() {
		return refreshDurtion;
	}



	public void setRefreshDurtion(Integer refreshDurtion) {
		this.refreshDurtion = refreshDurtion;
	}



	public String getDfpAccountNo() {
		return dfpAccountNo;
	}



	public void setDfpAccountNo(String dfpAccountNo) {
		this.dfpAccountNo = dfpAccountNo;
	}



	public String getCustomJsData() {
		return customJsData;
	}



	public void setCustomJsData(String customJsData) {
		this.customJsData = customJsData;
	}




	@JsonIgnore
	  @ManyToMany(mappedBy = "amsWebsiteAdUnits", fetch = FetchType.EAGER, cascade = { CascadeType.PERSIST, CascadeType.MERGE})
	    private Set<AmsWebsitePages> amsWebsitePages;



	public Set<AmsWebsitePages> getAmsWebsitePages() {
		return amsWebsitePages;
	}



	public void setAmsWebsitePages(Set<AmsWebsitePages> amsWebsitePages) {
		this.amsWebsitePages = amsWebsitePages;
	}



	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}




	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}



	public AmsWebsiteAdUnit() {
		
	}




	public AmsWebsiteAdUnit(String name) {
		super();

		this.name = name;
		
	}







	
	
}
