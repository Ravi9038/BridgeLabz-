package com.erelego.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
@Audited
@Table(name="ams_publisher_contacts")
public class AmsPublisherContact extends Auditable<String> {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	private Integer id;
	
	@Column(name = "id_user")
	private Integer userId;
	
	@Column(name = "name")
	private String name;
	
	@Column(name="designation")
	private String designation;
	
	@Column(name="contact_number_one")
	private String contactNumberOne;
	
	@Column(name="contact_number_two")
	private String contactNumberTwo;
	
	@Column(name="status")
	private String status;
	

	@Column(name = "email")
	private String email;
	
	@Column(name="id_reporting_user_name ")
	private String idReportingUserName ;
	
	

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getId() {
		return id;
	}

	public String getIdReportingUserName() {
		return idReportingUserName;
	}

	public void setIdReportingUserName(String idReportingUserName) {
		this.idReportingUserName = idReportingUserName;
	}

	public void setId(Integer id) {
		this.id = id;
	}




	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public String getContactNumberOne() {
		return contactNumberOne;
	}

	public void setContactNumberOne(String contactNumberOne) {
		this.contactNumberOne = contactNumberOne;
	}

	public String getContactNumberTwo() {
		return contactNumberTwo;
	}

	public void setContactNumberTwo(String contactNumberTwo) {
		this.contactNumberTwo = contactNumberTwo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public  AmsPublisherContact() {
		
	}

	
	
	
}
