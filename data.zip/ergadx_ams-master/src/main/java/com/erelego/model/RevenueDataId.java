package com.erelego.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class RevenueDataId implements Serializable{

	private static final long serialVersionUID = -925994419624332852L;

	@Column(name="id_website")
	int idWebsite;
	
	@Column(name="id_advertiser")
	int idAdvertiser;
	
	@Column(name="date")
	Date date;
	
	@Column(name="ad_type")
	String adType;

	public String getAdType() {
		return adType;
	}

	public void setAdType(String adType) {
		this.adType = adType;
	}

	public int getIdWebsite() {
		return idWebsite;
	}

	public void setIdWebsite(int idWebsite) {
		this.idWebsite = idWebsite;
	}

	public int getIdAdvertiser() {
		return idAdvertiser;
	}

	public void setIdAdvertiser(int idAdvertiser) {
		this.idAdvertiser = idAdvertiser;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
	 @Override
	  public boolean equals(Object o) {
	      if (this == o) return true;
	      if (o == null || getClass() != o.getClass()) return false;
	      RevenueDataId revenueDataId = (RevenueDataId) o;
	      if (this.idWebsite != revenueDataId.idWebsite) return false;
	      if(this.idAdvertiser != revenueDataId.idAdvertiser) return false;
	      if(!this.date.equals(revenueDataId.date)) return false;
	      if(!this.adType.equals(revenueDataId.adType)) return false;
	      return true;
	  }

	  @Override
	  public int hashCode() {
	      return Objects.hash(idWebsite, idAdvertiser,date,adType);
	  }
	
}