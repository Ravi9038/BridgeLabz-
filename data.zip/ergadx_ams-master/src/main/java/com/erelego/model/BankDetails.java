package com.erelego.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "ams_user_bank_details")
@Audited
public class BankDetails extends Auditable<String>
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	private Integer id;
	
	@Column(name = "id_user")
	private Integer userId;
	
	@Column(name = "payee_name")
	private String payeeName;
	
	@Column(name = "account_number")
	private String accountNumber;
	
	@Column(name = "ifsc_code")
	private String ifscCode;
	

	@Column(name = "ifsc_swift_code")
	private String ifscSwiftCode;
	
	@Column(name = "bank_name")
	private String bankName;
	
	@Column(name = "address" , columnDefinition="TEXT")
	private String address;
	
	@Column(name = "routing_number ")
	private String routingNumber;
	
	public BankDetails()
	{
	
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRoutingNumber() {
		return routingNumber;
	}
	public void setRoutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}

	public String getIfscSwiftCode() {
		return ifscSwiftCode;
	}

	public void setIfscSwiftCode(String ifscSwiftCode) {
		this.ifscSwiftCode = ifscSwiftCode;
	}
	
}
