package com.erelego.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Audited
@Table(name = "ams_website_advertiser_revenue")
public class RevenueData extends Auditable<String>{

	@EmbeddedId
	private RevenueDataId revenueDataId;
	
	@Column(name="amount")
	private float amount;

	@Column(name="currency")
	private String currency;
	
	@Column(name="impressions")
	private int impressions;
	
	@Column(name="cpm")
	private float cpm;
	
	@Column(name="total_impressions")
	private int totalImpressions;
	
	@Column(name="clicks")
	private int clicks;
	
	@Column(name="source_currency")
	private String sourceCurrency;
	
	@Column(name="pub_amount")
	private BigDecimal publisherAmount;
	
	@Column(name="erg_amount")
	private BigDecimal erelegoAmount;
	
	@Column(name="cut_amount")
	private BigDecimal platformFee;
	
	public RevenueDataId getRevenueDataId() {
		return revenueDataId;
	}

	public void setRevenueDataId(RevenueDataId revenueDataId) {
		this.revenueDataId = revenueDataId;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public int getImpressions() {
		return impressions;
	}

	public void setImpressions(int impressions) {
		this.impressions = impressions;
	}

	public float getCpm() {
		return cpm;
	}

	public void setCpm(float cpm) {
		this.cpm = cpm;
	}

	public int getTotalImpressions() {
		return totalImpressions;
	}

	public void setTotalImpressions(int totalImpressions) {
		this.totalImpressions = totalImpressions;
	}

	public int getClicks() {
		return clicks;
	}

	public void setClicks(int clicks) {
		this.clicks = clicks;
	}

	public String getSourceCurrency() {
		return sourceCurrency;
	}

	public void setSourceCurrency(String sourceCurrency) {
		this.sourceCurrency = sourceCurrency;
	}

	public BigDecimal getPublisherAmount() {
		return publisherAmount;
	}

	public void setPublisherAmount(BigDecimal publisherAmount) {
		this.publisherAmount = publisherAmount;
	}

	public BigDecimal getErelegoAmount() {
		return erelegoAmount;
	}

	public void setErelegoAmount(BigDecimal erelegoAmount) {
		this.erelegoAmount = erelegoAmount;
	}

	public BigDecimal getPlatformFee() {
		return platformFee;
	}

	public void setPlatformFee(BigDecimal platformFee) {
		this.platformFee = platformFee;
	}
}