package com.erelego.model;
/**
 * 
 * @author Vikas M Gowda
 *
 */
public enum Status {
	ACTIVE("1"), INACTIVE("0");

	private String value;

	private Status(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public static Status getKey(String inputString) {
		for (Status type : Status.values()) {
			if (type.getValue().equals(inputString)) {
				return type;
			}
		}
		return null;
	}

	public static Status getKeyBasedOnKeyString(String inputKeyString) {
		for (Status type : Status.values()) {
			if (type.toString().equals(inputKeyString)) {
				return type;
			}
		}
		return null;
	}

}
