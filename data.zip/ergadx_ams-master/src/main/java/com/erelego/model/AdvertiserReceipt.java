package com.erelego.model;
import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

import org.hibernate.envers.Audited;


@Entity
@Table(name = "ams_user_receipt")
@Audited
public class AdvertiserReceipt extends Auditable<String>
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "id_user")
	private Integer userId;
	@Column(name="user_company_name")
	private String companyName;
	
	@Column(name="company_gstin")
	private String userGstIn;
	@Column(name="user_address_line1")
	private String userAddressLine1;
	@Column(name="user_address_line2")
	private String userAddressLine2;
	@Column(name="user_post_office")
	private String userPostOffice;
	@Column(name="user_taluku")
	private String userTaluku;
	@Column(name="user_district")
	private String userDistrict;
	@Column(name="user_state")
	private String userState;
	
	
	@Column(name = "id_pay_cycle")
	private Integer payCycleId;

	@Column(name = "received_amount")
	private Double receivedAmount;


	@Column(name = "amount")
	private float amount;
	@Column(name = "deduction")
	private float deduction ;
	@Column(name = "start_date")
	Date startDate;
	@Column(name = "end_date")
	Date endDate;
	@Column(name = "currency")
	private String currency;
	@Column(name = "status")
	private String status;
	
	@Column(name = "net_amount")
	private Double netAmount;
	
	@Column(name="impression")
	private BigDecimal impression;

	@Column(name="tax")
	private Double tax;
	


	@Column(name = "received_date")
	Date receivedDate;
	
	public Double getReceivedAmount() {
		return receivedAmount;
	}
	public void setReceivedAmount(Double receivedAmount) {
		this.receivedAmount = receivedAmount;
	}
	
	public Date getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(Date receivedDate) {
		this.receivedDate = receivedDate;
	}
	public BigDecimal getImpression() {
		return impression;
	}
	public void setImpression(BigDecimal impression) {
		this.impression = impression;
	}


	public Double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(Double netAmount) {
		this.netAmount = netAmount;
	}

	public Double getTax() {
		return tax;
	}

	public void setTax(Double tax) {
		this.tax = tax;
	}
	

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getPayCycleId() {
		return payCycleId;
	}
	public void setPayCycleId(Integer payCycleId) {
		this.payCycleId = payCycleId;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public float getDeduction() {
		return deduction;
	}
	public void setDeduction(float deduction) {
		this.deduction = deduction;
	}
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getUserGstIn() {
		return userGstIn;
	}

	public void setUserGstIn(String userGstIn) {
		this.userGstIn = userGstIn;
	}

	public String getUserAddressLine1() {
		return userAddressLine1;
	}

	public void setUserAddressLine1(String userAddressLine1) {
		this.userAddressLine1 = userAddressLine1;
	}

	public String getUserAddressLine2() {
		return userAddressLine2;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setUserAddressLine2(String userAddressLine2) {
		this.userAddressLine2 = userAddressLine2;
	}

	public String getUserPostOffice() {
		return userPostOffice;
	}

	public void setUserPostOffice(String userPostOffice) {
		this.userPostOffice = userPostOffice;
	}

	public String getUserTaluku() {
		return userTaluku;
	}

	public void setUserTaluku(String userTaluku) {
		this.userTaluku = userTaluku;
	}

	public String getUserDistrict() {
		return userDistrict;
	}

	public void setUserDistrict(String userDistrict) {
		this.userDistrict = userDistrict;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}
	
	

	

	

	
	

}
