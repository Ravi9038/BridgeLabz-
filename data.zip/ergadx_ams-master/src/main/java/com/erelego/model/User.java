package com.erelego.model;

import java.time.LocalDateTime;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 
 * @author Vikas M Gowda
 *
 */

@Entity
@EntityListeners(AuditingEntityListener.class)
@Audited
@Table(name = "ams_users")
public class User extends Auditable<String>{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "company_name")
	private String companyName;
	
	@Column(name = "email",insertable=false,updatable=false)
	private String username;

	@Column(name = "id_role")
	private int idRole;

	@Column(name = "email")
	private String email;

	@Column(name = "gstin")
	private String gstin;

	
	@Column(name = "status")
	private String status;

	@Column(name="contact_person_name")
	private String contactPersonName;

	@Column(name="contact_person_number")
	private String contactPersonNumber;
	
	@Column(name="address_line1")	
	private String addressLineOne;
	
	@Column(name="address_line2")	
	private String addressLineTwo;
	
	@Column(name="post_office")	
	private String postOffice;
	
	@Column(name="taluk")	
	private String taluk;	
	
	@Column(name="district")	
	private String district;

	@Column(name="state")	
	private String state;	
	
//	@JsonIgnore
	@Column(name = "password")
	private String password;
	
	@Transient
	private String token;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getIdRole() {
		return idRole;
	}

	public void setIdRole(int idRole) {
		this.idRole = idRole;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactPersonNumber() {
		return contactPersonNumber;
	}

	public void setContactPersonNumber(String contactPersonNumber) {
		this.contactPersonNumber = contactPersonNumber;
	}

	/*
	 * public LocalDateTime getCreatedDate() { return createdDate; }
	 * 
	 * public void setCreatedDate(LocalDateTime createdDate) { this.createdDate =
	 * createdDate; }
	 * 
	 * public LocalDateTime getModifiedDate() { return modifiedDate; }
	 * 
	 * public void setModifiedDate(LocalDateTime modifiedDate) { this.modifiedDate =
	 * modifiedDate; }
	 */

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddressLineOne() {
		return addressLineOne;
	}

	public void setAddressLineOne(String addressLineOne) {
		this.addressLineOne = addressLineOne;
	}

	public String getAddressLineTwo() {
		return addressLineTwo;
	}

	public void setAddressLineTwo(String addressLineTwo) {
		this.addressLineTwo = addressLineTwo;
	}

	public String getPostOffice() {
		return postOffice;
	}

	public void setPostOffice(String postOffice) {
		this.postOffice = postOffice;
	}

	public String getTaluk() {
		return taluk;
	}

	public void setTaluk(String taluk) {
		this.taluk = taluk;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}
