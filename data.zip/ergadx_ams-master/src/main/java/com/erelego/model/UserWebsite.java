package com.erelego.model;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


@Entity
@EntityListeners(AuditingEntityListener.class)
@Audited
@Table(name = "ams_user_websites")
public class UserWebsite extends Auditable<String>
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "id_user")
	private Integer userId;
	
	@Column(name = "name")
	private String name;
	@Column(name = "host_url")
	private String hostURL;
	@Column(name = "http_enabled")
	private Integer httpEnabled;
	@Column(name = "https_enabled")
	private Integer httpsEnabled;
	@Column(name="manager_id")
	private Integer managerId;
	
	public Integer getManagerId() {
		return managerId;
	}

	public void setManagerId(Integer managerId) {
		this.managerId = managerId;
	}

	@Column(name="ads_txt_status")
	private String adsTxtStatus;
	
	@Column(name="idStatus")
	private String idStatus;
	
	@Column(name="ads_txt_status_date")
	@Temporal(TemporalType.TIMESTAMP)
	private java.util.Date adsTxtStatusDate;
	
	public String getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(String idStatus) {
		this.idStatus = idStatus;
	}

	@Column(name="no_failed_adstxt_records")
	private Integer noOfNotFoundAdsTxtRecords;
	
	@Column(name = "active")
	private Integer active;
	
	
	@Column(name="bank_id")
	private Integer bankId;
	
	public UserWebsite()
	{
		
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHostURL() {
		return hostURL;
	}
	public void setHostURL(String hostURL) {
		this.hostURL = hostURL;
	}
	public Integer getHttpEnabled() {
		return httpEnabled;
	}
	public void setHttpEnabled(Integer httpEnabled) {
		this.httpEnabled = httpEnabled;
	}
	public Integer getHttpsEnabled() {
		return httpsEnabled;
	}
	public void setHttpsEnabled(Integer httpsEnabled) {
		this.httpsEnabled = httpsEnabled;
	}
	public String getAdsTxtStatus() {
		return adsTxtStatus;
	}



	public void setAdsTxtStatus(String adsTxtStatus) {
		this.adsTxtStatus = adsTxtStatus;
	}



	public java.util.Date getAdsTxtStatusDate() {
		return adsTxtStatusDate;
	}



	public void setAdsTxtStatusDate(java.util.Date adsTxtStatusDate) {
		this.adsTxtStatusDate = adsTxtStatusDate;
	}



	public Integer getNoOfNotFoundAdsTxtRecords() {
		return noOfNotFoundAdsTxtRecords;
	}



	public void setNoOfNotFoundAdsTxtRecords(Integer noOfNotFoundAdsTxtRecords) {
		this.noOfNotFoundAdsTxtRecords = noOfNotFoundAdsTxtRecords;
	}

	public Integer getActive() {
		return active;
	}
	public void setActive(Integer active) {
		this.active = active;
	}

	public Integer getBankId() {
		return bankId;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}
	
	

}
