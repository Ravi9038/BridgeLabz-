
package com.erelego.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity

@Table(name = "ams_website_advertiser_revenue_share")

@Audited
public class WebsiteAdvertiserRevenueShare extends Auditable<String> {

	@EmbeddedId
	private WebsiteAdvertiserRevenueShareId websiteAdvertiserRevenueShareId;
	
	@Column(name = "pub_share")
	private BigDecimal pubShare;

	@Column(name = "erg_share")
	private BigDecimal ergShare;

	@Column(name = "cut_share")
	private BigDecimal deduction;

	public WebsiteAdvertiserRevenueShareId getWebsiteAdvertiserRevenueShareId() {
		return websiteAdvertiserRevenueShareId;
	}

	public void setWebsiteAdvertiserRevenueShareId(WebsiteAdvertiserRevenueShareId websiteAdvertiserRevenueShareId) {
		this.websiteAdvertiserRevenueShareId = websiteAdvertiserRevenueShareId;
	}

	public BigDecimal getPubShare() {
		return pubShare;
	}

	public void setPubShare(BigDecimal pubShare) {
		this.pubShare = pubShare;
	}

	public BigDecimal getErgShare() {
		return ergShare;
	}

	public void setErgShare(BigDecimal ergShare) {
		this.ergShare = ergShare;
	}

	public BigDecimal getDeduction() {
		return deduction;
	}

	public void setDeduction(BigDecimal deduction) {
		this.deduction = deduction;
		
	}

	
}

