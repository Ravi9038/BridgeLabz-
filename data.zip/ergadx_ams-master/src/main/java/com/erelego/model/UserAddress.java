package com.erelego.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * 
 * @author vikas m gowda
 *
 */

@Entity
@EntityListeners(AuditingEntityListener.class)
@Audited
@Table(name = "ams_user_address")
public class UserAddress extends Auditable<String>{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "id_user")
	private int idUser;

	@Column(name = "address", length = 255, nullable = false,columnDefinition="TEXT")
	private String address;

	@Column(name = "city", length = 255, nullable = false)
	private String city;

	@Column(name = "state", length = 255, nullable = false)
	private String state;

	@Column(name = "country", length = 255, nullable = false)
	private String country;

	@Column(name = "pincode", length = 255, nullable = false)
	private String pincode;

	@Column(name = "contact_emailid", length = 255, nullable = false)
	private String contactEmailid;

	@Column(name = "contact_person_name", length = 255, nullable = false)
	private String contactPersonName;

	@Column(name = "contact_person_number", length = 20, nullable = false)
	private String contactPersonNumber;

	@Column(name = "type", length = 25, nullable = false)
	private String type;

	/*
	 * @Column(name = "status") private Status status;
	 */

	/*
	 * @Column(name = "status" , columnDefinition="TINYINT") private int status;
	 */	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIdUser() {
		return idUser;
	}

	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getContactEmailid() {
		return contactEmailid;
	}

	public void setContactEmailid(String contactEmailid) {
		this.contactEmailid = contactEmailid;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactPersonNumber() {
		return contactPersonNumber;
	}

	public void setContactPersonNumber(String contactPersonNumber) {
		this.contactPersonNumber = contactPersonNumber;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	/*
	 * public int getStatus() { return status; }
	 * 
	 * public void setStatus(int status) { this.status = status; }
	 */

}
