package com.erelego.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable 
public class WebsiteAdvertiserRevenueShareId implements Serializable{

	private static final long serialVersionUID = -8610012015277058482L;

	@Column(name = "id_website")
	private Integer websiteId;

	@Column(name = "id_advertiser")
	private Integer advertiserId;
	
	public Integer getWebsiteId() {
		return websiteId;
	}

	public void setWebsiteId(Integer websiteId) {
		this.websiteId = websiteId;
	}

	public Integer getAdvertiserId() {
		return advertiserId;
	}

	public void setAdvertiserId(Integer advertiserId) {
		this.advertiserId = advertiserId;
	}
	
	@Override
	public boolean equals(Object o) {
      if (this == o) return true;
      if (o == null || getClass() != o.getClass()) return false;
      WebsiteAdvertiserRevenueShareId websiteAdvertiserRevenueShareId = (WebsiteAdvertiserRevenueShareId) o;
      if(this.websiteId != websiteAdvertiserRevenueShareId.websiteId) return false;
      if(this.advertiserId != websiteAdvertiserRevenueShareId.advertiserId) return false;
      return true;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(websiteId, advertiserId);
	}
}
