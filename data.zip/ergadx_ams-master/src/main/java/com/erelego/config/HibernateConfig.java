package com.erelego.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
@EnableTransactionManagement
public class HibernateConfig {
	@Value("${spring.datasource.driverClassName}")
	private String driverClassName;

	@Value("${spring.datasource.url}")
	private String dbUrl;
	
	@Value("${spring.datasource.username}")
	private String userName;

	@Value("${spring.datasource.password}")
	private String password;
	
	@Value("${spring.jpa.properties.hibernate.dialect}")
	private String hibernateDilect;
	
	@Bean(name="entityManagerFactory")
    public LocalSessionFactoryBean sessionFactory() {
        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(dataSource());
        sessionFactory.setPackagesToScan("com.erelego.model");
        sessionFactory.setHibernateProperties(hibernateProperties());
 
        return sessionFactory;
    }
 
    @Bean
    public DataSource dataSource() {
		  BasicDataSource dataSource = new BasicDataSource();
		  dataSource.setDriverClassName(this.driverClassName);
		  dataSource.setUrl(this.dbUrl); dataSource.setUsername(this.userName);
		  dataSource.setPassword(this.password);
		  dataSource.setInitialSize(10);
		  dataSource.setMaxActive(50);
		  dataSource.setMinIdle(10);
		  dataSource.setMaxIdle(15);
		  dataSource.setTestOnBorrow(true);
		  dataSource.setTestOnReturn(true);
		  dataSource.setTestWhileIdle(true);
		  dataSource.setConnectionProperties("connectTimeout=10000");
		  dataSource.setLogAbandoned(true);
		  dataSource.setRemoveAbandoned(true);
		  dataSource.setRemoveAbandonedTimeout(10);
		  dataSource.setTimeBetweenEvictionRunsMillis(30000);
		  return dataSource;
	}
 
    @Bean(name="transactionManager")
    public PlatformTransactionManager hibernateTransactionManager() {
        HibernateTransactionManager transactionManager
          = new HibernateTransactionManager();
        transactionManager.setSessionFactory(sessionFactory().getObject());
        return transactionManager;
    }
    
    
	/*@Bean(name="entityManagerFactory")
	 * public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
	 * LocalContainerEntityManagerFactoryBean em = new
	 * LocalContainerEntityManagerFactoryBean(); em.setDataSource(dataSource());
	 * em.setPackagesToScan("com.erelego.model");
	 * 
	 * JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
	 * em.setJpaVendorAdapter(vendorAdapter);
	 * //em.setJpaProperties(additionalProperties());
	 * 
	 * return em; }
	 */
 
    private final Properties hibernateProperties() {
        Properties hibernateProperties = new Properties();
        hibernateProperties.setProperty(
          "hibernate.dialect", this.hibernateDilect);
    	hibernateProperties.setProperty("hibernate.show-sql", "true");
    	hibernateProperties.setProperty("hibernate.connection.pool_size", "10");
    	hibernateProperties.setProperty("hibernate.connection.autoReconnect", "true");
    	hibernateProperties.setProperty("hibernate.dbcp.initialSize", "2");
    	hibernateProperties.setProperty("hibernate.dbcp.maxWait", "3000");
    	hibernateProperties.setProperty("hibernate.dbcp.validationQuery", "SELCET 1");
    	hibernateProperties.setProperty("hibernate.dbcp.testOnBorrow", "true");
    	hibernateProperties.setProperty("hibernate.dbcp.testOnReturn", "true");
    	hibernateProperties.setProperty("hibernate.dbcp.testWhileIdle", "true");
    	hibernateProperties.setProperty("hibernate.dbcp.timeBetweenEvictionRunsMillis", "30000");
    	hibernateProperties.setProperty("hibernate.dbcp.minEvictableIdleTimeMillis", "30000");
    	hibernateProperties.setProperty("hibernate.dbcp.poolPreparedStatements", "true");
    	hibernateProperties.setProperty("hibernate.hbm2ddl.auto", "validate");
    	hibernateProperties.put("audit_table_suffix","_aud");
    	return hibernateProperties;
    }
}