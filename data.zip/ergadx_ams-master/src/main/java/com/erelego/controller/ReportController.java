package com.erelego.controller;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.*;

import com.erelego.model.InvoiceDetails;
import com.erelego.model.InvoiceItem;
import com.erelego.service.*;
import com.erelego.util.Constants;
import com.fasterxml.jackson.databind.JsonNode;
import com.erelego.repository.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/report")
public class ReportController 
{
	@Autowired
	ReportService reportService;
	
	@PostMapping("/{id}")
	public ResponseEntity<JsonNode> fetchReportData(@PathVariable("id") Integer id , @RequestBody JsonNode jsonNode) throws IOException{
			return reportService.fetchReportData(jsonNode);
	}
	@PostMapping("/download/{id}")
	public ResponseEntity<ByteArrayInputStream> downloadReportData(@PathVariable("id") Integer id , @RequestBody JsonNode jsonNode) throws IOException{
			return reportService.downloadReportData(jsonNode);
	}
}