package com.erelego.controller;
import java.io.PrintStream;
import java.util.*;

import com.erelego.service.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/adstxt")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdsTxtController {
	
	@Autowired
    private AdsTxtService adsTxtService;
	
	@GetMapping("/")
	public ResponseEntity<?> validateAdsTxtForAllWebsites() {
		try {
			adsTxtService.validateAdsTxtForAllWebsites();
			 return new ResponseEntity<>(HttpStatus.OK);			
		}catch(Exception e ) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			 return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> validateAdsTxtForWebsite(@PathVariable Integer id) {
		try {
			
			Set<Object> notMatching = adsTxtService.validateAdsTxtForWebsite(id);
			 return new ResponseEntity<>(notMatching,new HttpHeaders(),HttpStatus.OK);			
		}catch(Exception e ) {
			 System.out.println(e.getMessage());
			 System.out.println(e.getCause());
			 return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
     
	}

	@GetMapping("/website/{id}")
	public ResponseEntity<ArrayNode> getAdsTxtRecordsForWebsite(@PathVariable Integer id){
			ArrayNode lAdsTxtRecords =  adsTxtService.getAdsTxtRecordsForWebsite(id);
			return new ResponseEntity<ArrayNode>(lAdsTxtRecords,new HttpHeaders(),HttpStatus.OK);
	}
	
	@GetMapping("/advertiser/{id}")
	public ResponseEntity<ArrayNode> getAdsTxtRecordsForAdvertiser(@PathVariable Integer id){
			ArrayNode lAdsTxtRecords =  adsTxtService.getAdsTxtRecordsForAdvertiser(id);
			return new ResponseEntity<ArrayNode>(lAdsTxtRecords,new HttpHeaders(),HttpStatus.OK);
	}
	
	@PostMapping("/advertiser/{id}")
	public ResponseEntity<?> insertAdsTxtRecordsForAdvertiser(@PathVariable Integer id ,@RequestBody JsonNode jsonNode){
		try {
			adsTxtService.insertAdsTxtRecordsForAdvertiser(jsonNode);
			return new ResponseEntity<>(HttpStatus.OK);
		}catch(Exception e) {
		return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	}
 
//	@PostMapping("/advertiser/")
//	public ResponseEntity<?> insertFor(@RequestBody JsonNode jsonNode){
//		try {
//			adsTxtService.insertAdsTxtForAdvertiser(jsonNode);
//			return new ResponseEntity<>(HttpStatus.OK);
//		}catch(Exception e) {
//			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
	
	@GetMapping("/get/")
	public ArrayNode getAllData() {
		return 	adsTxtService.getAll();
			

	} 
	@GetMapping("advertiser/get/")
	public ArrayNode getAllDataforAdvertiser() {
		
	return 	adsTxtService.getAllForAdvertiser();
			

	} 
	
	@GetMapping("/notmatched/{id}/getdata/{ids}")
	public ResponseEntity<?> notmatchedAdsTxtRecord(@PathVariable Integer id,@PathVariable String ids ){
		try {
			ArrayNode notmatched = adsTxtService.notMatchedAdsTxtRecords(id,ids);
			return new ResponseEntity<>(notmatched,new HttpHeaders(),HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}



