package com.erelego.controller;
import java.util.*;
import com.erelego.model.Payment;
import com.erelego.model.UserWebsite;
import com.erelego.service.*;
import com.erelego.repository.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class PaymentController 
{
	@Autowired
	private PaymentService service;
	@GetMapping("/api/payment")
	public List<Payment> list() 
	{
	    return service.listAll();
	}
     
	@GetMapping("/api/payment/{id}")
	public ResponseEntity<Payment> get(@PathVariable Integer id) 
	{
	    try {
	    	Payment payment = service.get(id);
	        return new ResponseEntity<Payment>(payment, HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<Payment>(HttpStatus.NOT_FOUND);
	    }      
	}
	
	
	
	@PostMapping("/api/payment")
	public void add(@RequestBody Payment payment) 
	{
	    service.save(payment);
	}
	
	@PutMapping("/api/payment/{id}")
	public ResponseEntity<?> update(@RequestBody Payment payment, @PathVariable Integer id)
	{
	    try {
	    	Payment existPayment = service.get(id);
	        service.save(payment);
	        return new ResponseEntity<>(HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }      
	}
	
	@GetMapping("/api/payment/user/{id}")
	public List<Payment> getPaymentByUserID(@PathVariable Integer id) 
	{
		
		return service.getPaymentByUserID(id);
	}
	
	
	
	@DeleteMapping("/api/payment/{id}")
	public void delete(@PathVariable Integer id)
	{
	    service.delete(id);


}
}
