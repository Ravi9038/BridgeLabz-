package com.erelego.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erelego.model.AmsPublisherContact;
import com.erelego.model.AmsWebsiteAdUnit;
import com.erelego.repository.AmsPublisherContactRepository;
import com.erelego.service.AmsPublisherContactService;
import com.fasterxml.jackson.databind.JsonNode;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/api/usercontact")
public class AmsPublisherContactController {
	
	@Autowired
	private AmsPublisherContactService contactService;
	
	@Autowired
	private AmsPublisherContactRepository repository;
	
	@GetMapping("/details")
	public List<AmsPublisherContact> getAllContact() {

		return contactService.listAll();

		
	}
	
	//to get data for user id
	@GetMapping("/details/{id}")
	public List<AmsPublisherContact> getAllContactForUserId(@PathVariable Integer id) {

		return contactService.findByUserId(id);

		
	}
	
	//to get data for contact id
	@GetMapping("/details/contact/{id}")
	public Optional<AmsPublisherContact> getById(@PathVariable Integer id) {
		return contactService.findById(id);
	}
	
	@PostMapping("/details/contact/{id}")
	public Optional<AmsPublisherContact> UpdateByID(@RequestBody AmsPublisherContact amsPublisherContact ,@PathVariable Integer id) {
		return contactService.UpdateByID(amsPublisherContact,id);
	}
	
	//adding new contact
   @PostMapping("/details")	
	public void addContact(@RequestBody List<AmsPublisherContact> amsPublisherContact) {
	
	    contactService.save(amsPublisherContact);
	}
   
   
   
   //updating contactdetail for profile
//   @PostMapping("/")	
//  	public void updateContact(@RequestBody  JsonNode amsPublisherContact) {
//	  contactService.updateContactForProfile(amsPublisherContact);
//	 
//  	}
   
   @PostMapping("/")	
 	public void updateContact(@RequestBody  List<AmsPublisherContact> amsPublisherContact) {
	  contactService.updateContactForProfile(amsPublisherContact);
	 
 	}
  
   //delete contact
   @DeleteMapping("/details/{id}")
   public void delete(@PathVariable Integer id) {
	   contactService.deleteContact(id);
   }
   
   @GetMapping(value = "/details/download/{id}")
   public ResponseEntity<InputStreamResource> getContactDetailsExcel(@PathVariable Integer id) throws IOException {
		ByteArrayInputStream in = contactService.generateExcelContactDetails(id);
		HttpHeaders headers = new HttpHeaders();
       headers.add("Content-Disposition", "attachment; filename=ContactDetails.xlsx");
       headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
       headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
       return new ResponseEntity<InputStreamResource>(new InputStreamResource(in),headers,HttpStatus.OK);
	 
   }
}

