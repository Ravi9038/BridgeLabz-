package com.erelego.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.erelego.model.BankDetails;
import com.erelego.model.User;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.model.WebsiteAdvertiserRevenueShareId;
import com.erelego.repository.WebsiteAdvertiserRevenueShareRepository;
import com.erelego.service.*;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.*;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.core.JsonProcessingException;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
//@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserWebsiteController {
	@Autowired
	private UserWebsiteService websiteService;

	@Autowired
	private UserService userService;
	
	@PersistenceContext
    private EntityManager entityManager;
	
	@Autowired
	RevenueProcessorService revenueProcessorService;
	
	@Autowired
	WebsiteAdvertiserRevenueShareRepository revenueRepository;
	
	@GetMapping("/api/userwebsite")
	public List<UserWebsite> list() {
		return websiteService.getAllWebsites();
	}

	@GetMapping("/api/userwebsite/{id}")
	public ResponseEntity<UserWebsite> get(@PathVariable Integer id) {
		try {
			UserWebsite userwebsite = websiteService.get(id);
			return new ResponseEntity<UserWebsite>(userwebsite, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<UserWebsite>(HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/api/userwebsite")
	public void add(@RequestBody UserWebsite userwebsite) {
		websiteService.save(userwebsite);
	}

	@PutMapping("/api/userwebsite/{id}")
	public ResponseEntity<?> update(@RequestBody UserWebsite userwebsite, @PathVariable Integer id) {
		try {
			UserWebsite existUserWebsite = websiteService.get(id);
			websiteService.save(userwebsite);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/api/userwebsite/user/{id}")
	public List<UserWebsite> getWebsiteByUserID(@PathVariable Integer id) {

		return websiteService.getWebsiteByUserID(id);
	}

	@DeleteMapping("/api/userwebsite/{id}")
	public void delete(@PathVariable Integer id) {
		websiteService.delete(id);

	}

	@GetMapping("/api/userwebsite/advertisers/{id}")
	public List<Integer> getMappedAdvertisersForWebsite(@PathVariable Integer id) {
		return websiteService.getMappedAdvertisersForWebsite(id);
	}
	
	
	
	@PostMapping("/api/websiteadvertisermapping")
	public void insertWebsiteAdvertiserMapping(@RequestBody JsonNode jsonNode)
			throws JsonMappingException, JsonProcessingException {

		websiteService.insertWebsiteAdvertiserMapping(jsonNode);
	}

	@PostMapping("/api/advertiserrevenue")
	public void insertAdvertiserRevenue(@RequestBody JsonNode jsonNode)
			throws JsonMappingException, JsonProcessingException {

		websiteService.insertAdvertiserRevenue(jsonNode);

	}

	@GetMapping("/api/exceltoDatabase")
	public void excelToDB() {

		websiteService.excelToDB();
	}
	
	@PostMapping("/api/website/revenue/")
	public ResponseEntity<ArrayNode> getWebsiteRevenueDataForReports(@RequestBody JsonNode jsonNode){
		ArrayNode lWebsiteRevenueData = websiteService.getWebsiteRevenueData(jsonNode);
		return new ResponseEntity<ArrayNode>(lWebsiteRevenueData,new HttpHeaders(),HttpStatus.OK);
	}
	
	@PostMapping(value = "/api/website/revenue/download")
    public ResponseEntity<InputStreamResource> getRevenueReportExcel(@RequestBody JsonNode jsonNode) throws IOException {
		ByteArrayInputStream in = websiteService.generateExcelReport(jsonNode);
		HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=report.xlsx");
        headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        return new ResponseEntity<InputStreamResource>(new InputStreamResource(in),headers,HttpStatus.OK);
    }
	
	@GetMapping("/api/website/revenue/{id}")
	public JsonNode getRevenueByuserId(@PathVariable Integer id) {
		return revenueProcessorService.getRevenueByuserId(id);
		
	}
	
	//update for revenue share 
	@PostMapping("/api/website/revenues/")
	public ResponseEntity<?> updatevalue(@RequestBody JsonNode jsonNode){
		ArrayNode lWebsiteRevenueData = websiteService.setWebsiteRevenueData(jsonNode);
	return new ResponseEntity<ArrayNode>(lWebsiteRevenueData,new HttpHeaders(),HttpStatus.OK);
	}
	
		
	@GetMapping("/api/singlewebsite/revenue/{id}")
	public JsonNode getRevenueByWebsiteId(@PathVariable Integer id) {
		return revenueProcessorService.getRevenueByWebsiteId(id);
		
	}
	
	//updation for profile view
	@PutMapping("/api/userwebsite/user")
	public ResponseEntity<?> updateforUserId(@RequestBody JsonNode userwebsite) {
		return websiteService.updateForId(userwebsite);
	}
	//updation for profile view
	@PutMapping("/api/userwebsite/account")
	public ResponseEntity<?> updateAccountforUserId(@RequestBody JsonNode userwebsite) {
		return websiteService.updateAccountforUserId(userwebsite);
	}

	
	@PutMapping("/api/userwebsite/users")
	public void addNewWebsites(@RequestBody List<UserWebsite> userWebsites) {
		websiteService.saveForList(userWebsites);
	}


	
	//Repeat Method
	@PostMapping("/api/userwebsiteRepeat/users")
	public void AddNewWebsiteListRepeat(@RequestBody List<UserWebsite> userWebsite) {
		websiteService.saveForList(userWebsite);
	}
	
	
	
	@GetMapping("/api/website/revenue/avg/{id}")
	public JsonNode getAvgRevenueForWebId(@PathVariable Integer id) {
		return revenueProcessorService.getAvgRevenueForWebId(id);
		
	}
	
	@GetMapping("/api/userwebsite/user/count/")
	public ArrayNode getNumberOfWebsitesForUserId() {
		return websiteService.getNumberOfWebsitesForUserId() ;
	}
	
	//add rev share
	@PostMapping("/api/website/revenues/add")
	public ResponseEntity<?> addRevenue(@RequestBody JsonNode jsonNode){
		ArrayNode lWebsiteRevenueData = websiteService.addWebsiteRevenueData(jsonNode);
	return new ResponseEntity<ArrayNode>(lWebsiteRevenueData,new HttpHeaders(),HttpStatus.OK);
	

	}

	@DeleteMapping("api/website/purge/{id}")
	public ResponseEntity<UserWebsite> getWebsiteID(@PathVariable Integer id) throws Exception {
		try {
			websiteService.purgeUrl(id);
			return new ResponseEntity<UserWebsite>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<UserWebsite>(HttpStatus.NOT_FOUND);
		}
	} 
	
	@DeleteMapping("api/website/idrole/{id}")
	public ResponseEntity<UserWebsite> getWebsiteForIdRole(@PathVariable Integer id) throws Exception {
		try {
			websiteService.getWebsiteForIdRole(id);
			return new ResponseEntity<UserWebsite>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<UserWebsite>(HttpStatus.NOT_FOUND);
		}
	} 
	@PostMapping("/api/website/revenues/{id}")
	public ResponseEntity<?> updatevalueFoeWebsite(@RequestBody JsonNode jsonNode,@PathVariable Integer id){
		ArrayNode lWebsiteRevenueData = websiteService.setWebsiteRevenue(jsonNode,id);
	return new ResponseEntity<ArrayNode>(lWebsiteRevenueData,new HttpHeaders(),HttpStatus.OK);
	

	}
	
	@GetMapping("/api/website/advertiser/{id}")
	public ResponseEntity<?> ViewAdvertiserWebsiteMapping(@PathVariable Integer id){
		ArrayNode lWebsiteRevenueData = websiteService.ViewAdvertiserWebsiteMapping(id);
	return new ResponseEntity<ArrayNode>(lWebsiteRevenueData,new HttpHeaders(),HttpStatus.OK);
	

	}
	
	
	
}
