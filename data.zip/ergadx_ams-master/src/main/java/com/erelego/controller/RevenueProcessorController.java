package com.erelego.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erelego.revenueprocessor.DFPAdvertiserRevenueProcessor;
import com.erelego.service.RevenueProcessorService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.springframework.web.bind.annotation.RequestParam;
@RestController
@RequestMapping("/api/revenueprocessor/")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class RevenueProcessorController {
	@Autowired
	RevenueProcessorService revenueProcessorService;
	private static Logger LOGGER = LogManager.getLogger(RevenueProcessorController.class);

	@GetMapping("/{id}")
	public ResponseEntity<?> fetchRevenueForWebsite(@PathVariable Integer id , @RequestParam("duration") String duration 
			, @RequestParam("start_date") String startDate , @RequestParam("end_date") String endDate) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			ObjectNode objectNode = objectMapper.createObjectNode();
			objectNode.put("duration", duration);
			objectNode.put("start_date", startDate);
			objectNode.put("end_date", endDate);
			revenueProcessorService.fetchRevenueForAdvertiser(id,objectNode);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			LOGGER.error("Error while fetching data for advertiser" , e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/")
	public ResponseEntity<?> fetchRevenueForAllWebsite(@RequestParam("duration") String duration 
			, @RequestParam("start_date") String startDate , @RequestParam("end_date") String endDate) {
		try {
			ObjectMapper objectMapper = new ObjectMapper();
			ObjectNode objectNode = objectMapper.createObjectNode();
			objectNode.put("duration", duration);
			objectNode.put("start_date", startDate);
			objectNode.put("end_date", endDate);
			revenueProcessorService.fetchRevenueForAllAdvertisers(objectNode);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			LOGGER.error("Error while fetching data for advertiser" , e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/query")
	public ResponseEntity<JsonNode> fetchQueryData( @RequestBody JsonNode jsonNode) {
		try {

			JsonNode lData = revenueProcessorService.fetchQueryData(jsonNode);
			return new ResponseEntity<JsonNode>(lData,new HttpHeaders(),HttpStatus.OK);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			LOGGER.error("Error while fetching data for advertiser" , e);
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
}
