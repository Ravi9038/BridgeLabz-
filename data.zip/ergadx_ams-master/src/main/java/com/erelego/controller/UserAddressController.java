package com.erelego.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erelego.exception.RecordNotFoundException;
import com.erelego.model.UserAddress;
import com.erelego.service.UserAddressService;

/**
 * 
 * @author Vikas M Gowda
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/userAddress")
public class UserAddressController {
	@Autowired
	private UserAddressService userAddressService;

	@GetMapping
	public ResponseEntity<List<UserAddress>> getAllUserAdress() {

		List<UserAddress> listOfUserAddress = userAddressService.getAllUserAddress();

		return new ResponseEntity<List<UserAddress>>(listOfUserAddress, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<UserAddress> getUserAddressById(@PathVariable("id") Integer id) throws RecordNotFoundException {

		UserAddress obtainedUserAddress = userAddressService.getUserAddressById(id);

		return new ResponseEntity<UserAddress>(obtainedUserAddress, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping
	public ResponseEntity<UserAddress> createOrUpdateUserAddress(@Validated @RequestBody UserAddress updateUserAddress) throws RecordNotFoundException {

		UserAddress editUserAddress = userAddressService.createOrUpdateUserAddress(updateUserAddress);

		return new ResponseEntity<UserAddress>(editUserAddress, new HttpHeaders(), HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<List<UserAddress>> deleteUserAdressById(@PathVariable("id") Integer id) throws RecordNotFoundException {
		
		userAddressService.deleteUserAddressById(id);
		List<UserAddress> listOfUserAddress = userAddressService.getAllUserAddress();

		return new ResponseEntity<List<UserAddress>>(listOfUserAddress, new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("/userid/{iduser}")
	public ResponseEntity<List<UserAddress>> getUserByIdRole(@PathVariable("iduser") Integer iduser) {

		List<UserAddress> obtainedUserAddress = userAddressService.getUserAddressByUserId(iduser);

		return new ResponseEntity<List<UserAddress>>(obtainedUserAddress, new HttpHeaders(), HttpStatus.OK);
	}

}
