package com.erelego.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import java.text.ParseException;

import java.util.*;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.erelego.model.InvoiceDetails;
import com.erelego.service.*;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.parser.Path;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.io.FileUtils;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItem;
import org.springframework.beans.factory.annotation.*;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpHeaders;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class InvoiceDetailsController {
	@Autowired
	private InvoiceDetailsService service;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private RevenueService revenue;

	@Value("${invoicePath}")
	private String invoiceStoragePath;

	@GetMapping("/api/invoicedetails")
	public List<InvoiceDetails> list() {
		return service.listAll();
	}

	@GetMapping("/api/invoicedetails/{id}")
	public ResponseEntity<InvoiceDetails> get(@PathVariable Integer id) {
		try {
			InvoiceDetails invoicedetails = (InvoiceDetails) service.get(id);
			return new ResponseEntity<InvoiceDetails>(invoicedetails, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<InvoiceDetails>(HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/api/invoicedetails/user/{id}")
	public List<InvoiceDetails> getInvoiceByAdvertiser(@PathVariable Integer id) {
		/*
		 * try { InvoiceDetails invoicedetailsList = service.getInvoiceByAdveritser(id);
		 * return new ResponseEntity<InvoiceDetails>(invoicedetailsList, HttpStatus.OK);
		 * } catch (NoSuchElementException e) { return new
		 * ResponseEntity<InvoiceDetails>(HttpStatus.NOT_FOUND); }
		 */

		return service.getInvoiceByAdveritser(id);
	}

	@PostMapping("/api/invoicedetails")
	public void add(@RequestBody InvoiceDetails invoicedetails) {
		service.save(invoicedetails);
	}

	@PutMapping("/api/invoicedetails/{id}")
	public ResponseEntity<?> update(@RequestBody InvoiceDetails invoicedetails, @PathVariable Integer id) {
		try {
			InvoiceDetails existInvoicedetails = (InvoiceDetails) service.get(id);
			service.save(invoicedetails);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/api/invoicedetails/{id}")
	public void delete(@PathVariable Integer id) {
		service.delete(id);

	}

	//Generate invoice for Publisher
	@GetMapping("/api/invoice/genrateinvoices")
	public List generateInvoices() throws ParseException {
		return (List) service.generateInvoices();
	}

	
	
	
	@GetMapping("api/invoice/pdf/{id}")
	public InvoiceDetails exportPDF(@PathVariable Integer id) throws FileNotFoundException, DocumentException {
		return service.generateInvoicePdf(id);

	}

	// adding a attachment name for the userid
	@PostMapping("api/invoice/pdf/{id}")
	public ResponseEntity<InvoiceDetails> invoiceAttachmentName(@RequestPart("file") MultipartFile file,
			@RequestPart("invoiceNumber") String invoiceNumber, @PathVariable Integer id)
			throws IllegalStateException, IOException {
		return service.addAttachmentName(file, invoiceNumber, id);

	}

	@RequestMapping(value = "/api/invoice/{userid}/view/{invoiceId}", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public ResponseEntity<InputStreamResource> getImage(@PathVariable("userid") Integer id,
			@PathVariable("invoiceId") Integer invoiceid) throws IOException {
		javax.persistence.Query lQuery= entityManager.createNativeQuery(
				"select  attached_file_name from ams_user_invoice where id =?");
		lQuery.setParameter(1, invoiceid);
		String name = lQuery.getSingleResult().toString();
		String directoryName = this.invoiceStoragePath + File.separator + id + File.separator + name;
		
		File imgFile = new File(directoryName);
		ByteArrayInputStream in = new ByteArrayInputStream(FileUtils.readFileToByteArray(imgFile));
		HttpHeaders headers = new HttpHeaders();
		String mimeType = Files.probeContentType(imgFile.toPath());
	
		// headers.add("Content-Disposition", "attachment; filename=test.pdf");
		headers.add("Content-Type", mimeType);
		//headers.add("Content-Type", format);
		return new ResponseEntity<InputStreamResource>(new InputStreamResource(in), headers, HttpStatus.OK);

	}

}

// multipart.transferTo(convFile);
// FileInputStream input = new FileInputStream(imgFile);
// MultipartFile multipartFile = new  MockMultipartFile("file",
//		 imgFile.getName(), "text/plain", IOUtils.toByteArray(input));
// DiskFileItem fileItem = new DiskFileItem("file", "text/plain", false, imgFile.getName(), (int) imgFile.length() , imgFile.getParentFile());
// fileItem.getOutputStream();
// MultipartFile multipartFile = new CommonsMultipartFile(fileItem);

//return ResponseEntity
//        .ok()
//        .contentType(MediaType.IMAGE_JPEG)
//        .body(new InputStreamResource(((MultipartFile) imgFile).getInputStream()));

// byte[] image = new byte[0];
//    try {
//        image = FileUtils.readFileToByteArray(new File(directoryName));
//    } catch (IOException e) {
//        e.printStackTrace();
//    }
//    Inflater inflater = new Inflater();
//	inflater.setInput(image);
//	ByteArrayOutputStream outputStream = new ByteArrayOutputStream(image.length);
//	byte[] buffer = new byte[1024];
//	try {
//		while (!inflater.finished()) {
//			int count = inflater.inflate(buffer);
//			outputStream.write(buffer, 0, count);
//		}
//		outputStream.close();
//	} catch (IOException ioe) {
//	} catch (DataFormatException e) {
//	}
//	return outputStream.toByteArray();
//    return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(image);

