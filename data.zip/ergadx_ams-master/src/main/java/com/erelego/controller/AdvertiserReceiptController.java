package com.erelego.controller;


import java.text.ParseException;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.erelego.model.AdvertiserReceipt;

import com.erelego.service.*;

import org.springframework.beans.factory.annotation.*;

import org.springframework.web.bind.annotation.*;


import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;


@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class AdvertiserReceiptController {
	@Autowired
	private AdvertiserReceiptService service;

	@PersistenceContext
	private EntityManager entityManager;


	@GetMapping("/api/receipt")
	public List<AdvertiserReceipt> list() {
		return service.listAll();
	}

	@GetMapping("/api/receipt/{id}")
	public ResponseEntity<AdvertiserReceipt> get(@PathVariable Integer id) {
		try {
			AdvertiserReceipt lAdvertiserReceipt = (AdvertiserReceipt) service.get(id);
			return new ResponseEntity<AdvertiserReceipt>(lAdvertiserReceipt, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			System.out.println(e.getMessage());
			return new ResponseEntity<AdvertiserReceipt>(HttpStatus.NOT_FOUND);
			
		}
	}

	@GetMapping("/api/receipt/user/{id}")
	public List<AdvertiserReceipt> getInvoiceByAdvertiser(@PathVariable Integer id) {
	
		return service.getInvoiceByAdveritser(id);
	}

	@PostMapping("/api/receipt")
	public void add(@RequestBody AdvertiserReceipt lAdvertiserReceipt) {
		service.save(lAdvertiserReceipt);
	}

	@PostMapping("/api/receipt/{id}")
	public ResponseEntity<?> update(@RequestBody AdvertiserReceipt advertiserReceipt, @PathVariable Integer id) {
		try {
			
			
			service.update(advertiserReceipt,id);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/api/receipt/{id}")
	public void delete(@PathVariable Integer id) {
		service.delete(id);

	}

	
	//Generate Recipt for Advertiser
		@GetMapping("/api/receipt/genratereceipt")
		public List generateInvoicesForAdvertiser() throws ParseException {
			 System.out.println();
			return (List) service.generateInvoicesForAdvertiser();
		}
		

	

}


