package com.erelego.controller;

import java.io.File;
import java.sql.Date;
import java.text.ParseException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


import com.erelego.model.RevenueData;
import com.erelego.service.RevenueService;
import com.erelego.util.DateUtil;


@RestController
public class DatePickerContoler {
	
	@Autowired
	private RevenueService revenue;
	
	@GetMapping("/api/find")
	public List<RevenueData> list() throws ParseException 
	{
	    return revenue.generateInvoices();
	}
	
	//fetch websites for that user
	//for each websites- fetch revenue for that website. - store it in array / map
	//insert into invoice table.
//		javax.persistence.Query insertData=entityManager.createNativeQuery("insert into ams_user_invoice (id_user,id_pay_cycle,amount,date, created_by, created_date, modified_date, modified_by) values(?,?,?,?,?,?,?,?) ");
//		insertData.setParameter(1, id);
//		insertData.setParameter(2, 1);
//		insertData.setParameter(3, lResult);
//		insertData.setParameter(4, date);
//		insertData.setParameter(5, 1);
//		insertData.setParameter(6, date);
//		insertData.setParameter(7, date);
//		insertData.setParameter(8, 1);
//		insertData.executeUpdate();
	/* Date lToday = new Date();
	String date = DateUtil.getFormattedDate(lToday, "yyyy-MM-dd");
	java.sql.Date day = new java.sql.Date(lToday.getTime()); */
	
	
	/*
	public void sendMailWithAttachment(String from,String to, String subject, String body, String fileToAttach) throws MessagingException 
	{
		MimeMessage message=mailSender.createMimeMessage();
		MimeMessageHelper helper;
		helper=new MimeMessageHelper(message,true);
		helper.setFrom(from);	
		helper.setSubject(subject);
		helper.setTo(to);
		helper.setText(body, true);
		FileSystemResource file = new FileSystemResource(new File(fileToAttach));
		helper.addAttachment("logo.jpg", file);
		mailSender.send(message);
		
	}*/
}
