package com.erelego.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erelego.exception.RecordNotFoundException;
import com.erelego.exception.UserAlreadyExistException;
import com.erelego.model.AmsPublisherContact;
import com.erelego.model.BankDetails;
import com.erelego.model.User;
import com.erelego.model.UserWebsite;
import com.erelego.service.UserService;
import com.erelego.util.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.springframework.web.bind.annotation.CrossOrigin;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping
	public ResponseEntity<List<User>> getAllUser() {
		List<User> listOfUser = userService.getAllUser();
		return new ResponseEntity<List<User>>(listOfUser, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/advertisers")
	public ResponseEntity<List<User>> getAllAdvertisers() {
		List<User> listOfUser = userService.getAllAdvertiser();
		return new ResponseEntity<List<User>>(listOfUser, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/publishers")
	public ResponseEntity<List<User>> getAllPublishers() {
		List<User> listOfUser = userService.getAllPublishers();
		return new ResponseEntity<List<User>>(listOfUser, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<User> getUserById(@PathVariable("id") Integer id) throws RecordNotFoundException {
		User obtainedUser = userService.getUserById(id);
		return new ResponseEntity<User>(obtainedUser, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping
	public ResponseEntity<User> createOrUpdate(@Validated @RequestBody User updateUser) throws Exception {
		try {
			User editUser = userService.createOrUpdateUser(updateUser);
			return new ResponseEntity<User>(editUser, new HttpHeaders(), HttpStatus.OK);
		} catch (UserAlreadyExistException e) {
			return new ResponseEntity<User>(HttpStatus.CONFLICT);
		}
		catch (Exception e) {
			return new ResponseEntity<User>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<List<User>> deleteUserById(@PathVariable("id") Integer id) throws RecordNotFoundException {
		userService.deleteUserById(id);
		List<User> listOfUser = userService.getAllUser();
		return new ResponseEntity<List<User>>(listOfUser, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/role/{role}")
	public ResponseEntity<List<User>> getUserByIdRole(@PathVariable("role") Integer role) {
		List<User> obtainedUser = userService.getUserByRole(role);
		return new ResponseEntity<List<User>>(obtainedUser, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/dashboard/{id}")
	public ResponseEntity<JsonNode> getDashboardDataForPublisher(@PathVariable("id") Integer id) {
		JsonNode lDashboardData = userService.getDashboardDataForUser(id, Constants.USER_TYPE_PUBLISHER);
		return new ResponseEntity<JsonNode>(lDashboardData, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/admin/dashboard/{id}")
	public ResponseEntity<JsonNode> getDashboardDataForAdmin(@PathVariable("id") Integer id) {
		JsonNode lDashboardData = userService.getDashboardDataForUser(id, Constants.USER_TYPE_ADMIN);
		return new ResponseEntity<JsonNode>(lDashboardData, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/admin/dashboard/datewisereport/{id}")
	public ResponseEntity<JsonNode> getDateWiseReportData(@PathVariable("id") Integer id,
			@RequestBody JsonNode jsonNode) {
		JsonNode lDashboardData = userService.getDateWiseRevenueReport(id, Constants.USER_TYPE_PUBLISHER, jsonNode);
		return new ResponseEntity<JsonNode>(lDashboardData, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/admin/dashboard/websitewisereport/{id}")
	public ResponseEntity<JsonNode> getWebsiteWiseReportData(@PathVariable("id") Integer id,
			@RequestBody JsonNode jsonNode) {
		JsonNode lDashboardData = userService.getWebSiteWiseReport(id, Constants.USER_TYPE_PUBLISHER, jsonNode);
		return new ResponseEntity<JsonNode>(lDashboardData, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/admin/dashboard/datewisereport/download/{id}")
	public ResponseEntity<InputStreamResource> downloadDateWiseReportData(@PathVariable("id") Integer id , @RequestBody JsonNode jsonNode) throws IOException, ParseException{
		ByteArrayInputStream in = userService.downloadDateWiseRevenueReport(id,Constants.USER_TYPE_PUBLISHER , jsonNode);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=report.xlsx");
		headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		return new ResponseEntity<InputStreamResource>(new InputStreamResource(in), headers, HttpStatus.OK);
	}

	// ByteArrayInputStream in = websiteService.generateExcelReport(jsonNode);

	@PostMapping("/admin/dashboard/websitewisereport/download/{id}")
	public ResponseEntity<InputStreamResource> downloadWebsiteWiseReportData(@PathVariable("id") Integer id , @RequestBody JsonNode jsonNode) throws IOException, ParseException{
		ByteArrayInputStream in = userService.downloadWebSiteWiseReport(id,Constants.USER_TYPE_PUBLISHER , jsonNode);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=report.xlsx");
		headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		return new ResponseEntity<InputStreamResource>(new InputStreamResource(in), headers, HttpStatus.OK);

	}

	@PostMapping("/admin/dashboard/mediawisereport/download/{id}")
	public ResponseEntity<InputStreamResource> downloadMediaWiseReportData(@PathVariable("id") Integer id , @RequestBody JsonNode jsonNode) throws IOException, ParseException{
		ByteArrayInputStream in = userService.downloadMediaWiseReport(id,Constants.USER_TYPE_PUBLISHER , jsonNode);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=report.xlsx");
		headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		return new ResponseEntity<InputStreamResource>(new InputStreamResource(in), headers, HttpStatus.OK);

	}

	@PostMapping("/admin/dashboard/advertiserwisereport/download/{id}")
	public ResponseEntity<InputStreamResource> downloadAdvertiserWiseReportData(@PathVariable("id") Integer id , @RequestBody JsonNode jsonNode) throws IOException, ParseException{
		ByteArrayInputStream in = userService.downloadAdvertiserWiseReport(id,Constants.USER_TYPE_PUBLISHER , jsonNode);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=report.xlsx");
		headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		return new ResponseEntity<InputStreamResource>(new InputStreamResource(in), headers, HttpStatus.OK);

	}

	@PostMapping("/admin/dashboard/publisherwisereport/download/{id}")
	public ResponseEntity<InputStreamResource> downloadPublisherWiseReportData(@PathVariable("id") Integer id , @RequestBody JsonNode jsonNode) throws IOException, ParseException{
		ByteArrayInputStream in = userService.downloadPublisherWiseReport(id,Constants.USER_TYPE_PUBLISHER , jsonNode);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=report.xlsx");
		headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		return new ResponseEntity<InputStreamResource>(new InputStreamResource(in), headers, HttpStatus.OK);

	}

	// contact , website, bankdetails for userid
	@GetMapping("/publishers/profile/{id}")
	public JsonNode getAllDetails(@PathVariable("id") Integer id) throws JSONException, JsonProcessingException {
		return userService.getAllPublisherDetails(id);
	}

	// profile updation
	@PutMapping("/{id}")
	public User updateProfileForTheUserId(@RequestBody User user, @PathVariable Integer id) {
		System.out.println(id);
		//System.out.println(user.getCompanyName());
		User exsistingUser = userService.getUserById(id);
		return userService.updateDetails(user, exsistingUser);

	}

	@GetMapping(value = "/details/download/")
	public ResponseEntity<InputStreamResource> getAdvertiserDetailsExcel() throws IOException {
		ByteArrayInputStream in = userService.generateExcelAdvertiserDetails();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=AdvertiserDetails.xlsx");
		headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		return new ResponseEntity<InputStreamResource>(new InputStreamResource(in), headers, HttpStatus.OK);

	}

	@GetMapping(value = "/details/download/publisher")
	public ResponseEntity<InputStreamResource> getPublisherDetailsExcel() throws IOException {
		ByteArrayInputStream in = userService.generateExcelPublisherDetails();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=PublisherDetails.xlsx");
		headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		return new ResponseEntity<InputStreamResource>(new InputStreamResource(in), headers, HttpStatus.OK);

	}

	@GetMapping("/publishers/profile/details/")
	public JsonNode getPublisherRevenueWebsite() throws JSONException, JsonProcessingException {
		return userService.getPublisherRevenueWebsite();
	}

	@GetMapping(value = "/details/download/get/")
	public ResponseEntity<InputStreamResource> getPublisherRevenueDetailExcel() throws IOException, JSONException {
		ByteArrayInputStream in = userService.getPublisherRevenueDetailExcel();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=RevenueDetails.xlsx");
		headers.add("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		headers.add("contentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		return new ResponseEntity<InputStreamResource>(new InputStreamResource(in), headers, HttpStatus.OK);

	}

	@GetMapping("/websites/get")
	public ResponseEntity<ArrayNode> getDetailsForAdsTxt() throws RecordNotFoundException {
		ArrayNode obtainedUser = userService.getUserDetailsForAds();
		return new ResponseEntity<ArrayNode>(obtainedUser, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/password/encrypt")
	public ResponseEntity<String> passwordEncryption(@RequestBody String password)
			throws RecordNotFoundException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
			IllegalBlockSizeException, BadPaddingException {
		String obtainedUser = userService.passwordEncryption(password);
		return new ResponseEntity<String>(obtainedUser, new HttpHeaders(), HttpStatus.OK);
	}

}
