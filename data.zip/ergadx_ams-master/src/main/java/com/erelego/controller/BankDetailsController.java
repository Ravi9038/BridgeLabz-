package com.erelego.controller;

import java.util.*;
import com.erelego.model.BankDetails;
import com.erelego.service.*;
import com.fasterxml.jackson.databind.JsonNode;

import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/bankdetails")
public class BankDetailsController {
	@Autowired
	private BankDetailsService service;

	@GetMapping("/")
	public List<BankDetails> list() {
		return service.listAll();
	}

	@GetMapping("/{id}")
	public ResponseEntity<BankDetails> get(@PathVariable Integer id) {
		try {
			BankDetails bankdetails = service.get(id);
			return new ResponseEntity<BankDetails>(bankdetails, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<BankDetails>(HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/users/{id}")
	public ResponseEntity<List<BankDetails>> getBankListByUserId(@PathVariable Integer id) {
		try {
			List<BankDetails> bankdetails = service.getBankListByUserId(id);
			return new ResponseEntity<List<BankDetails>>(bankdetails, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<List<BankDetails>>(HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<?> update(@RequestBody BankDetails bankdetails, @PathVariable Integer id) {
		try {
			BankDetails existBankdetails = service.get(id);
			existBankdetails.setAccountNumber(bankdetails.getAccountNumber());
			existBankdetails.setAddress(bankdetails.getAddress());
			existBankdetails.setBankName(bankdetails.getBankName());
			existBankdetails.setIfscCode(bankdetails.getIfscCode());
			existBankdetails.setPayeeName(bankdetails.getPayeeName());
			existBankdetails.setRoutingNumber(bankdetails.getRoutingNumber());
			service.save(bankdetails);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
		service.delete(id);
	}

	// updating for profile
	
	//public void updateForUserid(@RequestBody JsonNode amsBankDetails) {
	@PostMapping("/")
	public void updateForUserid(@RequestBody List<BankDetails> amsBankDetails) {
	
		 service.updateDataforId(amsBankDetails);
	}
//	
//	//adding new BankDetails
	@PostMapping("/add")
	public BankDetails  addBankDetails(@RequestBody List<BankDetails> bankdetails ) {
		return service.saveAll(bankdetails);
	}

}
