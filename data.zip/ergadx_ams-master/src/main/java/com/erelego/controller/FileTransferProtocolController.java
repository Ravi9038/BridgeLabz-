package com.erelego.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erelego.service.FileTransferProtocolService;

@RequestMapping("/api/filetransfer")
@RestController
public class FileTransferProtocolController {
	
	private static Logger LOGGER = LogManager.getLogger(FileTransferProtocolController.class);
	
	@Autowired
	FileTransferProtocolService fileTransferProtocolService;
	
	@PostMapping("/upload")	
	public ResponseEntity<?> uploadFile(){

		try {

			JSONObject jpJsnFtpConfigDatao = new JSONObject();

			
			jpJsnFtpConfigDatao.put("server", "192.168.1.97");
			//jpJsnFtpConfigDatao.put("server", "65.2.124.66");
			//jpJsnFtpConfigDatao.put("port", 22);
			jpJsnFtpConfigDatao.put("port", 21);
//			jpJsnFtpConfigDatao.put("user", "ubuntu");
//			jpJsnFtpConfigDatao.put("pass", "12345");
			jpJsnFtpConfigDatao.put("user", "FTP-User");
			jpJsnFtpConfigDatao.put("pass", "RAVIjadhav123");
			jpJsnFtpConfigDatao.put("localDirPath", "C:\\Users\\ravi\\Desktop\\ads.txt");
			//jpJsnFtpConfigDatao.put("remoteDirPath","/home/ubuntu/ravi");
			jpJsnFtpConfigDatao.put("remoteDirPath","/Demo/RAVI");
			jpJsnFtpConfigDatao.put("lFileName", "C:\\Users\\ravi\\Desktop\\ads.txt");
			//jpJsnFtpConfigDatao.put("ftp_type", "SFTP");
			jpJsnFtpConfigDatao.put("ftp_type", "FTP");

			fileTransferProtocolService.uploadFileRemoteServer(jpJsnFtpConfigDatao);
			return new ResponseEntity<FileTransferProtocolService>(HttpStatus.OK);

		}catch(Exception e) {
			e.printStackTrace();
			LOGGER.info(e);
			return new ResponseEntity<FileTransferProtocolService>(HttpStatus.BAD_REQUEST);
		}


	}
}

