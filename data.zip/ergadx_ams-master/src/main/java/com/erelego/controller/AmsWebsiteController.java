package com.erelego.controller;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.codehaus.jettison.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.erelego.model.AmsWebsitePages;

import com.erelego.service.AmsWebsiteService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AmsWebsiteController {

	@Autowired
	private AmsWebsiteService service;
	
	@GetMapping("/api/websitepage")
	public List<AmsWebsitePages> list() 
	{
	    return service.listAll();
	}
	
	
	@PostMapping("/api/websitepage")
	public void add(@RequestBody AmsWebsitePages amsWebsitePages) 
	{
	    service.save(amsWebsitePages);
	}
	
	@PutMapping("/api/websitepage/{id}")
	public void update(@RequestBody AmsWebsitePages amsWebsitePages, @PathVariable Integer id)
	{
	      service.save(amsWebsitePages);
	           
	}
	

	@DeleteMapping("/api/websitepage/{id}")
	public void delete(@PathVariable Integer id) {
		service.delete(id);
	}

	@GetMapping("/api/webpage/create")
	public List create() {
		return service.addDetails();
		
	}
	//
	@GetMapping("/api/websitepage/{id}")
	public AmsWebsitePages getById(@PathVariable Integer id) 
	{
		return service.get(id);
	}
	
	//getDataForWebsiteId
	@GetMapping("/api/websitepage/get/{id}")
	public List<AmsWebsitePages> getDataForWebsiteId(@PathVariable Integer id) {
		return  service.lgetDataForWebsiteId(id);
		
	}
	
	//get modified data for json
	
	@GetMapping("/api/websitepage/get/ad/{id}")
	public ResponseEntity<?> getAdPage(@PathVariable Integer id) throws JSONException, IOException {
		ArrayNode lAdRecords =  service.getpageData(id);
	service.createJSFile(lAdRecords,id);
		return new ResponseEntity<>(lAdRecords,new HttpHeaders(),HttpStatus.OK);

	}

	
	
}
