package com.erelego.controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.codehaus.jettison.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.erelego.model.AmsPublisherContact;
import com.erelego.model.AmsWebsiteAdUnit;

import com.erelego.service.AmsWebsiteAdUnitService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.node.ArrayNode;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AmsWebsiteAdUnitController {

	@Autowired
	private AmsWebsiteAdUnitService service;
	
	@GetMapping("/api/websitepagead")
	public List<AmsWebsiteAdUnit> list() 
	{
	    return service.listAll();
	}
	
	
	@PostMapping("/api/websitepagead")
	public void add(@RequestBody AmsWebsiteAdUnit amsWebsiteAdUnit) 
	{
	    service.save(amsWebsiteAdUnit);
	}
	
//	@PutMapping("/api/websitepagead/{id}")
//	public void update(@RequestBody AmsWebsiteAdUnit amsWebsiteAdUnit, @PathVariable Integer id)
//	{
//	      service.save(amsWebsiteAdUnit);
//	           
//	}
	
	@PutMapping("/api/websitepagead/{id}")
	public void update(@RequestBody AmsWebsiteAdUnit amsWebsiteAdUnit, @PathVariable Integer id)
	{
	      service.update(amsWebsiteAdUnit, id);
	           
	}

	@DeleteMapping("/api/websitepagead/{id}")
	public void delete(@PathVariable Integer id) {
		service.delete(id);

	}
	
	//getAdsForPageId
	@GetMapping("/api/websitepagead/{id}")
	public AmsWebsiteAdUnit getById(@PathVariable Integer id) 
	{
		return service.get(id);
	}
	
	@GetMapping("/api/adsize/")
	public ResponseEntity<?> getAdSize() {
		List lAdRecords =  service.getSize();
		return new ResponseEntity<>(lAdRecords,new HttpHeaders(),HttpStatus.OK);

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping("/api/ad/websitemap/{id}")
	public ResponseEntity<?> mappingAdPage(@RequestBody List<Integer> idAdUnit,@PathVariable Integer id) {
		List lAdRecords =  service.mappingAdPage(idAdUnit,id);
		return new ResponseEntity<>(lAdRecords,new HttpHeaders(),HttpStatus.OK);

	}
	@GetMapping("/api/ad/websitemap/get/{id}")
	public ResponseEntity<?> getmappingAdPage(@PathVariable Integer id) {
		ArrayNode lAdRecords =  service.getmappingAdPage(id);
		return new ResponseEntity<>(lAdRecords,new HttpHeaders(),HttpStatus.OK);

	}
	
	@DeleteMapping("/api/ad/websitemap/delete/{id}")
	public ResponseEntity<?> getmappingAdPage( @RequestBody List<Integer> idAdUnit,@PathVariable Integer id) {
		List lAdRecords =  service.deletemappingAdPage(idAdUnit,id);
		return new ResponseEntity<>(lAdRecords,new HttpHeaders(),HttpStatus.OK);

	}
	//get modified data for page id
	@GetMapping("/api/adwebsite/get/{id}")
	public ResponseEntity<?> getAdPage(@PathVariable Integer id) throws JSONException, JsonMappingException, JsonProcessingException {
		ArrayNode lAdRecords =  service.getAdPage(id);
		return new ResponseEntity<>(lAdRecords,new HttpHeaders(),HttpStatus.OK);

	}
	

	
}
