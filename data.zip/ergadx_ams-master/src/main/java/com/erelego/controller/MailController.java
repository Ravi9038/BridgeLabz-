package com.erelego.controller;

import java.io.File;

import javax.mail.MessagingException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RestController;

import com.erelego.service.SendMailService;



@RestController
public class MailController {

	@Autowired
	private SendMailService mail;

	@Value("${spring.mail.username}")
	private String from;
	
	@GetMapping("api/multiplemail")
	public void mSendMail() throws MessagingException {

     String[] to = { "report@erelego.com", "ergad@gmail.com" }; // list of recipient email addresses
   	String[] cc = { "shwethac.eee@gmail.com", "ereleg@gmail.com" };
   	String[] bcc = { "sxxxx@gmail.com" };
   	File attachment1 = new File("D:\\invoce1.pdf");
   	File attachment2 = new File("D:\\invoce1.pdf");
   	File[] attachments = new File[] { attachment1, attachment2 };
   	String subject = "AMS email test";
   	String body = "hi";
//  mail.sendMailWithAttachment(from, "shwethac.eee@gmail.com", "test","body", "D:\\invoce1.pdf");
 	mail.sendMailWithAttachment(from, to, cc, bcc, subject, body, attachments);
   	System.out.println("started");
		
	}

}
