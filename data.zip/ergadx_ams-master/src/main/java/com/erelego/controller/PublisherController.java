package com.erelego.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.erelego.exception.RecordNotFoundException;
import com.erelego.service.PublisherDataService;
import com.fasterxml.jackson.databind.JsonNode;


/**
 * 
 * @author Vikas M Gowda
 *
 */

@RestController
@RequestMapping("/publisherdata")
public class PublisherController {

	@Autowired
	private PublisherDataService publisherDataService;
	
	@GetMapping("/{id}")
	public ResponseEntity<JsonNode> getPublisherRevenueById(@PathVariable("id") Long id) throws RecordNotFoundException {

		JsonNode obtainedUserAddress = publisherDataService.getPublisherData(id);

		return new ResponseEntity<JsonNode>(obtainedUserAddress, new HttpHeaders(), HttpStatus.OK);
	}
	
	@GetMapping("/{fromdate}/{todate}")
	public ResponseEntity<List<JsonNode>> getPublisherData(@PathVariable("fromdate") String fromdate, @PathVariable("todate") String todate) throws RecordNotFoundException {

		List<JsonNode> obtainedUserAddress = publisherDataService.getRevenueByWebsiteForParticularDuration(fromdate, todate);

		return new ResponseEntity<List<JsonNode>>(obtainedUserAddress, new HttpHeaders(), HttpStatus.OK);
	}
}
