package com.erelego.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.erelego.service.GraphService;
import com.erelego.service.UserWebsiteService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

@RestController
//@CrossOrigin(origins = "http://localhost:3000")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class GraphController {

	
	@Autowired
	private GraphService graphService;
	
	@PostMapping("api/advertiser/revenue/")
	public ResponseEntity<?> getRevenue(@RequestBody JsonNode jsonNode){
		ArrayNode lWebsiteRevenueData = graphService.getRevenueShareForAll(jsonNode);
	return new ResponseEntity<ArrayNode>(lWebsiteRevenueData,new HttpHeaders(),HttpStatus.OK);
  

	}
	
	
	
	//get revshare for Graph
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping("api/advertiser/revenue/{id}")
	public ResponseEntity<?> getRevenue(@RequestBody JsonNode jsonNode,@PathVariable Integer id){
		ArrayNode lWebsiteRevenueData = graphService.getRevenueShare(jsonNode,id);
	return new ResponseEntity<ArrayNode>(lWebsiteRevenueData,new HttpHeaders(),HttpStatus.OK);
  

	}
	
}
