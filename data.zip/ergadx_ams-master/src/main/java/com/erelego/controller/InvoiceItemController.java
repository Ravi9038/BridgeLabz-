package com.erelego.controller;
import java.util.*;

import com.erelego.model.InvoiceDetails;
import com.erelego.model.InvoiceItem;
import com.erelego.model.UserWebsite;
import com.erelego.service.*;
import com.erelego.repository.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class InvoiceItemController 
{
	@Autowired
    private InvoiceItemService service;
	@GetMapping("/api/invoiceitem")
	public List<InvoiceItem> list() 
	{
	    return service.listAll();
	}
	@GetMapping("/api/invoiceitem/{id}")
	public ResponseEntity<InvoiceItem> get(@PathVariable Integer id) 
	{
	    try {
	    	InvoiceItem invoiceitem = service.get(id);
	        return new ResponseEntity<InvoiceItem>(invoiceitem, HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<InvoiceItem>(HttpStatus.NOT_FOUND);
	    }      
	}
	@PostMapping("/api/invoiceitem")
	public void add(@RequestBody InvoiceItem invoiceitem) 
	{
	    service.save(invoiceitem);
	}
	
	@PutMapping("/api/invoiceitem/{id}")
	public ResponseEntity<?> update(@RequestBody InvoiceItem invoiceitem, @PathVariable Integer id)
	{
	    try {
	    	InvoiceItem existInvoiceItem = service.get(id);
	        service.save(invoiceitem);
	        return new ResponseEntity<>(HttpStatus.OK);
	    } catch (NoSuchElementException e) {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }      
	}
	
	@DeleteMapping("/api/invoiceitem/{id}")
	public void delete(@PathVariable Integer id)
	{
	    service.delete(id);


}
	
//	@GetMapping("/api/invoiceitem/get")
//	 public List<Integer>  generateItem() {
//	    	 return   service.generateInvoiceItem();
//	    }
}
