package com.erelego.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
/**
 * 
 * @author Vikas M Gowda
 *
 */
@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class RecordNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -4108545716095762678L;
	private String exceptionDetail;
	private Object fieldValue;

	public RecordNotFoundException(String exceptionDetail, int fieldValue) {
		super(exceptionDetail + "-" + fieldValue);
		this.exceptionDetail = exceptionDetail;
		this.fieldValue = fieldValue;
	}
	
	public RecordNotFoundException(String exceptionDetail) {
		super(exceptionDetail);
		this.exceptionDetail = exceptionDetail;
	}

	public String getExceptionDetail() {
		return exceptionDetail;
	}

	public Object getFieldValue() {
		return fieldValue;
	}

}
