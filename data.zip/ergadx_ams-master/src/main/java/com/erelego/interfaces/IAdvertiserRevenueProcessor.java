package com.erelego.interfaces;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.service.UserWebsiteService;

@Service
public interface IAdvertiserRevenueProcessor {

	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception;
	public void doAuthentication() throws Exception;
	public void fetchData(Date startDate,Date endDate) throws Exception;
	public void processData() throws Exception;
	default float cleanseCurrencyField(String pCurrency) throws Exception{
		String lStrCurrency = pCurrency;
		if(pCurrency.equalsIgnoreCase("N/A") || pCurrency.equalsIgnoreCase("null") || pCurrency == null || pCurrency.equalsIgnoreCase(""))
			lStrCurrency = "0";
		else if(pCurrency.contains("Rs"))
			lStrCurrency = pCurrency.replace("Rs", "");
		else if(pCurrency.contains("$"))
			lStrCurrency = pCurrency.replace("$", "");
		return Float.parseFloat(lStrCurrency);
	}
}
