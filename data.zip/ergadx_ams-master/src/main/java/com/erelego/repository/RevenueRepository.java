package com.erelego.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.erelego.model.RevenueData;

import antlr.collections.List;

public interface RevenueRepository extends JpaRepository<RevenueData, Integer>{

	
	
}
