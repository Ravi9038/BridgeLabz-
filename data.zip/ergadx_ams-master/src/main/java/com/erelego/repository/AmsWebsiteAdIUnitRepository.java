package com.erelego.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erelego.model.AmsWebsiteAdUnit;
import com.erelego.model.AmsWebsitePages;


public interface AmsWebsiteAdIUnitRepository extends JpaRepository <AmsWebsiteAdUnit, Integer> {


}
