package com.erelego.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erelego.model.Payment;
import com.erelego.model.UserWebsite;


public interface PaymentRepository extends JpaRepository<Payment, Integer>
{
	List<Payment> findByUserId(int userId);
}
