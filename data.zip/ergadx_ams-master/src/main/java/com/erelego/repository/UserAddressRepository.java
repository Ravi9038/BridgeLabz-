package com.erelego.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.erelego.model.Status;
import com.erelego.model.UserAddress;

/**
 * 
 * @author Vikas M Gowda
 *
 */

@Repository
public interface UserAddressRepository extends JpaRepository<UserAddress, Integer> {

	//public List<UserAddress> findByStatus(Status status);

	public List<UserAddress> findByIdUser(int idUser);
}
