package com.erelego.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erelego.model.InvoiceDetails;
import com.erelego.model.UserWebsite;

public interface UserWebsiteRepository extends JpaRepository<UserWebsite, Integer> 
{
	List<UserWebsite> findByUserId(int userId);

}
