package com.erelego.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.erelego.model.InvoiceDetails;
import com.erelego.model.InvoiceItem;

public interface InvoiceItemRepository extends JpaRepository<InvoiceItem, Integer> {

}
