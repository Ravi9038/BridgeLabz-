package com.erelego.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erelego.model.BankDetails;
import com.fasterxml.jackson.databind.JsonNode;

public interface BankDetailsRepository extends JpaRepository<BankDetails, Integer> 
{
	List<BankDetails> findByUserId(int userId);

	void save(JsonNode lamsBankDetails);

	
}
