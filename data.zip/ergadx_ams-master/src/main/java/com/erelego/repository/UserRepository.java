package com.erelego.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.erelego.model.User;
import com.fasterxml.jackson.databind.JsonNode;
import com.erelego.model.Status;


@Repository
public interface UserRepository extends JpaRepository<User, Integer> {	
	public List<User> findByStatus(Status status);
	User findByEmail(String username);
	public List<User> findByIdRole(int idRole);
	User findByEmailAndPassword(String username, String password);
	User findByEmailAndCompanyName(String email, String companyName);
	
}