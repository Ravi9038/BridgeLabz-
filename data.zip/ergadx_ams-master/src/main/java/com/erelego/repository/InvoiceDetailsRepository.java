package com.erelego.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.erelego.model.InvoiceDetails;

public interface InvoiceDetailsRepository extends JpaRepository<InvoiceDetails, Integer>
{
	InvoiceDetails findByPayCycleId(int payCycleId);
	List<InvoiceDetails> findByUserId(int userId);

}
