package com.erelego.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erelego.model.AmsPublisherContact;
import com.erelego.model.AmsWebsiteAdUnit;

public interface AmsPublisherContactRepository  extends JpaRepository<AmsPublisherContact ,Integer> {

	List<AmsPublisherContact> findByUserId(Integer userId);



	


	

	

}
