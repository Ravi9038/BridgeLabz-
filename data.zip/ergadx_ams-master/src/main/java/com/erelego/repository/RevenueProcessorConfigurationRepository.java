package com.erelego.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.erelego.model.*;
public interface RevenueProcessorConfigurationRepository extends JpaRepository<RevenueProcessorConfiguration, Integer>
{

}