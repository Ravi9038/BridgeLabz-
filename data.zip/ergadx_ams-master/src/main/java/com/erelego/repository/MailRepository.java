package com.erelego.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erelego.model.BankDetails;
import com.erelego.model.MailConfirmationDetails;

public interface MailRepository extends JpaRepository <MailConfirmationDetails ,Integer>  {

}
