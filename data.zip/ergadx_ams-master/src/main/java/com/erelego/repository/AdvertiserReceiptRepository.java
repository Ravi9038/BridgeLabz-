package com.erelego.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erelego.model.AdvertiserReceipt;



public interface AdvertiserReceiptRepository extends JpaRepository<AdvertiserReceipt, Integer>{
	AdvertiserReceipt findByPayCycleId(int payCycleId);
	List<AdvertiserReceipt> findByUserId(int userId);
}
