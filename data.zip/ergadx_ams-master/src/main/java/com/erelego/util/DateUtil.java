package com.erelego.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.fasterxml.jackson.databind.JsonNode;

public class DateUtil {
	public static String getFormattedDate(Date date,String format) {
		DateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(date);
	}
	
	public static Date getDateFromStringFormat(String format,String date) throws ParseException {
		return new SimpleDateFormat(format).parse(date);
	}
	public static String getStringDateFromToday(int numberOfDays,String strFormat) {
		DateFormat dateFormat = new SimpleDateFormat(strFormat);//"yyyy-MM-dd");
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, numberOfDays);
		Date yesterday = calendar.getTime();
		return dateFormat.format(yesterday);
	}

	public static Date getDateFromToday(int numberOfDays) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, numberOfDays);
		Date date = calendar.getTime();
		return date;
	}
	
	public static Date addDays(Date date, int days) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		cal.add(Calendar.DATE, days);
				
		return cal.getTime();
	}
	
	public static Date subtractDays(Date date, int days) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		cal.add(Calendar.DATE, -days);
				
		return cal.getTime();
	}

	public Date getReportStartDate(JsonNode jsonNode) throws ParseException {
		String dateType = jsonNode.get("type").asText();
		Date lTodayDate = new Date();
		if(dateType.equalsIgnoreCase(Constants.TODAY) || dateType.equalsIgnoreCase(Constants.YESTERDAY) || dateType.equalsIgnoreCase(Constants.LAST_SEVEN_DAYS) || dateType.equalsIgnoreCase(Constants.Current_MONTH))
			return lTodayDate;
		else if(dateType.equalsIgnoreCase(Constants.LAST_MONTH))
			return DateUtil.subtractDays(lTodayDate, 1);
		else if(dateType.equalsIgnoreCase(Constants.CUSTOM_DATE)) {
			String lStartDate = jsonNode.get("start_date").asText();
			return DateUtil.getDateFromStringFormat(Constants.YYYYMMdd,lStartDate);
		}
		return null;
	}
	
	public static Date getMonthStartDate(int month ) {
		
		Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, month);
        calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        Date monthFirstDay = calendar.getTime();
        return monthFirstDay;
        
	}
	public static Date getMonthEndDate(int month) {
		Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, month);
		calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date monthLastDay = calendar.getTime();
        return monthLastDay;
	}	
	
	public Date getReportEndDate(JsonNode jsonNode) {
		String dateType = jsonNode.get("type").asText();
		Date lTodayDate = new Date();
		if(dateType.equalsIgnoreCase(Constants.TODAY))
			return lTodayDate;
		else if(dateType.equalsIgnoreCase(Constants.YESTERDAY))
			return DateUtil.subtractDays(lTodayDate, 1);
		else if(dateType.equalsIgnoreCase(Constants.LAST_SEVEN_DAYS))
			return DateUtil.subtractDays(lTodayDate, 6);
		else if(dateType.equalsIgnoreCase(Constants.Current_MONTH))
			return DateUtil.subtractDays(lTodayDate, 1);
		else if(dateType.equalsIgnoreCase(Constants.LAST_MONTH))
			return DateUtil.subtractDays(lTodayDate, 1);
		else if(dateType.equalsIgnoreCase(Constants.CUSTOM_DATE)) {
			String lStartDate = jsonNode.get("start_date").asText();
			//return DateUtil.getDateFromStringFormat(Constants.YYYYMMdd,lStartDate);
		}
		return null;
	}
	
	public static Date getEndDateForMonth( ) {
		//month -> 0-11
		Calendar aCalendar = Calendar.getInstance();
		aCalendar.set(Calendar.DATE, 1);
		aCalendar.add(Calendar.DAY_OF_MONTH, -1);
		Date lastDateOfPreviousMonth = aCalendar.getTime();
		return lastDateOfPreviousMonth;
	}
	
	public static Date getStartDateForMonth () {
		Calendar aCalendar = Calendar.getInstance();
		aCalendar.set(Calendar.DATE, 1);
		aCalendar.add(Calendar.DAY_OF_MONTH, -1);
		aCalendar.set(Calendar.DATE, 1);
		Date firstDateOfPreviousMonth = aCalendar.getTime();
		return firstDateOfPreviousMonth;
		
	}
}
