package com.erelego.util;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.erelego.service.AmsWebsiteService;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileUtil {
	static Logger LOGGER = LogManager.getLogger(AmsWebsiteService.class);
	public static void moveFile(String sourceFilePath,String destinationFilePath) throws IOException {
		File lFileSourceFile = new File(sourceFilePath);
        File lFileDestinationFile = new File(destinationFilePath);
		FileUtils.moveFile(lFileSourceFile, lFileDestinationFile);
	}
	
	public static void createDirectory(String directoryName ,  String fileName) throws IOException {
	     Path newpath = Paths.get(directoryName);
	        if (!Files.exists(newpath)) {
	            
	            Files.createDirectory(newpath);
	           System.out.println("Directory Created");
	            LOGGER.debug("Directory Created");
	            
	        } else {
	            
	            System.out.println("Directory already exists");
	            LOGGER.debug("Directory already exists");
	        }
	}
	
	public static void copyfile( String destinationpath,Path path, File source) {
		   File dest = new File(destinationpath);
	        try {
	        	 if (!Files.exists(path)) {
	        		 FileUtils.copyFile(source, dest); 
	        	 }
	        	 else {
	        		  LOGGER.debug("File already exists"); 
	        	 }
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	            
	        }
	}
}
