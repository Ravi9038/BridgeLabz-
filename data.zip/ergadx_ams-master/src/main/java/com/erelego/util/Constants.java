package com.erelego.util;

public class Constants {
	public static final String HTTP_PROTOCOL = "http";
	public static final String HTTPS_PROTOCOL = "https";
	public static final String STATUS_INPROGRESS = "INPROGRESS";
	public static final String STATUS_FAILURE = "FAILURE";
	public static final String STATUS_SUCCESS = "SUCCESS";
	public static final String USER_TYPE_PUBLISHER ="PUBLISHER";
	public static final String USER_TYPE_ADMIN ="ADMINISTRATOR";
	public static final String APPLICATION_NAME_PUBLISHER_DASHBOARD = "PublisherDashboard";
	public static final String TODAY = "Today";
	public static final String YESTERDAY = "Yesterday";
	public static final String LAST_SEVEN_DAYS = "Last7Days";
	public static final String Current_MONTH = "CurrentMonth";
	public static final String LAST_MONTH = "LastMonth";
	public static final String CUSTOM_DATE = "CustomDate";
	public static final String YYYYMMdd = "YYYY-MM-dd";
	public static final String ddMMYYYY = "dd-MM-yyyy";
	
}
