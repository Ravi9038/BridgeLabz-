package com.erelego.revenueprocessor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;

import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueData;
import com.erelego.model.RevenueDataId;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserWebsiteService;
import com.erelego.util.DateUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;


public class AniviewRevenueProcessor implements IAdvertiserRevenueProcessor {
	private static Logger LOGGER = LogManager.getLogger(ExcelRevenueProcessor.class);
	JsonNode configData = null;
	int idAdvertiser = 0;
	String adType="";
	@Autowired
	private UserWebsiteService userWebsiteService;
	@Autowired
	private EntityManager entityManager;

	@Autowired
	private CurrencyRateService currencyRateService;

	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;

	private Map<String, Double> currencyRates;
	private Map<String, WebsiteAdvertiserRevenueShare> websiteRevShareData;

	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception {
		configData = revenueProcessorConfiguration.getJsnConfigData();
		adType=revenueProcessorConfiguration.getAdType();
		this.idAdvertiser = revenueProcessorConfiguration.getIdAdvertiser();
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
	}

	@Override
	public void doAuthentication() throws Exception {

	}

	@Override
	@Transactional(propagation = Propagation.NESTED)
	public void fetchData(Date pStartDate, Date pEndDate) throws Exception {

		String lStrStartDate = "";
		String lStrEndDate = "";
		if (pStartDate == null) {
			lStrStartDate = DateUtil.getStringDateFromToday(-1, "yyyy-MM-dd");
			lStrEndDate = DateUtil.getStringDateFromToday(-1, "yyyy-MM-dd");
		} else {
			lStrStartDate = DateUtil.getFormattedDate(pStartDate, "yyyy-MM-dd");
			lStrEndDate = DateUtil.getFormattedDate(pEndDate, "yyyy-MM-dd");
		}

		String url = configData.get("url").asText();

		Map<String, UserWebsite> mapWebsite = this.userWebsiteService.getAllWebsiteMapWithURLAsId();
		Map<RevenueDataId, RevenueData> revenueDataMap = new HashMap<RevenueDataId, RevenueData>();

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		ObjectMapper objectMapper = new ObjectMapper();
		String tokens="http://manage.aniview.com/api/token?format=json";
		
		ObjectNode lJsonNodeAdsTxtRecord = objectMapper.createObjectNode();
		lJsonNodeAdsTxtRecord.put("id", "sudeer@erelego.com");
		lJsonNodeAdsTxtRecord.put( "password","ergadx@2021");
		lJsonNodeAdsTxtRecord.put( "accountId","5fd9c7d93f2f4c6ef13a1ec7");
		System.out.println(lJsonNodeAdsTxtRecord);
		ResponseEntity<String> tokenToBepassed = restTemplate.postForEntity(tokens, lJsonNodeAdsTxtRecord, String.class);
		ObjectMapper mappers = new ObjectMapper();
		 JsonNode lResponseDatas = mappers.readTree(tokenToBepassed.getBody());
		JsonNode tokenData=lResponseDatas.get("data");
		String lAuthenticationToken = tokenData.get("token").asText();
		
    
	
		String parameters = "startDate=" + lStrStartDate + "&endDate=" + lStrEndDate+"&dimensions=date,grR&metrics=impression,complete,revenue,netCpm,click,ctr,Request&format=json&query={}";
		System.out.println(parameters);
		String urlpass = url + parameters;
		ObjectMapper mapper = new ObjectMapper();

        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		
		headers.set("Cache-Control","no-cache" );
		headers.set("X-Bamboo-Token",lAuthenticationToken );
		HttpEntity<String> entity = new HttpEntity<String>("Headers", headers);
		RestTemplate restTemplates = new RestTemplate();
		ResponseEntity<String> response = restTemplates.postForEntity(urlpass,entity ,String.class);
		JsonNode  lResponseData = (JsonNode) mapper.readTree(response.getBody().toString());
        System.out.println(lResponseData);
    	ObjectMapper objectMappers = new ObjectMapper();
    	ArrayNode arrayNode = objectMappers.createArrayNode();
		
    	
		for (JsonNode lRevData : lResponseData) {
			JsonNode datas = lRevData;
			for(JsonNode data:datas) {
            JsonNode objectData = data;
			String websiteUrl = objectData.get("Grouped Domain").asText();
		    System.out.println(websiteUrl);
			websiteUrl = websiteUrl.replaceAll("www.", "");
			UserWebsite lUserWebsite = mapWebsite.get(websiteUrl);
			 if(lUserWebsite != null ) {
			String lMapKey = lUserWebsite.getId() + "-" + this.idAdvertiser;
			WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare = this.websiteRevShareData.get(lMapKey);
			   if(lWebsiteAdvertiserRevenueShare != null) {
			 long unixdate = objectData.get("date").asLong();
			 Date date = new java.util.Date(unixdate*1000L); 
			String recordDate = DateUtil.getFormattedDate(date, "yyyy-MM-dd");
			Date ldate = DateUtil.getDateFromStringFormat("yyyy-MM-dd", recordDate);
			RevenueData lRevenueData = new RevenueData();
			RevenueDataId lRevenueDataId = new RevenueDataId();
			lRevenueDataId.setDate(new java.sql.Date(ldate.getTime()));
			lRevenueDataId.setIdAdvertiser(this.idAdvertiser);
			lRevenueDataId.setIdWebsite(lUserWebsite.getId());
			lRevenueDataId.setAdType(adType);
			lRevenueData.setRevenueDataId(lRevenueDataId);

			if (revenueDataMap.containsKey(lRevenueDataId)) {
				lRevenueData = revenueDataMap.get(lRevenueDataId);
				float lCpm = lRevenueData.getCpm() + Float.parseFloat(objectData.get("NetCpm").asText());
				float lGrossAmount = lRevenueData.getAmount() + Float.parseFloat(objectData.get("Revenue").asText());
				int lImpressions = lRevenueData.getImpressions()
						+ Integer.parseInt(objectData.get("Impression").asText());
				int ltotalImpressions = lRevenueData.getTotalImpressions()
						+ Integer.parseInt(objectData.get("Request").asText());
				BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
				BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
				BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
				BigDecimal publisherShare = lAmountWithoutFlatformFee
						.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
				BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);

				lRevenueData.setAmount(lGrossAmount);
				lRevenueData.setCpm(lCpm);
				lRevenueData.setCurrency("USD");
				lRevenueData.setSourceCurrency("USD");
				lRevenueData.setImpressions(lImpressions);
				lRevenueData.setTotalImpressions(ltotalImpressions);// TO-DO need to take total impressions
				lRevenueData.setPlatformFee(lPlatformFee);
				lRevenueData.setErelegoAmount(erelegoShare);
				lRevenueData.setPublisherAmount(publisherShare);
			}

			else {
				float lCpm = Float.parseFloat(objectData.get("NetCpm").asText());
				float lGrossAmount = Float.parseFloat(objectData.get("Revenue").asText());
				int lImpressions = Integer.parseInt(objectData.get("Impression").asText());
				int ltotalImpressions = Integer.parseInt(objectData.get("Request").asText());
				BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
				BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
				BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
				BigDecimal publisherShare = lAmountWithoutFlatformFee
						.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
				BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);

				lRevenueData = new RevenueData();
				lRevenueData.setAmount(lGrossAmount);
				lRevenueData.setCpm(lCpm);
				lRevenueData.setCurrency("USD");
				lRevenueData.setSourceCurrency("USD");
				lRevenueData.setImpressions(lImpressions);
				lRevenueData.setTotalImpressions(ltotalImpressions);// TO-DO need to take total impressions
				lRevenueData.setRevenueDataId(lRevenueDataId);
				lRevenueData.setPlatformFee(lPlatformFee);
				lRevenueData.setErelegoAmount(erelegoShare);
				lRevenueData.setPublisherAmount(publisherShare);
				revenueDataMap.put(lRevenueDataId, lRevenueData);
			}
			}
			 else {
					LOGGER.error("Revenue Share Config not found for website : " + lUserWebsite.getHostURL() + " And advertiser id : " + this.idAdvertiser);
	              
	            }
			 }
			 else {
					LOGGER.error(websiteUrl + " not found");
					LOGGER.error("insert into ams_user_websites (id_user,name,host_url,http_enabled,https_enabled,active,created_date,created_by,modified_date,modified_by) values (58,'"+websiteUrl+"','"+websiteUrl+"',1,1,1,now(),1,now(),1);");

				}
		}
		
		}

		for (RevenueData lRevenueData : revenueDataMap.values()) {
			Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(lRevenueData);

		}

	}

	@Override
	public void processData() throws Exception {

	}

}
