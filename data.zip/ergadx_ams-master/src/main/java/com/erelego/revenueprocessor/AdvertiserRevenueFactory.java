package com.erelego.revenueprocessor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.erelego.interfaces.IAdvertiserRevenueProcessor;
@Configuration
public class AdvertiserRevenueFactory {
	
	@Bean
	public DFPAdvertiserRevenueProcessor getDFPAdvertiserRevenueProcessor() {
		return new DFPAdvertiserRevenueProcessor();
	}
	
	@Bean
	public CSVRevenueProcessor getCSVRevenueProcessor() {
		return new CSVRevenueProcessor();
	}
	
	@Bean
	public ExcelRevenueProcessor getExcelRevenueProcessor() {
		return new ExcelRevenueProcessor();
	}
	
	@Bean
	public AdsenseRevenueProcessor getAdsenseRevenueProcessor() {
		return new AdsenseRevenueProcessor();
	}
	
	@Bean
	public MGIDRevenueProcessor getMGIDRevenueProcessor() {
		return new MGIDRevenueProcessor();
	}
	
	@Bean
	public AndBeyondRevenueProcessor getAndBeyondRevenueProcessor() {
		return new AndBeyondRevenueProcessor();
	}
	
	@Bean
	public CTNRevenueProcessor getCTNRevenueProcessor() {
		return new CTNRevenueProcessor();
	}
	
	@Bean
	public AdsolutRevenueProcessor getAdsolutRevenueProcessor() {
		return new AdsolutRevenueProcessor();
	}
	
	@Bean
	public AdaptMXRevenueProcessor getAdaptMXRevenueProcessor() {
		return new AdaptMXRevenueProcessor();
	}
	
	@Bean
	public CTNBackfillRevenueProcessor getCTNBackfillRevenueProcessor() {
		return new CTNBackfillRevenueProcessor();
	}

	@Bean
	public AniviewRevenueProcessor getAniviewRevenueProcessor() {
		return new AniviewRevenueProcessor() ;
	}
	
	@Bean
	public RubiconRevenueProcessor getRubiconRevenueProcessor() {
		return new RubiconRevenueProcessor();
	}

	@Bean
	public OpenxRevenueProcessor getOpenxRevenueProcessor() {
		return new OpenxRevenueProcessor();
	}
	
	@Bean
	public VerizonRevenueProcessor getVerizonRevenueProcessor() {
		return new VerizonRevenueProcessor();
	}
	
	@Bean
	public AniviewCSVRevnueProcessor getAniviewCSVRevnueProcessor() {
		return new AniviewCSVRevnueProcessor();
	}

	@Bean
	public IAdvertiserRevenueProcessor getOutbrainRevenueProcessor() {
		// TODO Auto-generated method stub
		return new OutbrainRevenueProcessor();
	}
	
	@Bean
	public IAdvertiserRevenueProcessor getUnibotsRevenueProcessor() {
		// TODO Auto-generated method stub
		return new UnibotsRevenueProcessor();
	}
}
