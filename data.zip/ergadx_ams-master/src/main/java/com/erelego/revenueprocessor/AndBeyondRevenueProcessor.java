package com.erelego.revenueprocessor;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueData;
import com.erelego.model.RevenueDataId;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserWebsiteService;
import com.erelego.util.DateUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

public class AndBeyondRevenueProcessor implements IAdvertiserRevenueProcessor{

	private static Logger LOGGER = LogManager.getLogger(DFPAdvertiserRevenueProcessor.class);
	JsonNode configData = null;
	int idAdvertiser = 0;
	String adType="";
	private Map<String,String> opportunityData;
	@Autowired
	private UserWebsiteService userWebsiteService;
	@Autowired
	private EntityManager entityManager;
	
	private Date reportStartDate;
	private Date reportEndDate;
	
	@Autowired
	private CurrencyRateService currencyRateService;
	
	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;

	private Map<String,Double> currencyRates;
	private Map<String,WebsiteAdvertiserRevenueShare> websiteRevShareData;
	
	
	private JsonNode lReponseRevenueData;
	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception {
		configData = revenueProcessorConfiguration.getJsnConfigData();
		adType=revenueProcessorConfiguration.getAdType();
		this.idAdvertiser = revenueProcessorConfiguration.getIdAdvertiser();
		this.opportunityData = this.loadOpportunityData();
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
	}
	
	
	private Map<String,String> loadOpportunityData(){
		Map<String,String> lSectionUrlData = new HashMap<String,String>();
		Query lQueryGetAdsTxtForWebsite = entityManager.createNativeQuery("select id_unit,website_url from ams_advertiser_revenue_processor_config_andbeyond_ext");
     	List<?> lResultSectionData = lQueryGetAdsTxtForWebsite.getResultList();
 
    	for(int i=0 ; i < lResultSectionData.size() ; i++) {
    		Object[] lRecordSectionData  = (Object[]) lResultSectionData.get(i);
    		lSectionUrlData.put(lRecordSectionData[0].toString(), lRecordSectionData[1].toString());
    	}
		return lSectionUrlData;
	}

	@Override
	public void doAuthentication() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	@Transactional
	public void fetchData(Date pStartDate, Date pEndDate) throws Exception {
		String lStrStartDate = "";
		String lStrEndDate = "";
		
		if (pStartDate == null) {
			lStrStartDate = DateUtil.getStringDateFromToday(-1,"dd-MM-yyyy");
			lStrEndDate = DateUtil.getStringDateFromToday(-1,"dd-MM-yyyy");
			this.reportStartDate = DateUtil.getDateFromToday(-1);
			this.reportEndDate = DateUtil.getDateFromToday(-1);
		}else {
			this.reportStartDate = pStartDate;
			this.reportEndDate = pEndDate;
			lStrStartDate = DateUtil.getFormattedDate(pStartDate, "dd-MM-yyyy");
			lStrEndDate = DateUtil.getFormattedDate(pEndDate, "dd-MM-yyyy");
		}
		
		String userName = configData.get("username").asText();
		String password = configData.get("password").asText();
		String apiurl = configData.get("url").asText();

		RestTemplate restTemplate = new RestTemplate();
		String parameters = "?user_name=" + userName + "&password=" +password+ "&from_date=" + lStrStartDate +"&to_date=" + lStrEndDate;
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.add("user_name",userName);
		map.add("password",password);
		map.add("from_date",lStrStartDate);
		map.add("to_date",lStrStartDate);
		
		HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(map, headers);
			
		 ResponseEntity<String> response = 
                 restTemplate.exchange(apiurl, HttpMethod.POST, 
                                       entity, String.class);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode lResponseData = mapper.readTree(response.getBody());
		String status = lResponseData.get("status").asText();
		if(status.equalsIgnoreCase("success")) {
			this.lReponseRevenueData = lResponseData.get("data");
		}else {
			LOGGER.error("Error while retriveing data from andbeyondmedia " + apiurl + parameters);
			throw new Exception("Error while retriveing data from andbeyondmedia " + apiurl + parameters);
		}
			
		
	}

	@Override
	@Transactional
	public void processData() throws Exception {
		Map<String,UserWebsite> mapWebsite = this.userWebsiteService.getAllWebsiteMapWithURLAsId();	
		Map<RevenueDataId,RevenueData> revenueDataMap = new HashMap<RevenueDataId,RevenueData>();
		Set<String> setOpportunityKeys = this.opportunityData.keySet();
		for(String opportunityKeyId : setOpportunityKeys) {
			if(this.lReponseRevenueData.has(opportunityKeyId)) {
				UserWebsite lUserWebsite = mapWebsite.get(this.opportunityData.get(opportunityKeyId).toLowerCase());
				String lMapKey = lUserWebsite.getId() + "-" + this.idAdvertiser;
				WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare = this.websiteRevShareData.get(lMapKey);
				if(lUserWebsite != null) {
				JsonNode lJsnOpportunityData = this.lReponseRevenueData.get(opportunityKeyId);
				int numberOfChildNodes = lJsnOpportunityData.size();
				for(int index = 0 ; index < numberOfChildNodes; index++) {
					Date lCurrentDate = this.reportStartDate;
					
					while(lCurrentDate.before(this.reportEndDate) || lCurrentDate.compareTo(this.reportEndDate) == 0) {
						String lDateStr = DateUtil.getFormattedDate(lCurrentDate, "ddMMyyyy");
						if(lJsnOpportunityData.has(lDateStr)) {
							JsonNode lJsnDateRevenueData = lJsnOpportunityData.get(lDateStr);
							
							RevenueDataId lRevenueDataId = new RevenueDataId();
							
							lRevenueDataId.setIdAdvertiser(this.idAdvertiser);
							lRevenueDataId.setIdWebsite(lUserWebsite.getId());
							lRevenueDataId.setAdType(adType);
							lRevenueDataId.setDate( new java.sql.Date(lCurrentDate.getTime()));
							
							if(revenueDataMap.containsKey(lRevenueDataId)) {
								RevenueData lRevenueData = revenueDataMap.get(lRevenueDataId);
								
								float lCpm = lRevenueData.getCpm() + Float.parseFloat(lJsnDateRevenueData.get("erpm").asText());
								float lGrossAmount = lRevenueData.getAmount() + Float.parseFloat(lJsnDateRevenueData.get("revenue").asText());
								int lImpressions = lRevenueData.getImpressions() + lJsnDateRevenueData.get("monetized").asInt();
								
								BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
								BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
								BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
								BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
								BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
								
								
								lRevenueData.setAmount(lGrossAmount);
								lRevenueData.setCpm(lCpm);
								lRevenueData.setCurrency("USD");
								lRevenueData.setSourceCurrency("USD");
								lRevenueData.setImpressions(lImpressions);
								lRevenueData.setTotalImpressions(lImpressions);//TO-DO need to take total impressions
								lRevenueData.setPlatformFee(lPlatformFee);
								lRevenueData.setErelegoAmount(erelegoShare);
								lRevenueData.setPublisherAmount(publisherShare);
								revenueDataMap.put(lRevenueDataId, lRevenueData);
								
							}else {
								RevenueData lRevenueData = new RevenueData();
								lRevenueData.setRevenueDataId(lRevenueDataId);
																
								float lCpm = Float.parseFloat(lJsnDateRevenueData.get("erpm").asText());
								float lGrossAmount = Float.parseFloat(lJsnDateRevenueData.get("revenue").asText());
								int lImpressions = lJsnDateRevenueData.get("monetized").asInt();
								BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
								BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
								BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
								BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
								BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
								
								
								lRevenueData.setAmount(lGrossAmount);
								lRevenueData.setCpm(lCpm);
								lRevenueData.setCurrency("USD");
								lRevenueData.setSourceCurrency("USD");
								lRevenueData.setImpressions(lImpressions);
								lRevenueData.setTotalImpressions(lImpressions);//TO-DO need to take total impressions
								lRevenueData.setPlatformFee(lPlatformFee);
								lRevenueData.setErelegoAmount(erelegoShare);
								lRevenueData.setPublisherAmount(publisherShare);
								
								
								revenueDataMap.put(lRevenueDataId, lRevenueData);
							}
							
						}
						Calendar calendar = Calendar.getInstance();
				        calendar.setTime(lCurrentDate);
				        calendar.add(Calendar.DATE, 1);
				        lCurrentDate = calendar.getTime();
					}
				}
				}
			}
		}
		
		for(RevenueData lRevenueData : revenueDataMap.values()) {
			Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(lRevenueData);
		}
	}

}
