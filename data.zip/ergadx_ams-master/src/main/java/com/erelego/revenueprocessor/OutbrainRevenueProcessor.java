package com.erelego.revenueprocessor;

import java.io.FileInputStream;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;

import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueData;
import com.erelego.model.RevenueDataId;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserWebsiteService;
import com.erelego.util.DateUtil;
import com.erelego.util.FileUtil;
import com.fasterxml.jackson.databind.JsonNode;

public class OutbrainRevenueProcessor implements IAdvertiserRevenueProcessor {

	private static Logger LOGGER = LogManager.getLogger(OpenxRevenueProcessor.class);
	JsonNode configData = null;
	int idAdvertiser = 0;
	String adType="";
	@Autowired
	private UserWebsiteService userWebsiteService;
	@Autowired
	private EntityManager entityManager;
	private Map<String,String> sectionData;
	@Autowired
	private CurrencyRateService currencyRateService;
	
	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;

	private Map<String,Double> currencyRates;
	private Map<String,WebsiteAdvertiserRevenueShare> websiteRevShareData;
	
	@Value("${reportPath}")
	private String reportPath;
	private int skipNoOfRows = 0;
	
	@Value("${processedReportPath}")
	private String processedReportPath;
	
	private String filePath;
	private Date reportDate;
	
	
	
	Map<String,String> ladType = new HashMap<String,String>();
	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception {
		// TODO Auto-generated method stub
		configData = revenueProcessorConfiguration.getJsnConfigData();
		adType=revenueProcessorConfiguration.getAdType();
		this.filePath = revenueProcessorConfiguration.getFilePath();
		this.idAdvertiser = revenueProcessorConfiguration.getIdAdvertiser();
		this.skipNoOfRows = revenueProcessorConfiguration.getSkipNumberOfRows();
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
		sectionData = this.loadSectionData();

	}
	
	private Map<String,String> loadSectionData(){
		Map<String,String> lSectionUrlData = new HashMap<String,String>();
		Query lQueryGetAdsTxtForWebsite = entityManager.createNativeQuery("select section_name,website_url from ams_advertiser_revenue_processor_config_outbrain_ext");
     	List<?> lResultSectionData = lQueryGetAdsTxtForWebsite.getResultList();

     	for(int i=0 ; i < lResultSectionData.size() ; i++) {
    		Object[] lRecordSectionData  = (Object[]) lResultSectionData.get(i);    		
    		lSectionUrlData.put(lRecordSectionData[0].toString(), lRecordSectionData[1].toString());

    		
    	}
		return lSectionUrlData;
	}

	@Override
	public void doAuthentication() throws Exception {
		// TODO Auto-generated method stub

	}
	
	@Transactional
	@Override
	public void fetchData(Date pStartDate, Date endDate) throws Exception {
		// TODO Auto-generated method stub
		String lFilePath = this.reportPath + this.filePath;
		Map<String,UserWebsite> mapWebsite = this.userWebsiteService.getAllWebsiteMapWithURLAsId();	
		int totalNumberOfRows = 0;
		this.reportDate = pStartDate;
		
		String fileExtension = FilenameUtils.getExtension(this.filePath);
		String fileName = FilenameUtils.getBaseName(this.filePath);
		
		FileInputStream file = new FileInputStream(this.reportPath + this.filePath);

		
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
        
        JsonNode fieldsData = this.configData.get("fields");
		Map<RevenueDataId,RevenueData> revenueDataMap = new HashMap<RevenueDataId,RevenueData>();
        while (rowIterator.hasNext()) 	
        {
        	if(totalNumberOfRows < this.skipNoOfRows) {
        		totalNumberOfRows++;
        		continue;
        	}

            Row row = rowIterator.next();
            if( row.getCell(0)!=null ) {
    
            Cell adNameCell = row.getCell(1);
            String adName =  adNameCell.getStringCellValue();
            String websiteUrl = sectionData.get(adName);
            UserWebsite lUserWebsite = mapWebsite.get(websiteUrl); 
            if(lUserWebsite != null ) {
            	Date recordDate = null;
    			float amount = 0.0f;
	            int impressions = 0;
	            float cpm = 0.0f;
	           
	            if(fieldsData.has("impressions")) {
	            	Cell cell = row.getCell(fieldsData.get("impressions").get("index").asInt());
	            	if(cell.getCellType() == CellType.STRING)
	            		impressions = Integer.parseInt(cell.getStringCellValue());            	
	                else
	                	impressions=  (int) cell.getNumericCellValue();
	            }
	            
	            if(fieldsData.has("amount")) {
	            	Cell cell = row.getCell(fieldsData.get("amount").get("index").asInt());
	            	if(cell.getCellType() == CellType.STRING) {
	            		String lStrAmount = cell.getStringCellValue();
	            		amount = this.cleanseCurrencyField(lStrAmount);
	            	}
	                else
	                    amount =  (float) cell.getNumericCellValue();
	            }
	            if(fieldsData.has("cpm")) {
	            	Cell cell = row.getCell(fieldsData.get("cpm").get("index").asInt());
	            	if(cell.getCellType() == CellType.STRING) {
	            		String lStrEcpm = cell.getStringCellValue();
	            		cpm = this.cleanseCurrencyField(lStrEcpm);
	            	}
	                else
	                    cpm =  (float) cell.getNumericCellValue();
	            }
	            if(fieldsData.has("date")) {
	            	Cell cell = row.getCell(fieldsData.get("date").get("index").asInt());
	            	String dateFormat = fieldsData.get("date").get("format").asText();
	            	
	            	if(cell.getCellType() == CellType.STRING) {
	            		String strDate = cell.getStringCellValue();
	            		recordDate = DateUtil.getDateFromStringFormat(dateFormat, strDate);
	            	}else {
	                	recordDate = cell.getDateCellValue();
	                }
	            } 
	            
	            RevenueDataId lRevenueDataId = new RevenueDataId();
				lRevenueDataId.setDate(new java.sql.Date(recordDate.getTime()));
				lRevenueDataId.setIdAdvertiser(this.idAdvertiser);
				lRevenueDataId.setIdWebsite(lUserWebsite.getId());
				lRevenueDataId.setAdType(adType);
				String lMapKey = lUserWebsite.getId() + "-" + this.idAdvertiser;
				WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare = this.websiteRevShareData.get(lMapKey);
				if(lWebsiteAdvertiserRevenueShare != null) {
					RevenueData lRevenueData = null;
					if(revenueDataMap.containsKey(lRevenueDataId)) {
						lRevenueData = revenueDataMap.get(lRevenueDataId);
						float lCpm = lRevenueData.getCpm() + cpm;
						float lGrossAmount = lRevenueData.getAmount() + amount;
						int lImpressions = lRevenueData.getImpressions() + impressions;
						
						
						BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
						BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
						BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
						BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
						BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
						
						lRevenueData.setAmount(lGrossAmount);
						lRevenueData.setCpm(lCpm);
						lRevenueData.setCurrency("USD");
						lRevenueData.setSourceCurrency("USD");
						lRevenueData.setImpressions(lImpressions);
						lRevenueData.setPlatformFee(lPlatformFee);
						lRevenueData.setErelegoAmount(erelegoShare);
						lRevenueData.setPublisherAmount(publisherShare);
						
						revenueDataMap.put(lRevenueDataId, lRevenueData);
	
					}else {
						float lCpm = cpm;
						float lGrossAmount = amount;
						int lImpressions = impressions;
					
						BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
						BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
						BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
						BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
						BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
						
						lRevenueData = new RevenueData();
						lRevenueData.setAmount(lGrossAmount);
						lRevenueData.setCpm(lCpm);
						lRevenueData.setCurrency("USD");
						lRevenueData.setSourceCurrency("USD");
						lRevenueData.setImpressions(lImpressions);
						lRevenueData.setRevenueDataId(lRevenueDataId);
						lRevenueData.setPlatformFee(lPlatformFee);
						lRevenueData.setErelegoAmount(erelegoShare);
						lRevenueData.setPublisherAmount(publisherShare);
					
						revenueDataMap.put(lRevenueDataId, lRevenueData);
					}
					
					lRevenueData.setRevenueDataId(lRevenueDataId);
				}else {
					LOGGER.error("Revenue Share Config not found for website : " + lUserWebsite.getHostURL() + " And advertiser id : " + this.idAdvertiser);					
				}
            }else {
				LOGGER.error(adName + " not found");
				LOGGER.error("insert into ams_advertiser_revenue_processor_config_outbrain_ext (section_name,website_url) values '"+adName+"','"+adName+"');");

			}
        	totalNumberOfRows++;
        }
        }
        for(RevenueData lRevenueData : revenueDataMap.values()) {
			
			Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(lRevenueData);
		
		}
        workbook.close();
        
        file.close();
        
        String processedFileName = fileName + DateUtil.getFormattedDate(new Date(), "dd-MM-yyyy-hh-mm-ss") + "." + fileExtension;
     
        FileUtil.moveFile(this.reportPath + this.filePath, this.processedReportPath +  processedFileName);

	}

	@Override
	public void processData() throws Exception {
		// TODO Auto-generated method stub

	}

}
