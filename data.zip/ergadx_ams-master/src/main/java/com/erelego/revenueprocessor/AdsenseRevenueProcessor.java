package com.erelego.revenueprocessor;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueData;
import com.erelego.model.RevenueDataId;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserService;
import com.erelego.service.UserWebsiteService;
import com.erelego.util.DateUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.adsense.v2.Adsense;
import com.google.api.services.adsense.v2.AdsenseScopes;
import com.google.api.services.adsense.v2.Adsense.Accounts.Reports.Generate;
import com.google.api.services.adsense.v2.model.Account;
import com.google.api.services.adsense.v2.model.Cell;
import com.google.api.services.adsense.v2.model.Header;
import com.google.api.services.adsense.v2.model.ListAccountsResponse;
import com.google.api.services.adsense.v2.model.ReportResult;
import com.google.api.services.adsense.v2.model.Row;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.apache.logging.log4j.LogManager;
@Service
public class AdsenseRevenueProcessor implements IAdvertiserRevenueProcessor {

	private static Logger LOGGER = LogManager.getLogger(AdsenseRevenueProcessor.class);
	@Value("${dashboardConfigDir}")
	private String dashboardConfigDir;
	//private java.io.File DATA_STORE_DIR = new java.io.File(System.getProperty("user.home"),".store/adsense_management_sample");
	private java.io.File DATA_STORE_DIR ; 
	private FileDataStoreFactory dataStoreFactory;
	private JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	private HttpTransport httpTransport;
	private String publisherAccountId;
	private String clientSecretPath;
	private Adsense adsense;

	private List<Row> revenueData;
	private int idAdvertiser;
	private String adType;
	@Autowired
	private UserWebsiteService userWebsiteService;
	
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private CurrencyRateService currencyRateService;
	
	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;
	
	private Map<String,Double> currencyRates;
	
	private Map<String,WebsiteAdvertiserRevenueShare> websiteRevShareData;
	
	private Date reportDate;

	public AdsenseRevenueProcessor() {
		
	}
	
	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfig) throws Exception {
		
		DATA_STORE_DIR = new java.io.File(dashboardConfigDir); 
		JsonNode configurationData = revenueProcessorConfig.getJsnConfigData();
		this.idAdvertiser = revenueProcessorConfig.getIdAdvertiser();
		this.clientSecretPath = configurationData.get("APIConfigFilePath").asText();
		this.publisherAccountId = configurationData.get("PubAccountId").asText();
		this.httpTransport = GoogleNetHttpTransport.newTrustedTransport();
		this.dataStoreFactory = new FileDataStoreFactory(this.DATA_STORE_DIR);
		this.adsense = initializeAdsense();
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
		this.adType=revenueProcessorConfig.getAdType();

	}

	private Credential authorize() throws Exception {
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(this.JSON_FACTORY,
				new InputStreamReader(new FileInputStream(this.clientSecretPath)));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(this.httpTransport,
				this.JSON_FACTORY, clientSecrets, Collections.singleton(AdsenseScopes.ADSENSE_READONLY))
						.setDataStoreFactory(this.dataStoreFactory).build();
		return new AuthorizationCodeInstalledApp(flow, new LocalServerReceiver()).authorize("user");
	}

	@Override
	public void doAuthentication() throws Exception {
	
	}

	@Override
	public void fetchData(Date pStartDate,Date pEndDate) throws Exception {
		this.reportDate = pStartDate;
		String lStrStartDate = "";
		String lStrEndDate = "";
		if (pStartDate == null) {
			lStrStartDate = DateUtil.getStringDateFromToday(-1,"yyyy-MM-dd");
			lStrEndDate = DateUtil.getStringDateFromToday(-1,"yyyy-MM-dd");
		}else {
			lStrStartDate = DateUtil.getFormattedDate(pStartDate, "yyyy-MM-dd");
			lStrEndDate = DateUtil.getFormattedDate(pEndDate, "yyyy-MM-dd");
		}
		ListAccountsResponse lResponse = null;
		lResponse = adsense.accounts().list()
	          .setPageSize(50)
	          .setPageToken(null)
	          .execute();

	    Generate request = adsense.accounts().reports().generate(publisherAccountId);//, lStrStartDate, lStrEndDate);
		request.setDateRange("CUSTOM");
		request.setStartDateDay(pStartDate.getDate());
		request.setStartDateMonth(pStartDate.getMonth() + 1);
		request.setStartDateYear(pStartDate.getYear() + 1900);
		
		request.setEndDateDay(pEndDate.getDate());
		request.setEndDateMonth(pEndDate.getMonth() + 1);
		request.setEndDateYear(pEndDate.getYear() + 1900);
		
		request.setMetrics(Arrays.asList("PAGE_VIEWS", "AD_REQUESTS", "AD_REQUESTS_COVERAGE", "CLICKS",
				"AD_REQUESTS_CTR", "COST_PER_CLICK", "AD_REQUESTS_RPM", "ESTIMATED_EARNINGS"));
		//request.setUseTimezoneReporting(true);
		request.setDimensions(Arrays.asList("DATE", "DOMAIN_NAME"));
		request.setOrderBy(Arrays.asList("+DATE"));
		ReportResult response = request.execute();
		this.revenueData = response.getRows();
	      for (Header header : response.getHeaders()) {
	          System.out.printf("%25s", header.getName());
	        }
	        System.out.println();
		for (Row row : this.revenueData) {
	        for (Cell cell : row.getCells()) {
	          System.out.printf("%25s", cell.getValue());
	        }
	        System.out.println();
	        }
}
	
	

	

	@Override
	@Transactional
	public void processData() throws Exception {
		Map<String,UserWebsite> mapWebsite = this.userWebsiteService.getAllWebsiteMapWithURLAsId();	
		Map<RevenueDataId,RevenueData> revenueDataMap = new HashMap<RevenueDataId,RevenueData>();
		if (this.revenueData != null && !this.revenueData.isEmpty()) {
			for (Row row : this.revenueData) { 
				List<Cell> cells = row.getCells();
				String lStrWebsiteUrl = cells.get(1).getValue().replace("www.", "");
				UserWebsite lUserWebsite = mapWebsite.get(lStrWebsiteUrl);
				if(lUserWebsite != null &&  ! cells.get(0).getValue().isEmpty()) {
					String lMapKey = lUserWebsite.getId() + "-" + this.idAdvertiser;
					WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare = this.websiteRevShareData.get(lMapKey);
					if(lWebsiteAdvertiserRevenueShare != null) {
						Date lDate = DateUtil.getDateFromStringFormat("yyyy-MM-dd", cells.get(0).getValue().toString());
						String lImpressions = cells.get(3).getValue().toString();
						String lCpm = cells.get(8).getValue().toString();
						String lAmount = cells.get(9).getValue().toString();
						
						RevenueDataId lRevenueDataId = new RevenueDataId();
						lRevenueDataId.setDate(new java.sql.Date(lDate.getTime()));
						lRevenueDataId.setIdAdvertiser(this.idAdvertiser);
						lRevenueDataId.setIdWebsite(lUserWebsite.getId());
						lRevenueDataId.setAdType(adType);
						RevenueData lRevenueData = null;
						if(revenueDataMap.containsKey(lRevenueDataId)) {
							lRevenueData = revenueDataMap.get(lRevenueDataId);
							try {
								float lGrossAmount = lRevenueData.getAmount() + Float.parseFloat(lAmount);
								BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
								BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
								BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
								BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
								BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
								
								lRevenueData.setAmount(lGrossAmount);
								lRevenueData.setPlatformFee(lPlatformFee);
								lRevenueData.setErelegoAmount(erelegoShare);
								lRevenueData.setPublisherAmount(publisherShare);
								
							}catch(NumberFormatException e ) {
								lRevenueData.setAmount(lRevenueData.getAmount());
							}
							try {
								lRevenueData.setCpm(lRevenueData.getCpm() + Float.parseFloat(lCpm));
							}catch(NumberFormatException e ) {
								lRevenueData.setCpm(lRevenueData.getCpm());
							}
							try {
								lRevenueData.setImpressions(lRevenueData.getImpressions() + Integer.parseInt(lImpressions));
								lRevenueData.setTotalImpressions(lRevenueData.getImpressions() + Integer.parseInt(lImpressions));
	
							}catch(NumberFormatException e ) {
								lRevenueData.setImpressions(lRevenueData.getImpressions() );
								lRevenueData.setTotalImpressions(lRevenueData.getTotalImpressions());
							}
						}else {
							lRevenueData = new RevenueData();
							try{
								float lGrossAmount = Float.parseFloat(lAmount);
								BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
								BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
								BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
								BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
								BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
	
								lRevenueData.setAmount(lGrossAmount);
								lRevenueData.setPlatformFee(lPlatformFee);
								lRevenueData.setErelegoAmount(erelegoShare);
								lRevenueData.setPublisherAmount(publisherShare);
								
							}catch(NumberFormatException e) {
								lRevenueData.setAmount(0.0f);
							}
							try{
								lRevenueData.setCpm(Float.parseFloat(lCpm));
							}catch(NumberFormatException e) {
								lRevenueData.setCpm(0.0f);
							}
							try{
								lRevenueData.setImpressions(Integer.parseInt(lImpressions));
								lRevenueData.setTotalImpressions(Integer.parseInt(lImpressions));
							}catch(NumberFormatException e) {
								lRevenueData.setImpressions(0);
								lRevenueData.setTotalImpressions(0);
							}
							lRevenueData.setRevenueDataId(lRevenueDataId);
							revenueDataMap.put(lRevenueDataId, lRevenueData);
						}
					} else {
						LOGGER.error("Revenue Share Config not found for website : " + lUserWebsite.getHostURL() + " And advertiser id : " + this.idAdvertiser);						
					}
				}else {
					LOGGER.error(lStrWebsiteUrl + " not found");
					LOGGER.error("insert into ams_user_websites (id_user,name,host_url,http_enabled,https_enabled,active,created_date,created_by,modified_date,modified_by) values (58,'"+lStrWebsiteUrl+"','"+lStrWebsiteUrl+"',1,1,1,now(),1,now(),1);");
					//System.out.println(lStrWebsiteUrl + " not found");
				}
			}
			
			for(RevenueData lRevenueData : revenueDataMap.values()) {
					Session session = this.entityManager.unwrap(Session.class);
					session.saveOrUpdate(lRevenueData);
			}
		}

	}
	
	

	public Adsense initializeAdsense() throws Exception {
		Credential credential = authorize();

		// Set up AdSense Management API client.
		return new Adsense.Builder(new NetHttpTransport(), this.JSON_FACTORY, credential).setApplicationName("23")
				.build();
	}

	/*
	 * @Override public void setUserWebsiteService(UserWebsiteService
	 * userWebsiteService) { this.userWebsiteService = userWebsiteService;
	 * 
	 * }
	 * 
	 * @Override public void setEntityManager(EntityManager entityManager) {
	 * this.entityManager = entityManager; }
	 */

}
