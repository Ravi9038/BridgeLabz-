package com.erelego.revenueprocessor;

import java.io.FileReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueData;
import com.erelego.model.RevenueDataId;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserWebsiteService;
import com.erelego.util.Constants;
import com.erelego.util.DateUtil;
import com.erelego.util.FileUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.opencsv.CSVReader;

public class AniviewCSVRevnueProcessor implements IAdvertiserRevenueProcessor{
	JsonNode configData = null;
	private static Logger LOGGER = LogManager.getLogger(AniviewCSVRevnueProcessor.class);
	int idAdvertiser = 0;
	String adType="";
	@Autowired
	private UserWebsiteService userWebsiteService;

	@Autowired
	private EntityManager entityManager;
	private Map<String, String> sectionData;

	@Value("${reportPath}")
	private String reportPath;
	private int skipNoOfRows = 0;

	@Value("${processedReportPath}")
	private String processedReportPath;

	private String filePath;
	@Autowired
	private CurrencyRateService currencyRateService;

	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;

	private Map<String, Double> currencyRates;
	private Map<String, WebsiteAdvertiserRevenueShare> websiteRevShareData;
	private Double dblConversionRate = 0.0;
	private String strSourceCurrency;
	private String strDestCurrency;

	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception {
		configData = revenueProcessorConfiguration.getJsnConfigData();
		adType=revenueProcessorConfiguration.getAdType();
		this.filePath = revenueProcessorConfiguration.getFilePath();
		this.idAdvertiser = revenueProcessorConfiguration.getIdAdvertiser();
		this.skipNoOfRows = revenueProcessorConfiguration.getSkipNumberOfRows();
		this.strSourceCurrency = revenueProcessorConfiguration.getSrcCurrencyCode();
		this.strDestCurrency = revenueProcessorConfiguration.getDecCurrencyCode();
	
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.dblConversionRate = this.currencyRates.get(this.strSourceCurrency + "-" + this.strDestCurrency);
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
	}



	@Override
	public void doAuthentication() throws Exception {

	}

	@Override
	@Transactional(propagation = Propagation.NESTED)
	public void fetchData(Date pStartDate, Date pEndDate) throws Exception {
		String lFilePath = this.reportPath + this.filePath;
		Reader lReader = new FileReader(lFilePath);
		String fileExtension = FilenameUtils.getExtension(this.filePath);
		String fileName = FilenameUtils.getBaseName(this.filePath);
		Map<String, UserWebsite> mapWebsite = this.userWebsiteService.getAllWebsiteMapWithURLAsId();
		Map<RevenueDataId, RevenueData> revenueDataMap = new HashMap<RevenueDataId, RevenueData>();
		int totalNumberOfRows = 0;
		Date dtYesterday = DateUtil.subtractDays(new Date(), 1);
		java.sql.Date sqlDate = new java.sql.Date(dtYesterday.getTime());
		CSVReader csvReader = new CSVReader(lReader);
		String[] line;
		while ((line = csvReader.readNext()) != null) {
			if ( totalNumberOfRows < this.skipNoOfRows ) {
				totalNumberOfRows++;
				continue;
			}
			if( ! line[1].equalsIgnoreCase("")) {
//			String lSection = 

			String lWebsiteUrl = line[1];
			UserWebsite lUserWebsite = mapWebsite.get(lWebsiteUrl);

			String simpressions = line[2];
			
			String samount = line[3];
			String scpm = line[4];
			System.out.println(lWebsiteUrl);
//			System.out.println(lSection);
			System.out.println(samount);
			System.out.println(simpressions);

			Date recordDate = null;
			int impressions = Integer.parseInt(simpressions);
			float lamount = Float.parseFloat(samount);
			float amount = (float) (dblConversionRate * lamount);
			System.out.println(amount);
			float cpm = Float.parseFloat(scpm);

			if (lUserWebsite != null) {
				String lMapKey = lUserWebsite.getId() + "-" + this.idAdvertiser;
				WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare = this.websiteRevShareData.get(lMapKey);
				if (lWebsiteAdvertiserRevenueShare != null) {
			
					String strDate = line[0];
					recordDate = DateUtil.getDateFromStringFormat(Constants.ddMMYYYY, strDate);
					RevenueDataId lRevenueDataId = new RevenueDataId();
					lRevenueDataId.setDate(new java.sql.Date(recordDate.getTime()));
					lRevenueDataId.setIdAdvertiser(this.idAdvertiser);
					lRevenueDataId.setIdWebsite(lUserWebsite.getId());
					lRevenueDataId.setAdType(adType);
					RevenueData lRevenueData = null;
					if (revenueDataMap.containsKey(lRevenueDataId)) {
						lRevenueData = revenueDataMap.get(lRevenueDataId);
						float lCpm = lRevenueData.getCpm() + cpm;
						float lGrossAmount = lRevenueData.getAmount() + amount;
						int lImpressions = lRevenueData.getImpressions() + impressions;
						BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
						BigDecimal lPlatformFee = lBigDecGrossAmount
								.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
						BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
						BigDecimal publisherShare = lAmountWithoutFlatformFee
								.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
						BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);

						lRevenueData.setAmount(lGrossAmount);
						lRevenueData.setCpm(lCpm);
						lRevenueData.setCurrency(this.strDestCurrency);
						lRevenueData.setSourceCurrency(this.strSourceCurrency);
						lRevenueData.setImpressions(lImpressions);
						lRevenueData.setTotalImpressions(lImpressions);// TO-DO need to take total impressions
						lRevenueData.setPlatformFee(lPlatformFee);
						lRevenueData.setErelegoAmount(erelegoShare);
						lRevenueData.setPublisherAmount(publisherShare);
					} else {
						float lCpm = cpm;
						float lGrossAmount = amount;
						int lImpressions = impressions;
						BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
						BigDecimal lPlatformFee = lBigDecGrossAmount
								.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
						BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
						BigDecimal publisherShare = lAmountWithoutFlatformFee
								.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
						BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);

						lRevenueData = new RevenueData();
						lRevenueData.setAmount(lGrossAmount);
						lRevenueData.setCpm(lCpm);
						lRevenueData.setCurrency(this.strDestCurrency);
						lRevenueData.setSourceCurrency(this.strSourceCurrency);
						lRevenueData.setImpressions(lImpressions);
						lRevenueData.setTotalImpressions(lImpressions);// TO-DO need to take total impressions
						lRevenueData.setRevenueDataId(lRevenueDataId);
						lRevenueData.setPlatformFee(lPlatformFee);
						lRevenueData.setErelegoAmount(erelegoShare);
						lRevenueData.setPublisherAmount(publisherShare);
						revenueDataMap.put(lRevenueDataId, lRevenueData);
					}
					lRevenueData.setRevenueDataId(lRevenueDataId);
				} else {
					LOGGER.error("Revenue Share Config not found for website : " + lUserWebsite.getHostURL() + " And advertiser id : " + this.idAdvertiser);
				}

			} else {
				LOGGER.error(lWebsiteUrl + " not found");
				LOGGER.error(
						"insert into ams_user_websites (id_user,name,host_url,http_enabled,https_enabled,active,created_date,created_by,modified_date,modified_by) values (58,'"
								+ lWebsiteUrl + "','" + lWebsiteUrl + "',1,1,1,now(),1,now(),1);");

			}
			totalNumberOfRows++;
		}
	}
		for (RevenueData lRevenueData : revenueDataMap.values()) {

			Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(lRevenueData);

		}
	
		lReader.close();
		csvReader.close();
		String processedFileName = fileName + DateUtil.getFormattedDate(new Date(), "dd-MM-yyyy-hh-mm-ss") + "."
				+ fileExtension;
		FileUtil.moveFile(this.reportPath + this.filePath, this.processedReportPath + processedFileName);
	}

	@Override
	public void processData() throws Exception {

	}

	
}
