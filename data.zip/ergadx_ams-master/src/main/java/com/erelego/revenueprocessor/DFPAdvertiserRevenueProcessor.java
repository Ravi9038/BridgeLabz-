package com.erelego.revenueprocessor;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueData;
import com.erelego.model.RevenueDataId;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserWebsiteService;
import com.erelego.util.DateUtil;
import com.erelego.util.FileUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.api.ads.admanager.axis.factory.AdManagerServices;
import com.google.api.ads.admanager.axis.utils.v202105.ReportDownloader;
import com.google.api.ads.admanager.axis.v202105.Column;
import com.google.api.ads.admanager.axis.v202105.DateRangeType;
import com.google.api.ads.admanager.axis.v202105.Dimension;
import com.google.api.ads.admanager.axis.v202105.ExportFormat;
import com.google.api.ads.admanager.axis.v202105.Network;
import com.google.api.ads.admanager.axis.v202105.NetworkServiceInterface;
import com.google.api.ads.admanager.axis.v202105.ReportDownloadOptions;
import com.google.api.ads.admanager.axis.v202105.ReportJob;
import com.google.api.ads.admanager.axis.v202105.ReportJobStatus;
import com.google.api.ads.admanager.axis.v202105.ReportQuery;
import com.google.api.ads.admanager.axis.v202105.ReportServiceInterface;
import com.google.api.ads.admanager.axis.v202105.TimeZoneType;
import com.google.api.ads.admanager.lib.client.AdManagerSession;
import com.google.api.ads.common.lib.auth.OfflineCredentials;
import com.google.api.ads.common.lib.auth.OfflineCredentials.Api;
import com.google.api.client.auth.oauth2.Credential;
import com.google.common.io.Files;
import com.google.common.io.Resources;
import org.apache.logging.log4j.Logger;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;

@Service
public class DFPAdvertiserRevenueProcessor implements IAdvertiserRevenueProcessor {

	private static Logger LOGGER = LogManager.getLogger(DFPAdvertiserRevenueProcessor.class);
	private String configFile;
	private AdManagerSession session;
	private AdManagerServices adManagerServices;
	private File reportFile;
	private int idAdvertiser;
	String adType="";
	@Autowired
	private UserWebsiteService userWebsiteService;

	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private CurrencyRateService currencyRateService;
	
	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;
	
	private Map<String,Double> currencyRates;
	private Map<String,WebsiteAdvertiserRevenueShare> websiteRevShareData;
	private Date reportDate;
	
	@Value("${reportPath}")
	private String reportPath;
	
	@Value("${processedReportPath}")
	private String processedReportPath;

	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception {
		JsonNode configurationData = revenueProcessorConfiguration.getJsnConfigData();
		adType=revenueProcessorConfiguration.getAdType();
		this.configFile = configurationData.get("APIConfigFilePath").asText();
		this.idAdvertiser = revenueProcessorConfiguration.getIdAdvertiser();
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
		
	}

	@Override
	public void doAuthentication() throws Exception {
		//Resource resource = new ClassPathResource(configFile);
		File adsPropertiesFiles = new File(this.configFile);//resource.getFile();
		Credential oAuth2Credential = new OfflineCredentials.Builder().forApi(Api.AD_MANAGER)
				.fromFile(adsPropertiesFiles).build().generateCredential();
		session = new AdManagerSession.Builder().fromFile(adsPropertiesFiles).withOAuth2Credential(oAuth2Credential)
				.build();
		adManagerServices = new AdManagerServices();
		NetworkServiceInterface networkService = adManagerServices.get(session, NetworkServiceInterface.class);

		// Get all networks that you have access to with the current authentication
		// credentials.
		Network[] networks = networkService.getAllNetworks();

		int i = 0;
		for (Network network : networks) {
			System.out.printf("%d) Network with network code '%s' and display name '%s' was found.%n", i++,
					network.getNetworkCode(), network.getDisplayName());
		}
	}

	@Override
	public void fetchData(Date pStartDate,Date pEndDate) throws Exception {
		this.reportDate = pStartDate;
		downloadReportFile(pStartDate,pEndDate);
	}

	@Override
	@Transactional
	public void processData() throws Exception {
		FileInputStream file = new FileInputStream(this.reportFile);
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheetAt(0);
		Iterator<Row> rowIterator = sheet.iterator();
		Map<String, UserWebsite> mapWebsite = this.userWebsiteService.getAllWebsiteMapWithURLAsId();
		Map<RevenueDataId, RevenueData> revenueDataMap = new HashMap<RevenueDataId, RevenueData>();
		while (rowIterator.hasNext()) {
			String websiteURL = "";
			Row row = rowIterator.next();
			String strDate = "";
			if (row.getCell(0).getCellType().equals(CellType.STRING))
				strDate = row.getCell(0).getStringCellValue();
			else
				strDate = String.valueOf(row.getCell(0).getNumericCellValue());

			if (!strDate.equalsIgnoreCase("Total")) {
				if (row.getCell(1).getCellType() == CellType.STRING) {
					websiteURL = row.getCell(1).getStringCellValue();
					websiteURL = websiteURL.replaceAll("http://", "");
					websiteURL = websiteURL.replaceAll("https://", "");
					websiteURL = websiteURL.replaceAll("www.", "");
				}
				UserWebsite lUserWebsite = mapWebsite.get(websiteURL);
				if (lUserWebsite != null) {
					String lMapKey = lUserWebsite.getId() + "-" + this.idAdvertiser;
					WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare = this.websiteRevShareData.get(lMapKey);
					if(lWebsiteAdvertiserRevenueShare != null) {
							Date date = DateUtil.getDateFromStringFormat("M/d/yy", strDate);
							float amount = 0.0f;
							int totalImpressions = 0;
							int adExchangeImpressions = 0;
							float cpm = 0.0f;
							int clicks = 0;
							//int adServerImpressions = 0;
							//int unfilledImpressions = 0;
							if (row.getCell(2).getCellType() == CellType.STRING)
								totalImpressions = Integer.parseInt(row.getCell(2).getStringCellValue());
							else
								totalImpressions = (int) row.getCell(2).getNumericCellValue();
							
							if (row.getCell(3).getCellType() == CellType.STRING)
								adExchangeImpressions = Integer.parseInt(row.getCell(3).getStringCellValue());
							else
								adExchangeImpressions = (int) row.getCell(3).getNumericCellValue();
							
							/*
							 * if (row.getCell(8).getCellType() == CellType.STRING) adServerImpressions =
							 * Integer.parseInt(row.getCell(8).getStringCellValue()); else
							 * adServerImpressions = (int) row.getCell(8).getNumericCellValue();
							 * unfilledImpressions = ( totalImpressions - (adExchangeImpressions +
							 * adServerImpressions)); float unfilledRatio = ( unfilledImpressions /
							 * totalImpressions ) * 100; if(unfilledRatio > 5) {
							 * LOGGER.debug("Unfilled ratio is high"); }
							 */
							
							if (row.getCell(4).getCellType() == CellType.STRING)
								clicks = Integer.parseInt(row.getCell(4).getStringCellValue());
							else
								clicks = (int) row.getCell(4).getNumericCellValue();
							
							
							
							
							if (row.getCell(5).getCellType() == CellType.STRING)
								cpm = Float.parseFloat(row.getCell(6).getStringCellValue());
							else
								cpm = (float) row.getCell(6).getNumericCellValue();
		
							if (row.getCell(6).getCellType() == CellType.STRING)
								amount = Float.parseFloat(row.getCell(7).getStringCellValue());
							else
								amount = (float) row.getCell(7).getNumericCellValue();
		
							RevenueDataId lRevenueDataId = new RevenueDataId();
							lRevenueDataId.setDate(new java.sql.Date(date.getTime()));
							lRevenueDataId.setIdAdvertiser(this.idAdvertiser);
							lRevenueDataId.setIdWebsite(lUserWebsite.getId());
							lRevenueDataId.setAdType(adType);
							RevenueData lRevenueData = null;
							if (revenueDataMap.containsKey(lRevenueDataId)) {
								lRevenueData = revenueDataMap.get(lRevenueDataId);
								float lCpm = lRevenueData.getCpm() + cpm;
								float lGrossAmount = lRevenueData.getAmount() + amount;
								int lImpressions = lRevenueData.getImpressions() + adExchangeImpressions;
								int lClicks = lRevenueData.getClicks() + clicks;
								
								BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
								BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
								BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
								BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
								BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
								
								lRevenueData.setAmount(lGrossAmount);
								lRevenueData.setCpm(lCpm);
								lRevenueData.setCurrency("USD");
								lRevenueData.setSourceCurrency("USD");
								lRevenueData.setImpressions(lImpressions);
								lRevenueData.setTotalImpressions(lImpressions);//TO-DO need to take total impressions
								lRevenueData.setClicks(lClicks);
								lRevenueData.setPlatformFee(lPlatformFee);
								lRevenueData.setErelegoAmount(erelegoShare);
								lRevenueData.setPublisherAmount(publisherShare);
								
								revenueDataMap.put(lRevenueDataId, lRevenueData);
		
							} else {
								float lCpm = cpm;
								float lGrossAmount = amount;
								int lImpressions = adExchangeImpressions;
								int lClicks = clicks;
								
								BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
								BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
								BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
								BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
								BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
								
								lRevenueData = new RevenueData();
								lRevenueData.setAmount(lGrossAmount);
								lRevenueData.setCpm(lCpm);
								lRevenueData.setCurrency("USD");
								lRevenueData.setSourceCurrency("USD");
								lRevenueData.setImpressions(lImpressions);
								lRevenueData.setTotalImpressions(lImpressions);//TO-DO need to take total impressions
								lRevenueData.setClicks(lClicks);
								lRevenueData.setRevenueDataId(lRevenueDataId);
								lRevenueData.setPlatformFee(lPlatformFee);
								lRevenueData.setErelegoAmount(erelegoShare);
								lRevenueData.setPublisherAmount(publisherShare);
								
								revenueDataMap.put(lRevenueDataId, lRevenueData);
							}
		
							lRevenueData.setRevenueDataId(lRevenueDataId);
					}else {
						LOGGER.error("Revenue Share Config not found for website : " + lUserWebsite.getHostURL() + " And advertiser id : " + this.idAdvertiser);
					}
				} else {
					LOGGER.error(websiteURL + " not found");
					LOGGER.error("insert into ams_user_websites (id_user,name,host_url,http_enabled,https_enabled,active,created_date,created_by,modified_date,modified_by) values (58,'"+websiteURL+"','"+websiteURL+"',1,1,1,now(),1,now(),1);");
				}
			}

		}

		for (RevenueData lRevenueData : revenueDataMap.values()) {
			Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(lRevenueData);
		}
		workbook.close();
		file.close();
		String fileExtension = FilenameUtils.getExtension(this.reportFile.getName());
		String fileName = FilenameUtils.getBaseName(this.reportFile.getName());
        String processedFileName = fileName + DateUtil.getFormattedDate(new Date(), "dd-MM-yyyy-hh-mm-ss") + "." + fileExtension;
        FileUtil.moveFile(this.reportFile.getAbsolutePath(), this.processedReportPath + processedFileName);

	}

	private void downloadReportFile(Date pStartDate,Date pEndDate) throws Exception {
		
		Calendar startCalDate = Calendar.getInstance();
		
		
		Calendar endCalDate = Calendar.getInstance();
		
		if(pStartDate != null) {
			startCalDate.setTime(pStartDate);
			endCalDate.setTime(pEndDate);
		}else {
			Date yesterDay = DateUtil.getDateFromToday(-1);
			startCalDate.setTime(yesterDay);
			endCalDate.setTime(yesterDay);
		}
		
		ReportServiceInterface reportService = adManagerServices.get(session, ReportServiceInterface.class);
		ReportQuery reportQuery = new ReportQuery();
		reportQuery.setDimensions(new Dimension[] { Dimension.DATE, Dimension.AD_EXCHANGE_SITE_NAME });
		reportQuery.setColumns(
				new Column[] { Column.AD_EXCHANGE_AD_REQUESTS, Column.AD_EXCHANGE_IMPRESSIONS, Column.AD_EXCHANGE_CLICKS,
						Column.AD_EXCHANGE_CPC, Column.AD_EXCHANGE_AD_ECPM, Column.AD_EXCHANGE_ESTIMATED_REVENUE});
		reportQuery.setAdxReportCurrency("USD");
		reportQuery.setTimeZoneType(TimeZoneType.PUBLISHER);
		reportQuery.setDateRangeType(DateRangeType.CUSTOM_DATE);
		
		reportQuery.setStartDate(new com.google.api.ads.admanager.axis.v202105.Date(startCalDate.get(Calendar.YEAR) ,startCalDate.get(Calendar.MONTH) + 1,startCalDate.get(Calendar.DATE)));
		reportQuery.setEndDate(new com.google.api.ads.admanager.axis.v202105.Date(endCalDate.get(Calendar.YEAR) ,endCalDate.get(Calendar.MONTH) + 1, endCalDate.get(Calendar.DATE)));
		ReportJob reportJob = new ReportJob();
		reportJob.setReportQuery(reportQuery);
		reportJob = reportService.runReportJob(reportJob);
		ReportDownloader reportDownloader = new ReportDownloader(reportService, reportJob.getId());
		reportDownloader.waitForReportReady();
		ReportJobStatus status = reportService.getReportJobStatus(reportJob.getId());
		if (status == ReportJobStatus.COMPLETED) {
			this.reportFile = File.createTempFile("adexchange-report-", ".xlsx",new File(this.reportPath));
			System.out.printf("Downloading report to %s ...", this.reportFile.toString());
			ReportDownloadOptions options = new ReportDownloadOptions();
			options.setExportFormat(ExportFormat.XLSX);
			options.setUseGzipCompression(false);
			URL url = reportDownloader.getDownloadUrl(options);
			Resources.asByteSource(url).copyTo(Files.asByteSink(this.reportFile));
		} else {
			throw new Exception("Error while generating report");
		}
	}
}
