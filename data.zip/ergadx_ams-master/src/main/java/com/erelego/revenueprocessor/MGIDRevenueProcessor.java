package com.erelego.revenueprocessor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueData;
import com.erelego.model.RevenueDataId;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserWebsiteService;
import com.erelego.util.DateUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

public class MGIDRevenueProcessor implements IAdvertiserRevenueProcessor{

	JsonNode configData = null;
	int idAdvertiser = 0;
	String adType="";
	@Autowired
	private UserWebsiteService userWebsiteService;
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private CurrencyRateService currencyRateService;
	
	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;
	
	private Map<String,Double> currencyRates;
	private Map<String,WebsiteAdvertiserRevenueShare> websiteRevShareData;
	
	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception {
		configData = revenueProcessorConfiguration.getJsnConfigData();
		adType=revenueProcessorConfiguration.getAdType();
		this.idAdvertiser = revenueProcessorConfiguration.getIdAdvertiser();
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
	}

	@Override
	public void doAuthentication() throws Exception {
		
	}

	@Override
	@Transactional
	public void fetchData(Date pStartDate, Date pEndDate) throws Exception {
		
		String lStrStartDate = "";
		String lStrEndDate = "";
		if (pStartDate == null) {
			lStrStartDate = DateUtil.getStringDateFromToday(-1,"yyyy-MM-dd");
			lStrEndDate = DateUtil.getStringDateFromToday(-1,"yyyy-MM-dd");
		}else {
			lStrStartDate = DateUtil.getFormattedDate(pStartDate, "yyyy-MM-dd");
			lStrEndDate = DateUtil.getFormattedDate(pEndDate, "yyyy-MM-dd");
		}
		
		JsonNode lSitesData = configData.get("websites");
		String token = configData.get("token").asText();
		String url = configData.get("url").asText();
		Iterator<Entry<String, JsonNode>> lJsonDataFields= lSitesData.fields();
		Map<String,UserWebsite> mapWebsite = this.userWebsiteService.getAllWebsiteMapWithURLAsId();	
		Map<RevenueDataId,RevenueData> revenueDataMap = new HashMap<RevenueDataId,RevenueData>();
		while(lJsonDataFields.hasNext()) {
			Entry<String, JsonNode> lEntryJsonDataField = lJsonDataFields.next();
			String websiteId = lEntryJsonDataField.getKey();
			String websiteUrl = lEntryJsonDataField.getValue().asText();
			if(mapWebsite.containsKey(websiteUrl)) {
				UserWebsite lUserWebsite = mapWebsite.get(websiteUrl);
				String lMapKey = lUserWebsite.getId() + "-" + this.idAdvertiser;
				WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare = this.websiteRevShareData.get(lMapKey);
				RestTemplate restTemplate = new RestTemplate();
				String parameters = "?token=" + token + "&dateInterval=interval&dimensions=date&metrics=impressions,clicks,eCpm,wages&startDate=" + lStrStartDate +"&endDate=" + lStrEndDate + "&siteId=" + websiteId;
				ResponseEntity<String> response
				  = restTemplate.getForEntity(url + parameters , String.class);
				ObjectMapper mapper = new ObjectMapper();
				ArrayNode lResponseData = (ArrayNode) mapper.readTree(response.getBody());
				for(JsonNode lRevData : lResponseData ) {
					if(lRevData.has("date")) {
						Date recordDate = DateUtil.getDateFromStringFormat("yyyy-MM-dd", lRevData.get("date").asText());
						RevenueData lRevenueData = new RevenueData();
						RevenueDataId lRevenueDataId = new RevenueDataId();
						lRevenueDataId.setDate(new java.sql.Date(recordDate.getTime()));
						lRevenueDataId.setIdAdvertiser(this.idAdvertiser);
						lRevenueDataId.setIdWebsite(lUserWebsite.getId());
						lRevenueDataId.setAdType(adType);
						lRevenueData.setRevenueDataId(lRevenueDataId);
						
						float lCpm = Float.parseFloat(lRevData.get("eCpm").asText());
						float lGrossAmount = Float.parseFloat(lRevData.get("wages").asText());
						int lImpressions = Integer.parseInt(lRevData.get("impressions").asText());
						BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
						BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
						BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
						BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
						BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
						
						lRevenueData = new RevenueData();
						lRevenueData.setAmount(lGrossAmount);
						lRevenueData.setCpm(lCpm);
						lRevenueData.setCurrency("USD");
						lRevenueData.setSourceCurrency("USD");
						lRevenueData.setImpressions(lImpressions);
						lRevenueData.setTotalImpressions(lImpressions);//TO-DO need to take total impressions
						lRevenueData.setRevenueDataId(lRevenueDataId);
						lRevenueData.setPlatformFee(lPlatformFee);
						lRevenueData.setErelegoAmount(erelegoShare);
						lRevenueData.setPublisherAmount(publisherShare);
						revenueDataMap.put(lRevenueDataId, lRevenueData);
					}
				}
				
			}
			
		}
		
		
		for(RevenueData lRevenueData : revenueDataMap.values()) {
			Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(lRevenueData);
        	
		}
		
	}
	

	
	@Override
	public void processData() throws Exception {
		
	}

}
