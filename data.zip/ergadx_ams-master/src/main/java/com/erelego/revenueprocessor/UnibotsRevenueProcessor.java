package com.erelego.revenueprocessor;

import java.io.FileInputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueData;
import com.erelego.model.RevenueDataId;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserWebsiteService;
import com.erelego.util.DateUtil;
import com.erelego.util.FileUtil;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public class UnibotsRevenueProcessor implements IAdvertiserRevenueProcessor{
	
	private static Logger LOGGER = LogManager.getLogger(UnibotsRevenueProcessor.class);
	
	private int idAdvertiser;
	private JsonNode configData;
	private int skipNoOfRows = 0;
	private String filePath = "";
	private Double dblConversionRate = 0.0;
	private String strSourceCurrency;
	private String strDestCurrency;
	String adType="";
	@Autowired
	private UserWebsiteService userWebsiteService;
	@Value("${reportPath}")
	private String reportPath;
	
	@Value("${processedReportPath}")
	private String processedReportPath;
	
	private boolean totalRowExist = false;
	@Autowired
	private EntityManager entityManager;
	private Date reportDate;
	@Autowired
	private CurrencyRateService currencyRateService;
	
	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;
	
	private Map<String,Double> currencyRates;
	private Map<String,WebsiteAdvertiserRevenueShare> websiteRevShareData;
	private BigDecimal platformFee ;
	private Map<String,String> sectionData;
	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception {
		this.configData = revenueProcessorConfiguration.getJsnConfigData();
		adType=revenueProcessorConfiguration.getAdType();
		this.idAdvertiser = revenueProcessorConfiguration.getIdAdvertiser();
		this.skipNoOfRows = revenueProcessorConfiguration.getSkipNumberOfRows();
		this.strSourceCurrency = revenueProcessorConfiguration.getSrcCurrencyCode();
		this.strDestCurrency = revenueProcessorConfiguration.getDecCurrencyCode();
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.dblConversionRate = this.currencyRates.get(this.strSourceCurrency + "-" + this.strDestCurrency);
		this.filePath = revenueProcessorConfiguration.getFilePath();
		this.platformFee = revenueProcessorConfiguration.getPlatformFee();
		if(revenueProcessorConfiguration.getIsTotalRowPresent().equalsIgnoreCase("Yes"))
			this.totalRowExist= true;
		else
			this.totalRowExist = false;
		
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
		sectionData = this.loadSectionData();
	}

	
	private Map<String,String> loadSectionData(){
		Map<String,String> lSectionUrlData = new HashMap<String,String>();
		Query lQueryGetAdsTxtForWebsite = entityManager.createNativeQuery("select tagname,website_url from ams_advertiser_revenue_processor_config_unibots_ext");
     	List<?> lResultSectionData = lQueryGetAdsTxtForWebsite.getResultList();
 
    	for(int i=0 ; i < lResultSectionData.size() ; i++) {
    		Object[] lRecordSectionData  = (Object[]) lResultSectionData.get(i);
    		lSectionUrlData.put(lRecordSectionData[0].toString(), lRecordSectionData[1].toString());
    	}
		return lSectionUrlData;
	}
	@Override
	public void doAuthentication() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	@Transactional
	public void fetchData(Date pStartDate, Date pEndDate) throws Exception {
		this.reportDate = pStartDate;
		
		String fileExtension = FilenameUtils.getExtension(this.filePath);
		String fileName = FilenameUtils.getBaseName(this.filePath);
		
		FileInputStream file = new FileInputStream(this.reportPath + this.filePath);

		
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
        
        JsonNode fieldsData = this.configData.get("fields");
		Map<String,UserWebsite> mapWebsite = this.userWebsiteService.getAllWebsiteMapWithURLAsId();	
		Map<RevenueDataId,RevenueData> revenueDataMap = new HashMap<RevenueDataId,RevenueData>();
		int totalNumberOfRows = 0;
        while (rowIterator.hasNext()) 	
        {
        	if(totalNumberOfRows < this.skipNoOfRows) {
        		totalNumberOfRows++;
        		continue;
        	}

            Row row = rowIterator.next();
            if( row.getCell(0)!=null ) {
            	 Cell adNameCell = row.getCell(0);
                 String adName = adNameCell.getStringCellValue();
                 String websiteUrl = sectionData.get(adName);
                 UserWebsite lUserWebsite = mapWebsite.get(websiteUrl); 
            if(lUserWebsite != null ) {
			String lMapKey = lUserWebsite.getId() + "-" + this.idAdvertiser;
			WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare = this.websiteRevShareData.get(lMapKey);
	            if(lWebsiteAdvertiserRevenueShare != null) {
	            	Date recordDate = null;
	    			float amount = 0.0f;
		            int impressions = 0;
		            float cpm = 0.0f;
		            if(fieldsData.has("impressions")) {
		            	Cell cell = row.getCell(fieldsData.get("impressions").get("index").asInt());
		            	if( cell!=null && cell.getCellType() == CellType.STRING)
		            		impressions = Integer.parseInt(cell.getStringCellValue());            	
		                else if( cell!=null)
		                	impressions=  (int) cell.getNumericCellValue();
		            }
		            if(fieldsData.has("amount")) {
		            	Cell cell = row.getCell(fieldsData.get("amount").get("index").asInt());
		            	float lamount = 0;
						if( cell!=null && cell.getCellType() == CellType.STRING) {
		            		String lStrAmount = cell.getStringCellValue();
		            		
		            		lamount = this.cleanseCurrencyField(lStrAmount);
		            		amount=(float) (dblConversionRate*lamount);
		            	}
		                else if( cell!=null)
		                    lamount =  (float) cell.getNumericCellValue();
		              	amount=(float) (dblConversionRate*lamount);
		      
		            }
		            if(fieldsData.has("cpm")) {
		            	Cell cell = row.getCell(fieldsData.get("cpm").get("index").asInt());
		            	if(cell!=null && cell.getCellType() == CellType.STRING) {
		            		String lStrEcpm = cell.getStringCellValue();
		            		cpm = this.cleanseCurrencyField(lStrEcpm); 
		            	}
		                else  if( cell!=null)
		                    cpm =  (float) cell.getNumericCellValue();
		            }
		            if(fieldsData.has("date")) {
		            	Cell cell = row.getCell(fieldsData.get("date").get("index").asInt());
		            	String dateFormat = fieldsData.get("date").get("format").asText();
		            	String strDate = "";
		            	if(cell!=null && cell.getCellType() == CellType.STRING) {
		            		strDate =  cell.getStringCellValue();
		            		recordDate = DateUtil.getDateFromStringFormat(dateFormat, strDate);
		            	}else  if( cell!=null){
		                	recordDate = cell.getDateCellValue();
		                }
		            } 
		            
		            RevenueDataId lRevenueDataId = new RevenueDataId();
					lRevenueDataId.setDate(new java.sql.Date(recordDate.getTime()));
					lRevenueDataId.setIdAdvertiser(this.idAdvertiser);
					lRevenueDataId.setIdWebsite(lUserWebsite.getId());
					lRevenueDataId.setAdType(adType);
					
					RevenueData lRevenueData = null;
					if(revenueDataMap.containsKey(lRevenueDataId)) {
						lRevenueData = revenueDataMap.get(lRevenueDataId);
						float lCpm = lRevenueData.getCpm() + cpm;
						float lGrossAmount = lRevenueData.getAmount() + amount;
						int lImpressions = lRevenueData.getImpressions() + impressions;
						BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
						BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount;
						
						BigDecimal lDeduction = new BigDecimal(0.0);
						BigDecimal lPlatformFee = new BigDecimal(0.0);
						BigDecimal lPlatformFeeAndDeduction = new BigDecimal(0.0);
						
						if(this.platformFee.compareTo(BigDecimal.ZERO) > 0 ) {
							 lPlatformFee = lBigDecGrossAmount.multiply(this.platformFee);
							 lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
						}
						
						lDeduction = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
						lAmountWithoutFlatformFee = lAmountWithoutFlatformFee.subtract(lDeduction);
						
						lPlatformFeeAndDeduction = lDeduction.add(lPlatformFee);
						
						BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
						BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
						
						lRevenueData.setAmount(lGrossAmount);
						lRevenueData.setCpm(lCpm);
						lRevenueData.setCurrency("USD");
						lRevenueData.setSourceCurrency("USD");
						lRevenueData.setImpressions(lImpressions);
						lRevenueData.setTotalImpressions(lImpressions);//TO-DO need to take total impressions
						lRevenueData.setPlatformFee(lPlatformFeeAndDeduction);
						lRevenueData.setErelegoAmount(erelegoShare);
						lRevenueData.setPublisherAmount(publisherShare);
					}else {
						float lCpm = cpm;
						float lGrossAmount = amount;
						int lImpressions = impressions;
						BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
						
						BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount;
						
						BigDecimal lDeduction = new BigDecimal(0.0);
						BigDecimal lPlatformFee = new BigDecimal(0.0);
						BigDecimal lPlatformFeeAndDeduction = new BigDecimal(0.0);
						
						if(this.platformFee.compareTo(BigDecimal.ZERO) > 0 ) {
							 lPlatformFee = lBigDecGrossAmount.multiply(this.platformFee);
							 lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
						}
						lDeduction = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
						lAmountWithoutFlatformFee = lAmountWithoutFlatformFee.subtract(lDeduction);
						lPlatformFeeAndDeduction = lDeduction.add(lPlatformFee);
						
						BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
						BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
						
						lRevenueData = new RevenueData();
						lRevenueData.setAmount(lGrossAmount);
						lRevenueData.setCpm(lCpm);
						lRevenueData.setCurrency("USD");
						lRevenueData.setSourceCurrency("USD");
						lRevenueData.setImpressions(lImpressions);
						lRevenueData.setTotalImpressions(lImpressions);//TO-DO need to take total impressions
						lRevenueData.setRevenueDataId(lRevenueDataId);
						lRevenueData.setPlatformFee(lPlatformFeeAndDeduction);
						lRevenueData.setErelegoAmount(erelegoShare);
						lRevenueData.setPublisherAmount(publisherShare);
						
						revenueDataMap.put(lRevenueDataId, lRevenueData);
					}
					
					lRevenueData.setRevenueDataId(lRevenueDataId);
	            }else {
					LOGGER.error("Revenue Share Config not found for website : " + lUserWebsite.getHostURL() + " And advertiser id : " + this.idAdvertiser);
	              
	            }
            }else {
				LOGGER.error(websiteUrl + " not found");
				LOGGER.error("insert into ams_user_websites (id_user,name,host_url,http_enabled,https_enabled,active,created_date,created_by,modified_date,modified_by) values (58,'"+websiteUrl+"','"+websiteUrl+"',1,1,1,now(),1,now(),1);");

			}
        	totalNumberOfRows++;
        }
        }
        for(RevenueData lRevenueData : revenueDataMap.values()) {
			
			Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(lRevenueData);
		}
        workbook.close();
        
        file.close();
        
        String processedFileName = fileName + DateUtil.getFormattedDate(new Date(), "dd-MM-yyyy-hh-mm-ss") + "." + fileExtension;
     
        FileUtil.moveFile(this.reportPath + this.filePath, this.processedReportPath +  processedFileName);
	}

	@Override
	public void processData() throws Exception {

		
	}
}
