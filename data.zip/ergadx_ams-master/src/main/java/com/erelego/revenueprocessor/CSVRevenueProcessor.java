package com.erelego.revenueprocessor;

import java.util.Date;
import java.util.Map;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserWebsiteService;
@Service
public class CSVRevenueProcessor implements IAdvertiserRevenueProcessor{
	@Autowired
	private UserWebsiteService userWebsiteService;
	@Autowired
	private EntityManager entityManager;
	@Autowired
	private CurrencyRateService currencyRateService;
	
	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;

	private Map<String,Double> currencyRates;
	private Map<String,WebsiteAdvertiserRevenueShare> websiteRevShareData;
	
	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception {
		// TODO Auto-generated method stub
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
	}

	@Override
	public void doAuthentication() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fetchData(Date pStartDate,Date pEndDate) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processData() throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
	/*
	 * @Override public void setUserWebsiteService(UserWebsiteService
	 * userWebsiteService) { this.userWebsiteService = userWebsiteService; }
	 * 
	 * @Override public void setEntityManager(EntityManager entityManager) {
	 * this.entityManager = entityManager; }
	 */

}
