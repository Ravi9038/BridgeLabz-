package com.erelego.revenueprocessor;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.web.client.RestTemplate;

import com.erelego.components.CurrencyRateService;
import com.erelego.components.WebsiteRevenueShareService;
import com.erelego.interfaces.IAdvertiserRevenueProcessor;
import com.erelego.model.RevenueData;
import com.erelego.model.RevenueDataId;
import com.erelego.model.RevenueProcessorConfiguration;
import com.erelego.model.UserWebsite;
import com.erelego.model.WebsiteAdvertiserRevenueShare;
import com.erelego.service.UserWebsiteService;
import com.erelego.util.DateUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

public class AdaptMXRevenueProcessor implements IAdvertiserRevenueProcessor{
	private static Logger LOGGER = LogManager.getLogger(AdaptMXRevenueProcessor.class);
	JsonNode configData = null;
	int idAdvertiser = 0;
	String adType="";
	@Autowired
	private UserWebsiteService userWebsiteService;
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private CurrencyRateService currencyRateService;
	
	@Autowired
	private WebsiteRevenueShareService websiteRevenueShareService;
	
	private Map<String,Double> currencyRates;
	private Map<String,WebsiteAdvertiserRevenueShare> websiteRevShareData;
	
	@Override
	public void loadConfigurationData(RevenueProcessorConfiguration revenueProcessorConfiguration) throws Exception {
		configData = revenueProcessorConfiguration.getJsnConfigData();
		adType=revenueProcessorConfiguration.getAdType();
		this.idAdvertiser = revenueProcessorConfiguration.getIdAdvertiser();
		this.currencyRates = currencyRateService.getCurrencyRates();
		this.websiteRevShareData = websiteRevenueShareService.getWebsiteRevShareData();
	}

	@Override
	public void doAuthentication() throws Exception {
		
	}

	@Override
	@Transactional(propagation=Propagation.NESTED)
	public void fetchData(Date pStartDate, Date pEndDate) throws Exception {
		
		String lStrStartDate = "";
		String lStrEndDate = "";
		if (pStartDate == null) {
			lStrStartDate = DateUtil.getStringDateFromToday(-1,"yyyy-MM-dd");
			lStrEndDate = DateUtil.getStringDateFromToday(-1,"yyyy-MM-dd");
		}else {
			lStrStartDate = DateUtil.getFormattedDate(pStartDate, "yyyy-MM-dd");
			lStrEndDate = DateUtil.getFormattedDate(pEndDate, "yyyy-MM-dd");
		}
		
		
		String api_key = configData.get("api_key").asText();
		String url = configData.get("url").asText();
	
		Map<String,UserWebsite> mapWebsite = this.userWebsiteService.getAllWebsiteMapWithURLAsId();	
		Map<RevenueDataId,RevenueData> revenueDataMap = new HashMap<RevenueDataId,RevenueData>();
		
			
			
				RestTemplate restTemplate = new RestTemplate();
				
				String parameters = url+"?tz=UTC&start_date=" + lStrStartDate +"&end_date="+ lStrEndDate+
						"&dimensions=date,domain,applications_name&metrics=impressions,revenue,cpm&api_key="+api_key;
				HttpHeaders headers = new HttpHeaders();
				headers.set("Cache-Control","no-cache" );
				
			
				
//				ResponseEntity<String> response = restTemplates.postForEntity(urlpass,entity ,String.class);
				ResponseEntity<String> response
				  = restTemplate.getForEntity(parameters , String.class);
				ObjectMapper mapper = new ObjectMapper();
				ArrayNode lResponseData = (ArrayNode) mapper.readTree(response.getBody());
				for(JsonNode lRevData : lResponseData ) {
					
					UserWebsite lUserWebsite = mapWebsite.get(lRevData.get("applications_name").asText());
					 if(lUserWebsite != null ) {
					String lMapKey = lUserWebsite.getId() + "-" + this.idAdvertiser;
					WebsiteAdvertiserRevenueShare lWebsiteAdvertiserRevenueShare = this.websiteRevShareData.get(lMapKey);
					 if(lWebsiteAdvertiserRevenueShare != null) {
						Date recordDate = DateUtil.getDateFromStringFormat("yyyy-MM-dd", lRevData.get("date").asText());
						RevenueData lRevenueData = new RevenueData();
						RevenueDataId lRevenueDataId = new RevenueDataId();
						lRevenueDataId.setDate(new java.sql.Date(recordDate.getTime()));
						lRevenueDataId.setIdAdvertiser(this.idAdvertiser);
						lRevenueDataId.setIdWebsite(lUserWebsite.getId());
						lRevenueDataId.setAdType(adType);
						lRevenueData.setRevenueDataId(lRevenueDataId);
						
						if(revenueDataMap.containsKey(lRevenueDataId)) {
							lRevenueData = revenueDataMap.get(lRevenueDataId);
							float cpm = Float.parseFloat(lRevData.get("cpm").asText());
							float CPM = (float) Math.floor(cpm);
							float lCpm =lRevenueData.getCpm() +CPM;
							float revenue = Float.parseFloat(lRevData.get("revenue").asText());
							float REVENUE=(float) Math.floor(revenue);
							float lGrossAmount = lRevenueData.getAmount() + REVENUE;
							int lImpressions = lRevenueData.getImpressions() +  Integer.parseInt(lRevData.get("impressions").asText());
							BigDecimal lBigDecGrossAmount = new BigDecimal(lGrossAmount);
							BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
							BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
							BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
							BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
							
							lRevenueData.setAmount(lGrossAmount);
							lRevenueData.setCpm(lCpm);
							lRevenueData.setCurrency("USD");
							lRevenueData.setSourceCurrency("USD");
							lRevenueData.setImpressions(lImpressions);
							lRevenueData.setTotalImpressions(lImpressions);//TO-DO need to take total impressions
							lRevenueData.setPlatformFee(lPlatformFee);
							lRevenueData.setErelegoAmount(erelegoShare);
							lRevenueData.setPublisherAmount(publisherShare);
						}
						
						
						else {
						float lCpm = Float.parseFloat(lRevData.get("cpm").asText());
						DecimalFormat numberFormat = new DecimalFormat("#.00");
						String cpm=numberFormat.format(lCpm);
						float CPM = Float.parseFloat(cpm);

						float lGrossAmount = Float.parseFloat(lRevData.get("revenue").asText());
						String amounts=numberFormat.format(lGrossAmount);
						float REVENUE = Float.parseFloat(amounts);

						int lImpressions = Integer.parseInt(lRevData.get("impressions").asText());
						BigDecimal lBigDecGrossAmount = new BigDecimal(REVENUE);
						BigDecimal lPlatformFee = lBigDecGrossAmount.multiply(lWebsiteAdvertiserRevenueShare.getDeduction());
						BigDecimal lAmountWithoutFlatformFee = lBigDecGrossAmount.subtract(lPlatformFee);
						BigDecimal publisherShare = lAmountWithoutFlatformFee.multiply(lWebsiteAdvertiserRevenueShare.getPubShare());
						BigDecimal erelegoShare = lAmountWithoutFlatformFee.subtract(publisherShare);
						
						lRevenueData = new RevenueData();
						lRevenueData.setAmount(REVENUE);
						lRevenueData.setCpm(CPM);
						lRevenueData.setCurrency("USD");
						lRevenueData.setSourceCurrency("USD");
						lRevenueData.setImpressions(lImpressions);
						lRevenueData.setTotalImpressions(lImpressions);//TO-DO need to take total impressions
						lRevenueData.setRevenueDataId(lRevenueDataId);
						lRevenueData.setPlatformFee(lPlatformFee);
						lRevenueData.setErelegoAmount(erelegoShare);
						lRevenueData.setPublisherAmount(publisherShare);
						revenueDataMap.put(lRevenueDataId, lRevenueData);
					}
					
				}
					 else {
							LOGGER.error("Revenue Share Config not found for website : " + lUserWebsite.getHostURL() + " And advertiser id : " + this.idAdvertiser);
			              
			            }
					 }
					 else {
							LOGGER.error(lUserWebsite + " not found");
							LOGGER.error("insert into ams_user_websites (id_user,name,host_url,http_enabled,https_enabled,active,created_date,created_by,modified_date,modified_by) values (58,'"+lUserWebsite+"','"+lUserWebsite+"',1,1,1,now(),1,now(),1);");

						}
				}
					 
				
			
	
		
		for(RevenueData lRevenueData : revenueDataMap.values()) {
			Session session = this.entityManager.unwrap(Session.class);
			session.saveOrUpdate(lRevenueData);
		
		}
		
	}
	

	
	@Override
	public void processData() throws Exception {
		
	}

}
