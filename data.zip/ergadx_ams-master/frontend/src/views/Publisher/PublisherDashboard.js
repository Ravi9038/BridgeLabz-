import React, { Component } from 'react'

export class PublisherDashboard extends Component {
    render() {
        return (
            <div>
                <h1>PublisherDashboard</h1>
            </div>
        )
    }
}

export default PublisherDashboard
