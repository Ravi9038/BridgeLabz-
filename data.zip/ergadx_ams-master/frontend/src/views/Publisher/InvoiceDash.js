import React, { Component } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Store from "@material-ui/icons/Store";
// import InfoOutline from "@material-ui/icons/InfoOutline";
import Warning from "@material-ui/icons/Warning";
import DateRange from "@material-ui/icons/DateRange";
import LocalOffer from "@material-ui/icons/LocalOffer";
import Update from "@material-ui/icons/Update";
import Language from "@material-ui/icons/Language";

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Table from "components/Table/Table.js";
import Newtable from "components/Table/Newtable.js";
import dropdown from "components/CustomDropdown/CustomDropdown.js";
import Danger from "components/Typography/Danger.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";

import CardFooter from "components/Card/CardFooter.js";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { SERVER_URL } from "../../variables/constants";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import CustomTabs from "components/CustomTabs/CustomTabs.js";
import Tasks from "components/Tasks/Tasks.js";
import styles from "assets/jss/material-dashboard-pro-react/views/dashboardStyle.js";
import BugReport from "@material-ui/icons/BugReport";
import Code from "@material-ui/icons/Code";
import Cloud from "@material-ui/icons/Cloud";
import axios from 'axios';

// @material-ui/core components

import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import FormControl from "@material-ui/core/FormControl";
// material-ui icons
import Menu from "@material-ui/icons/Menu";
import Globe from "@material-ui/icons/Public";
import Bankicon from "@material-ui/icons/AccountBalance";
import Addpersonicon from "@material-ui/icons/PersonAdd";
import Profileicon from "@material-ui/icons/Person"
import MButton from '@material-ui/core/Button';
import ImageUpload from "components/CustomUpload/ImageUpload.js";
// core components

import Button from "components/CustomButtons/Button.js";
import { cardHeader } from "assets/jss/material-dashboard-pro-react";
import { ArrowDropDown } from "@material-ui/icons";
import { card } from "assets/jss/material-dashboard-pro-react";
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import Checkbox from '@material-ui/core/Checkbox';
import FormLabel from '@material-ui/core/FormLabel';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import InputAdornment from '@material-ui/core/InputAdornment';
import Add from '@material-ui/icons/Add';
import Dialog from '@material-ui/core/Dialog';
import ListItemText from '@material-ui/core/ListItemText';
import ListItem from '@material-ui/core/ListItem';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import * as moment from 'moment';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import AddInvoice from '@material-ui/icons/AddToQueue';
import Slide from '@material-ui/core/Slide';
import ReactTable from "react-table";
import { dataTable } from "variables/Invoicetable.js";
//import { dataTable } from "variables/paymentreportdatatable.js";
import Paymenticon from "@material-ui/icons/Money";
import Invoiceicon from "@material-ui/icons/Receipt";
import Attachmentsicon from "@material-ui/icons/AttachFile";
import TotalInvoiceCard from 'views/Widgets/TotalInvoiceDialog.js';
import TotalAmountCard from 'views/Widgets/TotalAmountDialog.js';
import ReceivedAmountButton from 'views/Widgets/ReceivedAmountDialog.js';
import RaisedInvoices from 'views/Widgets/RaisedInvoices.js';
import Tooltip from '@material-ui/core/Tooltip';
import ViewOff from "@material-ui/icons/VisibilityOff";
import View from "@material-ui/icons/Visibility";
const LightTooltip = withStyles((theme) => ({
  tooltip: {
    // backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    // boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}))(Tooltip);
const useStyles = makeStyles((theme) => ({
  root: {
    '& .MuiFormControlLabel-root': {
      paddingTop: "6px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },
    '& .MuiFormControl-root': {
      margin: theme.spacing(1),
      width: "100%",

    },
    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },



    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },

  },
  rootslider: {
    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "6px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },
    '& .MuiFormControl-root': {
      margin: theme.spacing(1),
      width: "100%",

    },
    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },


    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },
    '& .MuiPaper-root': {
      backgroundColor: "#dddddd!important"
    },
    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",
      boxShadow: "none!important"

    },
    '& .MuiFormControl-root': {
      margin: theme.spacing(1),
      width: "100%",
    },
    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important"
    },
    '& .MuiPaper-elevation4': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important"
    }
  },
  root2: {
    '& > *': {
      margin: theme.spacing(1),
      float: "right"
    },
  },
  CardHeading: {
    textAlign: "center",
    color: "black!important",
  },
  MainHeading: {
    textAlign: "left",
    color: "#3c4858!important",

  },
  CloseButton: {
    backgroundColor: "white",
    borderRadius: "30px",
    color: "black",
    width: "41px",
    height: "41px",

    minWidth: "41px",
    paddingLeft: "12px",
    paddingRight: "12px"
  },
  SliderTitle: {
    fontSize: "16px",
    paddingLeft: "30px",
    color: "black !important",
    fontWeight: "400"

  },
  CustomappBar: {
    display: "flex",
    flex: " 0 0 64px",
    background: "#ebebeb",
    height: " 64px",
    borderBottom: "1px solid rgb(0 0 0 / 10%)",


  },
  heading: {
    color: "black!important"
  },
  SliderBackground: {
    backgroundColor: "#dddddd!important"
  },
  TextCenter: {
    textAlign: "center"
  },
  SmallText: {
    fontSize: "12px",
    color: "#000000de",
    fontWeight: "300"
  }
}));

export class Invoices extends Component {
  constructor (props) {
    super(props);
    this.state = {
      InvoiceDetails: [],
      TotalInvoiceNos: 0,
      userID: '',
      TotalInvoiceDetails: [],


    }
  };
  componentDidMount() {
    debugger;
    const USER_ID = this.props.data.id;
    this.setState({ userID: USER_ID });
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/invoicedetails/${USER_ID}`).then(response => response.data)
      .then((data) => {
        console.log(data);
        this.setState({ InvoiceDetails: data });
      }).catch((error) => {
        console.error(error);
      });
    this.getInvoiceDetails();

  }

  getInvoiceDetails = () => {
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/invoicedetails/`).then(response => response.data)
      .then((data) => {
        console.log(data);
        this.setState({ TotalInvoiceDetails: data });

      }).catch((error) => {
        console.error(error);
      });
  }
  viewReport = (userID, invoiceId) => {



  }

  renderInvoiceDetails = () => {
    const classes = this.props.classes;
    return <GridItem xs={ 12 } lg={ 12 } md={ 12 }>
      <Card>
        <CardBody>
          <ReactTable
            data={ this.state.TotalInvoiceDetails }
            filterable
            columns={ [
              {
                Header: "Sl No",
                accessor: "userId"
              },

              {
                Header: "Publisher Name",
                accessor: "companyName"
              },
              {
                Header: "Invoice Id",
                accessor: "id"
              },
              {
                Header: "Amount",
                accessor: "amount"
              },
              {
                Header: "Start Date",
                accessor: "startDate",
                Cell: id => (
                  new moment(id.original.startDate).format("MMMM")
                )


              },
              {
                Header: "End Date",
                accessor: "endDate",
                Cell: id => (
                  new moment(id.original.startDate).format("YYYY")
                )
              },
              {
                Header: "Status",
                accessor: "status"
              },
              {
                Header: "Actions",
                accessor: "id",
                id: "row",

                Cell: id => (
                  <div className={ classes.ActionsButton }>
                    { id.original.status == "RECIVED" &&
                      <LightTooltip title="View" aria-label="view" placement="top">

                        <Button href={ SERVER_URL + "/api/invoice/" + id.original.userId + "/view/" + id.original.id }
                          target="_blank"
                          justIcon
                          round
                          simple
                          color="success"
                          className="view"
                        >
                          <View />
                        </Button>
                      </LightTooltip>
                    }
                  </div>
                ),
                sortable: false,
                filterable: false
              }
            ] }
            defaultPageSize={ 5 }
            showPaginationTop
            showPaginationBottom={ false }
            className="-striped -highlight"
          />
        </CardBody>
      </Card>
    </GridItem>

  }

  render() {
    const { classes } = this.props;
    return <div className={ classes.root }>
      <GridContainer>
        <GridItem xs={ 12 } md={ 3 } lg={ 3 }>
          <TotalInvoiceCard />

        </GridItem>
        <GridItem xs={ 12 } md={ 3 } lg={ 3 }>
          <TotalAmountCard />
        </GridItem>
        <GridItem xs={ 12 } md={ 3 } lg={ 3 }>
          <ReceivedAmountButton />
        </GridItem>

        <GridItem xs={ 12 } md={ 3 } lg={ 3 }>
          <Card>
            <CardBody>
              <h4 className={ classes.CardHeading }>Balance </h4>
              <h4 className={ classes.CardHeading }>0</h4>
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
      <GridContainer>
        <GridItem lg={ 12 }>
          <h4 className={ classes.MainHeading }>Invoice to be Raised</h4>
        </GridItem>
        <GridItem lg={ 1 }></GridItem>
        <GridItem lg={ 10 }>
          <RaisedInvoices />
        </GridItem>
        <GridItem lg={ 1 }></GridItem>
      </GridContainer>
      <GridContainer>
        { this.state.userID === 1 && this.renderInvoiceDetails() }
      </GridContainer>

    </div>


  }
}
const InvoicesHOC = withStyles(styles)(Invoices);
export default connect(mapStateToProps, mapDispatchToProps)(InvoicesHOC);
