import React, { Component } from 'react'
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Globe from "@material-ui/icons/Language";
import ReactTable from "react-table";
// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import axios from 'axios';
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Table from "components/Table/Table.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import { SERVER_URL } from "../../variables/constants";
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import Button from "components/CustomButtons/Button.js";
import MButton from '@material-ui/core/Button';
import SlidingPane from "react-sliding-pane";
import "react-sliding-pane/dist/react-sliding-pane.css";
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import { connect } from 'react-redux';
import RefreshIcon from '@material-ui/icons/Refresh';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
import styles from "assets/jss/material-dashboard-pro-react/views/PublisherCustomStyle.js";
import View from "@material-ui/icons/Visibility";
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from '@material-ui/core/IconButton';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import Tooltip from '@material-ui/core/Tooltip';
const LightTooltip = withStyles((theme) => ({
    tooltip: {
       backgroundColor: theme.palette.common.white,
      color: 'rgba(0, 0, 0, 0.87)',
       boxShadow: theme.shadows[1],
      fontSize: 11,
    },
  }))(Tooltip);
  
  const useStyles = makeStyles(styles);
  const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="left" ref={ref} {...props} />;
  });

const panelStyles = {
    panelClass: {
      zIndex:999
    },
    ModalStyle: {
      width:'100% !important',
      backgroundColor:'#ddd'
    },
    viewSectionsModalStyle: {
      width:'60% !important',
      backgroundColor:'#ddd'
    },
    viewAssignmentModalStyle: {
      width:'40% !important',
      backgroundColor:'#ddd'
    },
  };


export class AdsTxtManager extends Component {
    state = {
        websites:[],
        AdstxtViewIconOpen: false,
        arrayData: '',
        adxDetails:[],
        notMatchedadxDetails:[],
        notMatchedarrayData:'',
        forAll:false,
        forIndividual:false,
    }
    AdstxtViewIconhandleClose = () => {
        this.setState({ AdstxtViewIconOpen: false });
      };
      AdstxtViewIconhandleClose = () => {
        this.setState({ AdstxtViewIconOpen: false });
      };
      renderAdxDetails = () => {
        const classes = this.props.classes;
        let adxTxtDetails = this.state.adxDetails;
        return <GridContainer>
          <GridItem lg={3} md={3} ></GridItem>
          <GridItem lg={6} md={6} ><Card className={classes.CustomCard}>
            <CardBody>
              <GridContainer>
                <GridItem lg={12} md={12}>
                  <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10}
                    defaultValue={this.state.arrayData}
                  />
                </GridItem>
              </GridContainer>
            </CardBody>
     
          </Card></GridItem>
          <GridItem lg={3} md={3} ></GridItem>
        </GridContainer>
      }
      renderNotMatchedAdxDetails = () => {
        const classes = this.props.classes;
        let adxTxtDetails = this.state.adxDetails;
        return <GridContainer>
          <GridItem lg={3} md={3} ></GridItem>
          <GridItem lg={6} md={6} ><Card className={classes.CustomCard}>
            <CardBody>
              <GridContainer>
                <GridItem lg={12} md={12}>
                  <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10}
                    defaultValue={this.state.notMatchedarrayData}
                  />
                </GridItem>
              </GridContainer>
            </CardBody>
     
          </Card></GridItem>
          <GridItem lg={3} md={3} ></GridItem>
        </GridContainer>
      }
  AllAds=(id)=>{
    const USER_ID = this.props.data.id;
   
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/adstxt/website/${id}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        this.setState({ adxDetails: data })
        
        var array = [];

        for (let i = 0; i < data.length; i++) {

          if (data[i].certification_auth_id !== "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "," + data[i].certification_auth_id + "\n");

          }
          else if (data[i].certification_auth_id === "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "\n");

          }
        }
        var passingArray = array.join("\n");

        this.setState({ 
            forAll : true,
            forIndividual : false,
            arrayData: passingArray ,
            adxDetails: data ,
            AdstxtViewIconOpen: true 
        });


      }).catch((error) => {
        console.error(error);
      });
}
refreshAdstxt=(idWebsite)=>{

const TOKEN = 'Bearer '.concat(this.props.data.token);
 
  axios.defaults.headers.common['Authorization'] = TOKEN;
  axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
  axios.get(`${SERVER_URL}/api/adstxt/${idWebsite}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
    .then((data) => {
    
     alert("Verification Done")
    }).catch((error) => {
      console.error(error);
    }); 
}

notMatched=(id,idstatus)=>{
 

  const USER_ID = this.props.data.id;
  const TOKEN = 'Bearer '.concat(this.props.data.token);
 
  axios.defaults.headers.common['Authorization'] = TOKEN;
  axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
  axios.get(`${SERVER_URL}/api/adstxt/notmatched/${id}/getdata/${idstatus}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
    .then((data) => {
   
      var array = [];

      for (let i = 0; i < data.length; i++) {
      
        if (data[i].certification_auth_id !== "") {
          array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "," + data[i].certification_auth_id + "\n");

        }
        else if (data[i].certification_auth_id === "") {
          array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "\n");

        }
      }
      var passingArray = array.join("\n");
        this.setState({ 
          notMatchedadxDetails: data,
          forIndividual:true, 
          forAll : false,
          notMatchedarrayData: passingArray,
          AdstxtViewIconOpen: true 
      });
    
    }).catch((error) => {
      console.error(error);
    }); 
}

 renderTable=()=>{
    const classes = this.props.classes;
    return <CardBody>
                    <ReactTable
                        data={this.state.websites}
                        filterable
                        columns={[
                            {
                                Header: "Publisher",
                                accessor: "company_name",
                                Filter: ({ filter, onChange }) => (
                                    <input type='text' style={{ textAlign: 'center' }}
                                        placeholder="Search Publisher"
                                        value={filter ? filter.value : ''}
                                        onChange={event => onChange(event.target.value)}
                                    />
                                ),
                                Footer: (
                                    <span><strong></strong></span>
                                )



                            },
                            {
                                Header: "Email",
                                accessor: "email",
                                Filter: ({ filter, onChange }) => (
                                    <input type='text' style={{ textAlign: 'center' }}
                                        placeholder="Search Email"
                                        value={filter ? filter.value : ''}
                                        onChange={event => onChange(event.target.value)}
                                    />
                                ),
                                Footer: (
                                    <span><strong></strong></span>
                                )


                            },
                            {
                                Header: "Websites",
                                accessor: "website",
                                Filter: ({ filter, onChange }) => (
                                    <input type='text' style={{ textAlign: 'center' }}
                                        placeholder="Search Websites"
                                        value={filter ? filter.value : ''}
                                        onChange={event => onChange(event.target.value)}
                                    />
                                ),

                                Footer: (
                                    <span><strong></strong></span>
                                )

                            },
                            {
                                Header: "Status",
                                accessor: "adsStatus",
                                Filter: ({ filter, onChange }) => (
                                    <input type='text' style={{ textAlign: 'center' }}
                                        placeholder="Search All"
                                        value={filter ? filter.value : ''}
                                        onChange={event => onChange(event.target.value)}
                                    />
                                ),
                               

                                Footer: (
                                    <span><strong></strong></span>
                                )
                            },


                            {
                              Header: "Refresh",
                              accessor: "id",
                              Cell: id => (
                                  <div className={classes.ActionsButton}>
                                    <LightTooltip title="Refresh" aria-label="Refresh" placement="top">
                                      <Button onClick={() => { this.refreshAdstxt(id.original.id) }}
                                        justIcon
                                        round
                                        simple
                                        color="success"
                                        className="view"
                                      >
                                        <RefreshIcon />
                                      </Button>
                                    </LightTooltip>
                                 
                                     

                                  
                                  
                                  </div>
                                ),

                              Footer: (
                                  <span><strong></strong></span>
                              )
                          },

                            {
                                Header: "All",
                                accessor: "id",
                                Cell: id => (
                                    <div className={classes.ActionsButton}>
                                      <LightTooltip title="View" aria-label="view" placement="top">
                                        <Button onClick={() => { this.AllAds(id.original.id) }}
                                          justIcon
                                          round
                                          simple
                                          color="success"
                                          className="view"
                                        >
                                          <View />
                                        </Button>
                                      </LightTooltip>
                                   
                                       

                                    
                                    
                                    </div>
                                  ),

                                Footer: (
                                    <span><strong></strong></span>
                                )
                            },

                            
                            {
                                Header: "Error",
                                accessor: "Error",
                               
                                Cell: id => (
                                    <div className={classes.ActionsButton}>
                                      <LightTooltip title="View" aria-label="view" placement="top">
                                      <Button onClick={() => { this.notMatched(id.original.id,id.original.idStatus) }}
                                          justIcon
                                          round
                                          simple
                                          color="danger"
                                          className="view"
                                        >
                                          <View />
                                        </Button>
                                      </LightTooltip>
                                   
                                       

                                    
                                    
                                    </div>
                                  ),
                                
                                Footer: (
                                    <span><strong></strong></span>
                                )

                            },
                            {
                                Header: "Last Checked",
                                accessor: "adsStatusDate",
                                Filter: ({ filter, onChange }) => (
                                    <input type='text' style={{ textAlign: 'center' }}
                                        placeholder="Search Last Checked"
                                        value={filter ? filter.value : ''}
                                        onChange={event => onChange(event.target.value)}
                                    />
                                ),
                                Footer: (
                                    <span><strong></strong></span>
                                )

                            }
                        ]}
                        defaultPageSize={5}
                        showPaginationTop
                        showPaginationBottom={false}
                        className="-highlight"
                    />
                </CardBody>

 }
    

    componentDidMount() {
        const classes = this.props.classes;
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    
    
        axios.get(`${SERVER_URL}/api/users/websites/get`, { headers: { "Authorization": TOKEN } })
          .then(res => {
            this.setState({ websites: res.data });
         
          }).catch(function (error) {
            console.log(error);
          });
    }
    render() {


        const classes = this.props.classes;
        return (
            <div>
            <GridContainer>
                <GridItem xs={12}>
                    <Card>
                        <CardHeader color="rose" icon>
                            <CardIcon color="rose">
                                <Assignment />
                            </CardIcon>
                            <h4 className={classes.cardIconTitle}>Websites</h4>
                        </CardHeader>
                        <CardBody>
                        {this.renderTable()}
                        </CardBody>
                    </Card>
                </GridItem>
                
            </GridContainer >
            <SlidingPane
            className={classes.ModalStyle +" panelHeaderClass"}
            overlayClassName={classes.panelClass}
            isOpen={this.state.isPaneOpen}
            title="Ads-Txt Records"
            subtitle=""
            onRequestClose={() => {
              this.setState({ isPaneOpen: false });
            }}
          >

          {this.state.strHtmlxtRecord}

          </SlidingPane>
     {  this.state.forAll===true &&
          <Dialog fullScreen open={this.state.AdstxtViewIconOpen} onClose={this.AdstxtViewIconhandleClose} TransitionComponent={Transition} className={classes.rootslider}>
        <AppBar className={classes.CustomappBar}>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={this.AdstxtViewIconhandleClose} aria-label="close" className={classes.CloseButton}>
              <LeftAorrow />
            </IconButton>
            <h4 className={classes.SliderTitle}>All Ads.txt</h4>
          </Toolbar>
        </AppBar>
        {this.renderAdxDetails()}
      </Dialog>
    }
    {  this.state.forIndividual===true &&
      <Dialog fullScreen open={this.state.AdstxtViewIconOpen} onClose={this.AdstxtViewIconhandleClose} TransitionComponent={Transition} className={classes.rootslider}>
        <AppBar className={classes.CustomappBar}>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={this.AdstxtViewIconhandleClose} aria-label="close" className={classes.CloseButton}>
              <LeftAorrow />
            </IconButton>
            <h4 className={classes.SliderTitle}>Not Matched Ads.txt</h4>
          </Toolbar>
        </AppBar>
        {this.renderNotMatchedAdxDetails()}
      </Dialog>
    }
            </div>
        )
    }
}

const AdsTxtManagerHOC = withStyles(styles)(AdsTxtManager);
export default connect(mapStateToProps, mapDispatchToProps)(AdsTxtManagerHOC);