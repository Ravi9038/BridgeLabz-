import React, { Component } from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
// @material-ui/core components
import { withStyles, makeStyles } from "@material-ui/core/styles";

import ProfileView from './ProfileView.js'
import View from "@material-ui/icons/Visibility";
import CreateContact from './CreateContact.js';

import CreateInternational from './CreateInternational.js';

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import { dataTable } from "variables/Publisherdatatable";
import Switch from '@material-ui/core/Switch';
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import MButton from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import InputBase from '@material-ui/core/InputBase';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormLabel from '@material-ui/core/FormLabel';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import Tooltip from '@material-ui/core/Tooltip';
// material-ui icons
import IconButton from '@material-ui/core/IconButton';
import Publishicon from "@material-ui/icons/Group";
import Globe from "@material-ui/icons/Public";
import Bankicon from "@material-ui/icons/AccountBalance";
import Profileicon from "@material-ui/icons/Person"
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import Mappingicon from '@material-ui/icons/LinearScale';
import PermContactCalendarIcon from '@material-ui/icons/PermContactCalendar';
import ViewOff from "@material-ui/icons/VisibilityOff";
import CheckIcon from "@material-ui/icons/Done";
import UncheckIcon from "@material-ui/icons/Close";
import LedgerView from '@material-ui/icons/ListAlt';
import styles from "assets/jss/material-dashboard-pro-react/views/PublisherCustomStyle.js";
import Addcontact from "@material-ui/icons/PersonAdd";
import Button from "components/CustomButtons/Button.js";
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import InputAdornment from '@material-ui/core/InputAdornment';
import Add from '@material-ui/icons/Add'
import AddContactButton from 'views/Publisher/AddContact.js';
import axios from "axios";
import { SERVER_URL } from "../../variables/constants";

import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import { forEachChild } from "typescript";

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}))(Tooltip);

const useStyles = makeStyles(styles);
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="left" ref={ ref } { ...props } />;
});

export class Publisher extends Component {

  constructor (props) {
    super(props);
    this.state = {
      updatedata: {
        pub_share: "",
        totalPublisher: '',
        profileKey: "",
        erg_share: "",
        id_advertiser: "",
        id_website: ""
      },
      arrayData: '',
      completearrayData: '',
      status: '',
      contactStatus: '',
      userStatus: '',
      publisherId: 0,
      RevenueshareEnable: true,
      revenueEditText: 'Edit',
      revenueDatas: [],
      adxData: [],
      pub_share: [],
      erg_share: [],
      advertiserid: [],
      websiteId: [],
      updaterevenue: {},
      updatedvalue: [],
      adxDetails: [],
      expanded: 1,
      tab: 'View',
      PublisherViewopen: false,
      PublisherProfileopen: false,
      RevenueShareopen: false,
      RevenueShareViewopen: false,
      Adstxtopen: false,
      AdstxtViewopen: false,
      AdstxtViewIconOpen: false,
      LatestAdstxtopen: false,
      ViewLedgeropen: false,
      Ledgeropen: false,
      websitedata: [],
      accoordionHtml: [],
      publisherContactViewOpen: false,
      ContactDetials: [],
      websiteCount: 0,
      Name: '',
      Designation: '',
      contactNumberOne: '',
      contactNumberTwo: '',
      email: '',
      contactId: '',
      profileType: "Domastic",
      count: 1,
      publisherdata: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          slno: prop[0],
          publisherName: prop[1],
          contactName: prop[2],
          contactNumber: prop[3],
          email: prop[4],
          actions: prop[5],
          level: prop[5],
          designation: prop[6],
          reportingTo: prop[7],
          actionContactView: prop[8],
          WebsiteCount: prop[8],
          OneMRank: prop[9],
          ThreeMRank: prop[10],
          LifeTimeRank: prop[11],
          actionsPublisherProfile: prop[12],
          publisherShare: prop[12],
          DomainName: prop[13],
          date: prop[14],
          particular: prop[15],
          debit: prop[16],
          credit: prop[17],
          balance: prop[18]


        };

      }),
      activepublisherdata: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          slno: prop[0],
          publisherName: prop[1],
          contactName: prop[2],
          contactNumber: prop[3],
          email: prop[4],
          actions: prop[5],
          level: prop[5],
          designation: prop[6],
          reportingTo: prop[7],
          actionContactView: prop[8],
          WebsiteCount: prop[8],
          OneMRank: prop[9],
          ThreeMRank: prop[10],
          LifeTimeRank: prop[11],
          actionsPublisherProfile: prop[12],
          publisherShare: prop[12],
          DomainName: prop[13],
          date: prop[14],
          particular: prop[15],
          debit: prop[16],
          credit: prop[17],
          balance: prop[18]


        };

      }),
      inActivepublisherdata: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          slno: prop[0],
          publisherName: prop[1],
          contactName: prop[2],
          contactNumber: prop[3],
          email: prop[4],
          actions: prop[5],
          level: prop[5],
          designation: prop[6],
          reportingTo: prop[7],
          actionContactView: prop[8],
          WebsiteCount: prop[8],
          OneMRank: prop[9],
          ThreeMRank: prop[10],
          LifeTimeRank: prop[11],
          actionsPublisherProfile: prop[12],
          publisherShare: prop[12],
          DomainName: prop[13],
          date: prop[14],
          particular: prop[15],
          debit: prop[16],
          credit: prop[17],
          balance: prop[18]


        };

      }),

      publisherContactDetails: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          slno: prop[0],
          publisherName: prop[1],
          designation: prop[2],
          contactNumber: prop[3],
          email: prop[4],
          reportingTo: prop[5]

        }
      }),

      activePublisherContactDetails: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          slno: prop[0],
          publisherName: prop[1],
          designation: prop[2],
          contactNumber: prop[3],
          email: prop[4],
          reportingTo: prop[5]

        }
      }),
      inActivePublisherContactDetails: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          slno: prop[0],
          publisherName: prop[1],
          designation: prop[2],
          contactNumber: prop[3],
          email: prop[4],
          reportingTo: prop[5]

        }
      }),

      websiteRevenueAvgData: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          slno: prop[0],
          numberOfWebsite: prop[1],
          publisherName: prop[2],
          publisherShare: prop[3],

        }
      }),
      activeWebsiteRevenueAvgData: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          slno: prop[0],
          numberOfWebsite: prop[1],
          publisherName: prop[2],
          publisherShare: prop[3],

        }
      }),
      inActiveWebsiteRevenueAvgData: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          slno: prop[0],
          numberOfWebsite: prop[1],
          publisherName: prop[2],
          publisherShare: prop[3],

        }
      }),

    }
  }
  filterCaseInsensitive = (filter, row) => {

    const id = filter.pivotId || filter.id;
    if (row[id] !== null) {
      return (
        row[id] !== undefined ?
          String(row[id].toString().toLowerCase())
            .includes(filter.value.toString().toLowerCase())
          :
          true
      );
    }
  }


  PublisherViewhandleClose = () => {
    this.setState({ PublisherViewopen: false });
  };
  PublisherProfilehandleClickOpen = () => {
    this.setState({ PublisherProfileOpen: true });

  };

  PublisherProfilehandleClose = () => {
    this.setState({ PublisherProfileOpen: false });
  };
  PublisherProfileViewhandleClickOpen = (pKey) => {
    this.setState({ PublisherProfileViewOpen: true });
    this.setState({ profileKey: pKey })
  };

  PublisherProfileViewhandleClose = () => {
    this.setState({ PublisherProfileViewOpen: false });
  };

  RevenueSharehandleClickOpen = () => {
    this.setState({ RevenueShareOpen: true });
    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    axios.get(`${SERVER_URL}/api/users/publishers/profile/details/`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {

        this.setState({ websiteRevenueAvgData: data });
        var active = [];
        var inActive = [];
        for (let one in data) {
          if (data[one].status === "ACTIVE") {
            active.push(data[one]);
          }
          else if (data[one].status === "INACTIVE") {
            inActive.push(data[one])
          }
        }
        this.setState({ activeWebsiteRevenueAvgData: active })
        this.setState({ inActiveWebsiteRevenueAvgData: inActive })

      }).catch((error) => {
        console.error(error);
      });

  };

  RevenueSharehandleClose = () => {
    this.setState({ RevenueShareOpen: false });
  };


  RevenueShareViewhandleClose = () => {
    this.setState({ RevenueShareViewOpen: false });
  };

  AdstxthandleClickOpen = () => {
    this.setState({ AdstxtOpen: true });

    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    axios.get(`${SERVER_URL}/api/userwebsite`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        this.setState({ adxData: data })

      }).catch((error) => {
        console.error(error);
      });

  };

  AdstxthandleClose = () => {
    this.setState({ AdstxtOpen: false });
  };
  LatestAdstxthandleClickOpen = () => {
    this.setState({ LatestAdstxtOpen: true });
  };

  LatestAdstxthandleClose = () => {
    this.setState({ LatestAdstxtOpen: false });
  };

  AdstxtViewhandleClickOpen = () => {
    this.setState({ AdstxtViewOpen: true });
  };

  AdstxtViewhandleClose = () => {
    this.setState({ AdstxtViewOpen: false });
  };
  // AdstxtViewIconhandleClickOpen = (value) => {
  //   this.sample(value);
  //   this.setState({ AdstxtViewIconOpen: true });
  // };

  AdstxtViewIconhandleClose = () => {
    this.setState({ AdstxtViewIconOpen: false });
  };
  LedgerhandleClickOpen = () => {
    this.setState({ LedgerOpen: true });
  };

  LedgerhandleClose = () => {
    this.setState({ LedgerOpen: false });
  };
  ViewLedgerhandleClickOpen = () => {
    this.setState({ ViewLedgerOpen: true });
  };

  ViewLedgerhandleClose = () => {
    this.setState({ ViewLedgerOpen: false });
  };
  handleChange = (panel) => (event, isExpanded) => {
    //debugger;

    this.setState({ expanded: (isExpanded ? panel : false) })

  };

  tabsetCreate = () => {

    const create = document.getElementById("create");
    const view = document.getElementById("view");
    create.style = "background-color:#1E90FF; color:#fff"; 
    view.style = "background-color:#fff; color:#000";

    this.setState({ tab: 'Create' });

  }

  tabsetView = () => {

    const create = document.getElementById("create");
    const view = document.getElementById("view");
    view.style = "background-color:#1E90FF; color:#fff"; 
    create.style = "background-color:#fff; color:#000";

    this.setState({ tab: 'View' });
  }

  componentDidMount() {

    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    axios.get(`${SERVER_URL}/api/users/publishers/`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {

        this.setState({ publisherdata: data });
        this.setState({ totalPublisher: data.length })
        var active = [];
        var inActive = [];
        for (let one in data) {
          if (data[one].status === "ACTIVE") {
            active.push(data[one]);
          }
          else if (data[one].status === "INACTIVE") {
            inActive.push(data[one])
          }
        }
        this.setState({ activepublisherdata: active })
        this.setState({ inActivepublisherdata: inActive })

      }).catch((error) => {
        console.error(error);
      });

    axios.get(`${SERVER_URL}/api/adstxt/get/`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {

        var array = [];

        for (let i = 0; i < data.length; i++) {

          if (data[i].certification_auth_id !== "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "," + data[i].certification_auth_id + "\n");

          }
          else if (data[i].certification_auth_id === "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "\n");

          }
        }
        var passingArray = array.join("\n");

        this.setState({ completearrayData: passingArray });


      }).catch((error) => {
        console.error(error);
      });
    this.getTotalNumberOfWebsite();
  }
  getTotalNumberOfWebsite = () => {
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    axios.get(`${SERVER_URL}/api/userwebsite`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        var count = 0
        for (let one in data) {
          if (data[one].id !== null) {
            count++;
          }
        }
        this.setState({ websiteCount: count })
      }).catch((error) => {
        console.error(error);
      });
  }
  PublisherViewhandleClickOpen = (pKey) => {
    this.setState({ publisherId: pKey })

    this.setState({ PublisherViewopen: true });
    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/usercontact/details/${pKey}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        this.setState({ publisherContactDetails: data });
        var active = [];
        var inactive = [];

        for (let i = 0; i < data.length; i++) {
          if (data[i].status === "ACTIVE") {
            active.push(data[i]);
          }
          else if (data[i].status === "INACTIVE") {
            inactive.push(data[i]);
          }
        }

        this.setState({ activePublisherContactDetails: active });

        this.setState({ inActivePublisherContactDetails: inactive });


      }).catch((error) => {
        console.error(error);
      });


  };

  updateShare = (value, advertiserId, WebsiteId, key, fieldName) => {

    var lRevenueData = this.state.revenueDatas;
    var data = lRevenueData[WebsiteId];

    for (let i = 0; i < data.length; i++) {
      data[key][fieldName] = value;
    }
    lRevenueData[WebsiteId] = data;
    this.setState({ revenueDatas: lRevenueData });

  }


  enableRevenueDetails = () => {

    if (this.state.RevenueshareEnable) { 
      this.setState({
        RevenueshareEnable: false,
        revenueEditText: 'Cancel'
      });
      alert("Do you want to Edit");      
    }
    else { 
      this.setState({
        RevenueshareEnable: true,
        revenueEditText: 'Edit'
      });
      alert("Do You want to Cancel");
     
    }
  }


  submitData = () => {

    var data = this.state.revenueDatas;
    for (var key in data) {

      const dataPass = data[key];
      const TOKEN = 'Bearer '.concat(this.props.data.token);
      axios.defaults.headers.common['Authorization'] = TOKEN;
      axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
      axios.post(`${SERVER_URL}/api/website/revenues/`, dataPass, { headers: { "Authorization": TOKEN } })
        .then(response => response.data)
        .then((data) => {
          console.log(data);

        }).catch(error => { console.log(error); })
    }
    alert("data Submitted")
  }

  sample = (id) => {

    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/adstxt/website/${id}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        this.setState({ adxDetails: data })

        var array = [];

        for (let i = 0; i < this.state.adxDetails.length; i++) {

          if (data[i].certification_auth_id !== "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "," + data[i].certification_auth_id + "\n");

          }
          else if (data[i].certification_auth_id === "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "\n");

          }
        }
        var passingArray = array.join("\n");

        this.setState({ arrayData: passingArray });
        this.setState({ AdstxtViewIconOpen: true });

      }).catch((error) => {
        console.error(error);
      });
  }

  downloadTextFile = (value) => {
    const element = document.createElement("a");
    const file = new Blob([value], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = "ADS.txt";
    document.body.appendChild(element); // Required for this to work in FireFox
    element.click();
  }



  renderAdxDetails = () => {
    const classes = this.props.classes;
    let adxTxtDetails = this.state.adxDetails;
    return <GridContainer>
      <GridItem lg={ 3 } md={ 3 } ></GridItem>
      <GridItem lg={ 6 } md={ 6 } ><Card className={ classes.CustomCard }>
        <CardBody>
          <GridContainer>
            <GridItem lg={ 12 } md={ 12 }>
              <TextareaAutosize className={ classes.TextAreacustom } disabled="true" aria-label="minimum height" rowsMin={ 10 }
                defaultValue={ this.state.arrayData }
              />
            </GridItem>
          </GridContainer>
        </CardBody>
        <CardHeader >
          <div className={ classes.FloatLeft } >
            <span><MButton variant="outlined" color="primary" onClick={ () => { navigator.clipboard.writeText(this.state.arrayData) } } >Copy text to clipboard</MButton></span>
            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="primary" onClick={ () => { this.downloadTextFile(this.state.arrayData) } } >Download Ads.txt File</MButton></span>
          </div>
          {/* <div className={classes.FloatRight} >
            <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
            <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="secondary" >Cancel</MButton></span>
          </div> */}
        </CardHeader>
      </Card></GridItem>
      <GridItem lg={ 3 } md={ 3 } ></GridItem>
    </GridContainer>
  }
  renderRevenuedata = () => {
    var array = [];
    const classes = this.props.classes;
    var data = this.state.revenueDatas;

    var lAccordionHtml = [];
    var index = 0;
    var firstPanelIndex = 0;
    for (var websiteid in data) {

      if (index == 0)
        firstPanelIndex = websiteid;
      var lIsExpanded = false;
      if (this.state.expanded == websiteid)
        lIsExpanded = true;
      //index++;
      var lRevData = data[websiteid];
      //this.setState({websitedata:data[prop]});
      array.push(websiteid)
      var lAccordionDetailsHtml = lRevData.map((item, key) =>
      
        <GridContainer>
          
          <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
            <InputBase className={ classes.margin } value={ key + 1}  inputProps={ { 'aria-label': 'slno' } }
            />
          </GridItem>
          <GridItem lg={ 4 } md={ 2 } className={ classes.textfieldsgrid }>
            <InputBase className={ classes.margin } value={ item.advertiser_name } inputProps={ { 'aria-label': 'advertisername' } }
            />
          </GridItem>
          <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
            <TextField type="text" className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue={ item.erg_share } style={ { width: "100%", textAlign: "center" } }
              onChange={ (event) => this.updateShare(event.target.value, item.id_advertiser, item.id_website, key, "erg_share") }
            />
          </GridItem>
          <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }> 
            <TextField type="text" className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue={ item.pub_share } id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } }
              onChange={ (event) => this.updateShare(event.target.value, item.id_advertiser, item.id_website, key, "pub_share") }
            />
          </GridItem>
          <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
            <TextField className={ classes.textfields } label="Effective Date" type="date"
              InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
          </GridItem>
        </GridContainer>
        
    ); 
      var lAccordionChildHtml = <Accordion key={ websiteid } expanded={ true } onChange={ () => this.handleChange(lIsExpanded) } className={ classes.Accordianinput }>
        <AccordionSummary expandIcon={ <ExpandMoreIcon /> }  >
          <GridContainer>
            <GridItem lg={ 1 } md={ 1 }>
              <Typography className={ classes.secondaryHeading }> { lRevData[0].id_website } </Typography>
            </GridItem>
            <GridItem lg={ 8 } md={ 8 }>
              <Typography className={ classes.secondaryHeading }>
                { lRevData[0].website_name }
              </Typography>
            </GridItem>
            <GridItem lg={ 3 } md={ 3 }>
              <Typography className={ classes.secondaryHeading }>3% | 97% </Typography>
            </GridItem>
          </GridContainer>
        </AccordionSummary>
        <AccordionDetails className={ classes.AccordionInsideinput }>
          <Card>
            <CardBody>

              { lAccordionDetailsHtml }

            </CardBody>
            <CardHeader style={ { float: "right!important" } }>
              <div className={ classes.root2 } >
                <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" onClick={ this.submitData } >
                  Confirm
                </MButton>
                  <span style={ { paddingLeft: "10px" } } ><MButton variant="outlined" onClick={ this.enableRevenueDetails }>{ this.state.revenueEditText }</MButton>
                  </span>
                </span>
              </div>
            </CardHeader>
          </Card>
        </AccordionDetails>
      </Accordion>
      lAccordionHtml.push(lAccordionChildHtml);
      firstPanelIndex++;



      //this.RevenueShareViewhandleClickOpen();
      index++;
    }
    this.setState({
      RevenueShareViewOpen: true,
      expanded: firstPanelIndex,
      accoordionHtml: lAccordionHtml

    });
  }
  getDataForWebsiteId = (pKey) => {

    const classes = this.props.classes;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/website/revenue/${pKey}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {

        this.setState({ revenueDatas: data });
        this.renderRevenuedata();

      }).catch((error) => {
        console.error(error);
      });
  }


  editAdvertiser = (editObject) => {
    this.props.history.push('/admin/edit-user', { editObject });
  }

  disableAdvertiser = (pKey) => {


    var url = `${SERVER_URL}/api/users/${pKey}`;
    axios.delete(url, {}).then(response => response.data)
      .then((data) => {
        this.setState({ publisherdata: data })
      }).catch(error => { console.log(error); })

  }

  latestAllAds = () => {
    const classes = this.props.classes;

    return <GridContainer >
      <GridItem lg={ 3 } md={ 3 } ></GridItem>
      <GridItem lg={ 6 } md={ 6 } ><Card className={ classes.CustomCard }>
        <CardBody>
          <GridContainer>
            <GridItem lg={ 12 } md={ 12 }>
              <TextareaAutosize className={ classes.TextAreacustom } disabled="true" aria-label="minimum height" rowsMin={ 10 }
                value={ this.state.completearrayData }
              />
            </GridItem>
          </GridContainer>
        </CardBody>
        <CardHeader >
          <div className={ classes.FloatLeft } >
            <span><MButton variant="outlined" color="primary" onClick={ () => { navigator.clipboard.writeText(this.state.completearrayData) } } >Copy text to clipboard</MButton></span>
            <span className={ classes.ButtonLeftSpace }> <MButton variant="outlined" color="primary" onClick={ () => { this.downloadTextFile(this.state.completearrayData) } }>Download Ads.txt File</MButton></span>
          </div>
          {/*  <div className={classes.FloatRight} >
            <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
            <span className={classes.ButtonLeftSpace}> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
          </div> */}
        </CardHeader>
      </Card></GridItem>
      <GridItem lg={ 3 } md={ 3 } ></GridItem>
    </GridContainer>
  }


  setrenderPublisherDetails = (value) => {
    const allBtn = document.getElementById("all_btn");
    const activeBtn = document.getElementById("active_btn");
    const inactiveBtn = document.getElementById("inactive_btn");

    if (value === "ALL") {
      allBtn.style = "background-color:#1E90FF; color:#fff"; 
      activeBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else if (value === "ACTIVE") { 
      activeBtn.style = "background-color:#1E90FF; color:#fff";
      allBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else{
      inactiveBtn.style = "background-color:#1E90FF; color:#fff";
      activeBtn.style = "background-color:#fff; color:#000";
      allBtn.style = "background-color:#fff; color:#000";
    }
    this.setState({ status: value })
  }


  PublisherDeactivate=(id,e)=>{
    var status = ""
    console.log(e.target.checked)
    if (e.target.checked) {
      status = "INACTIVE"
    }
    else {
      status = "ACTIVE"
    }
    var dataPass = {
      "status": status
    }
    debugger;
    console.log(status)
    var ldata = this.state.publisherdata;

    ldata.forEach((element, index, array) => {
      if (element.id === id) {
        element.status = status
      }

    });

    this.setState({ publisherdata: ldata })
    console.log(this.state.publisherdata)

    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.put(`${SERVER_URL}/api/users/${id}`, dataPass, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);

      }).catch(error => { console.log(error); })
  }

  
  renderPublisherDetails = () => {
    const classes = this.props.classes;
    var data = 0;
    if (this.state.status === "ACTIVE") {
      data = this.state.activepublisherdata;
    }
    else if (this.state.status === "ALL") {
      data = this.state.publisherdata;
    }
    else if (this.state.status === "INACTIVE") {
      data = this.state.inActivepublisherdata;
    }
    else {
      data = this.state.activepublisherdata;
    }

    return <CardBody>
      <ReactTable
        data={ data }
        filterable
        columns={ [
          {
            Header: "Sl No.",
            accessor: "id",
            Cell: (row) => {
              return <div>{ row.index + 1 }</div>;
            },
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Sl No"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Publisher Name",
            accessor: "companyName",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'Left' } }
                placeholder="Search Name"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
            getProps: () => {
              return {
                style: {
                  textAlign: 'Left'
                },
              }
            }
          },
          {
            Header: "GSTIN",
            accessor: "gstin",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search GSTIN"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Contact Person",
            accessor: "contactPersonName",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Name"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
            getProps: () => {
              return {
                style: {
                  textAlign: 'Left'
                },
              }
            }
          },
          {
            Header: "Contact Number",
            accessor: "contactPersonNumber",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Contact No"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "email",
            accessor: "email",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search email"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },

          {
            Header: "View ",
            accessor: "actionsPublisherProfile",
            Cell: id => (
              <div className={ classes.ActionsButton }>
                <LightTooltip title="View" aria-label="view" placement="top">
                  <MButton onClick={ () => this.PublisherProfileViewhandleClickOpen(id.original.id) }
                    justIcon
                    round
                    simple
                    color="secondary"
                    className="view"

                  >
                    <View />
                  </MButton>
                </LightTooltip>



              </div>
            ),
            sortable: false,
            filterable: false
          },
          {
            Header: "Action ",
            accessor: "actionsPublisherProfile",
            Cell: id => (
              <div className={ classes.ActionsButton }>
                <LightTooltip title="Disable / Enable" aria-label="Disableunable" placement="top">
                  <Switch
                    name="Disableunable"
                    inputProps={ { 'aria-label': 'secondary' } }
                    size="small"
                    checked={ id.original.status === "ACTIVE" }
                    onChange={ ((e) => this.PublisherDeactivate(id.original.id, e)) }
                  />
                </LightTooltip >

                { "" }


              </div>
            ),
            sortable: false,
            filterable: false
          }


        ] }
        defaultPageSize={ 5 }
        minRows={ 1 }
        defaultFilterMethod={ this.filterCaseInsensitive }
        showPaginationTop
        showPaginationBottom={ false }
        className="-highlight"
      />
    </CardBody>

  }

  publisherContactProfileViewhandleClickOpen = (pkey) => {
    this.setState({ publisherContactViewOpen: true });
    this.setState({ contactId: pkey })
    const classes = this.props.classes;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/usercontact/details/contact/${pkey}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {

        this.setState({
          ContactDetials: data,
          Name: data.name,
          Designation: data.designation,
          contactNumberOne: data.contactNumberOne,
          contactNumberTwo: data.contactNumberTwo,
          email: data.email
        });


      }).catch((error) => {
        console.error(error);
      });


  };
  publisherContactProfileViewhandleClickClsoe = () => {
    this.setState({ publisherContactViewOpen: false });

  };

  setrenderPublisherContactDetails = (value) => {
    const allBtn = document.getElementById("all_btn");
    const activeBtn = document.getElementById("active_btn");
    const inactiveBtn = document.getElementById("inactive_btn");

    if (value === "ALL") {
      allBtn.style = "background-color:#1E90FF; color:#fff"; 
      activeBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else if (value === "ACTIVE") { 
      activeBtn.style = "background-color:#1E90FF; color:#fff";
      allBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else{
      inactiveBtn.style = "background-color:#1E90FF; color:#fff";
      activeBtn.style = "background-color:#fff; color:#000";
      allBtn.style = "background-color:#fff; color:#000";
    }
    this.setState({ contactStatus: value })
  }
  PublisherContactDeactivate = (id, e) => {
    var status = ""
    console.log(e.target.checked)
    if (e.target.checked) {
      status = "INACTIVE"
    }
    else {
      status = "ACTIVE"
    }
    var dataPass = {
      "status": status
    }
    debugger;
    console.log(status)
    var ldata = this.state.publisherContactDetails;

    ldata.forEach((element, index, array) => {
      if (element.id === id) {
        element.status = status
      }

    });

    this.setState({ publisherContactDetails: ldata })
    console.log(this.state.publisherContactDetails)

    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.post(`${SERVER_URL}/api/usercontact/`, this.state.publisherContactDetails, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);

      }).catch(error => { console.log(error); })
  }


  editContactDetails = () => {
    var id = this.state.contactId;
    var data = {}
    data.name = this.state.Name;
    data.designation = this.state.Designation;
    data.contactNumberOne = this.state.contactNumberOne;
    data.contactNumberTwo = this.state.contactNumberTwo;
    data.email = this.state.email;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.post(`${SERVER_URL}/api/usercontact/details/contact/${id}`, data, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data submitted")
      }).catch(error => { console.log(error); })
  }
  renderContact() {
    const classes = this.props.classes;


    return <div className={ classes.root }>
      <GridContainer>
        <GridItem lg={ 2 }></GridItem>
        <GridItem xs="12" md="8" lg="8">
          <Card>
            <CardHeader color="primary" icon>
              <CardIcon color="primary">
                <Profileicon />
              </CardIcon>
              <h4 className={ classes.heading }>Contact</h4>
            </CardHeader>
            <CardBody className={ classes.CardBody }>
              <GridContainer className={ classes.gridcontainer }>
                <GridItem lg={ 6 } xs={ 12 } md={ 6 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Name " value={ this.state.Name } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => {
                      this.setState({ "Name": event.target.value })
                    } } />
                </GridItem>
                <GridItem lg={ 6 } xs={ 12 } md={ 6 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Designation" value={ this.state.Designation } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => {
                      this.setState({ "Designation": event.target.value })
                    } } />
                </GridItem>
              </GridContainer>

              <GridContainer className={ classes.gridcontainer }>

                <GridItem lg={ 4 } xs={ 6 } md={ 4 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="contactNumberOne" value={ this.state.contactNumberOne } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => {
                      this.setState({ "contactNumberOne": event.target.value })
                    } } />
                </GridItem>
                <GridItem lg={ 4 } xs={ 6 } md={ 4 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } className={ classes.taluk } value={ this.state.contactNumberTwo } label="contactNumberTwo" variant="outlined" id="outlined-size-small" size="small"
                    onChange={ (event) => {
                      this.setState({ "contactNumberTwo": event.target.value })
                    } } />
                </GridItem>
                <GridItem lg={ 4 } xs={ 6 } md={ 4 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="email" value={ this.state.email } variant="outlined" id="outlined-size-small" size="small"
                    onChange={ (event) => {
                      this.setState({ "email": event.target.value })
                    } } />
                </GridItem>

              </GridContainer>
              <GridContainer >
                <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
                  <div className={ classes.root2 } >

                    <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="primary" onClick={ this.editContactDetails } >
                      Submit
                    </MButton>
                    </span>
                  </div>
                </GridItem>
              </GridContainer>

            </CardBody>

          </Card>
        </GridItem>
        <GridItem lg={ 2 }></GridItem>
      </GridContainer>


    </div>
  }

  renderPublisherContactDetails = () => {
    const classes = this.props.classes;
    var data = 0;
    if (this.state.contactStatus === "ACTIVE") {
      data = this.state.activePublisherContactDetails;
    }
    else if (this.state.contactStatus === "ALL") {
      data = this.state.publisherContactDetails;
    }
    else if (this.state.contactStatus === "INACTIVE") {
      data = this.state.inActivePublisherContactDetails;
    }
    else {
      data = this.state.activePublisherContactDetails;
    }
    return <CardBody>
      <ReactTable
        data={ data }
        filterable
        columns={ [
          {
            Header: "Sl No.",
            accessor: "id",
            Cell: (row) => {
              return <div>{ row.index + 1 }</div>;
            },
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Sl No"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Level",
            accessor: "level",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Level"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Name",
            accessor: "name",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'Left' } }
                placeholder="Search Name"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
            getProps: () => {
              return {
                style: {
                  textAlign: 'Left'
                },
              }
            }
          },
          {
            Header: "Designation",
            accessor: "designation",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Designation"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Contact Number",
            accessor: "contactNumberOne",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Contact Number"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },

          {
            Header: "Email ID",
            accessor: "email",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Email Id"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Reporting To",
            accessor: "idReportingUserName",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Name"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "View",
            accessor: "actionContactView",
            Cell: id => (
              <div className={ classes.ActionsButton }>
                <LightTooltip title="View" aria-label="view" placement="top">
                  <MButton onClick={ () =>
                    this.publisherContactProfileViewhandleClickOpen(id.original.id) }
                    justIcon
                    round
                    simple
                    color="secondary"
                    className="view"

                  >
                    <View />
                  </MButton>
                </LightTooltip>
                { " " }

              </div>
            ),
            sortable: false,
            filterable: false
          },

          {
            Header: "Action",
            accessor: "actionContactView",
            Cell: id => (
              <div className={ classes.ActionsButton }>
                <LightTooltip title="Disable / Enable" aria-label="Disableunable" placement="top">
                  <Switch
                    name="Disableunable"
                    inputProps={ { 'aria-label': 'secondary checkbox' } }
                    size="small"
                    checked={ id.original.status === "ACTIVE" }
                    onChange={ ((e) => this.PublisherContactDeactivate(id.original.id, e)) }
                  />
                </LightTooltip >
                { " " }

              </div>
            ),
            sortable: false,
            filterable: false
          }
        ] }
        defaultPageSize={ 5 }
        minRows={ 1 }
        defaultFilterMethod={ this.filterCaseInsensitive }
        showPaginationTop
        showPaginationBottom={ false }
        className="-highlight"
      />
    </CardBody>

  }
  setrenderPublisherRevenueDetails = (value) => {
    const allBtn = document.getElementById("all_btn");
    const activeBtn = document.getElementById("active_btn");
    const inactiveBtn = document.getElementById("inactive_btn");

    if (value === "ALL") {
      allBtn.style = "background-color:#1E90FF; color:#fff"; 
      activeBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else if (value === "ACTIVE") { 
      activeBtn.style = "background-color:#1E90FF; color:#fff";
      allBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else{
      inactiveBtn.style = "background-color:#1E90FF; color:#fff";
      activeBtn.style = "background-color:#fff; color:#000";
      allBtn.style = "background-color:#fff; color:#000";
    }
    this.setState({ userStatus: value })
  }


  renderRevnuePublisherDetails = () => {
    const classes = this.props.classes;
    var data = 0;
    if (this.state.userStatus === "ACTIVE") {
      data = this.state.activeWebsiteRevenueAvgData;
    }
    else if (this.state.userStatus === "ALL") {
      data = this.state.websiteRevenueAvgData;
    }
    else if (this.state.userStatus === "INACTIVE") {
      data = this.state.inActiveWebsiteRevenueAvgData;
    }
    else {
      data = this.state.websiteRevenueAvgData;
    }
    return <CardBody>
      <ReactTable
        data={ data }
        filterable
        columns={ [
          {
            Header: "Sl No.",
            accessor: "id",
            Cell: (row) => {
              return <div>{ row.index + 1 }</div>;
            },
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Sl No"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Publisher Name",
            accessor: "company_name",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'Left' } }
                placeholder="Search Name"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
            getProps: () => {
              return {
                style: {
                  textAlign: 'Left'
                },
              }
            }
          },
          {
            Header: "Number of Websites",
            accessor: "website_Count",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Number"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },/*
          {
            Header: "Publisher Share",
            accessor: "avg_pub_share",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Share"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
            },*/

          { 
            Header: "View",
            accessor: "actionContactView",
            Cell: id => (
              <div className={ classes.ActionsButton }>
                <LightTooltip title="View" aria-label="view" placement="top">

                  <MButton onClick={ () => {
                    this.getDataForWebsiteId(id.original.id);
                  } }
                    justIcon
                    round
                    simple
                    color="secondary"
                    className="view"

                  >
                    <View />
                  </MButton>
                </LightTooltip>
              </div>
            ),
            sortable: false,
            filterable: false
          }
        ] }  
        defaultPageSize={ 5 }
        minRows={ 1 }
        defaultFilterMethod={ this.filterCaseInsensitive }
        showPaginationTop
        showPaginationBottom={ false }
        className="-highlight"
      />
    </CardBody>

  }
  profile = (e) => {
    console.log(e.target.value)
    this.setState({ profileType: e.target.value })
  }
  render() {
    const classes = this.props.classes;

    return <div>
      <GridContainer >
        <GridItem lg={ 3 } md={ 3 } sm={ 12 } xs={ 12 }>
          <Card>
            <CardBody>
              <h4 className={ classes.CardHeading }>Total Publisher</h4>
              <h4 className={ classes.CardHeading }>{ this.state.totalPublisher }</h4>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 } sm={ 12 } xs={ 12 }>
          <Card>
            <CardBody>
              <h4 className={ classes.CardHeading }>Paid This FY</h4>
              <h4 className={ classes.CardHeading }>0</h4>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 } sm={ 12 } xs={ 12 }>
          <Card>
            <CardBody>
              <h4 className={ classes.CardHeading }>Total Website</h4>
              <h4 className={ classes.CardHeading }>{ this.state.websiteCount }</h4>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 } sm={ 12 } xs={ 12 }>
          <Card>
            <CardBody>
              <h4 className={ classes.CardHeading }>Outstanding Payable</h4>
              <h4 className={ classes.CardHeading }>0</h4>
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
      <GridContainer style={ { paddingTop: "10px" } }>
        <GridItem xs={ 12 } md={ 3 } lg={ 3 }>
          <button className={ classes.CardButton } onClick={ this.PublisherProfilehandleClickOpen } >
            Publisher Profile
          </button>
        </GridItem>
        <GridItem xs={ 12 } md={ 3 } lg={ 3 }>
          <button className={ classes.CardButton } onClick={ this.RevenueSharehandleClickOpen } >
            Revenue Share
          </button>
        </GridItem>
        <GridItem xs={ 12 } md={ 3 } lg={ 3 }>
          <button className={ classes.CardButton } onClick={ this.AdstxthandleClickOpen } >
            Ads.txt
          </button>
        </GridItem>
        <GridItem xs={ 12 } md={ 3 } lg={ 3 }>
          <button className={ classes.CardButton } onClick={ this.LedgerhandleClickOpen } >
            Ledger
          </button>
        </GridItem>
      </GridContainer>
      <GridContainer style={ { paddingTop: "3%" } }>
        <GridItem lg={ 12 }>
          <Card>
            <CardHeader color="primary" icon>
              <CardIcon color="primary">
                <PermContactCalendarIcon style={ { color: "white" } } />
              </CardIcon>
              <h4 className={ classes.cardIconTitle } style={ { marginTop: "0px!important,", color: "black" } }>Contact</h4>
            </CardHeader>
            <CardBody>
              <ReactTable
                data={ this.state.publisherdata }
                filterable
                columns={ [
                  {
                    Header: "Sl No.",
                    accessor: "id",
                    Cell: (row) => {
                      return <div>{ row.index + 1 }</div>;
                    },
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'center' } }
                        placeholder="Search Sl No"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                  },
                  {
                    Header: "Publisher Name",
                    accessor: "companyName",
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'Left' } }
                        placeholder="Search Name"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                    getProps: () => {
                      return {
                        style: {
                          textAlign: 'Left'
                        },
                      }
                    }
                  },
                  {
                    Header: "Contact Person",
                    accessor: "contactPersonName",
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'left' } }
                        placeholder="Search Person"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                    getProps: () => {
                      return {
                        style: {
                          textAlign: 'Left'
                        },
                      }
                    }
                  },
                  {
                    Header: "Contact Number",
                    accessor: "contactPersonNumber",
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'center' } }
                        placeholder="Search Contact Number"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                  },
                  {
                    Header: "Email ID",
                    accessor: "email",
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'center' } }
                        placeholder="Search Email Id"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                  },

                  {
                    Header: "Actions",
                    accessor: "actions",
                    Cell: id => (
                      <div className={ classes.ActionsButton }>
                        <LightTooltip title="View" aria-label="view" placement="top">
                          <MButton onClick={ () => this.PublisherViewhandleClickOpen(id.original.id) }
                            justIcon
                            round
                            simple
                            color="secondary"
                            className="view"

                          >
                            <View />
                          </MButton>
                        </LightTooltip>
                        { " " }

                      </div>
                    ),
                    sortable: false,
                    filterable: false
                  }
                ] }
                defaultPageSize={ 5 }
                minRows={ 1 }
                defaultFilterMethod={ this.filterCaseInsensitive }
                showPaginationTop
                showPaginationBottom={ false }
                className="-highlight"
              />
            </CardBody>

          </Card>
        </GridItem>

      </GridContainer>

      <Dialog fullScreen open={ this.state.publisherContactViewOpen } onClose={ this.publisherContactProfileViewhandleClickClsoe } TransitionComponent={ Transition } className={ classes.PublisherViewSlider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.publisherContactProfileViewhandleClickClsoe } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Contact
            </h4>
          </Toolbar>
          { this.renderContact() }
        </AppBar>
      </Dialog>





      <Dialog fullScreen open={ this.state.PublisherViewopen } onClose={ this.PublisherViewhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.PublisherViewhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Publisher Name
            </h4>
          </Toolbar>
        </AppBar>
        <GridContainer style={ { paddingTop: "3%" } }>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
          <GridItem lg={ 10 } md={ 10 } >
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">
                  <Profileicon />
                </CardIcon>
                <h4 className={classes.heading}>
                  <div className={classes.ButtonRightCard} >
                    <span style={{ paddingLeft: "10px" }}>
                      <MButton color="primary" id="all_btn" variant="outlined"
                      onClick={() => { this.setrenderPublisherContactDetails("ALL") }} >
                      All
                    </MButton></span>
                    <span style={{ paddingLeft: "10px" }}>
                      <MButton color="primary" style={{'background':'#1E90FF', 'color':'#fff'}} id="active_btn" variant="outlined"
                      onClick={() => { this.setrenderPublisherContactDetails("ACTIVE") }}>
                      Active
                    </MButton></span>
                    <span style={{ paddingLeft: "10px" }}>
                    <MButton color="primary" id="inactive_btn" variant="outlined"
                      onClick={() => { this.setrenderPublisherContactDetails("INACTIVE") }}>
                      Inactive
                    </MButton></span>
                  </div>
                </h4>
              </CardHeader>
              { this.renderPublisherContactDetails() }
              <CardHeader className={ classes.SimpleButton } >
                <AddContactButton id={ this.state.publisherId } />

                <div className={ classes.root2 } >
                  <span style={ { paddingLeft: "10px" } }>
                    <MButton color="secondary" variant="outlined" >
                      <a href={ SERVER_URL + "/api/usercontact/details/download/" + this.state.publisherId }>
                        Export</a>
                    </MButton></span>
                </div>

              </CardHeader>
            </Card>
          </GridItem>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
        </GridContainer>
      </Dialog>

      <Dialog fullScreen open={ this.state.PublisherProfileOpen } onClose={ this.PublisherProfilehandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.PublisherProfilehandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Publisher Profile
            </h4>
            <ButtonGroup aria-label="outlined secondary button group" style={ { paddingLeft: "70%" } }>
              <MButton onClick={ this.tabsetCreate } id="create">Create</MButton>
              <MButton onClick={ this.tabsetView }id="view" style={{'background':'#1E90FF', 'color':'#fff'} } >View</MButton>
            </ButtonGroup>
          </Toolbar>
        </AppBar>
        { this.state.tab == 'Create' &&
          <div>
            <RadioGroup aria-label="gender" name="gender1" value={ this.state.profileType } onChange={ (e) => { this.profile(e) } } >
              <FormControlLabel value="Domastic" control={ <Radio /> } label="Domastic" />
              <FormControlLabel value="Internatinal" control={ <Radio /> } label="Internatinal" />
            </RadioGroup>
            { this.state.profileType === "Domastic" && <CreateContact type="publisher"></CreateContact> }
            { this.state.profileType === "Internatinal" && <CreateInternational type="publisher"></CreateInternational> }
          </div> }

        { this.state.tab == 'View' &&
          <div>
            <GridContainer style={ { paddingTop: "3%" } }>
              <GridItem lg={ 1 } md={ 1 }></GridItem>
              <GridItem lg={ 10 } md={ 10 } >
                <Card>
                  <CardHeader color="primary" icon>
                    <CardIcon color="primary">
                      <Profileicon />
                    </CardIcon>
                    <h4 className={ classes.heading }>Publisher Profile View
                      <div className={ classes.ButtonRightCard } >
                        <span style={ { paddingLeft: "10px" } }>
                          <MButton color="primary" id="all_btn" variant="outlined"
                          onClick={() => { this.setrenderPublisherDetails("ALL") }} >
                          All
                        </MButton></span>
                        <span style={{ paddingLeft: "10px" }}>
                          <MButton color="primary" style={{'background':'#1E90FF', 'color':'#fff'}} id="active_btn" variant="outlined"
                          onClick={() => { this.setrenderPublisherDetails("ACTIVE") }} >
                          Active
                        </MButton></span>
                        <span style={{ paddingLeft: "10px" }}> 
                        <MButton color="primary" id="inactive_btn" variant="outlined"
                          onClick={() => { this.setrenderPublisherDetails("INACTIVE") }}  >
                          Inactive
                        </MButton></span>
                      </div>
                    </h4>
                  </CardHeader>
                  { this.renderPublisherDetails() }
                  <CardHeader className={ classes.SimpleButton } >
                    <div className={ classes.root2 } >
                      <span style={ { paddingLeft: "10px" } }><MButton color="secondary" variant="outlined" >
                        <a href={ SERVER_URL + "/api/users/details/download/publisher" }>
                          Export</a>
                      </MButton></span>
                    </div>
                  </CardHeader>
                </Card>
              </GridItem>
              <GridItem lg={ 1 } md={ 1 }></GridItem>
            </GridContainer>
          </div> }
      </Dialog>

      <Dialog fullScreen open={ this.state.PublisherProfileViewOpen } onClose={ this.PublisherProfileViewhandleClose } TransitionComponent={ Transition } className={ classes.PublisherViewSlider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.PublisherProfileViewhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Publisher Profile View
            </h4>
          </Toolbar>
        </AppBar>
        <ProfileView idUser={ this.state.profileKey } type="Publisher" action="view"></ProfileView>

        <GridContainer style={ { marginBottom: "20px" } }>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
          <GridItem lg={ 8 } md={ 8 }>
            <button className={ classes.CardButton } onClick={ this.ViewLedgerhandleClickOpen } >
              <LedgerView style={ { verticalAlign: "bottom" } } />
              View Ledger
            </button>
          </GridItem>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
        </GridContainer>
      </Dialog>
      <Dialog fullScreen open={ this.state.RevenueShareOpen } onClose={ this.RevenueSharehandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.RevenueSharehandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Revenue Share
            </h4>
          </Toolbar>
        </AppBar>
        <GridContainer style={ { paddingTop: "3%" } }>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
          <GridItem lg={ 10 } md={ 10 } >
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">
                  <Profileicon />
                </CardIcon>
                <h4 className={classes.heading}>Revenue Share
                  <div className={classes.ButtonRightCard} >
                    <span style={{ paddingLeft: "10px" }}>
                      <MButton color="primary" id="all_btn" variant="outlined"
                      onClick={() => { this.setrenderPublisherRevenueDetails("ALL") }} >
                      All
                    </MButton></span>
                    <span style={{ paddingLeft: "10px" }}>
                      <MButton color="primary" style={{'background':'#1E90FF', 'color':'#fff'}} id="active_btn" variant="outlined"
                      onClick={() => { this.setrenderPublisherRevenueDetails("ACTIVE") }} >
                      Active
                    </MButton></span>
                    <span style={{ paddingLeft: "10px" }}>
                       <MButton color="primary" id="inactive_btn" variant="outlined"
                      onClick={() => { this.setrenderPublisherRevenueDetails("INACTIVE") }}  >
                      Inactive
                    </MButton></span>
                  </div>
                </h4>
              </CardHeader>
              { this.renderRevnuePublisherDetails() }
              <CardHeader className={ classes.SimpleButton } >
                <div className={ classes.root2 } >
                  <span style={ { paddingLeft: "10px" } }><MButton color="secondary" variant="outlined" >
                    <a href={ SERVER_URL + "/api/users/details/download/get/" } color="secondary" >
                      Export</a>
                  </MButton></span>
                </div>

              </CardHeader>
            </Card>
          </GridItem>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
        </GridContainer>
      </Dialog>
      <Dialog fullScreen open={ this.state.RevenueShareViewOpen } onClose={ this.RevenueShareViewhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ () => { this.RevenueShareViewhandleClose(); } } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={classes.SliderTitle}>
            Publisher name  
            </h4>
          </Toolbar>
        </AppBar>


        <GridContainer style={ { paddingTop: "3%" } }>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
          <GridItem lg={ 8 }>

            { this.state.accoordionHtml }

          </GridItem>

        </GridContainer>
      </Dialog>


      <Dialog fullScreen open={ this.state.AdstxtOpen } onClose={ this.AdstxthandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.AdstxthandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Ads.txt
            </h4>
          </Toolbar>
        </AppBar>
        <GridContainer>
          <GridItem lg={2} md={2}></GridItem>
          <GridItem lg={8} md={8}>
            {/*<a className={classes.dataoverlay} onClick={this.LatestAdstxthandleClickOpen}>
              <Card>
                <CardBody>
                  <p className={ classes.OverlayCardheading }>Latest Ads.txt</p>
                </CardBody>
              </Card>
              </a>*/}
            <Dialog fullScreen open={ this.state.LatestAdstxtOpen } onClose={ this.LatestAdstxthandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
              <AppBar className={ classes.CustomappBar }>
                <Toolbar>
                  <IconButton edge="start" color="inherit" onClick={ this.LatestAdstxthandleClose } aria-label="close" className={ classes.CloseButton }>
                    <LeftAorrow />
                  </IconButton>
                  <h4 className={ classes.SliderTitle }>
                    Latest Ads.txt
                  </h4>
                </Toolbar>
              </AppBar> 
              <GridContainer >
                <GridItem lg={ 3 } md={ 3 }></GridItem>
                <GridItem lg={ 6 } md={ 6 }>
                  <a className={ classes.dataoverlay } onClick={ this.AdstxtViewhandleClickOpen }>
                    <Card>
                      <CardBody>
                        <p className={ classes.OverlayCardheading }>All Ads.txt</p>
                      </CardBody>
                    </Card>
                  </a>
                  <Dialog fullScreen open={ this.state.AdstxtViewOpen } onClose={ this.AdstxtViewhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
                    <AppBar className={ classes.CustomappBar }>
                      <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={ this.AdstxtViewhandleClose } aria-label="close" className={ classes.CloseButton }>
                          <LeftAorrow />
                        </IconButton>
                        <h4 className={ classes.SliderTitle }>
                          All Ads.txt
                        </h4>
                      </Toolbar>
                    </AppBar>

                    { this.latestAllAds() }
                  </Dialog>
                </GridItem>
                <GridItem lg={ 3 } md={ 3 }></GridItem>
              </GridContainer>
              <GridContainer>
                <GridItem lg={ 3 } md={ 3 }></GridItem>
                <GridItem lg={ 6 }>
                  <Accordion expanded={ this.state.expanded === 'panel1' } onChange={ () => this.handleChange('panel1') } className={ classes.Accordianinput }>
                    <AccordionSummary
                      expandIcon={ <ExpandMoreIcon /> }
                      aria-controls="panel1bh-content"
                      id="panel5bh-header"
                    >
                      <GridContainer>
                        <GridItem lg={ 1 } md={ 1 }>
                          <Typography className={ classes.secondaryHeading }>
                            1
                          </Typography>
                        </GridItem>
                        <GridItem lg={ 11 } md={ 11 }>
                          <Typography className={ classes.secondaryHeading }>
                            Advertiser1 - Adx.txt
                          </Typography>
                        </GridItem>
                      </GridContainer>
                    </AccordionSummary>
                    <AccordionDetails className={ classes.AccordionInsideinput }>
                      <Card className={ classes.CustomCard }>
                        <CardBody>
                          <GridContainer>
                            <GridItem lg={ 12 } md={ 12 }>
                              <TextareaAutosize className={ classes.TextAreacustom } disabled="true" aria-label="minimum height" rowsMin={ 10 }
                                defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                              />
                            </GridItem>
                          </GridContainer>
                        </CardBody>
                        <CardHeader >
                          <div className={ classes.FloatLeft } >
                            <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                            <span className={ classes.ButtonLeftSpace }> <MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>
                          </div>
                          <div className={ classes.FloatRight } >
                            <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                            <span className={ classes.ButtonLeftSpace }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                          </div>
                        </CardHeader>
                      </Card>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion expanded={ this.state.expanded === 'panel2' } onChange={ () => this.handleChange('panel2') } className={ classes.Accordianinput }>
                    <AccordionSummary
                      expandIcon={ <ExpandMoreIcon /> }
                      aria-controls="panel2bh-content"
                      id="panel2bh-header"
                    >
                      <GridContainer>
                        <GridItem lg={ 1 } md={ 1 }>
                          <Typography className={ classes.secondaryHeading }>
                            2
                          </Typography>
                        </GridItem>
                        <GridItem lg={ 11 } md={ 11 }>
                          <Typography className={ classes.secondaryHeading }>
                            Advertiser2- Adx.txt
                          </Typography>
                        </GridItem>
                      </GridContainer>
                    </AccordionSummary>
                    <AccordionDetails className={ classes.AccordionInsideinput }>
                      <Card className={ classes.CustomCard }>
                        <CardBody>
                          <GridContainer>
                            <GridItem lg={ 12 } md={ 12 }>
                              <TextareaAutosize className={ classes.TextAreacustom } disabled="true" aria-label="minimum height" rowsMin={ 10 }
                                defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                              />
                            </GridItem>
                          </GridContainer>
                        </CardBody>
                        <CardHeader >
                          <div className={ classes.FloatLeft } >
                            <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>
                          </div>
                          <div className={ classes.FloatRight } >
                            <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                          </div>
                        </CardHeader>
                      </Card>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion expanded={ this.state.expanded === 'panel3' } onChange={ () => this.handleChange('panel3') } className={ classes.Accordianinput }>
                    <AccordionSummary
                      expandIcon={ <ExpandMoreIcon /> }
                      aria-controls="pane3bh-content"
                      id="panel3bh-header"
                    >
                      <GridContainer>
                        <GridItem lg={ 1 } md={ 1 }>
                          <Typography className={ classes.secondaryHeading }>
                            3
                          </Typography>
                        </GridItem>
                        <GridItem lg={ 11 } md={ 11 }>
                          <Typography className={ classes.secondaryHeading }>
                            Advertiser3 - Adx.txt
                          </Typography>
                        </GridItem>
                      </GridContainer>
                    </AccordionSummary>
                    <AccordionDetails className={ classes.AccordionInsideinput }>
                      <Card className={ classes.CustomCard }>
                        <CardBody>
                          <GridContainer>
                            <GridItem lg={ 12 } md={ 12 }>
                              <TextareaAutosize className={ classes.TextAreacustom } disabled="true" aria-label="minimum height" rowsMin={ 10 }
                                defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                              />
                            </GridItem>
                          </GridContainer>
                        </CardBody>
                        <CardHeader >
                          <div className={ classes.FloatLeft } >
                            <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>
                          </div>
                          <div className={ classes.FloatRight } >
                            <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                          </div>
                        </CardHeader>
                      </Card>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion expanded={ this.state.expanded === 'panel4' } onChange={ () => this.handleChange('panel4') } className={ classes.Accordianinput }>
                    <AccordionSummary
                      expandIcon={ <ExpandMoreIcon /> }
                      aria-controls="panel4bh-content"
                      id="panel4bh-header"
                    >
                      <GridContainer>
                        <GridItem lg={ 1 } md={ 1 }>
                          <Typography className={ classes.secondaryHeading }>
                            4
                          </Typography>
                        </GridItem>
                        <GridItem lg={ 11 } md={ 11 }>
                          <Typography className={ classes.secondaryHeading }>
                            Advertiser4 - Adx.txt
                          </Typography>
                        </GridItem>
                      </GridContainer>
                    </AccordionSummary>
                    <AccordionDetails className={ classes.AccordionInsideinput }>
                      <Card className={ classes.CustomCard }>
                        <CardBody>
                          <GridContainer>
                            <GridItem lg={ 12 } md={ 12 }>
                              <TextareaAutosize className={ classes.TextAreacustom } disabled="true" aria-label="minimum height" rowsMin={ 10 }
                                defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                              />
                            </GridItem>
                          </GridContainer>
                        </CardBody>
                        <CardHeader >
                          <div className={ classes.FloatLeft } >
                            <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>
                          </div>
                          <div className={ classes.FloatRight } >
                            <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                          </div>
                        </CardHeader>
                      </Card>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion expanded={ this.state.expanded === 'panel5' } onChange={ () => this.handleChange('panel5') } className={ classes.Accordianinput }>
                    <AccordionSummary
                      expandIcon={ <ExpandMoreIcon /> }
                      aria-controls="5bh-content"
                      id="5bh-header"
                    >
                      <GridContainer>
                        <GridItem lg={ 1 } md={ 1 }>
                          <Typography className={ classes.secondaryHeading }>
                            5
                          </Typography>
                        </GridItem>
                        <GridItem lg={ 11 } md={ 11 }>
                          <Typography className={ classes.secondaryHeading }>
                            Advertiser5 - Adx.txt
                          </Typography>
                        </GridItem>
                      </GridContainer>
                    </AccordionSummary>
                    <AccordionDetails className={ classes.AccordionInsideinput }>
                      <Card className={ classes.CustomCard }>
                        <CardBody>
                          <GridContainer>
                            <GridItem lg={ 12 } md={ 12 }>
                              <TextareaAutosize className={ classes.TextAreacustom } disabled="true" aria-label="minimum height" rowsMin={ 10 }
                                defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                              />
                            </GridItem>
                          </GridContainer>
                        </CardBody>
                        <CardHeader >
                          <div className={ classes.FloatLeft } >
                            <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>
                          </div>
                          <div className={ classes.FloatRight } >
                            <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                          </div>
                        </CardHeader>
                      </Card>
                    </AccordionDetails>
                  </Accordion>
                </GridItem>
                <GridItem lg={ 3 } md={ 3 }></GridItem>
              </GridContainer>
            </Dialog>
          </GridItem>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
        </GridContainer>
        <GridContainer>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
          <GridItem lg={ 8 } md={ 8 }>
            <Card>
              <CardBody>
                <ReactTable
                  data={ this.state.adxData }
                  filterable
                  columns={ [
                    {
                      Header: "Sl No",
                      accessor: "id"
                    },
                    {
                      Header: "Status",
                      accessor: "id",
                      id: "row",
                      Cell: (row) => (
                        <div className={ classes.ActionsButton }>

                          { this.state.adxData[row.index] && this.state.adxData[row.index].adsTxtStatus && this.state.adxData[row.index].adsTxtStatus !== 'FAILURE' &&
                            <Button
                              justIcon
                              round
                              simple
                              color="success"
                              className="check"
                            >
                              <CheckIcon />
                            </Button> }

                          {
                            this.state.adxData[row.index] && this.state.adxData[row.index].adsTxtStatus && this.state.adxData[row.index].adsTxtStatus === 'FAILURE' &&
                            <Button
                              justIcon
                              round
                              simple
                              color="danger"
                              className="uncheck"
                            >
                              <UncheckIcon />
                            </Button> }

                        </div>
                      ),

                      sortable: false,
                      filterable: false
                    },
                    {
                      Header: "Publisher Name",
                      accessor: "name"
                    },
                    {
                      Header: "Domain Name",
                      accessor: "hostURL"
                    },

                    {
                      Header: "Actions",
                      accessor: "id",
                      id: "row",
                      Cell: id => (
                        <div className={ classes.ActionsButton }>
                          { this.state.adxData[id.index] && this.state.adxData[id.index].adsTxtStatus && this.state.adxData[id.index].adsTxtStatus !== 'FAILURE' &&
                            <LightTooltip title="View" aria-label="view" placement="top">
                              <Button onClick={ () => this.sample(id.original.id) }
                                justIcon
                                round
                                simple
                                color="success"
                                className="view"
                              >
                                <View />
                              </Button>
                            </LightTooltip>
                          }
                          {
                            this.state.adxData[id.index] && this.state.adxData[id.index].adsTxtStatus && this.state.adxData[id.index].adsTxtStatus === 'FAILURE' &&
                            <LightTooltip title="View" aria-label="view" placement="top">
                              <Button onClick={ () => this.sample(id.original.id) }
                                justIcon
                                round
                                simple
                                color="danger"
                                className="view"
                              >
                                <ViewOff />
                              </Button>
                            </LightTooltip>
                          }
                        </div>
                      ),
                      sortable: false,
                      filterable: false
                    }
                  ] }
                  defaultPageSize={ 5 }
                  minRows={ 1 }
                  defaultFilterMethod={ this.filterCaseInsensitive }
                  showPaginationTop
                  showPaginationBottom={ false }
                  className="-striped -highlight"
                />
              </CardBody>
            </Card>
          </GridItem>

          <GridItem lg={ 2 } md={ 2 }></GridItem>
        </GridContainer>
      </Dialog>
      <Dialog fullScreen open={ this.state.AdstxtViewIconOpen } onClose={ this.AdstxtViewIconhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.AdstxtViewIconhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>All Ads.txt</h4>
          </Toolbar>
        </AppBar>
        { this.renderAdxDetails() }
      </Dialog>
      <Dialog fullScreen open={ this.state.LedgerOpen } onClose={ this.LedgerhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.LedgerhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Ledger
            </h4>
          </Toolbar>
        </AppBar>
        <GridContainer style={ { paddingTop: "3%" } }>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
          <GridItem lg={ 10 } md={ 10 } >
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">
                  <LedgerView />
                </CardIcon>
                <h4 className={classes.heading}>Ledger
                  <div className={classes.ButtonRightCard} >
                    <span style={{ paddingLeft: "10px" }}>
                      <MButton color="primary" id="all_btn" variant="outlined" >
                      All
                    </MButton></span>
                    <span style={{ paddingLeft: "10px" }}>
                      <MButton color="primary" style={{'background':'#1E90FF', 'color':'#fff'}} id="active_btn" variant="outlined">
                      Active
                    </MButton></span>
                    <span style={{ paddingLeft: "10px" }}> 
                    <MButton color="primary" id="inactive_btn" variant="outlined" >
                      Inactive
                    </MButton></span>
                  </div>
                </h4>
              </CardHeader>
              <CardBody>
                <ReactTable
                  data={ this.state.publisherdata }
                  filterable
                  columns={ [
                    {
                      Header: "Date",
                      accessor: "date",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Date"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>Total</strong>
                        </span>
                      )
                    },

                    {
                      Header: "Publisher Name",
                      accessor: "publisherName",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'left' } }
                          placeholder="Search Name"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      getProps: () => {
                        return {
                          style: {
                            textAlign: 'Left'
                          },
                        }
                      }
                    },
                    {
                      Header: "Particular",
                      accessor: "particular",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Particular"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                    },
                    {
                      Header: "Debit",
                      accessor: "debit",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Debit"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>59,000</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Credit",
                      accessor: "credit",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Amount"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>0</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Balance",
                      accessor: "balance",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Balance"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>0</strong>
                        </span>
                      )
                    },


                  ] }
                  defaultPageSize={ 5 }
                  minRows={ 1 }
                  defaultFilterMethod={ this.filterCaseInsensitive }
                  showPaginationTop
                  showPaginationBottom={ false }
                  className="-highlight"
                />
              </CardBody>
              <CardHeader className={ classes.SimpleButton } >

                <div className={ classes.root2 } >
                  <span style={ { paddingLeft: "10px" } }><MButton color="secondary" variant="outlined" >
                    Export
                  </MButton></span>
                </div>

              </CardHeader>
            </Card>
          </GridItem>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
        </GridContainer>
      </Dialog>
      <Dialog fullScreen open={ this.state.ViewLedgerOpen } onClose={ this.ViewLedgerhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.ViewLedgerhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              View Ledger
            </h4>
          </Toolbar>
        </AppBar>
        <GridContainer style={ { paddingTop: "3%" } }>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
          <GridItem lg={ 10 } md={ 10 } >
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">

                  <LedgerView />
                </CardIcon>
                <h4 className={ classes.heading }>View Ledger
                  <div className={ classes.ButtonRightCard } >
                    <span style={ { paddingLeft: "10px" } }><MButton color="primary" variant="outlined" >
                      All
                    </MButton></span>
                    <span style={ { paddingLeft: "10px" } }><MButton color="primary" variant="outlined">
                      Active
                    </MButton></span>
                    <span style={ { paddingLeft: "10px" } }> <MButton color="primary" variant="outlined" >
                      Inactive
                    </MButton></span>
                  </div>
                </h4>
              </CardHeader>
              <CardBody>
                <ReactTable
                  data={ this.state.publisherdata }
                  filterable
                  columns={ [
                    {
                      Header: "Date",
                      accessor: "date",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Date"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>Total</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Particular",
                      accessor: "particular",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Particular"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                    },
                    {
                      Header: "Debit",
                      accessor: "debit",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Debit"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>59,000</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Credit",
                      accessor: "credit",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Amount"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>0</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Balance",
                      accessor: "balance",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Balance"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>0</strong>
                        </span>
                      )
                    },


                  ] }
                  defaultPageSize={ 5 }
                  minRows={ 1 }
                  defaultFilterMethod={ this.filterCaseInsensitive }
                  showPaginationTop
                  showPaginationBottom={ false }
                  className="-highlight"
                />
              </CardBody>
              <CardHeader className={ classes.SimpleButton } >

                <div className={ classes.root2 } >
                  <span style={ { paddingLeft: "10px" } }><MButton color="secondary" variant="outlined" >
                    Export
                  </MButton></span>
                </div>

              </CardHeader>
            </Card>
          </GridItem>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
        </GridContainer>
      </Dialog>
    </div>



  }
}

const PublisherHOC = withStyles(styles)(Publisher);
export default connect(mapStateToProps, mapDispatchToProps)(PublisherHOC);