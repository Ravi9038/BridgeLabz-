
import React, { Component } from 'react'
import { SERVER_URL } from "../../variables/constants";
import ChartistGraph from "react-chartist";
import { connect } from 'react-redux';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { makeStyles } from "@material-ui/core/styles";
import { withStyles } from '@material-ui/styles';
import axios from 'axios';

import Timeline from "@material-ui/icons/Timeline";
import * as moment from 'moment';
import Heading from "components/Heading/Heading.js";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
import DateSelectionDropDown from "../Widgets/DateSelectionDropdown.js";
import Checkbox from '@material-ui/core/Checkbox';
import styles from "assets/jss/material-dashboard-pro-react/views/chartsStyle.js";
import Button from "components/CustomButtons/Button.js";
import Chartist from 'chartist';

import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import StarIcon from '@material-ui/icons/Star';
//import Line from "views/Publisher/Line";


var delays = 2,
    durations = 500;

var seq = 0;



export class Graph extends Component {
    constructor (props) {
        super(props);
        this.state = {
            selectedAdvertiserId: '',
            selectedAdvertiser: '',
            lstartDate: '',
            lendDate: '',
            advertiserData: '',
            todaysDate: new moment().utcOffset('GMT-00:00').format("YYYY-MM-DD"),
            data: {
                labels: '',
                series: '',
            },
            options: {
                lineSmooth: Chartist.Interpolation.cardinal({
                    tension: 0
                }),
                axisY: {
                    showGrid: true,

                    offset: 40,
                    position: "start",

                },
                axisX: {
                    showGrid: true,
                    offset: 40,
                    position: "end"
                },


                onHover: e => {
                    const item = Chartist.getElementAtEvent(e)
                    if (item.length) {
                        const x = this.state.data.series[item[0]._index].x,
                            y = this.state.data.series[item[0]._index].y
                        this.props.setXYInfo(x, y)
                    }
                },

                seriesBarDistance: 5,
                scaleMinSpace: 20,
                showArea: true,
                height: '350px',
                // low: 0,
                // high: 150,


                showArea: true,
                onlyInteger: true,
                referenceValue: 5,
            },


            animation: {
                draw: (data) => {
                    seq++;
                    if (data.type === 'line') {
                        // If the drawn element is a line we do a simple opacity fade in. This could also be achieved using CSS3 animations.
                        data.element.animate({
                            opacity: {
                                // The delay when we like to start the animation
                                begin: seq * delays + 1000,
                                // Duration of the animation
                                dur: durations,
                                // The value where the animation should start
                                from: 0,
                                // The value where it should end
                                to: 1
                            }
                        });
                    } else if (data.type === 'label' && data.axis === 'x') {
                        data.element.animate({
                            y: {
                                begin: seq * delays,
                                dur: durations,
                                from: data.y + 100,
                                to: data.y,
                                // We can specify an easing function from Chartist.Svg.Easing
                                easing: 'easeOutQuart'
                            }
                        });
                    } else if (data.type === 'label' && data.axis === 'y') {
                        data.element.animate({
                            x: {
                                begin: seq * delays,
                                dur: durations,
                                from: data.x - 100,
                                to: data.x,
                                easing: 'easeOutQuart'
                            }
                        });
                    } else if (data.type === 'point') {
                        data.element.animate({
                            x1: {
                                begin: seq * delays,
                                dur: durations,
                                from: data.x - 10,
                                to: data.x,
                                easing: 'easeOutQuart'
                            },
                            x2: {
                                begin: seq * delays,
                                dur: durations,
                                from: data.x - 10,
                                to: data.x,
                                easing: 'easeOutQuart'
                            },
                            opacity: {
                                begin: seq * delays,
                                dur: durations,
                                from: 0,
                                to: 1,
                                easing: 'easeOutQuart'
                            }
                        });
                    } else if (data.type === 'grid') {
                        // Using data.axis we get x or y which we can use to construct our animation definition objects
                        var pos1Animation = {
                            begin: seq * delays,
                            dur: durations,
                            from: data[data.axis.units.pos + '1'] - 30,
                            to: data[data.axis.units.pos + '1'],
                            easing: 'easeOutQuart'
                        };

                    }


                    if (data.type === "line" || data.type === "area") {
                        data.element.animate({
                            d: {
                                begin: 600,
                                dur: 700,
                                from: data.path
                                    .clone()
                                    .scale(1, 0)
                                    .translate(0, data.chartRect.height())
                                    .stringify(),
                                to: data.path.clone().stringify(),
                                easing: Chartist.Svg.Easing.easeOutQuint
                            }
                        });
                    } else if (data.type === "point") {
                        data.element.animate({
                            opacity: {
                                begin: (data.index + 1) * delays,
                                dur: durations,
                                from: 0,
                                to: 1,
                                easing: "ease"
                            }
                        });
                    }
                }
            }
        }
    }






    renderWebsiteWiseData = (pStartDate, pEndDate) => {
        console.log(pStartDate);
        console.log(pEndDate);
        this.viewGraph(pStartDate, pEndDate);



    }
    handleWebsiteDropDownChange = (pStartDate, pEndDate) => {
        this.renderWebsiteWiseData(pStartDate, pEndDate);
        this.setState({ lstartDate: pStartDate })
        this.setState({ lendDate: pEndDate })
    }
    componentDidMount = () => {

        const TOKEN = 'Bearer '.concat(this.props.data.token);
        var todayDate = new moment().utcOffset('GMT-00:00');
        var endDate = todayDate.format("YYYY-MM-DD");
        var startDate = todayDate.subtract(6, 'days').format("YYYY-MM-DD");
        this.renderWebsiteWiseData(startDate, endDate);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/users/advertisers`, { headers: { "Authorization": TOKEN } })
            .then(res => {
                console.log(res.data);
                let advertiser = [];
                res.data.forEach(item => {
                    let lAdvertiser = [];
                    lAdvertiser.push(item.companyName);
                    lAdvertiser.push(item.id);
                    advertiser.push(lAdvertiser)
                })
                this.setState({ advertiserData: advertiser });
                console.log(this.state.advertiserData)
            }).catch(function (error) {
                console.log(error);
            });

        var request = {};
        request.start_date = startDate;
        request.end_date = endDate;
        console.log(request)
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.post(`${SERVER_URL}/api/advertiser/revenue/`, request, { headers: { "Authorization": TOKEN } })
            .then(res => {
                console.log(res.data);
                let advertiserRevenue = [];
                let advertiserImpression = [];
                let advertiserCpm = [];
                let advertiserDate = [];
                res.data.forEach(item => {
                    advertiserRevenue.push((item.revenue));
                    advertiserImpression.push((item.impression));
                    advertiserCpm.push(item.cpm);
                    advertiserDate.push(item.date);
                })
                let completeArray = [];
                console.log(advertiserRevenue);
                console.log(advertiserImpression);
                console.log(advertiserCpm);
                console.log(advertiserDate);
                completeArray.push(advertiserRevenue, advertiserImpression, advertiserCpm);
                console.log(completeArray)
                this.setState({
                    data: {
                        ...this.state.data,
                        labels: advertiserDate
                    }
                })
                this.setState({
                    data: {
                        ...this.state.data,
                        series: completeArray
                    }
                })

                console.log(this.state.data.labels);
                console.log(this.state.data.series);
            }).catch(function (error) {
                console.log(error);
            });

    }

    /* componentWillMount() {
        Chartist.pluginService.register({
          afterDraw: function (chart, easing) {
            if (chart.tooltip._active && chart.tooltip._active.length) {
              const activePoint = chart.controller.tooltip._active[0];
              const ctx = chart.ctx;
              const x = activePoint.tooltipPosition().x;
              const topY = chart.scales['y-axis-1'].top;
              const bottomY = chart.scales['y-axis-1'].bottom;
              ctx.save();
              ctx.beginPath();
              ctx.moveTo(x, topY);
              ctx.lineTo(x, bottomY);
              ctx.lineWidth = 2;
              ctx.strokeStyle = '#e23fa9';
              ctx.stroke();
              ctx.restore();
            }
          }
        });
      } */
    choosedAdvertiser = (event, values) => {
        console.log(values[1])
        this.setState({ selectedAdvertiser: values[0] })
        this.setState({ selectedAdvertiserId: values[1] })
        this.viewGraph(this.state.lstartDate, this.state.lendDate)

    }
    viewGraph = (pStartDate, pEndDate) => {
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        var id = this.state.selectedAdvertiserId;
        console.log(id)
        var request = {};
        request.start_date = pStartDate;
        request.end_date = pEndDate;
        console.log(request)
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.post(`${SERVER_URL}/api/advertiser/revenue/${id}`, request, { headers: { "Authorization": TOKEN } })
            .then(res => {
                console.log(res.data);
                let advertiserRevenue = [];
                let advertiserImpression = [];
                let advertiserCpm = [];
                let advertiserDate = [];
                res.data.forEach(item => {
                    advertiserRevenue.push((item.revenue) / 10);
                    advertiserImpression.push((item.impression) / 100000);
                    advertiserCpm.push(item.cpm);
                    advertiserDate.push(item.date);
                })
                let completeArray = [];
                console.log(advertiserRevenue);
                console.log(advertiserImpression);
                console.log(advertiserCpm);
                console.log(advertiserDate);
                completeArray.push(advertiserRevenue, advertiserImpression, advertiserCpm);
                console.log(completeArray)
                this.setState({
                    data: {
                        ...this.state.data,
                        labels: advertiserDate
                    }
                })
                this.setState({
                    data: {
                        ...this.state.data,
                        series: completeArray
                    }
                })

                console.log(this.state.data.labels);
                console.log(this.state.data.series);
            }).catch(function (error) {
                console.log(error);
            });
    }
    render() {
        const classes = this.props.classes;
        return (
            <div>
                <GridContainer>
                    <GridItem xs={ 12 } sm={ 12 } md={ 12 } >
                        <Card>
                            <CardHeader color="warning" icon>
                                <GridContainer >
                                    <GridItem xs={ 12 } sm={ 12 } md={ 8 } lg={ 5 }> <h4 className={ classes.cardIconTitle }> <CardIcon color="warning">
                                        <Timeline />
                                    </CardIcon>
                                        Revenue Chart
                                    </h4></GridItem>

                                    <GridItem xs={ 12 } sm={ 12 } md={ 2 } lg={ 2 } style={ { marginTop: "10px", marginLeft: "160px" } } >

                                        <DateSelectionDropDown id="websiteDropDown" customStyle={ { paddingRight: "10px", width: "180px" } } onDropDownChange={ this.handleWebsiteDropDownChange } defaultValue="Last7Days"
                                            classes={ {
                                                select: classes.select
                                            } } />

                                    </GridItem>
                                    <GridItem xs={ 12 } sm={ 12 } md={ 2 } lg={ 3 } style={ { marginTop: "10px" } } >
                                        <Autocomplete
                                            id="country-select-demo"
                                            className={ classes.SelectDropdownStyle }
                                            options={ this.state.advertiserData }
                                            classes={ {
                                                option: classes.option,
                                            } }
                                            getOptionLabel={ (option) => option[0] }
                                            onChange={ this.choosedAdvertiser }
                                            renderOption={ (option) => (
                                                <React.Fragment>
                                                    { option[0] }
                                                </React.Fragment>
                                            ) }
                                            renderInput={ (params) => (
                                                <TextField
                                                    { ...params }
                                                    label="Choose an advertiser"
                                                    variant="outlined"
                                                    inputProps={ {
                                                        ...params.inputProps,
                                                        autoComplete: 'new-password', // disable autocomplete and autofill
                                                    } }

                                                />
                                            ) }
                                        />
                                    </GridItem>
                                    {/*  <GridItem xs={12} sm={12} md={2} lg={2} >

                                        <div className={classes.buttonstyle}>

                                            <Button color="info" onClick={this.viewGraph} >
                                                View
                                            </Button>

                                        </div>
                                    </GridItem> */}
                                </GridContainer>
                                <ChartistGraph
                                    data={ this.state.data }
                                    type="Line"
                                    options={ this.state.options }
                                    listener={ this.state.animation }
                                    plugins={ this.state.options.plugins }
                                />


                                {/*  <div style={{height:"200px" , width:"100%"}}>
                                    <Line></Line>
                                    </div>  */}
                            </CardHeader>
                            <CardBody>

                            </CardBody>
                            <CardBody className={ classes.GraphIdentifier }>
                                <List component="nav" className={ classes.root } aria-label="contacts" style={ { display: "inlineFlex" } }>
                                    <ListItem >
                                        <ListItemIcon>
                                            <StarIcon style={ { color: "#f05b4f" } } />
                                        </ListItemIcon>
                                        <ListItemText >
                                            Impression
                                        </ListItemText>
                                    </ListItem>
                                    <ListItem >
                                        <ListItemIcon>
                                            <StarIcon style={ { color: "#f4c63d" } } />
                                        </ListItemIcon>
                                        <ListItemText primary="CPM" />
                                    </ListItem>
                                    <ListItem >
                                        <ListItemIcon>
                                            <StarIcon style={ { color: "#18b2c6" } } />
                                        </ListItemIcon>
                                        <ListItemText primary="Revenue" />
                                    </ListItem>

                                </List>
                            </CardBody>
                        </Card>

                    </GridItem>

                </GridContainer>
            </div>
        );
    }
}
const GraphHOC = withStyles(styles)(Graph);
export default connect(mapStateToProps, mapDispatchToProps)(GraphHOC);