import React from "react";
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import ReactTable from "react-table";
// @material-ui/core components
import { makeStyles } from '@material-ui/styles';
import { withStyles } from "@material-ui/core/styles";
import InputBase from '@material-ui/core/InputBase';
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js"; 
import CardHeader from "components/Card/CardHeader.js";

import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import MButton from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Tooltip from '@material-ui/core/Tooltip';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
// material-ui icons
import View from "@material-ui/icons/Visibility";
import ViewOff from "@material-ui/icons/VisibilityOff";
import CheckIcon from "@material-ui/icons/Done";
import UncheckIcon from "@material-ui/icons/Close";
import Button from "components/CustomButtons/Button.js";
import IconButton from '@material-ui/core/IconButton';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'
import styles from "assets/jss/material-dashboard-pro-react/views/AdstxtmangementStyle.js";
import { dataTable } from "variables/AdstxtManagementDatable.js";
const LightTooltip = withStyles((theme) => ({
  tooltip: { 
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}))(Tooltip);

const useStyles = makeStyles(styles);
const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="left" ref={ref} {...props} />;
  });
export default function RevenueShare() {
const [expanded, setExpanded] = React.useState(false);
const handleChange = (panel) => (event, isExpanded) => {
          setExpanded(isExpanded ? panel : false);
        };
const [open, setOpen] = React.useState(false);
const [tableOpen, settableOpen] = React.useState(false);
const [AllAdstxtOpen, setAllAdstxtOpen] = React.useState(false);

const [data, setData] = React.useState(
dataTable.dataRows.map((prop, key) => {
            return {
              id: key,
              SlNo: prop[0],
              Staus: prop[0],
              DomainName: prop[1],
              actions: prop[2],
            };
          })
);

const handleClickOpen = () => {
setOpen(true);
};     
const handleClose = () => {
setOpen(false); 
};

const tablehandleClickOpen = () => {
settableOpen(true);
};     
const tablehandleClose = () => {
settableOpen(false); 
};
const AllAdstxthandleClickOpen = () => {
        setAllAdstxtOpen(true);
        };     
        const AllAdstxthandleClose = () => {
        setAllAdstxtOpen(false); 
        };
const classes = useStyles();
return (
        <div className={classes.root} >
        <GridContainer>
                <GridItem lg={2} md={2}></GridItem>
                <GridItem lg={8} md={8}>
                <a className={classes.dataoverlay} onClick={handleClickOpen}>
                <Card>
                <CardBody>
                <p className={classes.heading}>Latest Ads.txt</p>
                </CardBody>
                </Card>       
                </a> 
                <Dialog fullScreen open={open} onClose={handleClose} TransitionComponent={Transition} className={classes.rootslider}>
                <AppBar className={classes.CustomappBar}>
                <Toolbar>
                <IconButton edge="start" color="inherit" onClick={handleClose} aria-label="close" className={classes.CloseButton}>
                <LeftAorrow />
                </IconButton>
                <h4 className={classes.SliderTitle}>
                Latest Ads.txt
                </h4>
                 </Toolbar>
                </AppBar> 
                <GridContainer >
                <GridItem lg={3} md={3}></GridItem>
                <GridItem lg={6} md={6}>
                <a className={classes.dataoverlay} onClick={AllAdstxthandleClickOpen}>
                <Card>
                <CardBody>
                <p className={classes.heading}>All Ads.txt</p>
                </CardBody>
                </Card>       
                </a>  
                <Dialog fullScreen open={AllAdstxtOpen} onClose={AllAdstxthandleClose} TransitionComponent={Transition} className={classes.rootslider}>
                        <AppBar className={classes.CustomappBar}>
                        <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={AllAdstxthandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                        All Ads.txt
                        </h4>
                        </Toolbar>
                        </AppBar>
                                    
                       <GridContainer >
                           <GridItem lg={3} md={3} ></GridItem>  
                           <GridItem lg={6} md={6} ><Card className={classes.CustomCard}>
                        <CardBody>
                        <GridContainer>
                                 <GridItem lg={12} md={12}>
                                 <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10} 
                                   defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                                 />
                                 </GridItem>
                         </GridContainer>
                        </CardBody>
                        <CardHeader >
                        <div className={classes.FloatLeft} >
                        <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                        <span className={classes.ButtonLeftSpace}> <MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>        
                        </div>
                        <div className={classes.FloatRight} >
                        <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                        <span className={classes.ButtonLeftSpace}> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>        
                        </div>
                        </CardHeader>
                        </Card></GridItem>  
                        <GridItem lg={3} md={3} ></GridItem> 
                        </GridContainer>                            
                                           
                        </Dialog>
                        </GridItem>
                        <GridItem lg={3} md={3}></GridItem>
                        </GridContainer>
                        <GridContainer>
                        <GridItem lg={3} md={3}></GridItem>
                        <GridItem lg={6}>
                        <Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')} className={classes.Accordianinput}>
                        <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1bh-content"
                        id="panel5bh-header"
                        >
                        <GridContainer>
                        <GridItem lg={1} md={1}>
                        <Typography className={classes.secondaryHeading}>
                        1
                        </Typography>
                        </GridItem>
                        <GridItem lg={11} md={11}>
                        <Typography className={classes.secondaryHeading}>
                        Advertiser1 - Adx.txt
                        </Typography>
                        </GridItem>
                        </GridContainer>
                        </AccordionSummary>
                        <AccordionDetails className={classes.AccordionInsideinput}>
                        <Card className={classes.CustomCard}>
                        <CardBody>
                    <GridContainer>
                                 <GridItem lg={12} md={12}>
                                 <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10} 
                                   defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                                 />
                                 </GridItem>
                         </GridContainer>
                        </CardBody>
                        <CardHeader >
                        <div className={classes.FloatLeft} >
                        <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                        <span className={classes.ButtonLeftSpace}> <MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>        
                        </div>
                        <div className={classes.FloatRight} >
                        <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                        <span className={classes.ButtonLeftSpace}> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>        
                        </div>
                        </CardHeader>
                        </Card>
                        </AccordionDetails>
                        </Accordion>
                        <Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')} className={classes.Accordianinput}>
                        <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel2bh-content"
                        id="panel2bh-header"
                        >
                        <GridContainer>
                        <GridItem lg={1} md={1}>
                        <Typography className={classes.secondaryHeading}>
                        2
                        </Typography>
                        </GridItem>
                        <GridItem lg={11} md={11}>
                        <Typography className={classes.secondaryHeading}>
                        Advertiser2- Adx.txt
                        </Typography>
                        </GridItem>
                        </GridContainer>
                        </AccordionSummary>
                        <AccordionDetails className={classes.AccordionInsideinput}>
                        <Card className={classes.CustomCard}>
                        <CardBody>
                    <GridContainer>
                                 <GridItem lg={12} md={12}>
                                 <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10} 
                                   defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                                 />
                                 </GridItem>
                         </GridContainer>
                        </CardBody>
                        <CardHeader >
                        <div className={classes.FloatLeft} >
                        <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                        <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>        
                        </div>
                        <div className={classes.FloatRight} >
                        <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                         <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="secondary" >Cancel</MButton></span>        
                        </div>
                        </CardHeader>
                        </Card>
                        </AccordionDetails>
                        </Accordion>
                        <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')} className={classes.Accordianinput}>
                        <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="pane3bh-content"
                        id="panel3bh-header"
                        >
                        <GridContainer>
                        <GridItem lg={1} md={1}>
                        <Typography className={classes.secondaryHeading}>
                        3
                        </Typography>
                        </GridItem>
                        <GridItem lg={11} md={11}>
                        <Typography className={classes.secondaryHeading}>
                        Advertiser3 - Adx.txt
                        </Typography>
                        </GridItem>
                        </GridContainer>
                        </AccordionSummary>
                        <AccordionDetails className={classes.AccordionInsideinput}>
                        <Card className={classes.CustomCard}>
                        <CardBody>
                    <GridContainer>
                                 <GridItem lg={12} md={12}>
                                 <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10} 
                                   defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                                 />
                                 </GridItem>
                         </GridContainer>
                        </CardBody>
                        <CardHeader >
                        <div className={classes.FloatLeft} >
                        <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                        <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>        
                        </div>
                        <div className={classes.FloatRight} >
                        <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                         <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="secondary" >Cancel</MButton></span>        
                        </div>
                        </CardHeader>
                        </Card>
                        </AccordionDetails>
                        </Accordion>
                        <Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')} className={classes.Accordianinput}>
                        <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel4bh-content"
                        id="panel4bh-header"
                        >
                        <GridContainer>
                        <GridItem lg={1} md={1}>
                        <Typography className={classes.secondaryHeading}>
                        4
                        </Typography>
                        </GridItem>
                        <GridItem lg={11} md={11}>
                        <Typography className={classes.secondaryHeading}>
                        Advertiser4 - Adx.txt
                        </Typography>
                        </GridItem>
                        </GridContainer>
                        </AccordionSummary>
                        <AccordionDetails className={classes.AccordionInsideinput}>
                        <Card className={classes.CustomCard}>
                        <CardBody>
                    <GridContainer>
                                 <GridItem lg={12} md={12}>
                                 <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10} 
                                   defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                                 />
                                 </GridItem>
                         </GridContainer>
                        </CardBody>
                        <CardHeader >
                        <div className={classes.FloatLeft} >
                        <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                         <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>        
                        </div>
                        <div className={classes.FloatRight} >
                        <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                         <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="secondary" >Cancel</MButton></span>        
                        </div>
                        </CardHeader>
                        </Card>
                        </AccordionDetails>
                        </Accordion>
                        <Accordion expanded={expanded === 'panel5'} onChange={handleChange('panel5')} className={classes.Accordianinput}>
                        <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="pane5bh-content"
                        id="panel5bh-header"
                        >
                        <GridContainer>
                        <GridItem lg={1} md={1}>
                        <Typography className={classes.secondaryHeading}>
                        5
                        </Typography>
                        </GridItem>
                        <GridItem lg={11} md={11}>
                        <Typography className={classes.secondaryHeading}>
                        Advertiser5 - Adx.txt
                        </Typography>
                        </GridItem>
                        </GridContainer>
                        </AccordionSummary>
                        <AccordionDetails className={classes.AccordionInsideinput}>
                        <Card className={classes.CustomCard}>
                        <CardBody>
                    <GridContainer>
                                 <GridItem lg={12} md={12}>
                                 <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10} 
                                   defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                                 />
                                 </GridItem>
                         </GridContainer>
                        </CardBody>
                        <CardHeader >
                        <div className={classes.FloatLeft} >
                        <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                         <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>        
                        </div>
                        <div className={classes.FloatRight} >
                        <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                         <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="secondary" >Cancel</MButton></span>        
                        </div>
                        </CardHeader>
                        </Card>
                        </AccordionDetails>
                        </Accordion>
                        </GridItem>
                        <GridItem lg={3} md={3}></GridItem>
                        </GridContainer>                   
                        </Dialog>
                        </GridItem>
                        <GridItem lg={2} md={2}></GridItem>
                        </GridContainer>
                        <GridContainer>
                        <GridItem  lg={2} md={2}></GridItem>
                        <GridItem  lg={8} md={8}>
                        <Card>
                        <CardBody>
                        <ReactTable
                        data={data}
                        filterable
                        columns={[
                        {
                        Header: "Sl No",
                        accessor: "SlNo"
                        },
                        {
                        Header: "Status",
                        accessor: "Staus",
                        Cell: id => (
                        <div className={classes.ActionsButton}>
                        <Button 
                        justIcon
                        round
                        simple
                        color="success"
                        className="check"
                        >
                        <CheckIcon />
                        </Button>
                                                        
                        {" "}
                        <Button
                        justIcon
                        round
                        simple
                        color="danger"
                        className="uncheck"
                        >
                        <UncheckIcon />
                        </Button>
                                                        
                        </div>	
                        ),
                        sortable: false,
                        filterable: false
                        },
                        {
                        Header: "Domain Name",
                        accessor: "DomainName"
                        },
                                        
                        {
                        Header: "Actions",
                        accessor: "id",
                        Cell: id => (
                        <div className={classes.ActionsButton}>
                        <LightTooltip  title="View" aria-label="view"  placement="top">
                        <Button onClick={tablehandleClickOpen}
                        justIcon
                        round
                        simple
                        color="success"
                        className="view"
                >
                        <View />
                        </Button>
                        </LightTooltip>
                        <Dialog fullScreen open={tableOpen} onClose={tablehandleClose} TransitionComponent={Transition} className={classes.rootslider}>
                        <AppBar className={classes.CustomappBar}>
                        <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={tablehandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                        All Ads.txt
                        </h4>
                        </Toolbar>
                        </AppBar>
                                    
                       <GridContainer>
                           <GridItem lg={3} md={3} ></GridItem>  
                           <GridItem lg={6} md={6} ><Card className={classes.CustomCard}>
                        <CardBody>
                        <GridContainer>
                                 <GridItem lg={12} md={12}>
                                 <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10} 
                                   defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                                 /> 
                                 </GridItem>
                         </GridContainer>
                        </CardBody>
                        <CardHeader >
                        <div className={classes.FloatLeft} >
                        <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                         <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>        
                        </div>
                        <div className={classes.FloatRight} >
                        <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                         <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="secondary" >Cancel</MButton></span>        
                        </div>
                        </CardHeader>
                        </Card></GridItem>  
                        <GridItem lg={3} md={3} ></GridItem> 
                        </GridContainer> 
                                                        
                        </Dialog>
                        {" "}
                        <LightTooltip  title="View" aria-label="view"  placement="top">
                        <Button   onClick={tablehandleClickOpen}
                        justIcon
                        round
                        simple
                        color="danger"
                        className="view"
                        >
                        <ViewOff />
                        </Button>
                        </LightTooltip>
                        <Dialog fullScreen open={tableOpen} onClose={tablehandleClose} TransitionComponent={Transition} className={classes.rootslider}>
                        <AppBar className={classes.CustomappBar}>
                        <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={tablehandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                        All Ads.txt
                        </h4>
                        </Toolbar>
                        </AppBar>
                                    
                       <GridContainer >
                           <GridItem lg={3} md={3} ></GridItem>  
                           <GridItem lg={6} md={6} ><Card className={classes.CustomCard}>
                        <CardBody>
                        <GridContainer>
                                 <GridItem lg={12} md={12}>
                                 <TextareaAutosize className={classes.TextAreacustom} disabled="true" aria-label="minimum height" rowsMin={10} 
                                   defaultValue="
                                   google.com, pub-4586415728471297, RESELLER, f08c47fec0942fa0
                                   Adsolut.in, 15313, DIRECT
                                   Playstream.media, 444, DIRECT
                                   nativeads.com, 80793, RESELLER
                                   smartyads.com, 144, RESELLER
                                   somoaudience.com,7ec0502f670ef0899a5ae35e08b0ba0c,RESELLER
                                   mobileadtrading.com,7ec0502f670ef0899a5ae35e08b0ba0c,DIRECT
                                   Monetize.com, 1188, Reseller
                                   admanmedia.com, 5be58409, RESELLER
                                   "
                                 />
                                 </GridItem>
                         </GridContainer>
                        </CardBody>
                        <CardHeader >
                        <div className={classes.FloatLeft} >
                        <span><MButton variant="outlined" color="primary" >Copy text to clipboard</MButton></span>
                         <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="primary" >Download Ads.txt File</MButton></span>        
                        </div>
                        <div className={classes.FloatRight} >
                        <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
                        <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="secondary" >Cancel</MButton></span>        
                        </div>
                        </CardHeader>
                        </Card></GridItem>  
                        <GridItem lg={3} md={3} ></GridItem> 
                        </GridContainer> 
                                                        
                        </Dialog>
                        </div>
                        ),
                        sortable: false,
                        filterable: false
                        }
                        ]}
                        defaultPageSize={5}
                        showPaginationTop
                        showPaginationBottom={false}
                        className="-striped -highlight"
                        />                                                 
                        </CardBody>
                        </Card>
                        </GridItem>
                        <GridItem  lg={2} md={2}></GridItem>
                 </GridContainer> 
     </div> 

  );
  
}
