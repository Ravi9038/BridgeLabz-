import React, { Component } from 'react'
import { makeStyles } from "@material-ui/core/styles";
import Download from "../Reports/DownloadReport.js";
// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import axios from 'axios';
import { addDays } from 'date-fns'
import { DateRangePicker } from 'react-date-range';

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Datetime from "react-datetime";
import Table from "components/Table/Table.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import { SERVER_URL } from "../../variables/constants";
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "components/CustomButtons/Button.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import customCheckboxRadioSwitch from "assets/jss/material-dashboard-pro-react/customCheckboxRadioSwitch.js";
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file
import DateSelectionDropDown from "../Widgets/DateSelectionDropdown.js";
import Input from '@material-ui/core/Input';
import * as moment from 'moment';
import Globe from "@material-ui/icons/Language";
import Paper from "@material-ui/core/Paper";
import ReactTable from "react-table";
import TextField from '@material-ui/core/TextField';
import ListItemText from '@material-ui/core/ListItemText';
import FormHelperText from '@material-ui/core/FormHelperText';
import Checkbox from '@material-ui/core/Checkbox';
import Chip from '@material-ui/core/Chip';
import Autocomplete from '@material-ui/lab/Autocomplete';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
const dataTable = {
    dataRows: []
};
const styles = {
    ...customSelectStyle,
    ...customCheckboxRadioSwitch,
    customCardContentClass: {
        paddingLeft: "0",
        paddingRight: "0"
    },
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    },
    SelectCustom: {
        '& .MuiSelect-select': {
            border: "1px solid #999"
        },
        '& .MuiInputBase-input': {
            paddingLeft: "10px",
            borderRadius: "5px!important",

        },
        '&.MuiSelect-outlined.MuiSelect-outlined': {
            paddingRight: "32px",
            width: "618px"
        }

    },
    SelectItem: {
        marginTop: "10px"
    },
    adUnits: {
        '& .MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"] ': {
            padding: '0px'
        },
        '& .MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"] .MuiAutocomplete-input': {
            padding: "8px"
        },
        '& .MuiInputLabel-outlined': {
            zIndex: '1',
            transform: 'translate(14px, 9px) scale(1)',
            pointerEvents: 'none'
        },
        '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
            transform: 'translate(14px, -6px) scale(0.85)'
        },
        '& .MuiChip-root': {
            display: 'none'
        }

    },
    SelectedWebLi: {
        padding: "5px",
        listStyle: "none"
    },
    '&.MuiSelect-outlined.MuiSelect-outlined': {
        paddingRight: "32px",
        width: "500px"
    },
    select: {
        padding: "10px"
    },
    labels: {
        display: "none"
    }

};
function filterCaseInsensitive(filter, row) {

    const id = filter.pivotId || filter.id;
    if (row[id] !== null) {
        return (
            row[id] !== undefined ?
                String(row[id].toString().toLowerCase())
                    .includes(filter.value.toString().toLowerCase())
                :
                true
        );
    }
}
const useStyles = makeStyles(styles);
export class Reports extends Component {
    state = {
        groupsBy: '',
        IdWeb: [],
        IdAdvertisers: [],
        todaysDate: new moment().utcOffset('GMT-00:00').format("YYYY-MM-DD"),
        websiteHeaders: ["Name", "Url", "Http Enabled", "Https Enabled", "Edit"],
        websiteData: [],
        advertiserData: [],
        selectedWebsites: [],
        websiteRevenueHeaders: ["Name", "URL", "Impression", "CPM", "Amount", "Date"],
        websiteRevenueData: [],
        simpleSelect: [],
        selectedWebsiteIds: [],
        selectedAdvertiserIds: [],
        selectedDuration: "",
        isAllWebsiteSelected: true,
        isAllAdveriserSelected: true,
        isReportDataVisible: false,
        dateRange: {
            startDate: new Date(),
            endDate: addDays(new Date(), 7),
            key: 'selection'
        },
        Dimention: [
            "Website",
            "Advertiser",
            "Date"
        ],
        selectedDimention: [],
        exclude: [
            "Include",
            "Exclude"
        ],
        selectedExclude: [],
        tag: [
            "Websites",

        ],
        tagAdvertiser: [
            "Advertiser",
        ],
        stringWebsiteId: '',
        stringAdvertiserIds: '',
        groupsBy: '',
        selectedTag: [],
        selectedAdvertiserTag: [],
        selectedExclude1: [],
        view: false,
        sendingStartDate: '',
        sendingEndDate: '',
        data: dataTable.dataRows.map((prop, key) => {
            return {
                id: key,
                Sites: prop[0],
                Date: prop[1],
                Revenue: prop[2],
                Impression: prop[3],
                eCPM: prop[4]
            };
        }),
        totalPubRevenue: 0.0,
        totalErgRevenue: 0.0,
        totalImpressions: 0,
        totaleCpm: 0.0,
    }

    handleSimple = event => {
        this.setState({ 'simpleSelect': event.target.value });
    }
    // selectWebsite = (event, id) => {
    //     this.setState(prevState => ({
    //         IdWeb: [...prevState.IdWeb, id]
    //     }))
    //     let isAllWebsiteSelected = false;

    //     if (isAllWebsiteSelected) {
    //         this.setState({ 'selectedWebsiteIds': [-1], isAllWebsiteSelected: true });
    //     } else {
    //         this.setState({ 'selectedWebsiteIds': event.target.value, isAllWebsiteSelected: false });
    //     }
    // }
    selectWebsite = (id, website) => {
        console.log(id)
        console.log(website)

        this.setState(prevState => ({
            IdWeb: [...prevState.IdWeb, id]
        }))
        let isAllWebsiteSelected = false;
        if (isAllWebsiteSelected) {
            this.setState({ 'selectedWebsiteIds': [-1], isAllWebsiteSelected: true });
        } else {
            //  this.setState({ selectedWebsiteIds: website, isAllWebsiteSelected: false });
            this.setState(prevState => ({
                selectedWebsiteIds: [...prevState.selectedWebsiteIds, website]
            }))
            this.setState({ isAllWebsiteSelected: false });

        }
        console.log(this.state.selectedWebsiteIds);
    }

    handleDelete = (i) => {
        console.log(1)
        const { selectedWebsiteIds } = this.state;
        this.setState({
            selectedWebsiteIds: selectedWebsiteIds.filter((file, index) => index !== i),
        });
        const { IdWeb } = this.state;
        this.setState({
            IdWeb: IdWeb.filter((file, index) => index !== i),
        });
    }
    handleDeleteForWebsites = (i) => {
        console.log(1)
        const { selectedAdvertiserIds } = this.state;
        this.setState({
            selectedAdvertiserIds: selectedAdvertiserIds.filter((file, index) => index !== i),
        });
        const { IdAdvertisers } = this.state;
        this.setState({
            IdAdvertisers: IdAdvertisers.filter((file, index) => index !== i),
        });
    }
    selectAdvertiser = (advertiser, id) => {
        console.log(id)
        this.setState(prevState => ({
            IdAdvertisers: [...prevState.IdAdvertisers, id]
        }))
        let isAllAdveriserSelected = false;

        if (isAllAdveriserSelected) {
            this.setState({ 'selectedAdvertiserIds': [-1], isAllAdveriserSelected: true });
        } else {
            // this.setState({ 'selectedAdvertiserIds': event.target.value, isAllAdveriserSelected: false });
            this.setState(prevState => ({
                selectedAdvertiserIds: [...prevState.selectedAdvertiserIds, advertiser]
            }))
            this.setState({ isAllAdveriserSelected: false });
        }
    }

    componentDidMount() {
        const USER_ID = this.props.data.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';


        axios.get(`${SERVER_URL}/api/userwebsite/`, { headers: { "Authorization": TOKEN } })
            .then(res => {
                let lWebsiteData = [];
                res.data.forEach(item => {
                    let lWebsite = [];
                    lWebsite.push(item.name);
                    lWebsite.push(item.hostURL);
                    item.httpEnabled ? lWebsite.push("Yes") : lWebsite.push("No");
                    item.httpsEnabled ? lWebsite.push("Yes") : lWebsite.push("No");
                    lWebsite.push(item.id);
                    lWebsiteData.push(lWebsite);

                });
                this.setState({ websiteData: lWebsiteData });
                console.log(this.state.websiteData)
            }).catch(function (error) {
                console.log(error);
            });
        this.renderWebsiteWiseData(this.state.todaysDate, this.state.todaysDate);

        axios.get(`${SERVER_URL}/api/users/advertisers`, { headers: { "Authorization": TOKEN } })
            .then(res => {
                console.log(res.data);
                let advertiser = [];
                res.data.forEach(item => {
                    let lAdvertiser = [];
                    lAdvertiser.push(item.companyName);
                    lAdvertiser.push(item.id);
                    advertiser.push(lAdvertiser)
                })
                this.setState({ advertiserData: advertiser });
                console.log(this.state.advertiserData)
            }).catch(function (error) {
                console.log(error);
            });
    }

    renderWebsiteWiseData = (pStartDate, pEndDate) => {
        console.log(pStartDate);
        console.log(pEndDate);
        this.setState({ sendingStartDate: pStartDate })
        this.setState({ sendingEndDate: pEndDate })



    }

    viewReports = () => {
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        this.setState({ view: true })
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        var requestData = {};
        let strWebsiteIds = "";
        let strAdvertiserIds = "";
        /*  if (this.state.isAllWebsiteSelected) {
             for (var index = 0; index < this.state.websiteData.length; index++) {
                 var lWebsiteRecord = this.state.websiteData[index];
                 strWebsiteIds = strWebsiteIds + lWebsiteRecord[4];
                 if (index + 1 != this.state.IdWeb.length)
                     strWebsiteIds = strWebsiteIds + ",";
             }
         } */

        if (!this.state.isAllWebsiteSelected) {
            if (this.state.selectedExclude.includes("Include")) {
                for (var index = 0; index < this.state.IdWeb.length; index++) {
                    strWebsiteIds = strWebsiteIds + this.state.IdWeb[index];
                    if (index + 1 != this.state.IdWeb.length)
                        strWebsiteIds = strWebsiteIds + ",";
                }
            }
            else if (this.state.selectedExclude.includes("Exclude")) {
                var selectedId = this.state.IdWeb;
                var websiteId = [];
                for (var index = 0; index < this.state.websiteData.length; index++) {
                    var lWebsiteRecord = this.state.websiteData[index];
                    websiteId.push(lWebsiteRecord[4]);

                }
                var array3 = websiteId.filter(entry1 => !selectedId.some(entry2 => entry1 === entry2));
                for (var i = 0; i < array3.length; i++) {
                    strWebsiteIds = strWebsiteIds + array3[i];
                    if (index + 1 != this.state.IdWeb.length)
                        strWebsiteIds = strWebsiteIds + ",";
                }
            }
        }

        /*  if (this.state.isAllAdveriserSelected) {
             for (var index = 0; index < this.state.advertiserData.length; index++) {
                 var lWebsiteRecord = this.state.advertiserData[index];
                 strAdvertiserIds = strAdvertiserIds + lWebsiteRecord[1];
                 if (index + 1 != this.state.IdWeb.length)
                     strAdvertiserIds = strAdvertiserIds + ",";
             }
         } */
        if (!this.state.isAllAdveriserSelected) {
            if (this.state.selectedExclude1.includes("Include")) {
                for (var index = 0; index < this.state.IdAdvertisers.length; index++) {
                    strAdvertiserIds = strAdvertiserIds + this.state.IdAdvertisers[index];
                    if (index + 1 != this.state.IdAdvertisers.length)
                        strAdvertiserIds = strAdvertiserIds + ",";
                }
            }
            else if (this.state.selectedExclude1.includes("Exclude")) {
                var selectedId = this.state.IdAdvertisers;
                var websiteId = [];
                for (var index = 0; index < this.state.advertiserData.length; index++) {
                    var lWebsiteRecord = this.state.advertiserData[index];
                    websiteId.push(lWebsiteRecord[1]);

                }
                var array3 = websiteId.filter(entry1 => !selectedId.some(entry2 => entry1 === entry2));
                for (var i = 0; i < array3.length; i++) {
                    strAdvertiserIds = strAdvertiserIds + array3[i];
                    if (index + 1 != this.state.IdAdvertisers.length)
                        strAdvertiserIds = strAdvertiserIds + ",";
                }
            }

        }
        var lgroupBy = '';
        if (this.state.selectedDimention.length === 3) {
            console.log(123);
            lgroupBy = "host_url,Date,id_advertiser";
            this.setState({ groupsBy: lgroupBy });

        }
        else if (this.state.selectedDimention.length === 2) {
            if (!this.state.selectedDimention.includes("Website")) {
                lgroupBy = "Date,id_advertiser";
                this.setState({ groupsBy: lgroupBy });

            }
            else if (!this.state.selectedDimention.includes("Advertiser")) {
                lgroupBy = "host_url,Date";
                this.setState({ groupsBy: lgroupBy });

            }
            else if (!this.state.selectedDimention.includes("Date")) {
                lgroupBy = "host_url,id_advertiser";
                this.setState({ groupsBy: lgroupBy });

            }

        }
        else {
            if (this.state.selectedDimention.includes("Website")) {
                lgroupBy = "host_url";
                this.setState({ groupsBy: lgroupBy });

            }
            else if (this.state.selectedDimention.includes("Advertiser")) {
                lgroupBy = "id_advertiser";
                this.setState({ groupsBy: lgroupBy });

            }
            else if (this.state.selectedDimention.includes("Date")) {
                lgroupBy = "Date";
                this.setState({ groupsBy: lgroupBy });

            }
        }


        console.log(this.state.groupsBy);
        requestData.start_date = this.state.sendingStartDate;
        requestData.end_date = this.state.sendingEndDate;
        requestData.website_ids = strWebsiteIds;
        requestData.advertiser_ids = strAdvertiserIds;
        requestData.groupBy = lgroupBy;
        console.log(requestData)
        axios.post(`${SERVER_URL}/api/website/revenue/`, requestData, { headers: { "Authorization": TOKEN } })
            .then(res => {
                this.setState({ websiteRevenueData: res.data, isReportDataVisible: true });
                console.log(this.state.websiteRevenueData);
                let lTotalImpressions = 0;
                let lTotalRevenue = 0;
                let lTotalPubRevenue = 0;
                let lTotalErgRevenue = 0;
                let lData = res.data.map((prop, key) => {
                    var lPubRevenue = Number(prop.pubRevenue);
                    var lErgRevenue = Number(prop.ergRevenue);
                    var lRevenue = lPubRevenue + lErgRevenue;
                    var lImpressions = Number(prop.Impressions);
                    lTotalImpressions = lTotalImpressions + lImpressions;
                    lTotalPubRevenue = lTotalPubRevenue + lPubRevenue;
                    lTotalErgRevenue = lTotalErgRevenue + lErgRevenue;
                    lTotalRevenue = lTotalRevenue + lRevenue;
                    var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
                    return {
                        id: key,
                        Sites: prop.website,
                        Date: prop.Date,
                        PubRevenue: prop.pubRevenue,
                        ErgRevenue: prop.ergRevenue,
                        eCPM: eCpm
                    };
                })
                let lTotalECpm = (lTotalRevenue / (lTotalImpressions / 1000)).toFixed(2);
                this.setState({

                    totalImpressions: lTotalImpressions,
                    totalPubRevenue: lTotalPubRevenue.toFixed(2),
                    totalErgRevenue: lTotalErgRevenue.toFixed(2),
                    totaleCpm: lTotalECpm
                });

                console.log(this.state.totalImpressions)
                console.log(this.state.totalPubRevenue)
                console.log(this.state.totalErgRevenue)
                console.log(this.state.totaleCpm)
            }).catch(function (error) {
                console.log(error);
            });
    }

    downloadReport = () => {
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        var requestData = {};
        let strWebsiteIds = "";
        let strAdvertiserIds = "";
        /*     if (this.state.isAllWebsiteSelected) {
                for (var index = 0; index < this.state.websiteData.length; ++index) {
                    var lWebsiteRecord = this.state.websiteData[index];
                    strWebsiteIds = strWebsiteIds + lWebsiteRecord[4];
                    if (index + 1 != this.state.IdWeb.length)
                        strWebsiteIds = strWebsiteIds + ",";
                }
            } */

        if (!this.state.isAllWebsiteSelected) {
            if (this.state.selectedExclude.includes("Include")) {
                for (var index = 0; index < this.state.IdWeb.length; ++index) {
                    strWebsiteIds = strWebsiteIds + this.state.IdWeb[index];
                    if (index + 1 != this.state.IdWeb.length)
                        strWebsiteIds = strWebsiteIds + ",";
                }
            }
            else if (this.state.selectedExclude.includes("Exclude")) {
                var selectedId = this.state.IdWeb;
                var websiteId = [];
                for (var index = 0; index < this.state.websiteData.length; ++index) {
                    var lWebsiteRecord = this.state.websiteData[index];
                    websiteId.push(lWebsiteRecord[4]);

                }
                var array3 = websiteId.filter(entry1 => !selectedId.some(entry2 => entry1 === entry2));
                for (var i = 0; i < array3.length; i++) {
                    strWebsiteIds = strWebsiteIds + array3[i];
                    if (index + 1 != this.state.IdWeb.length)
                        strWebsiteIds = strWebsiteIds + ",";
                }
            }
        }

        /*   if (this.state.isAllAdveriserSelected) {
              for (var index = 0; index < this.state.advertiserData.length; ++index) {
                  var lWebsiteRecord = this.state.advertiserData[index];
                  strAdvertiserIds = strAdvertiserIds + lWebsiteRecord[1];
                  if (index + 1 != this.state.IdWeb.length)
                      strAdvertiserIds = strAdvertiserIds + ",";
              }
          } */
        if (!this.state.isAllAdveriserSelected) {
            if (this.state.selectedExclude1.includes("Include")) {
                for (var index = 0; index < this.state.IdAdvertisers.length; ++index) {
                    strAdvertiserIds = strAdvertiserIds + this.state.IdAdvertisers[index];
                    if (index + 1 != this.state.IdAdvertisers.length)
                        strAdvertiserIds = strAdvertiserIds + ",";
                }
            }
            else if (this.state.selectedExclude1.includes("Exclude")) {
                var selectedId = this.state.IdAdvertisers;
                var websiteId = [];
                for (var index = 0; index < this.state.advertiserData.length; ++index) {
                    var lWebsiteRecord = this.state.advertiserData[index];
                    websiteId.push(lWebsiteRecord[1]);

                }
                var array3 = websiteId.filter(entry1 => !selectedId.some(entry2 => entry1 === entry2));
                for (var i = 0; i < array3.length; i++) {
                    strAdvertiserIds = strAdvertiserIds + array3[i];
                    if (index + 1 != this.state.IdAdvertisers.length)
                        strAdvertiserIds = strAdvertiserIds + ",";
                }
            }

        }
        var lgroupBy = '';
        if (this.state.selectedDimention.length === 3) {
            console.log(123);
            lgroupBy = "host_url,Date,id_advertiser";
            this.setState({ groupsBy: lgroupBy });

        }
        else if (this.state.selectedDimention.length === 2) {
            if (!this.state.selectedDimention.includes("Website")) {
                lgroupBy = "Date,id_advertiser";
                this.setState({ groupsBy: lgroupBy });

            }
            else if (!this.state.selectedDimention.includes("Advertiser")) {
                lgroupBy = "host_url,Date";
                this.setState({ groupsBy: lgroupBy });

            }
            else if (!this.state.selectedDimention.includes("Date")) {
                lgroupBy = "host_url,id_advertiser";
                this.setState({ groupsBy: lgroupBy });

            }

        }
        else {
            if (this.state.selectedDimention.includes("Website")) {
                lgroupBy = "host_url";
                this.setState({ groupsBy: lgroupBy });

            }
            else if (this.state.selectedDimention.includes("Advertiser")) {
                lgroupBy = "id_advertiser";
                this.setState({ groupsBy: lgroupBy });

            }
            else if (this.state.selectedDimention.includes("Date")) {
                lgroupBy = "Date";
                this.setState({ groupsBy: lgroupBy });

            }
        }


        console.log(this.state.groupsBy);
        requestData.start_date = this.state.sendingStartDate;
        requestData.end_date = this.state.sendingEndDate;
        requestData.website_ids = strWebsiteIds;
        requestData.advertiser_ids = strAdvertiserIds;
        requestData.groupBy = lgroupBy;
        console.log(requestData)
        // axios.post(`${SERVER_URL}/api/website/revenue/download`, requestData, { headers: { "Authorization": TOKEN, responseType: 'blob' } })
        //     .then(response => {
        //         let fileName = "report.xlsx";
        //         if (window.navigator && window.navigator.msSaveOrOpenBlob) { // IE variant
        //             window.navigator.msSaveOrOpenBlob(new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
        //                 fileName);
        //         } else {
        //             const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
        //             const link = document.createElement('a');
        //             link.href = url;
        //             link.setAttribute('download', fileName);
        //             document.body.appendChild(link);
        //             link.click();
        //         }
        //     }).catch(function (error) {
        //         console.log(error);
        //     });


        /* const xslxurl = `${SERVER_URL}/api/website/revenue/download`;
         axios.post(xslxurl, null,
             {
                 headers:
                 {
                     "Authorization": TOKEN,
                   
                 },
                 responseType: 'arraybuffer',
             }
         ).then((response) => {
             const url = window.URL.createObjectURL(new Blob([response.data]));
             const link = document.createElement('a');
             link.href = url;
             link.setAttribute('download', 'template.xlsx');
             document.body.appendChild(link);
             link.click();
         })
             .catch((error) => console.log(error)); */

        axios({
            url: `${SERVER_URL}/api/website/revenue/download`,
            method: 'POST',
            data: requestData,
            responseType: 'blob', // important
        }).then((response) => {
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'Report.xlsx');
            document.body.appendChild(link);
            link.click();
        });
    }

    handleChange = (event) => {
        this.setState({ selectedDimention: event.target.value });

    }
    handleChangeForExport = (event) => {
        this.setState({ selectedExclude: event.target.value });

    }
    handleChangeForExport1 = (event) => {
        this.setState({ selectedExclude1: event.target.value });

    }
    handleChangeForWebsite = (event) => {
        this.setState({ selectedTag: event.target.value });

    }
    handleChangeForAdvertiser = (event) => {
        console.log(event.target.value)
        this.setState({ selectedAdvertiserTag: event.target.value });

    }
    handleChangeWebsite = (event) => {
        this.setState({ selectedWebsites: event.target.value });

    }
    handleWebsiteDropDownChange = (pStartDate, pEndDate) => {
        this.renderWebsiteWiseData(pStartDate, pEndDate);
    }


    renderTable = () => {
        const classes = this.props.classes;
        return <GridContainer>
            <GridItem xs={ 12 } sm={ 12 } lg={ 12 } md={ 12 } >
                <Card>
                    <CardHeader color="primary" icon>
                        <CardIcon color="primary">
                            <Globe style={ { color: "white" } } />
                        </CardIcon>
                    </CardHeader>
                    <CardBody>
                        <ReactTable
                            data={ this.state.websiteRevenueData }

                            filterable
                            columns={ [

                                {
                                    Header: "Sites",
                                    accessor: "website",
                                    show: this.state.groupsBy.includes("host_url") ? true : false,
                                    Filter: ({ filter, onChange }) => (
                                        <input type='text' style={ { textAlign: 'center' } }
                                            placeholder="Search Sites"
                                            value={ filter ? filter.value : '' }
                                            onChange={ event => onChange(event.target.value) }
                                        />
                                    ),
                                    Footer: (
                                        <span><strong>Total</strong></span>
                                    )



                                },
                                {
                                    Header: "Advertiser",
                                    accessor: "id_advertiser",
                                    show: this.state.groupsBy.includes("id_advertiser") ? true : false,
                                    Filter: ({ filter, onChange }) => (
                                        <input type='text' style={ { textAlign: 'center' } }
                                            placeholder="Search Sites"
                                            value={ filter ? filter.value : '' }
                                            onChange={ event => onChange(event.target.value) }
                                        />
                                    ),
                                    Footer: (
                                        <span><strong></strong></span>
                                    )



                                },
                                {
                                    Header: "Date",
                                    accessor: "Date",
                                    show: this.state.groupsBy.includes("Date") ? true : false,
                                    Filter: ({ filter, onChange }) => (
                                        <input type='text' style={ { textAlign: 'center' } }
                                            placeholder="Search Date"
                                            value={ filter ? filter.value : '' }
                                            onChange={ event => onChange(event.target.value) }
                                        />
                                    ),
                                    Footer: (
                                        <span><strong></strong></span>
                                    )


                                },
                                {
                                    Header: "Pub Revenue",
                                    accessor: "pubRevenue",
                                    Filter: ({ filter, onChange }) => (
                                        <input type='text' style={ { textAlign: 'center' } }
                                            placeholder="Search Revenue"
                                            value={ filter ? filter.value : '' }
                                            onChange={ event => onChange(event.target.value) }
                                        />
                                    ),

                                    Footer: (
                                        <span><strong>${ this.state.totalPubRevenue }</strong></span>
                                    )

                                },
                                {
                                    Header: "Erg Revenue",
                                    accessor: "ergRevenue",
                                    Filter: ({ filter, onChange }) => (
                                        <input type='text' style={ { textAlign: 'center' } }
                                            placeholder="Search Revenue"
                                            value={ filter ? filter.value : '' }
                                            onChange={ event => onChange(event.target.value) }
                                        />
                                    ),

                                    Footer: (
                                        <span><strong>${ this.state.totalErgRevenue }</strong></span>
                                    )

                                },
                                // {
                                //     Header: "Total Revenue",
                                //     accessor: "ergRevenue",
                                //     Filter: ({ filter, onChange }) => (
                                //         <input type='text' style={{ textAlign: 'center' }}
                                //             placeholder="Search Revenue"
                                //             value={filter ? filter.value : ''}
                                //             onChange={event => onChange(event.target.value)}
                                //         />
                                //     ),
                                //   Cell:row=>(
                                //       <div>{(parseFloat(row.original.pubRevenue)+parseFloat(row.original.ergRevenue)).toFixed(2)}</div>
                                //   ),
                                //     Footer: (
                                //         <span><strong></strong></span>
                                //     )

                                // },
                                {
                                    Header: "Impression",
                                    accessor: "Impressions",
                                    Filter: ({ filter, onChange }) => (
                                        <input type='text' style={ { textAlign: 'center' } }
                                            placeholder="Search Impression"
                                            value={ filter ? filter.value : '' }
                                            onChange={ event => onChange(event.target.value) }
                                        />
                                    ),

                                    Footer: (
                                        <span><strong>{ this.state.totalImpressions }</strong></span>
                                    )
                                },
                                {
                                    Header: "eCPM",
                                    accessor: "ecpm",
                                    Filter: ({ filter, onChange }) => (
                                        <input type='text' style={ { textAlign: 'center' } }
                                            placeholder="Search eCPM"
                                            value={ filter ? filter.value : '' }
                                            onChange={ event => onChange(event.target.value) }
                                        />
                                    ),
                                    Cell: row => (
                                        <div>{ (((parseFloat(row.original.pubRevenue) + parseFloat(row.original.ergRevenue)) / ((parseInt(row.original.Impressions)) / 1000))).toFixed(2) }</div>
                                    ),
                                    Footer: (
                                        <span><strong>${ this.state.totaleCpm }</strong></span>
                                    )

                                }
                            ] }
                            defaultPageSize={ 5 }
                            minRows={ 1 }
                            defaultFilterMethod={ filterCaseInsensitive }
                            showPaginationTop
                            showPaginationBottom={ false }
                            className="-highlight"
                        />
                    </CardBody>

                </Card>
            </GridItem>
        </GridContainer>

    }
    render() {


        const classes = this.props.classes;
        return (
            <div>
                <GridContainer>
                    <GridItem xs={ 12 } >
                        <Card>
                            <CardHeader color="rose" icon>
                                {/* <CardIcon color="rose">
                                <Assignment />
                            </CardIcon> */}
                                <h4 className={ classes.cardIconTitle }>Report Content</h4>
                            </CardHeader>

                            <CardBody style={ { borderTop: "1px solid #999" } }>
                                <GridContainer className={ classes.SelectCustom }>
                                    <GridItem xs={ 12 } sm={ 12 } lg={ 4 } md={ 4 } align="right">
                                        <h5>Dimensions</h5>
                                    </GridItem>
                                    <GridItem xs={ 12 } sm={ 12 } lg={ 8 } md={ 8 }>
                                        <FormControl className={ classes.formControl } fullWidth>
                                            <Select
                                                labelId="demo-mutiple-checkbox-label"
                                                id="demo-mutiple-checkbox"
                                                multiple
                                                value={ this.state.selectedDimention }
                                                onChange={ this.handleChange }
                                                input={ <Input /> }
                                                renderValue={ (selected) => selected.join(', ') }

                                            >
                                                { this.state.Dimention.map((name) => (
                                                    <MenuItem key={ name } value={ name }>
                                                        <Checkbox checked={ this.state.selectedDimention.indexOf(name) > -1 } />
                                                        <ListItemText primary={ name } />
                                                    </MenuItem>
                                                )) }
                                            </Select>
                                        </FormControl>
                                    </GridItem>

                                </GridContainer>


                                {/* <GridContainer className={classes.SelectCustom}>
                                <GridItem xs={12} sm={12} lg={3} md={3} align="right">
                                    <h5>Matrics</h5>
                                </GridItem>
                                <GridItem xs={12} sm={12} lg={9} md={9}>
                                    <FormControl className={classes.formControl} fullWidth>
                                        <Select
                                            labelId="demo-mutiple-checkbox-label"
                                            id="demo-mutiple-checkbox"
                                            multiple
                                            value={this.state.selectedDimention}
                                            onChange={this.handleChange}
                                            input={<Input />}
                                            renderValue={(selected) => selected.join(', ')}
                                            
                                        >
                                            {this.state.Dimention.map((name) => (
                                                <MenuItem key={name} value={name}>
                                                    <Checkbox  />
                                                    <ListItemText primary={name} /> 
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </GridItem>

                            </GridContainer>
                         */}

                                <GridContainer className={ classes.SelectCustom }>
                                    <GridItem xs={ 12 } sm={ 12 } lg={ 4 } md={ 4 } align="right">
                                        <h5>Date Range</h5>
                                    </GridItem>
                                    <GridItem xs={ 12 } sm={ 12 } lg={ 8 } md={ 8 }  >

                                        <DateSelectionDropDown id="websiteDropDown" customStyle={ { width: "660px" } } onDropDownChange={ this.handleWebsiteDropDownChange }
                                            classes={ {
                                                select: classes.select
                                            } }
                                        />

                                    </GridItem>

                                </GridContainer>


                            </CardBody>
                            <CardHeader color="rose" icon>
                                <h4 className={ classes.cardIconTitle }>Filter</h4>
                            </CardHeader>
                            <CardBody style={ { borderTop: "1px solid #999" } }>
                                <GridContainer className={ classes.SelectCustom } >
                                    <GridItem xs={ 1 } sm={ 12 } lg={ 2 } md={ 2 } align="right">
                                        <h5>Websites</h5>
                                    </GridItem>
                                    <GridItem xs={ 2 } sm={ 12 } lg={ 2 } md={ 2 } align="right">
                                        <FormControl className={ classes.formControl } fullWidth>

                                            <Select
                                                labelId="demo-mutiple-checkbox-label"
                                                id="demo-mutiple-checkbox"

                                                value={ this.state.selectedExclude }
                                                onChange={ this.handleChangeForExport }
                                            >
                                                { this.state.exclude.map((name) => (
                                                    <MenuItem key={ name } value={ name }>
                                                        { name }
                                                    </MenuItem>
                                                )) }
                                            </Select>
                                        </FormControl>
                                    </GridItem>

                                    {/*  <GridItem xs={12} sm={12} lg={2} md={2}>
                                        <FormControl className={classes.formControl} fullWidth>
                                            <Select
                                                labelId="demo-mutiple-checkbox-label"
                                                id="demo-mutiple-checkbox"

                                                value={this.state.selectedTag}
                                                onChange={this.handleChangeForWebsite}
                                            >
                                                {this.state.tag.map((name) => (
                                                    <MenuItem key={name} value={name}>
                                                        {name}
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>
                                    </GridItem>
                                     */}
                                    <GridItem lg={ 4 } md={ 4 } className={ classes.textfieldsgrid }>

                                        <FormControl variant="outlined" className={ classes.formControl } fullWidth>
                                            {/* <InputLabel htmlFor="outlined-age-native-simple">Ad Unit</InputLabel> */ }
                                            <Autocomplete
                                                multiple
                                                id="checkboxes-tags-demo"
                                                className={ classes.adUnits }
                                                options={ this.state.websiteData }
                                                disableCloseOnSelect
                                                getOptionLabel={ (option) => option[1] }
                                                renderOption={ (option, { selected }) => (
                                                    <React.Fragment>
                                                        <Checkbox
                                                            icon={ icon }

                                                            checkedIcon={ checkedIcon }
                                                            style={ { marginRight: 8 } }
                                                            // checked={selected}
                                                            checked={ this.state.selectedWebsiteIds.includes(option[1]) }
                                                            onClick={ () => this.selectWebsite(option[4], option[1]) }
                                                        />
                                                        { option[1] }
                                                    </React.Fragment>
                                                ) }

                                                renderInput={ (params, i) => (
                                                    <TextField { ...params } variant="outlined" label="Websites" />

                                                ) }
                                            />

                                        </FormControl>

                                    </GridItem>

                                    <GridItem lg={ 4 } md={ 4 } className={ classes.textfieldsgrid + " " + classes.selectedItem } >
                                        <InputLabel htmlFor="outlined-age-native-simple">Selected Websites</InputLabel>
                                        <Paper component="ul" >
                                            { this.state.selectedWebsiteIds.length > 0 && this.state.selectedWebsiteIds.map((data, i) => {
                                                let icon = "";
                                                return (
                                                    <li className={ classes.SelectedWebLi }>
                                                        <Chip
                                                            icon={ icon }
                                                            variant="outline"
                                                            color="primary"
                                                            onDelete={ () => this.handleDelete(i) }
                                                            label={ data }
                                                            className="m-1"
                                                        />
                                                    </li>
                                                );
                                            }) }

                                        </Paper>

                                    </GridItem>

                                    {/* <GridItem xs={12} sm={12} lg={8} md={8}>
                                        <FormControl fullWidth>
                                            <Select
                                                multiple
                                                value={this.state.selectedWebsiteIds}
                                                onChange={(event, child) => this.selectWebsite(event, child.props.id)}
                                                MenuProps={{ className: classes.selectMenu }}
                                                labelId="demo-mutiple-chip-label"
                                                id="demo-mutiple-chip"
                                                input={<Input id="select-multiple-chip" />}
                                                renderValue={(selected) => (
                                                    <div className={classes.chips}>
                                                        {selected.map((value) => (
                                                            <Chip key={value} label={value} className={classes.chip} />
                                                        ))}
                                                    </div>
                                                )}
                                            >

                                                {this.state.websiteData.map((lWebsite) => {
                                                    return (<MenuItem key={lWebsite} id={lWebsite[4]}

                                                        value={lWebsite[1]}
                                                    >
                                                        <Checkbox checked={this.state.selectedWebsiteIds.indexOf(lWebsite[1]) > -1} />
                                                        {lWebsite[1]}
                                                    </MenuItem>)
                                                })}

                                            </Select>
                                        </FormControl>
                                    </GridItem> */}

                                </GridContainer>

                                <GridContainer className={ classes.SelectCustom } >
                                    <GridItem xs={ 12 } sm={ 12 } lg={ 2 } md={ 2 } align="right">
                                        <h5>Advertiser</h5>
                                    </GridItem>
                                    <GridItem xs={ 12 } sm={ 12 } lg={ 2 } md={ 2 } align="right" className={ classes.SelectItem }>
                                        <FormControl className={ classes.formControl } fullWidth>

                                            <Select
                                                labelId="demo-mutiple-checkbox-label"
                                                id="demo-mutiple-checkbox"
                                                value={ this.state.selectedExclude1 }
                                                onChange={ this.handleChangeForExport1 }
                                            >
                                                { this.state.exclude.map((name) => (
                                                    <MenuItem key={ name } value={ name }>
                                                        { name }
                                                    </MenuItem>
                                                )) }
                                            </Select>

                                        </FormControl>
                                    </GridItem>

                                    {/* <GridItem xs={12} sm={12} lg={2} md={2}  className={classes.SelectItem}>
                                        <FormControl className={classes.formControl} fullWidth>
                                            <Select
                                                labelId="demo-mutiple-checkbox-label"
                                                id="demo-mutiple-checkbox"

                                                value={this.state.selectedAdvertiserTag}
                                                onChange={this.handleChangeForAdvertiser}
                                            >
                                                {this.state.tagAdvertiser.map((name) => (
                                                    <MenuItem key={name} value={name}>
                                                        {name}
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>
                                    </GridItem>
                                   */}
                                    <GridItem lg={ 4 } md={ 4 } className={ classes.SelectItem }>
                                        <FormControl variant="outlined" className={ classes.formControl } fullWidth>
                                            {/* <InputLabel htmlFor="outlined-age-native-simple">Ad Unit</InputLabel> */ }
                                            <Autocomplete
                                                multiple
                                                id="checkboxes-tags-demo"
                                                className={ classes.adUnits }
                                                options={ this.state.advertiserData }
                                                disableCloseOnSelect
                                                getOptionLabel={ (option) => option[0] }
                                                renderOption={ (option, { selected }) => (
                                                    <React.Fragment>
                                                        <Checkbox
                                                            icon={ icon }

                                                            checkedIcon={ checkedIcon }
                                                            style={ { marginRight: 8 } }
                                                            // checked={selected}
                                                            checked={ this.state.selectedAdvertiserIds.includes(option[0]) }
                                                            onClick={ () => this.selectAdvertiser(option[0], option[1]) }
                                                        />
                                                        { option[0] }
                                                    </React.Fragment>
                                                ) }

                                                renderInput={ (params, i) => (
                                                    <TextField { ...params } variant="outlined" label="Advertiser" />

                                                ) }
                                            />

                                        </FormControl>

                                    </GridItem>
                                    <GridItem lg={ 4 } md={ 4 } className={ classes.SelectItem } >
                                        <InputLabel htmlFor="outlined-age-native-simple">Selected Advertiser</InputLabel>
                                        <Paper component="ul" >
                                            { this.state.selectedAdvertiserIds.length > 0 && this.state.selectedAdvertiserIds.map((data, i) => {
                                                let icon = "";
                                                return (
                                                    <li className={ classes.SelectedWebLi }>
                                                        <Chip
                                                            icon={ icon }
                                                            variant="outline"
                                                            color="primary"
                                                            onDelete={ () => this.handleDeleteForWebsites(i) }
                                                            label={ data }
                                                            className="m-1"
                                                        />
                                                    </li>
                                                );
                                            }) }

                                        </Paper>

                                    </GridItem>

                                    {/* <GridItem xs={12} sm={12} lg={8} md={8} className={classes.SelectItem}>
                                        <FormControl fullWidth>
                                            <Select
                                                multiple
                                                value={this.state.selectedAdvertiserIds}
                                                onChange={(event, child) => this.selectAdvertiser(event, child.props.id)}
                                                MenuProps={{ className: classes.selectMenu }}
                                                labelId="demo-mutiple-chip-label"
                                                id="demo-mutiple-chip"
                                                input={<Input id="select-multiple-chip" />}
                                                renderValue={(selected) => (
                                                    <div className={classes.chips}>
                                                        {selected.map((value) => (
                                                            <Chip key={value} label={value} className={classes.chip} />
                                                        ))}
                                                    </div>
                                                )}
                                            >

                                                {this.state.advertiserData.map((lWebsite) => {
                                                    return (<MenuItem key={lWebsite} id={lWebsite[1]}

                                                        value={lWebsite[0]}
                                                    >
                                                        <Checkbox checked={this.state.selectedAdvertiserIds.indexOf(lWebsite[0]) > -1} />
                                                        {lWebsite[0]}
                                                    </MenuItem>)
                                                })}

                                            </Select>
                                        </FormControl>
                                    </GridItem>
 */}
                                </GridContainer>

                                <GridContainer>
                                    <GridItem xs={ 12 } sm={ 12 } md={ 6 }>

                                        <div className={ classes.cardContentRight }>

                                            <Button color="info" onClick={ this.viewReports } className={ classes.marginRight }>
                                                View
                                            </Button>
                                            <Button color="info" onClick={ this.downloadReport } className={ classes.marginRight }>
                                                Download
                                            </Button>
                                        </div>
                                    </GridItem>
                                </GridContainer>
                            </CardBody>
                        </Card>
                    </GridItem>
                </GridContainer >
                { this.state.view && this.renderTable() }
            </div>
        )
    }

    renderRevenueTable = () => {
        if (this.state.isReportDataVisible) {
            return <Table
                tableHeaderColor="primary"
                tableHead={ this.state.websiteRevenueHeaders }
                tableData={ this.state.websiteRevenueData }
                coloredColls={ [3] }
                colorsColls={ ["primary"] }
            />
        }
    }
}

const ReportsHOC = withStyles(styles)(Reports);
export default connect(mapStateToProps, mapDispatchToProps)(ReportsHOC);