import React from "react";
// @material-ui/core components
import { withStyles, makeStyles } from "@material-ui/core/styles";
import InputBase from '@material-ui/core/InputBase';
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardHeader from "components/Card/CardHeader.js";
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import MButton from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Tooltip from '@material-ui/core/Tooltip';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
// material-ui icons
import IconButton from '@material-ui/core/IconButton';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'


const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}))(Tooltip);
const styles = {

  cardIconTitle: {
    ...cardTitle,
    marginTop: "15px",
    marginBottom: "0px"
  },
  rootslider: {
    '& .MuiInputBase-root': {
      width: "100%"
    },
    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "6px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },

    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",

    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },

    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },

    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",


    },
    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important",
      width: "100%",
      boxShadow: "none!important"
    },
    '& .MuiPaper-elevation4': {
      background: "#ebebeb !important",

    },
    '& .MuiPaper-elevation24': {
      boxShadow: "none!important"
    },
    '& .MuiBackdrop-root': {
      backgroundColor: "#21212114"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "0px!important",
      marginRight: "0px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },
    '& .MuiFormControl-root': {
      //margin: theme.spacing(1),
      width: "100%",

    },
    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },
    '& .MuiGrid-grid-md-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2 .MuiInputBase-input ': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiGrid-grid-lg-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-2 .MuiInputBase-input ': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-12': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-12': {
      padding: "0 5px !important"
    },
    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",
    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },

    '& .MuiGrid-grid-lg-1': {
      padding: "0 2px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-lg-1 .MuiInputBase-input': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-1': {
      padding: "0 2px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-1 .MuiInputBase-input': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiInputBase-input': {

      padding: " 10px 5px 10px"

    }
  },
  CardHeading: {
    textAlign: "center",
    color: "black!important",
  },
  MainHeading: {
    textAlign: "left",
    color: "#3c4858!important",

  },
  CloseButton: {
    backgroundColor: "white",
    borderRadius: "30px",
    color: "black",
    width: "41px",
    height: "41px",

    minWidth: "41px",
    paddingLeft: "12px",
    paddingRight: "12px"
  },
  SliderTitle: {
    fontSize: "16px",
    paddingLeft: "30px",
    color: "black !important",
    fontWeight: "400"

  },
  CustomappBar: {
    display: "flex",
    flex: " 0 0 64px",
    background: "#ebebeb",
    height: " 64px",
    borderBottom: "1px solid rgb(0 0 0 / 10%)",

  },
  heading: {
    color: "black!important",
    fontSize: "15px",
    fontWeight: "400",

  },
  headingcenter: {
    color: "black!important",
    fontSize: "15px",
    fontWeight: "400",
    textAlign: "center"
  },
  data: {
    fontSize: "15px",
    fontWeight: "200"
  },
  datacenter: {
    fontSize: "15px",
    fontWeight: "200",
    textAlign: "center !important"
  },
  dataoverlay: {
    cursor: "pointer",
    color: "black !important",
    fontSize: "15px",
    fontWeight: "200",

  },
  SliderBackground: {
    backgroundColor: "#dddddd!important"
  },
  TextCenter: {
    textAlign: "center"
  },
  SmallText: {
    fontSize: "12px",
    color: "#000000de",
    fontWeight: "300"
  },
  headingStyle: {
    marginBottom: "0px",
    fontSize: "1.1em",
    fontWeight: "500",
    marginTop: "25px",
  },
  root2: {

    float: "right"
  },
  ButtonSpace: {
    paddingLeft: "10px",
    paddingRight: "10px"
  },
  checkboxroot: {
    '& .MuiSvgIcon-root': {
      width: "0.7em",
      height: "0.7em"
    },
  },
  ActionsButton: {
    '& .MuiButton-root': {
      minWidth: " 0px"
    },
    '& .MuiButton-root': {
      height: "0px"
    }

  },
  CardBodyPadding: {
    marginTop: "20px",
    marginBottom: "30px"
  },
  HeadingRow: {
    marginTop: "10px"
  },

  margin: {
    paddingTop: "10px"
  },
  Accordianinput: {
    '& .MuiAccordionSummary-root': {
      boxShadow: "0 2px 5px 0 rgba(0,0,0,0.16), 0 2px 10px 0 rgba(0,0,0,0.12) !important"
    },
    '& .MuiAccordionDetails-root': {
      padding: "10px 16px 10px"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-8': {
      padding: "0 5px !important",

    },
    '& .MuiGrid-grid-lg-2 .MuiInputBase-input ': {
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-2 .MuiInputBase-input ': {
      textAlign: "center"
    },

    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important",
      textAlign: "center"
    },

    '& .MuiGrid-grid-lg-8': {
      padding: "0 5px !important"
    },
    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "0px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",

    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .MuiGrid-grid-lg-1': {
      padding: "0 5px !important",
      textAlign: "center"

    },
    '& .MuiGrid-grid-lg-1 .MuiInputBase-input ': {
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-1 .MuiInputBase-input ': {
      textAlign: "center"
    },

    '& .MuiGrid-grid-md-1': {
      padding: "0 5px !important",
      textAlign: "center"
    },
  },

  CardCustomize: {
    marginBottom: " 0px !important"
  },
  CardBodyCustomize: {
    padding: "6px 20px"
  }

};

const useStyles = makeStyles(styles);
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="left" ref={ ref } { ...props } />;
});
export default function RevenueShare() {
  const [expanded, setExpanded] = React.useState(false);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };
  const [open, setOpen] = React.useState(false);
  const classes = useStyles();
  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  return (
    <div className={ classes.root } >
      <GridContainer>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
        <GridItem lg={ 6 } md={ 6 }>
          <Card className={ classes.CardCustomize }>
            <CardBody className={ classes.CardBodyCustomize }>
              <a className={ classes.dataoverlay } onClick={ handleClickOpen }>
                <GridContainer className={ classes.HeadingRow }>
                  <GridItem lg={ 1 } md={ 1 }>
                    <p className={ classes.headingcenter }>1</p>
                  </GridItem>
                  <GridItem lg={ 8 } md={ 8 }>
                    <p className={ classes.heading }> Publisher Name1</p>
                  </GridItem>
                  <GridItem lg={ 3 } md={ 3 }>
                    <p className={ classes.headingcenter }>3% | 97%</p>
                  </GridItem>
                </GridContainer>
              </a>
              <Dialog fullScreen open={ open } onClose={ handleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
                <AppBar className={ classes.CustomappBar }>
                  <Toolbar>
                    <IconButton edge="start" color="inherit" onClick={ handleClose } aria-label="close" className={ classes.CloseButton }>
                      <LeftAorrow />
                    </IconButton>
                    <h4 className={ classes.SliderTitle }>
                      Websites
                    </h4>
                  </Toolbar>
                </AppBar>

                <GridContainer style={ { paddingTop: "3%" } }>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                  <GridItem lg={ 8 }>
                    <Accordion expanded={ expanded === 'panel1' } onChange={ handleChange('panel1') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>3% | 97% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails className={ classes.AccordionInsideinput }>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel2' } onChange={ handleChange('panel2') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>2% | 98% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >
                                Cancel
                              </MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel3' } onChange={ handleChange('panel3') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>5% | 95% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel4' } onChange={ handleChange('panel4') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>4% | 96% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel5' } onChange={ handleChange('panel5') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>10% | 90% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                  </GridItem>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                </GridContainer>
              </Dialog>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
      </GridContainer>

      <GridContainer>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
        <GridItem lg={ 6 } md={ 6 }>
          <Card className={ classes.CardCustomize }>
            <CardBody className={ classes.CardBodyCustomize }>
              <a className={ classes.dataoverlay } onClick={ handleClickOpen }>
                <GridContainer className={ classes.HeadingRow }>
                  <GridItem lg={ 1 } md={ 1 }>
                    <p className={ classes.headingcenter }>2</p>
                  </GridItem>
                  <GridItem lg={ 8 } md={ 8 }>
                    <p className={ classes.heading }>Publisher Name2</p>
                  </GridItem>
                  <GridItem lg={ 3 } md={ 3 }>
                    <p className={ classes.headingcenter }>10% | 90%</p>
                  </GridItem>
                </GridContainer>
              </a>
              <Dialog fullScreen open={ open } onClose={ handleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
                <AppBar className={ classes.CustomappBar }>
                  <Toolbar>
                    <IconButton edge="start" color="inherit" onClick={ handleClose } aria-label="close" className={ classes.CloseButton }>
                      <LeftAorrow />
                    </IconButton>
                    <h4 className={ classes.SliderTitle }>
                      Websites
                    </h4>
                  </Toolbar>
                </AppBar>

                <GridContainer style={ { paddingTop: "3%" } }>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                  <GridItem lg={ 8 }>
                    <Accordion expanded={ expanded === 'panel1' } onChange={ handleChange('panel1') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>3% | 97% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails className={ classes.AccordionInsideinput }>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel2' } onChange={ handleChange('panel2') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>2% | 98% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >
                                Cancel
                              </MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel3' } onChange={ handleChange('panel3') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>5% | 95% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel4' } onChange={ handleChange('panel4') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>4% | 96% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel5' } onChange={ handleChange('panel5') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>10% | 90% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                  </GridItem>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                </GridContainer>
              </Dialog>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
      </GridContainer>

      <GridContainer>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
        <GridItem lg={ 6 } md={ 6 }>
          <Card className={ classes.CardCustomize }>
            <CardBody className={ classes.CardBodyCustomize }>
              <a className={ classes.dataoverlay } onClick={ handleClickOpen }>
                <GridContainer className={ classes.HeadingRow }>
                  <GridItem lg={ 1 } md={ 1 }>
                    <p className={ classes.headingcenter }>3</p>
                  </GridItem>
                  <GridItem lg={ 8 } md={ 8 }>
                    <p className={ classes.heading }> Publisher Name3</p>
                  </GridItem>
                  <GridItem lg={ 3 } md={ 3 }>
                    <p className={ classes.headingcenter }>15% | 85%</p>
                  </GridItem>
                </GridContainer>
              </a>
              <Dialog fullScreen open={ open } onClose={ handleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
                <AppBar className={ classes.CustomappBar }>
                  <Toolbar>
                    <IconButton edge="start" color="inherit" onClick={ handleClose } aria-label="close" className={ classes.CloseButton }>
                      <LeftAorrow />
                    </IconButton>
                    <h4 className={ classes.SliderTitle }>
                      Websites
                    </h4>
                  </Toolbar>
                </AppBar>

                <GridContainer style={ { paddingTop: "3%" } }>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                  <GridItem lg={ 8 }>
                    <Accordion expanded={ expanded === 'panel1' } onChange={ handleChange('panel1') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>3% | 97% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails className={ classes.AccordionInsideinput }>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel2' } onChange={ handleChange('panel2') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>2% | 98% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >
                                Cancel
                              </MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel3' } onChange={ handleChange('panel3') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>5% | 95% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel4' } onChange={ handleChange('panel4') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>4% | 96% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel5' } onChange={ handleChange('panel5') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>10% | 90% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                  </GridItem>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                </GridContainer>
              </Dialog>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
      </GridContainer>
      <GridContainer>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
        <GridItem lg={ 6 } md={ 6 }>
          <Card className={ classes.CardCustomize }>
            <CardBody className={ classes.CardBodyCustomize }>
              <a className={ classes.dataoverlay } onClick={ handleClickOpen }>
                <GridContainer className={ classes.HeadingRow }>
                  <GridItem lg={ 1 } md={ 1 }>
                    <p className={ classes.headingcenter }>4</p>
                  </GridItem>
                  <GridItem lg={ 8 } md={ 8 }>
                    <p className={ classes.heading }> Publisher Name4</p>
                  </GridItem>
                  <GridItem lg={ 3 } md={ 3 }>
                    <p className={ classes.headingcenter }>20% | 80%</p>
                  </GridItem>
                </GridContainer>
              </a>
              <Dialog fullScreen open={ open } onClose={ handleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
                <AppBar className={ classes.CustomappBar }>
                  <Toolbar>
                    <IconButton edge="start" color="inherit" onClick={ handleClose } aria-label="close" className={ classes.CloseButton }>
                      <LeftAorrow />
                    </IconButton>
                    <h4 className={ classes.SliderTitle }>
                      Websites
                    </h4>
                  </Toolbar>
                </AppBar>

                <GridContainer style={ { paddingTop: "3%" } }>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                  <GridItem lg={ 8 }>
                    <Accordion expanded={ expanded === 'panel1' } onChange={ handleChange('panel1') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>3% | 97% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails className={ classes.AccordionInsideinput }>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel2' } onChange={ handleChange('panel2') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>2% | 98% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >
                                Cancel
                              </MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel3' } onChange={ handleChange('panel3') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>5% | 95% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel4' } onChange={ handleChange('panel4') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>4% | 96% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel5' } onChange={ handleChange('panel5') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>10% | 90% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                  </GridItem>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                </GridContainer>
              </Dialog>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
      </GridContainer>
      <GridContainer>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
        <GridItem lg={ 6 } md={ 6 }>
          <Card className={ classes.CardCustomize }>
            <CardBody className={ classes.CardBodyCustomize }>
              <a className={ classes.dataoverlay } onClick={ handleClickOpen }>
                <GridContainer className={ classes.HeadingRow }>
                  <GridItem lg={ 1 } md={ 1 }>
                    <p className={ classes.headingcenter }>5</p>
                  </GridItem>
                  <GridItem lg={ 8 } md={ 8 }>
                    <p className={ classes.heading }> Publisher Name5</p>
                  </GridItem>
                  <GridItem lg={ 3 } md={ 3 }>
                    <p className={ classes.headingcenter }>22% | 78%</p>
                  </GridItem>
                </GridContainer>
              </a>
              <Dialog fullScreen open={ open } onClose={ handleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
                <AppBar className={ classes.CustomappBar }>
                  <Toolbar>
                    <IconButton edge="start" color="inherit" onClick={ handleClose } aria-label="close" className={ classes.CloseButton }>
                      <LeftAorrow />
                    </IconButton>
                    <h4 className={ classes.SliderTitle }>
                      Websites
                    </h4>
                  </Toolbar>
                </AppBar>

                <GridContainer style={ { paddingTop: "3%" } }>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                  <GridItem lg={ 8 }>
                    <Accordion expanded={ expanded === 'panel1' } onChange={ handleChange('panel1') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website1
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>3% | 97% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails className={ classes.AccordionInsideinput }>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel2' } onChange={ handleChange('panel2') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website2
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>2% | 98% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >
                                Cancel
                              </MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel3' } onChange={ handleChange('panel3') } className={ classes.Accordianinput }>
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website3
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>5% | 95% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel4' } onChange={ handleChange('panel4') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website4
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>4% | 96% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                    <Accordion expanded={ expanded === 'panel5' } onChange={ handleChange('panel5') } className={ classes.Accordianinput } >
                      <AccordionSummary
                        expandIcon={ <ExpandMoreIcon /> }
                        aria-controls="panel1bh-content"
                        id="panel1bh-header"
                      >
                        <GridContainer>
                          <GridItem lg={ 1 } md={ 1 }>
                            <Typography className={ classes.secondaryHeading }>
                              5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 8 } md={ 8 }>
                            <Typography className={ classes.secondaryHeading }>
                              Website5
                            </Typography>
                          </GridItem>
                          <GridItem lg={ 3 } md={ 3 }>
                            <Typography className={ classes.secondaryHeading }>10% | 90% </Typography>
                          </GridItem>
                        </GridContainer>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Card>
                          <CardBody>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="1" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 1" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="3%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="97%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="2" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 2" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="4%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="96%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="3" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 3" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="2%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="98%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="4" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 4" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="10%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="90%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                            <GridContainer>
                              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                <InputBase className={ classes.margin } value="5" inputProps={ { 'aria-label': 'slno' } }
                                />
                              </GridItem>
                              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                                <InputBase className={ classes.margin } value="Advertiser 5" inputProps={ { 'aria-label': 'advertisername' } }
                                />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" defaultValue="7%" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.InputCenter } label=" Publisher Share" variant="outlined" defaultValue="93%" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } } />
                              </GridItem>
                              <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
                                <TextField className={ classes.textfields } label="Effective Date" type="date"
                                  InputLabelProps={ { shrink: true, } } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
                              </GridItem>
                            </GridContainer>
                          </CardBody>
                          <CardHeader style={ { float: "right!important" } }>
                            <div className={ classes.root2 } >
                              <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="secondary" >Confirm</MButton></span>
                              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
                            </div>
                          </CardHeader>
                        </Card>
                      </AccordionDetails>
                    </Accordion>
                  </GridItem>
                  <GridItem lg={ 2 } md={ 2 }></GridItem>
                </GridContainer>
              </Dialog>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 }></GridItem>
      </GridContainer>
    </div>

  );

}
