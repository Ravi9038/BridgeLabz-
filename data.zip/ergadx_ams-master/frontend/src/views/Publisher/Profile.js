import React, { Component } from "react";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import ProfileView from './ProfileView.js'


const styles = {};


class Profile extends Component {

  constructor(props) {
    super(props);
    
  }

  componentDidMount = () => {
    
  }
  

  render() {
    const classes = this.props.classes;
    return <div className={classes.root}>
      <ProfileView idUser="-1" type="Publisher" action="view"></ProfileView>
    </div>
  }
}


const ProfileHOC = withStyles(styles)(Profile);
export default connect(mapStateToProps, mapDispatchToProps)(ProfileHOC);