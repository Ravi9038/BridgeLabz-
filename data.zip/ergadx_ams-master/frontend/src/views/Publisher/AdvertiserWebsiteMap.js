import React, { Component } from 'react'
import { makeStyles } from "@material-ui/core/styles";

// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import axios from 'axios';
// core components
import GridContainer from "components/Grid/GridContainer.js";
import Checkbox from "@material-ui/core/Checkbox";
import Check from "@material-ui/icons/Check";
import GridItem from "components/Grid/GridItem.js";
import Table from "components/Table/Table.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import Button from "components/CustomButtons/Button.js";
import CardFooter from "components/Card/CardFooter.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import { SERVER_URL } from "../../variables/constants";
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import customCheckboxRadioSwitch from "assets/jss/material-dashboard-pro-react/customCheckboxRadioSwitch.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'

const styles = {
    ...customCheckboxRadioSwitch,
    ...customSelectStyle,
    customCardContentClass: {
        paddingLeft: "0",
        paddingRight: "0"
    },
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    }
};

const useStyles = makeStyles(styles);
export class AdvertiserWebsiteMap extends Component {
    state = {
        advertiserHeaders: ["", "Advertiser Name"],
        advertisersData: [],
        websiteData: [],
        existingMappedAdvertiserIds:  new Map(),
        newMappedAdvertiserIds: new Map(),
        currentSelectedWebsiteId: null
    }

    mapAdvertisers =() =>{
        let lData = {};
        lData.id_website = this.state.currentSelectedWebsiteId;
        lData.id_users = [];
        let objectIterator = this.state.newMappedAdvertiserIds.keys();
        for (const lAdvertiserId of objectIterator) {
            console.log(lAdvertiserId);
            lData.id_users.push(lAdvertiserId);
        }
        if(lData.id_website && lData.id_users.length > 0){
            const TOKEN = 'Bearer '.concat(this.props.data.token);
            axios.defaults.headers.common['Authorization'] = TOKEN;
            axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
            axios.post(`${SERVER_URL}/api/websiteadvertisermapping`,lData, { headers: { "Authorization": TOKEN } })
            .then(res => {
                if(res.status == 200){
                    alert("Success");
                }
                this.setState({newMappedAdvertiserIds : new Map()})    
            }).catch(function (error) {
                console.log(error);
            });
        }
    }
    selectAdvertiser = (id) => {
        const classes = this.props.classes;
        var newMappedAdvertiserIds = this.state.newMappedAdvertiserIds;
        var advertisersData = this.state.advertisersData;
        if(!newMappedAdvertiserIds.has(id)){
            newMappedAdvertiserIds.set(id,true);
            advertisersData.forEach(item=>{
                if(item[2] == id){
                    item[0] = <Checkbox
                    key="key"
                    className={classes.positionAbsolute}
                    tabIndex={-1}
                    onClick={() => this.selectAdvertiser(item[2])}
                    checkedIcon={<Check className={classes.checkedIcon} />}
                    icon={<Check className={classes.uncheckedIcon} />}
                    classes={{
                        checked: classes.checked,
                        root: classes.checkRoot
                    }}
                />
                }
            })
        }else{
            newMappedAdvertiserIds.delete(id);
            advertisersData.forEach(item=>{
                if(item[2] == id){
                    item[0] = <Checkbox
                    key="key"
                    className={classes.positionAbsolute}
                    tabIndex={-1}
                    onClick={() => this.selectAdvertiser(item[2])}
                    checkedIcon={<Check className={classes.uncheckedIcon} />}
                    icon={<Check className={classes.uncheckedIcon} />}
                    classes={{
                        checked: classes.checked,
                        root: classes.checkRoot
                    }}
                />
                }
            })
        } 
        this.setState({
            advertisersData : advertisersData,
            newMappedAdvertiserIds : newMappedAdvertiserIds
        })    
    }
    changeWebsite = (event) =>{
        const classes = this.props.classes;
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        //this.setState({currentSelectedWebsiteId:event.target.value});
        const lCurrentSelectedWebsiteId = event.target.value;
        var lNewMappedAdvertiserIds = new Map();
        var lExistingMappedAdvertiserIds = new Map();
        var lExstingAdvertiserData = this.state.advertisersData;
        var lNewAdvertiserData = [];
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/userwebsite/advertisers/${lCurrentSelectedWebsiteId}`, { headers: { "Authorization": TOKEN } })
            .then(res => {

                res.data.forEach(item => {
                    lExistingMappedAdvertiserIds.set(item,true);
                });

                lExstingAdvertiserData.forEach(item =>{
                    let lAdvertiser = [];
                    
                    
                        if(lExistingMappedAdvertiserIds.has(item[2])){
                            lAdvertiser.push(<Checkbox
                        key="key"
                        className={classes.positionAbsolute}
                        tabIndex={-1}
                        //onClick={() => this.selectAdvertiser(item.id)}
                        checkedIcon={<Check className={classes.checkedIcon} />}
                        icon={<Check className={classes.checkedIcon} />}
                        classes={{
                            checked: classes.checked,
                            root: classes.checkRoot,
                            disabled: classes.disabledCheckboxAndRadio
                        }}
                    />);
                        }else{
                            lAdvertiser.push(<Checkbox
                        key="key"
                        className={classes.positionAbsolute}
                        tabIndex={-1}
                        onClick={() => this.selectAdvertiser(item[2])}
                        checkedIcon={<Check className={classes.uncheckedIcon} />}
                        icon={<Check className={classes.uncheckedIcon} />}
                        classes={{
                            checked: classes.checked,
                            root: classes.checkRoot
                        }}
                    />);
                        }

                        lAdvertiser.push(item[1]);
                    lAdvertiser.push(item[2]);
                    lNewAdvertiserData.push(lAdvertiser);
                });

                this.setState({
                    currentSelectedWebsiteId : lCurrentSelectedWebsiteId,
                    advertisersData: lNewAdvertiserData,
                    existingMappedAdvertiserIds:  lExistingMappedAdvertiserIds,
                    newMappedAdvertiserIds: lNewMappedAdvertiserIds,
                });

            }).catch(function (error) {
                console.log(error);
            });
            
    }
    componentDidMount() {
        const classes = this.props.classes;
        const USER_ID = this.props.data.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';


        axios.get(`${SERVER_URL}/api/userwebsite`, { headers: { "Authorization": TOKEN } })
            .then(res => {
                let lWebsiteData = [];
                res.data.forEach(item => {
                    let lWebsite = [];
                    lWebsite.push(item.name);
                    lWebsite.push(item.hostURL);
                    lWebsite.push(item.id);
                    lWebsiteData.push(lWebsite);
                });
                this.setState({ websiteData: lWebsiteData });
            }).catch(function (error) {
                console.log(error);
            });

        axios.get(`${SERVER_URL}/api/users/advertisers`).then(response => response.data)
            .then((data) => {
                let lData = []
                data.forEach(element => {
                    let lAdvertiser = [];
                    lAdvertiser.push(<Checkbox
                        key="key"
                        className={classes.positionAbsolute}
                        tabIndex={-1}
                        onClick={() => this.selectAdvertiser(element.id)}
                        checkedIcon={<Check className={classes.checkedIcon} />}
                        icon={<Check className={classes.uncheckedIcon} />}
                        classes={{
                            checked: classes.checked,
                            root: classes.checkRoot
                        }}
                    />);
                    lAdvertiser.push(element.companyName);
                    lAdvertiser.push(element.id);
                    lData.push(lAdvertiser);
                })
                this.setState({ advertisersData: lData })
            }).catch((error) => {
                console.error(error);
            });
    }
    render() {


        const classes = this.props.classes;
        return (
            <GridContainer>
                <GridItem xs={12}>
                    <Card>
                        <CardHeader color="rose" icon>
                            <CardIcon color="rose">
                                <Assignment />
                            </CardIcon>
                            <h4 className={classes.cardIconTitle}>Assign advertisers to Website</h4>
                        </CardHeader>

                        <CardBody>
                            <GridItem xs={12} sm={12} md={6}>
                                <GridContainer>
                                    <GridItem xs={12} sm={6} md={5} lg={5}>
                                        <FormControl
                                            fullWidth
                                            className={classes.selectFormControl}
                                        >
                                            <InputLabel
                                                htmlFor="simple-select"
                                                className={classes.selectLabel}
                                            >
                                                Select Website
                                            </InputLabel>
                                            <Select
                                                MenuProps={{
                                                    className: classes.selectMenu
                                                }}
                                                classes={{
                                                    select: classes.select
                                                }}
                                                value={this.state.currentSelectedWebsiteId}
                                                onChange={this.changeWebsite}
                                                inputProps={{
                                                    name: "simpleSelect",
                                                    id: "simple-select"
                                                }}
                                            >
                                                <MenuItem
                                                    disabled
                                                    classes={{
                                                        root: classes.selectMenuItem
                                                    }}
                                                    value="-1"
                                                >

                                                    All Websites
                                                </MenuItem>
                                                {this.state.websiteData.map((lWebsite, i) => {
                                                    return (<MenuItem
                                                        classes={{
                                                            root: classes.selectMenuItem,
                                                            selected: classes.selectMenuItemSelectedMultiple
                                                        }}
                                                        value={lWebsite[2]}
                                                    >
                                                        {lWebsite[1]}
                                                    </MenuItem>)
                                                })}

                                            </Select>
                                        </FormControl>
                                    </GridItem>
                                </GridContainer>
                            </GridItem>
                            {this.renderAdvertiserData()}
                        </CardBody>
                        <CardFooter>
                        <Button color="info" className={classes.marginRight} onClick ={this.mapAdvertisers}>
                                Submit 
                        </Button>
                        </CardFooter>
                    </Card>
                </GridItem>
            </GridContainer >
        )
    }
    renderAdvertiserData = () => {
        if (this.state.currentSelectedWebsiteId) {
            return <Table tableHeaderColor="primary"
                tableHead={this.state.advertiserHeaders}
                tableData={this.state.advertisersData}
                coloredColls={[3]}
                colorsColls={["primary"]}
            />
        }
    }
}

const AdvertiserWebsiteMapHOC = withStyles(styles)(AdvertiserWebsiteMap);
export default connect(mapStateToProps, mapDispatchToProps)(AdvertiserWebsiteMapHOC);