import React, { Component } from "react";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Checkbox from '@material-ui/core/Checkbox';
import Chip from '@material-ui/core/Chip';
import InputLabel from '@material-ui/core/InputLabel';
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import { connect } from 'react-redux';
import ListItemText from '@material-ui/core/ListItemText';
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import Card from "components/Card/Card.js";
import Autocomplete from '@material-ui/lab/Autocomplete';
import Button from "components/CustomButtons/Button.js";
import Assignment from "@material-ui/icons/Assignment";
import Input from '@material-ui/core/Input';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import { SERVER_URL } from "../../variables/constants";
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import MButton from '@material-ui/core/Button';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
const styles = {
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    },
    root: {
        ' & .makeStyles-card-194': {
            width: "70%",
            marginLeft: "200px",
        }
    },
    adUnits: {
        ' & .MuiAutocomplete-input ': {
            padding: "1px !important"
        }
    },
    bidderDetails: {
        border: "1px solid #c4c4c4",
        borderRadius: "4px",
        padding: "10px",
        marginBottom: "10px !important",
        
    },
    bidderDisplay:{
        padding:"0px",
        '& .MuiSvgIcon-fontSizeSmall ':{
            display:"none",
            
        } 
    }
}

class AdUnit extends Component {

    constructor(props) {
        super(props);
        this.state = {
            pageCheckType: [
                "Contains",
                "Equals",
                "Regex"
            ],
            Type: [
                "DFP",
                "CustomJS"
            ],
            adFormat: [
                "Banner",
                "Video",
                "Interstitial",
                "inImage",
                "Sticky"
            ],

            Dimention: [
                { name: "Mobile", status: false },
                { name: "Tablet", status: false },
                { name: "DeskTop", status: false }
            ],
            selectedDimention: [],
            refreshEnable: [
                "Yes",
                "No"
            ],
            DFPAccountNumber: [
                "21854674376",
                "116865642"
            ],
            selectedRefreshEnable: [],
            operation: [
                "append",
                "prepend",
                "insertBefore",
                "insertAfter"
            ],

            selectedOperation: '',
            selectedTypes: '',
            selectedAdFormat: '',
            name: '',
            elementSector: '',
            adElementSector: '',
            css: '',
            dfpAccountNo: '',
            customJsData: '',
            refreshDurtion: '',
            adSize: [],
            selectedSize: [],
            divId: '',
            layout: '',
            prebidEnable: [
                "Yes",
                "No"
            ],
            selectedprebidEnable: [],
            bidder: [
                "openx",
                "aol",
                "rubicon",
                "amx",
                "adsolut",
                "quantumdex",
                "emx_digital"
            ],
            selectedBidder: [],
            unit: '',
            delDomain: '',
            unitcustomParams: '',
            dcn: '',
            pos: '',
            ext: '',
            accountId: '',
            siteId: '',
            zoneId: '',
            testMode: '',
            tagId: '',
            adUnitId: '',
            host: '',
            zoneIdAdsoult: '',
            siteIdQ: '',
            tagid:'',
            bidfloor:'',
           
		}

        }
    


    componentDidMount = () => {

        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/adsize/`, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                this.setState({ adSize: data })
            }).catch(error => { console.log(error); })

    }
    updateType = (event) => {
        console.log(event.target.value);
        this.setState({ selectedTypes: event.target.value })
    }
    updatesAdFormat = (event) => {
        console.log(event.target.value);
        this.setState({ selectedAdFormat: event.target.value })
    }
    updateswebsiteData = (event) => {
        console.log(event.target.value);
        this.setState({ pageCheckTypes: event.target.value })

    }
    insertForWebsitePage = (event) => {
        this.setState({ selectedDimention: event.target.value });
        console.log(this.state.selectedDimention);

    }


    updateForRefreshEnable = (event) => {
        this.setState({ selectedRefreshEnable: event.target.value })
        console.log(this.state.selectedRefreshEnable)
    }

    updateForPrebidEnable = (event) => {
        this.setState({ selectedprebidEnable: event.target.value })
        console.log(this.state.selectedprebidEnable)
    }


    updateForOperation = (event) => {
        this.setState({ selectedOperation: event.target.value })
        console.log(this.state.selectedOperation)
    }



    addAdUnit = (value, fieldName) => {
        if (fieldName === 'name') {
            this.setState({ name: value })
        }
        if (fieldName === 'elementSector') {
            this.setState({ elementSector: value })
        }
        if (fieldName === 'adElementSector') {
            this.setState({ adElementSector: value })
        }
        if (fieldName === 'css') {
            this.setState({ css: value })
        }
        if (fieldName === 'refreshDurtion') {
            this.setState({ refreshDurtion: value })
        }
        if (fieldName === 'dfpAccountNo') {
            this.setState({ dfpAccountNo: value })
        }
        if (fieldName === 'customJsData') {
            this.setState({ customJsData: value })
        }
        if (fieldName === 'div_id') {
            this.setState({ divId: value })
        }
        if (fieldName === 'layout') {
            this.setState({ layout: value })
        }
    }
    updatesDfpAccountNo = (event) => {
        this.setState({ dfpAccountNo: event.target.value })
        console.log(this.state.dfpAccountNo)
    }
    selectedSize = (option) => {
        console.log(option)
        this.setState(prevState => ({
            selectedSize: [...prevState.selectedSize, option]
        }))

    }
    submitDetails = () => {

        var biddersToPass= [{
            bidder: 'openx',
            params: {
                delDomain: this.state.delDomain,
                unit: this.state.unit,
                unitcustomParams:this.state.unitcustomParams
            }
        }, {
            bidder: "aol",
            params: {
                dcn: this.state.dcn,
                pos: this.state.pos,
                ext: this.state.ext
            }
        }, {
            bidder: 'rubicon',
            params: {
                accountId: this.state.accountId,
                siteId: this.state.siteId,
                zoneId: this.state.zoneId
            }
        }, {
            bidder: "amx",
            params: {
                testMode: this.state.testMode,
                tagId: this.state.tagId,
                adUnitId: this.state.adUnitId
            }
        }, {
            bidder: 'adsolut',
            params: {
                host: this.state.host,
                zoneId: this.state.zoneIdAdsoult
            }
        }, {
            bidder: 'quantumdex',
            params: {
                siteId: this.state.siteIdQ
            }
        }, {
            bidder: 'emx_digital',
            params: {
                tagid: this.state.tagid

            }
        }]
       var StringBidder=JSON.stringify(biddersToPass);
        console.log(StringBidder)
         var size = '';
        console.log(this.state.selectedSize)
        size = this.state.selectedSize.toString();
        console.log(size)
        let Mobilestatus = false
        let tabletstatus = false
        let desktopstatus = false
        if (this.state.selectedDimention.includes("Mobile")) {
            Mobilestatus = true
        } if (this.state.selectedDimention.includes("Tablet")) {
            tabletstatus = true
        } if (this.state.selectedDimention.includes("DeskTop")) {
            desktopstatus = true
        }
        var CSS = this.state.css;
        var newString = CSS.replace(/\s+/g, ' ').trim();

        var Customjsdata = this.state.customJsData;
        var customdataJS = Customjsdata.replace(/\s+/g, ' ').trim();
        var deviceStatus = { "mobile": Mobilestatus, "tablet": tabletstatus, "desktop": desktopstatus }
        var obj = JSON.stringify(deviceStatus);
        var request = {};
        request.name = this.state.name;
        request.type = this.state.selectedTypes;
        request.adFormat = this.state.selectedAdFormat;
        request.elementSector = this.state.elementSector;
        request.adElementSector = this.state.adElementSector;
        request.refreshDurtion = this.state.refreshDurtion;
        request.refreshEnabled = this.state.selectedRefreshEnable;
        request.size = size;
        request.css = newString;
        request.dfpAccountNo = this.state.dfpAccountNo;
        request.customJsData = customdataJS;
        request.device = obj;
        request.divId = this.state.divId;
        request.operation = this.state.selectedOperation;
        request.layout = this.state.layout;
        request.bidders=StringBidder
        console.log(request);

        const ID = this.props.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.post(`${SERVER_URL}/api/websitepagead`, request, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                alert("data submitted ")
            }).catch(error => { console.log(error); }) 
    }
    selectedBidders = (option) => {
        console.log(option);

        this.setState(prevState => ({
            selectedBidder: [...prevState.selectedBidder, option]
        }))
        console.log(this.state.selectedBidder)
    }
    handleDeleteForWebsites = (i) => {
        console.log(i)
    }
    deleteBidder = (event, value, reason) => {
        console.log(value)
        this.setState({ selectedBidder: value })
    }
    updateForopenxData = (e, item) => {
        if (item === "unit") {
            this.setState({ unit: e.target.value });
        } if (item === "delDomain") {
            this.setState({ delDomain: e.target.value });

        } if (item === "unitcustomParams") {
            this.setState({ unitcustomParams: e.target.value });
        }
    }

    updateForaolData = (e, item) => {
        if (item === "dcn") {
            this.setState({ dcn: e.target.value });
        } if (item === "pos") {
            this.setState({ pos: e.target.value });

        } if (item === "ext") {
            this.setState({ ext: e.target.value });
        }
    }
    updateForRbiconData = (e, item) => {
        if (item === "accountId") {
            this.setState({ accountId: e.target.value });
        } if (item === "siteId") {
            this.setState({ siteId: e.target.value });

        } if (item === "zoneId") {
            this.setState({ zoneId: e.target.value });
        }
    }
    updateForAmxData = (e, item) => {
        if (item === "testMode") {
            this.setState({ testMode: e.target.value });
        } if (item === "tagId") {
            this.setState({ tagId: e.target.value });

        } if (item === "adUnitId") {
            this.setState({ adUnitId: e.target.value });
        }
    }
    updateForAdsolutData = (e, item) => {
        if (item === "host") {
            this.setState({ host: e.target.value });
        } if (item === "zoneId") {
            this.setState({ zoneIdAdsoult: e.target.value });

        }
    }
    updateForQuantumdextData = (e, item) => {
        if (item === "siteId") {
            this.setState({ siteIdQ: e.target.value });
        }
    }
    updateForEmxDigitalData= (e, item) => {
        console.log(item)
     if(item==="tagid"){
        this.setState({tagid:e.target.value})
     }
     if(item==="bidfloor")
     {
        this.setState({bidfloor:e.target.value})
     }
    }
    bidderRender = () => {
        console.log(this.state.selectedBidder)
        console.log(this.state.selectedBidder.length)
        var labelsforOpenx = [];
        if (this.state.selectedBidder.includes("openx")) {
            labelsforOpenx.push("unit");
            labelsforOpenx.push("delDomain");
            labelsforOpenx.push("unitcustomParams");

        }
        var labelsforAol = [];
        if (this.state.selectedBidder.includes("aol")) {
            labelsforAol.push("dcn");
            labelsforAol.push("pos");
            labelsforAol.push("ext");

        }
        var labelsforRubicon = [];
        if (this.state.selectedBidder.includes("rubicon")) {
            labelsforRubicon.push("accountId");
            labelsforRubicon.push("siteId");
            labelsforRubicon.push("zoneId");

        }
        var labelsforAmx = [];
        if (this.state.selectedBidder.includes("amx")) {
            labelsforAmx.push("testMode");
            labelsforAmx.push("tagId");
            labelsforAmx.push("adUnitId");
        }
        var labelsforAdsolut = [];
        if (this.state.selectedBidder.includes("adsolut")) {
            labelsforAdsolut.push("host");
            labelsforAdsolut.push("zoneId");
        }
        var labelsforQuantumdex = [];
        if (this.state.selectedBidder.includes("quantumdex")) {
            labelsforQuantumdex.push("siteId");

        }
        var labelsforEmxDigital = [];
        if (this.state.selectedBidder.includes("emx_digital")) {
            labelsforEmxDigital.push("tagid");
            labelsforEmxDigital.push("bidfloor");

        }
        const classes = this.props.classes;
        var openxData = labelsforOpenx.map((item, key) => <GridItem xs={12} md={12} lg={4} className={classes.textfieldsgrid}>
            <TextField className={classes.textfields} label={item} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                onChange={(event) => this.updateForopenxData(event, item)} />
        </GridItem>);
        var Aoldata = labelsforAol.map((item, key) => <GridItem xs={12} md={12} lg={4} className={classes.textfieldsgrid}>
            <TextField className={classes.textfields} label={item} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                onChange={(event) => this.updateForaolData(event, item)} />
        </GridItem>);
        var Rubicondata = labelsforRubicon.map((item, key) => <GridItem xs={12} md={12} lg={4} className={classes.textfieldsgrid}>
            <TextField className={classes.textfields} label={item} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                onChange={(event) => this.updateForRbiconData(event, item)} />
        </GridItem>);
        var Amxdata = labelsforAmx.map((item, key) => <GridItem xs={12} md={12} lg={4} className={classes.textfieldsgrid}>
            <TextField className={classes.textfields} label={item} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                onChange={(event) => this.updateForAmxData(event, item)} />
        </GridItem>);
        var Adsolutdata = labelsforAdsolut.map((item, key) => <GridItem xs={12} md={12} lg={4} className={classes.textfieldsgrid}>
            <TextField className={classes.textfields} label={item} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                onChange={(event) => this.updateForAdsolutData(event, item)} />
        </GridItem>);
        var Quantumdexdata = labelsforQuantumdex.map((item, key) => <GridItem xs={12} md={12} lg={4} className={classes.textfieldsgrid}>
            <TextField className={classes.textfields} label={item} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                onChange={(event) => this.updateForQuantumdextData(event, item)} />
        </GridItem>);
        var EmxDigitaldata = labelsforEmxDigital.map((item, key) => <GridItem xs={12} md={12} lg={4} className={classes.textfieldsgrid}>
            <TextField className={classes.textfields} label={item} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }} 
            onChange={(event) => this.updateForEmxDigitalData(event, item)} />
        </GridItem>);
        return <div>
            {this.state.selectedBidder.includes("openx") &&
                <div className={classes.bidderDetails}>
                    <GridContainer >
                        <GridItem lg={12} md={12} sm={12} xs={12}>
                            <label style={{color:"black"}}>
                                Openx
                        </label>
                        </GridItem>
                        {openxData}
                    </GridContainer >
                </div>
            }
            {this.state.selectedBidder.includes("aol") &&
                <div className={classes.bidderDetails}>
                    <GridContainer >
                        <GridItem lg={12} md={12} sm={12} xs={12}>
                            <label style={{color:"black"}}>
                                Aol
                        </label>
                        </GridItem>
                        {Aoldata}
                    </GridContainer >
                </div>
            }
            {this.state.selectedBidder.includes("rubicon") &&
                <div className={classes.bidderDetails}>
                    <GridContainer >
                        <GridItem lg={12} md={12} sm={12} xs={12}>
                            <label style={{color:"black"}}>
                                Rubicon
                        </label>
                        </GridItem>
                        {Rubicondata}
                    </GridContainer >
                </div>
            }
            {this.state.selectedBidder.includes("amx") &&
                <div className={classes.bidderDetails}>
                    <GridContainer >
                        <GridItem lg={12} md={12} sm={12} xs={12}>
                            <label style={{color:"black"}}>
                                Amx
                        </label>
                        </GridItem>
                        {Amxdata}
                    </GridContainer >
                </div>
            }
            {this.state.selectedBidder.includes("adsolut") &&
                <div className={classes.bidderDetails}>
                    <GridContainer >
                        <GridItem lg={12} md={12} sm={12} xs={12}>
                            <label style={{color:"black"}}>
                                Adsoult
                        </label>
                        </GridItem>
                        {Adsolutdata}
                    </GridContainer >
                </div>
            }
            {this.state.selectedBidder.includes("quantumdex") &&
                <div className={classes.bidderDetails}>
                    <GridContainer >
                        <GridItem lg={12} md={12} sm={12} xs={12}>
                            <label style={{color:"black"}}>
                                Quantumdex
                        </label>
                        </GridItem>
                        {Quantumdexdata}
                    </GridContainer >
                </div>
            }
            {this.state.selectedBidder.includes("emx_digital") &&
                <div className={classes.bidderDetails}>
                    <GridContainer >
                        <GridItem lg={12} md={12} sm={12} xs={12}>
                            <label style={{color:"black"}}>
                                Emx_Digital
                        </label>
                        </GridItem>
                        {EmxDigitaldata}
                    </GridContainer >
                </div>
            }
        </div>


    }
    renderAd = () => {
        const classes = this.props.classes;
        return <GridContainer justify="center">
            <GridItem xs={12} sm={12} md={8} lg={8} >
                <Card>
                    <CardHeader color="rose" icon>
                        <CardIcon color="rose">
                            <Assignment />
                        </CardIcon>
                        <h4 className={classes.cardIconTitle}> New Adunit Creation</h4>
                    </CardHeader>
                    <CardBody   >
                        <GridContainer className={classes.SelectCustom} style={{ margitnBottom: "15px" }} >
                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="AdUnitName" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.addAdUnit(event.target.value, "name") }} />
                            </GridItem>
                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Type</InputLabel>
                                    <Select className={classes.SelectDropdown}
                                        native

                                        onChange={this.updateType}

                                        label="select"
                                        inputProps={{
                                            name: 'BankDetails',
                                            id: 'outlined-age-native-simple',
                                        }}>
                                        <option aria-label="None" value="" />
                                        {this.state.Type.map((item, key) => (
                                            <option value={item}  >{item}</option>
                                        ))}
                                    </Select>
                                </FormControl>
                            </GridItem>

                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Ad Format</InputLabel>
                                    <Select className={classes.SelectDropdown}
                                        native
                                        onChange={this.updatesAdFormat}
                                        label="select"
                                        inputProps={{
                                            name: 'BankDetails',
                                            id: 'outlined-age-native-simple',
                                        }}>
                                        <option aria-label="None" value="" />
                                        {this.state.adFormat.map((item, key) => (
                                            <option value={item}  >{item}</option>
                                        ))}
                                    </Select>
                                </FormControl>
                            </GridItem>

                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="Element Selector" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.addAdUnit(event.target.value, "elementSector") }} />
                            </GridItem>
                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="Ad Element Selector" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.addAdUnit(event.target.value, "adElementSector") }} />
                            </GridItem>
                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Devices</InputLabel>
                                    <Select
                                        labelId="demo-mutiple-checkbox-label"
                                        id="demo-mutiple-checkbox"
                                        multiple
                                        value={this.state.selectedDimention}
                                        onChange={this.insertForWebsitePage}
                                        input={<Input />}
                                        renderValue={(selected) => selected.join(', ')}

                                    >
                                        {this.state.Dimention.map((element) => (
                                            <MenuItem key={element.name} value={element.name}>
                                                <Checkbox checked={this.state.selectedDimention.indexOf(element.name) > -1} />
                                                <ListItemText primary={element.name} />
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>
                            </GridItem>


                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="Div Id" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.addAdUnit(event.target.value, "div_id") }} />
                            </GridItem>

                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Operation</InputLabel>
                                    <Select className={classes.SelectDropdown}
                                        native

                                        onChange={this.updateForOperation}

                                        label="select"
                                        inputProps={{
                                            name: 'BankDetails',
                                            id: 'outlined-age-native-simple',
                                        }}>
                                        <option aria-label="None" value="" />
                                        {this.state.operation.map((item, key) => (
                                            <option value={item}  >{item}</option>
                                        ))}
                                    </Select>
                                </FormControl>

                            </GridItem>
                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="Layout" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.addAdUnit(event.target.value, "layout") }} />
                            </GridItem>


                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="Refresh Duration" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.addAdUnit(event.target.value, "refreshDurtion") }} />
                            </GridItem>


                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Refresh Enable</InputLabel>
                                    <Select className={classes.SelectDropdown}
                                        native

                                        onChange={this.updateForRefreshEnable}

                                        label="select"
                                        inputProps={{
                                            name: 'BankDetails',
                                            id: 'outlined-age-native-simple',
                                        }}>
                                        <option aria-label="None" value="" />
                                        {this.state.refreshEnable.map((item, key) => (
                                            <option value={item}  >{item}</option>
                                        ))}
                                    </Select>
                                </FormControl>

                            </GridItem>

                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                {/* <FormControl variant="outlined" className={classes.formControl}>
                                                <InputLabel htmlFor="outlined-age-native-simple">Ad Sizes</InputLabel>
                                                <Select className={classes.SelectDropdown}
                                                    native
                                                    onChange={this.selectedSize}
                                                    label="select"
                                                    inputProps={{
                                                        name: 'BankDetails',
                                                        id: 'outlined-age-native-simple',
                                                    }}>
                                                    <option aria-label="None" value="" />
                                                    {this.state.adSize.map((item, key) => (
                                                        <option value={item}  >{item}</option>
                                                    ))}
                                                </Select>
                                            </FormControl> */}
                                <FormControl variant="outlined" className={classes.formControl}>
                                    {/* <InputLabel htmlFor="outlined-age-native-simple">Ad Unit</InputLabel> */}
                                    <Autocomplete
                                        multiple
                                        id="checkboxes-tags-demo"
                                        className={classes.adUnits}
                                        options={this.state.adSize}
                                        disableCloseOnSelect
                                        getOptionLabel={(option) => option}
                                        renderOption={(option, { selected }) => (
                                            <React.Fragment>
                                                <Checkbox
                                                    icon={icon}

                                                    checkedIcon={checkedIcon}
                                                    style={{ marginRight: 8 }}
                                                    checked={selected}
                                                    // checked={this.state.selectedSize.includes(option)}
                                                    onClick={() => this.selectedSize(option)}
                                                />
                                                {option}
                                            </React.Fragment>
                                        )}

                                        renderInput={(params) => (
                                            <TextField {...params} variant="outlined" label="Ad Sizes " />
                                        )}
                                    />

                                </FormControl>

                            </GridItem>


                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField multiline rows={5} className={classes.textfields} label="CSS" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.addAdUnit(event.target.value, "css") }} />
                            </GridItem>



                            {this.state.selectedTypes === "DFP" &&
                                <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                    <FormControl variant="outlined" className={classes.formControl}>
                                        <InputLabel htmlFor="outlined-age-native-simple">DFP Account Number</InputLabel>
                                        <Select className={classes.SelectDropdown}
                                            native

                                            onChange={this.updatesDfpAccountNo}

                                            label="select"
                                            inputProps={{
                                                name: 'BankDetails',
                                                id: 'outlined-age-native-simple',
                                            }}>
                                            <option aria-label="None" value="" />
                                            {this.state.DFPAccountNumber.map((item, key) => (
                                                <option value={item}  >{item}</option>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </GridItem>
                            }
                            {this.state.selectedTypes === "CustomJS" &&
                                <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                    <TextField multiline rows={5} className={classes.textfields} label="Custom JS Data" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                        onChange={(event) => { this.addAdUnit(event.target.value, "customJsData") }} />
                                </GridItem>
                            }
                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Is Prebid Enabled</InputLabel>
                                    <Select className={classes.SelectDropdown}
                                        native

                                        onChange={this.updateForPrebidEnable}

                                        label="select"
                                        inputProps={{
                                            name: 'isPrebidEnabled',
                                            id: 'outlined-age-native-simple',
                                        }}>
                                        <option aria-label="None" value="" />
                                        {this.state.prebidEnable.map((item, key) => (
                                            <option value={item}  >{item}</option>
                                        ))}
                                    </Select>
                                </FormControl>
                            </GridItem>

                        </GridContainer>
                        {/*   <GridContainer >
                                        <GridItem xs={12} md={12} lg={4} className={classes.textfieldsgrid}>
                                        <FormControl variant="outlined" className={classes.formControl}>
                                                <InputLabel htmlFor="outlined-age-native-simple">Bidder</InputLabel>
                                                <Select className={classes.SelectDropdown}
                                                    native
                                                  
                                                    onChange={this.updateForBidderEnable}
    
                                                    label="select"
                                                    inputProps={{
                                                        name: 'isPrebidEnabled',
                                                        id: 'outlined-age-native-simple',
                                                    }}>
                                                    <option aria-label="None" value="" />
                                                    {this.state.bidder.map((item, key) => (
                                                        <option value={item}  >{item}</option>
                                                    ))}
                                                </Select>
                                            </FormControl>
                                        </GridItem> */}
                                         {this.state.selectedprebidEnable === "Yes" &&
                                 <GridContainer >
                            <GridItem xs={12} md={12} lg={4} className={classes.textfieldsgrid}>
                                <FormControl className={classes.formControl}>
                                    <Autocomplete
                                        multiple
                                        id="checkboxes-tags-demo"
                                        className={classes.bidderDisplay}
                                        options={this.state.bidder}
                                        /* onChange={(event,value,reason)=>{console.log(event + value + reason);}} */
                                        onChange={(event, value, reason) => this.deleteBidder(event, value, reason)}
                                        getOptionLabel={(option) => option}

                                        renderOption={(option, { selected }) => (
                                            <React.Fragment>
                                                <Checkbox
                                                    icon={icon}

                                                    checkedIcon={checkedIcon}
                                                    style={{ marginRight: 8 }}
                                                    checked={selected}


                                                />
                                                {option}

                                            </React.Fragment>
                                        )}

                                        renderInput={(params) => (
                                            <TextField {...params} variant="outlined" label="Bidder " />
                                        )}
                                    />
                                </FormControl>
                            </GridItem>

                        </GridContainer>}
                        {this.state.selectedprebidEnable === "Yes" && this.bidderRender()}

                        {/*     </GridContainer> */}

                        <GridContainer style={{ marginTop: "10px" }}>
                            <GridItem xs={12} md={12} lg={12} className={classes.textfieldsgrid}>
                                <div className={classes.root2} >
                                    <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" color="primary" onClick={this.submitDetails} >
                                        Submit  </MButton> </span>

                                </div>
                            </GridItem>

                        </GridContainer>
                    </CardBody>
                </Card>
            </GridItem>
        </GridContainer >

    }




    render() {
        const classes = this.props.classes;
        return (
            <div>
                {this.renderAd()}
            </div>
        )
    }
}
const AdUnitHOC = withStyles(styles)(AdUnit);
export default connect(mapStateToProps, mapDispatchToProps)(AdUnitHOC);