import React, { Component } from "react";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Checkbox from '@material-ui/core/Checkbox';
import Chip from '@material-ui/core/Chip';
import InputLabel from '@material-ui/core/InputLabel';
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import { connect } from 'react-redux';
import ListItemText from '@material-ui/core/ListItemText';
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import Card from "components/Card/Card.js";
import Button from "components/CustomButtons/Button.js";
import Assignment from "@material-ui/icons/Assignment";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from '@material-ui/core/IconButton';
import Input from '@material-ui/core/Input';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import { SERVER_URL } from "../../variables/constants";
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import MButton from '@material-ui/core/Button';
import Paper from "material-ui/Paper";
import Autocomplete from '@material-ui/lab/Autocomplete';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import CloseIcon from "@material-ui/icons/Close";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
const styles = {
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    },
    root: {
        ' & .makeStyles-card-194': {
            width: "70%",
            marginLeft: "200px",
        }
    }
    ,
    adUnits: {
        ' & .MuiAutocomplete-input ': {
            padding: "1px !important"
        }
    }
}

class AdUnitPageView extends Component {

    constructor(props) {
        super(props);
        this.state = {
            pageCheckType: [
                "Contains",
                "Equals",
                "Regex"
            ],
            Type: [
                "DFP",
                "CustomJS"
            ],

            adFormat: [
                "Banner",
                "Video",
                "Interstitial",
                "inImage",
                "Sticky"
            ],
            DFPAccountNumber: [
                "21854674376",
                "116865642"
            ]
            ,
            Dimention: [
                "Mobile",
                "Tablet",
                "DeskTop"
            ],
            selectedDimention: [],
            refreshEnable: [
                "Yes",
                "No"
            ],
            selectedRefreshEnable: [],
            label: '',
            pageCheckValue: '',
            pageCheckTypes: '',
            selectedTypes: '',
            adUnitName: '',
            elementSector: '',
            adElementSector: '',
            css: '',
            refreshDurtion: '',
            refreshEnabled: '',
            dfpAccountNo: '',
            device: '',
            customJsData: '',
            type: '',
            adFormats: '',
            adSize: [],
            size: '',
            divId:'',
            operation:[
                'append',
                'prepend'
            ],
            selectedOperation:'',
            layout:'',
        }
    }


    componentDidMount = () => {
        const ID = this.props.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/websitepagead/${ID}`, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                this.setState({ adUnitName: data.name })
                this.setState({ adFormats: data.adFormat })
                this.setState({ elementSector: data.elementSector })
                this.setState({ adElementSector: data.adElementSector })
                this.setState({ css: data.css })
                this.setState({ refreshDurtion: data.refreshDurtion })
                this.setState({ refreshEnabled: data.refreshEnabled })
                this.setState({ dfpAccountNo: data.dfpAccountNo })
                this.setState({ device: data.device })
                this.setState({ customJsData: data.customJsData }) 
                this.setState({ selectedOperation: data.operation })
                this.setState({ divId: data.divId })
                this.setState({ layout: data.layout })
               
                var list = data.size.split(",");
                var list2 = [];
                for (var i = 0; i < list.length; i += 2) {
                    list2.push(list[i] + "," + list[i+1]);
                }
                console.log(list2);
                this.setState({ adSize: list2 })
                this.setState({ type: data.type });
                var valueToPass = [];
                const value = JSON.parse(this.state.device)
                if (value.mobile) {
                    valueToPass.push("mobile")
                }
                if (value.tablet) {
                    valueToPass.push("tablet")
                }
                if (value.desktop) {
                    valueToPass.push("desktop")
                }
                //  this.setState({selectedDimention:valueToPass})
            }).catch(error => { console.log(error); })
        this.loadAdsize();

    }
    updateType = (event) => {
        console.log(event.target.value);
        this.setState({ selectedTypes: event.target.value })
    }
    insertForWebsitePage = (event) => {
        this.setState({ selectedDimention: event.target.value });
        console.log(this.state.selectedDimention);

    }
    loadAdsize = () => {

        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/adsize/`, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                this.setState({ size: data })
            }).catch(error => { console.log(error); })
    }
    UpdateAdunit = (value, fieldName) => {
        if (fieldName === 'adUnitName') {
            this.setState({ adUnitName: value })
        }
        if (fieldName === 'elementSector') {
            this.setState({ elementSector: value })
        }
        if (fieldName === 'adElementSector') {
            this.setState({ adElementSector: value })
        }
        if (fieldName === 'css') {
            this.setState({ css: value })
        }
        if (fieldName === 'refreshDurtion') {
            this.setState({ refreshDurtion: value })
        }

        if (fieldName === 'customJsData') {
            this.setState({ customJsData: value })
        }
        if(fieldName==='divId'){
            this.setState({divId:value})
        }
        if(fieldName==='layout'){
            this.setState({layout:value})
        }
    }

    updateAdFormat = (event) => {

        this.setState({ adFormats: event.target.value })
        console.log(this.state.adFormats)
    }
    updateForRefreshEnable = (event) => {
        this.setState({ refreshEnabled: event.target.value })
        console.log(this.state.refreshEnabled)
    }
    updatesDfpAccountNo = (event) => {
        this.setState({ dfpAccountNo: event.target.value })
        console.log(this.state.dfpAccountNo)
    }
    updateSize = (option) => {

        this.setState(prevState => ({
            adSize: [...prevState.adSize, option]
        }))
    }
    updateOperation=(event)=>{
        this.setState({selectedOperation:event.target.value})
    }

    submitDetails = () => {
        console.log(this.state.adSize)
        var size='';
        console.log(this.state.adSize)
        size=this.state.adSize.toString();
        console.log(size)
        console.log(this.state.selectedDimention)
        const IDwebsite = this.props.idWebsite;
        let Mobilestatus = false
        let tabletstatus = false
        let desktopstatus = false
        if (this.state.selectedDimention.includes("Mobile")) {
            Mobilestatus = true
        } if (this.state.selectedDimention.includes("Tablet")) {
            tabletstatus = true
        } if (this.state.selectedDimention.includes("DeskTop")) {
            desktopstatus = true
        }
        var deviceStatus = { "mobile": Mobilestatus, "tablet": tabletstatus, "desktop": desktopstatus }
        var obj = JSON.stringify(deviceStatus);
        console.log(obj)
        var request = {};
        var CSS=this.state.css;
       var newString = CSS.replace(/\s+/g,' ').trim();

       var Customjsdata=this.state.customJsData;
       var customdataJS
       if(Customjsdata!==null){
        customdataJS=Customjsdata.replace(/\s+/g,' ').trim();
       }
        request.name = this.state.adUnitName;
        request.adFormat = this.state.adFormats;
        const IDS = this.props.id;
        request.elementSector = this.state.elementSector;
        request.adElementSector = this.state.adElementSector;
        request.css = newString;
        request.size = size;
        request.customJsData =customdataJS;
        request.dfpAccountNo = this.state.dfpAccountNo;
        request.refreshDurtion = this.state.refreshDurtion;
        request.refreshEnabled = this.state.refreshEnabled;
        request.divId = this.state.divId;
        request.operation = this.state.selectedOperation;
        request.layout = this.state.layout;
        
        request.device = obj;
        console.log(request)
         const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.put(`${SERVER_URL}/api/websitepagead/${IDS}`, request, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                alert("data submitted");
            }).catch(error => { console.log(error); }) 
    }
    renderAd = () => {
        const classes = this.props.classes;
        return <GridContainer justify="center">
            <GridItem xs={12} sm={12} md={8} lg={8} >
                <Card>
                    <CardHeader color="rose" icon>
                        <CardIcon color="rose">
                            <Assignment />
                        </CardIcon>
                        <h4 className={classes.cardIconTitle}>Adunit </h4>
                    </CardHeader>
                    <CardBody   >
                        <GridContainer className={classes.SelectCustom} style={{ margitnBottom: "15px" }} >
                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="AdUnitName" value={this.state.adUnitName} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.UpdateAdunit(event.target.value, "adUnitName") }} />
                            </GridItem>

                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="AdUnitType" value={this.state.type} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.UpdateAdunit(event.target.value, "type") }} />
                            </GridItem>
                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Ad Format</InputLabel>
                                    <Select className={classes.SelectDropdown}
                                        native
                                        value={this.state.adFormats}
                                        onChange={this.updateAdFormat}

                                        label="select"
                                        inputProps={{
                                            name: 'BankDetails',
                                            id: 'outlined-age-native-simple',
                                        }}>
                                        <option aria-label="None" value="" />
                                        {this.state.adFormat.map((item, key) => (
                                            <option value={item}  >{item}</option>
                                        ))}
                                    </Select>
                                </FormControl>

                            </GridItem>

                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="Element Selector" variant="outlined" value={this.state.elementSector} id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.UpdateAdunit(event.target.value, "elementSector") }} />
                            </GridItem>
                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="Ad Element Selector" variant="outlined" value={this.state.adElementSector} id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.UpdateAdunit(event.target.value, "adElementSector") }} />
                            </GridItem>
                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Devices</InputLabel>
                                    <Select
                                        labelId="demo-mutiple-checkbox-label"
                                        id="demo-mutiple-checkbox"
                                        multiple
                                        value={this.state.selectedDimention}
                                        onChange={this.insertForWebsitePage}
                                        input={<Input />}
                                        renderValue={(selected) => selected.join(', ')}

                                    >
                                        {this.state.Dimention.map((element) => (
                                            <MenuItem key={element} value={element}>
                                                <Checkbox checked={this.state.selectedDimention.indexOf(element) > -1} />
                                                <ListItemText primary={element} />
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>
                            </GridItem>


                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="div Id" value={this.state.divId} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.UpdateAdunit(event.target.value, "divId") }} />
                            </GridItem>

                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Operation</InputLabel>
                                    <Select className={classes.SelectDropdown}
                                        native
                                        value={this.state.selectedOperation}
                                        onChange={this.updateOperation}

                                        label="select"
                                        inputProps={{
                                            name: 'BankDetails',
                                            id: 'outlined-age-native-simple',
                                        }}>
                                        <option aria-label="None" value="" />
                                        {this.state.operation.map((item, key) => (
                                            <option value={item}  >{item}</option>
                                        ))}
                                    </Select>
                                </FormControl>

                            </GridItem>

                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="Layout" value={this.state.layout} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.UpdateAdunit(event.target.value, "layout") }} />
                            </GridItem>



                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField className={classes.textfields} label="Refresh Duration" value={this.state.refreshDurtion} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.UpdateAdunit(event.target.value, "refreshDurtion") }} />
                            </GridItem>
                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    <InputLabel htmlFor="outlined-age-native-simple">Refresh Enable</InputLabel>
                                    <Select className={classes.SelectDropdown}
                                        native
                                        value={this.state.refreshEnabled}
                                        onChange={this.updateForRefreshEnable}

                                        label="select"
                                        inputProps={{
                                            name: 'BankDetails',
                                            id: 'outlined-age-native-simple',
                                        }}>
                                        <option aria-label="None" value="" />
                                        {this.state.refreshEnable.map((item, key) => (
                                            <option value={item}  >{item}</option>
                                        ))}
                                    </Select>
                                </FormControl>

                            </GridItem>

                            <GridItem lg={4} md={5} className={classes.textfieldsgrid}>

                                <FormControl variant="outlined" className={classes.formControl}>
                                    {/* <InputLabel htmlFor="outlined-age-native-simple">Ad Unit</InputLabel> */}
                                    <Autocomplete
                                        multiple
                                        id="checkboxes-tags-demo"
                                        className={classes.adUnits}
                                        options={this.state.size}
                                        disableCloseOnSelect
                                        getOptionLabel={(option) => option}
                                        renderOption={(option, { selected }) => (
                                            <React.Fragment>
                                                <Checkbox
                                                    icon={icon}

                                                    checkedIcon={checkedIcon}
                                                    style={{ marginRight: 8 }}
                                                    // checked={selected}
                                                     checked={this.state.adSize.includes(option)}
                                                    onClick={() => this.updateSize(option)}
                                                />
                                                {option}
                                            </React.Fragment>
                                        )}

                                        renderInput={(params) => (
                                            <TextField {...params} variant="outlined" label="Ad Sizes " />
                                        )}
                                    />

                                </FormControl>
                                {/* <FormControl variant="outlined" className={classes.formControl}>
                                                <InputLabel htmlFor="outlined-age-native-simple">Ad Size</InputLabel>
                                                <Select className={classes.SelectDropdown}
                                                    native
                                                    value={this.state.size}
                                                    onChange={this.updateSize}
    
                                                    label="select"
                                                    inputProps={{
                                                        name: 'BankDetails',
                                                        id: 'outlined-age-native-simple',
                                                    }}>
                                                    <option aria-label="None" value="" />
                                                    {this.state.adSize.map((item, key) => (
                                                        <option value={item}  >{item}</option>
                                                    ))}
                                                </Select>
                                            </FormControl> */}

                            </GridItem>

                           
                            <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                <TextField multiline rows={5} className={classes.textfields} label="CSS" variant="outlined" value={this.state.css} id="outlined-size-small" size="small" style={{ width: "100%" }}
                                    onChange={(event) => { this.UpdateAdunit(event.target.value, "css") }} />
                            </GridItem>
                            

                            
                           
                            {this.state.type === "DFP" &&
                                <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                    <FormControl variant="outlined" className={classes.formControl}>
                                        <InputLabel htmlFor="outlined-age-native-simple">DFP Account Number</InputLabel>
                                        <Select className={classes.SelectDropdown}
                                            native
                                            value={this.state.dfpAccountNo}
                                            onChange={this.updatesDfpAccountNo}

                                            label="select"
                                            inputProps={{
                                                name: 'BankDetails',
                                                id: 'outlined-age-native-simple',
                                            }}>
                                            <option aria-label="None" value="" />
                                            {this.state.DFPAccountNumber.map((item, key) => (
                                                <option value={item}  >{item}</option>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </GridItem>
                            }
                            {this.state.type === "CustomJS" &&
                                <GridItem lg={4} xs={12} md={6} className={classes.textfieldsgrid}>
                                    <TextField multiline rows={5}  className={classes.textfields} label="Custom JS Data" value={this.state.customJsData} variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                        onChange={(event) => { this.UpdateAdunit(event.target.value, "customJsData") }} />
                                </GridItem>
                            }
                        </GridContainer>

                        <GridContainer >
                            <GridItem xs={12} md={12} lg={12} className={classes.textfieldsgrid}>
                                <div className={classes.root2} >
                                    <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" color="primary" onClick={this.submitDetails} >
                                        Submit  </MButton> </span>

                                </div>
                            </GridItem>

                        </GridContainer>
                    </CardBody>
                </Card>
            </GridItem>
        </GridContainer >

    }




    render() {
        const classes = this.props.classes;
        return (
            <div>
                {this.renderAd()}
            </div>
        )
    }
}
const AdUnitPageViewHOC = withStyles(styles)(AdUnitPageView);
export default connect(mapStateToProps, mapDispatchToProps)(AdUnitPageViewHOC);