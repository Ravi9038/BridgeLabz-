import React, { Component } from "react";
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
// import InfoOutline from "@material-ui/icons/InfoOutline";

// core components
import InputBase from '@material-ui/core/InputBase';
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import axios from 'axios';
import { SERVER_URL } from "../../variables/constants";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import PermContactCalendarIcon from '@material-ui/icons/PermContactCalendar';
//import styles from "assets/jss/material-dashboard-pro-react/views/dashboardStyle.js";

// @material-ui/core components

// material-ui icons
import Globe from "@material-ui/icons/Public";
import Bankicon from "@material-ui/icons/AccountBalance";
import Profileicon from "@material-ui/icons/Person"
import MButton from '@material-ui/core/Button';
// core components

import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import InputAdornment from '@material-ui/core/InputAdornment';
import Add from '@material-ui/icons/Add';
import Remove from '@material-ui/icons/Remove';
import AddIcon from '@material-ui/icons/Add';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import NativeSelect from '@material-ui/core/NativeSelect';
import { BorderAllRounded } from "@material-ui/icons";


const styles = {

    cssLabelRed: {
        color: 'red'
    },
    cssLabelBlue: {
        color: 'blue'
    },

    cssFocused: {},

    notchedOutlineRed: {
        borderColor: 'red !important'
    },
    notchedOutlineBlue: {
        borderColor: 'blue !important'
    },
    checkboxroot: {
        '& .MuiSvgIcon-root': {
            width: "0.7em",
            height: "0.7em"
        },
    },
    root: {
        '& .MuiIconButton-colorSecondary': {
            padding: "2px",
        },
        '& .PrivateSwitchBase-root-221': {
            padding: "2px",

        },
        '& .MuiFormControlLabel-root': {
            paddingTop: "3px!important",
            marginRight: "3px!important",
            marginLeft: "0px !important"

        },
        '& .MuiTypography-body1': {
            fontSize: "15px"
        },
        '& .MuiFormControl-root': {
            //margin: theme.spacing(1),
            width: "100%",

        },
        '& .MuiGrid-container': {
            paddingLeft: "6px",
            paddingRight: "6px"
        },
        '& .MuiGrid-grid-md-10': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-md-11': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-md-6': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-md-5': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-md-4': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-md-3': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-md-2': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-md-12': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-lg-10': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-lg-11': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-lg-6': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-lg-5': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-lg-4': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-lg-3': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-lg-2': {
            padding: "0 5px !important"
        },
        '& .MuiGrid-grid-lg-12': {
            padding: "0 5px !important"
        },
        '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
            transform: "translate(14px, -6px) scale(0.85)"
        },
        '& .MuiInputLabel-outlined': {
            transform: "translate(14px, 14px) scale(1)",
            fontSize: "0.9rem !important"
        },
        '& .MuiOutlinedInput-input': {
            paddingTop: "10px",
            paddingBottom: "10px",
            paddingLeft: "10px",
            paddingRight: "10px"
        },
        '& .MuiFormControl-root ': {
            width: "100%",
            marginTop: "10px",
            marginBottom: "10px",
            marginLeft: "0px",
            marginRight: "0px",


        },
        '& .makeStyles-grid-166': {
            padding: "0 5px !important"
        },
        '& .MuiOutlinedInput-adornedStart': {
            paddingLeft: "23px"
        },
        '& .makeStyles-grid-167': {
            padding: "0 5px !important"
        },

        '& .MuiGrid-grid-lg-1': {
            padding: "0 2px !important",
            textAlign: "center"
        },
        '& .MuiGrid-grid-md-1': {
            padding: "0 2px !important",
            textAlign: "center"
        },
        '& #document-type': {
            textAlign: "center!important"
        },

        '&  .MuiFormLabel-root.Mui-disabled': {
            color: "#3f51b5"
        },
        '& .MuiInputBase-root.Mui-disabled ': {
            color: "#000000"

        },
    },

    root2: {
        '& > *': {
            //margin: theme.spacing(1),
            float: "right"
        },
    },
    heading: {
        color: "black!important"
    },
    InsideCard: {
        padding: "0 5px !important"
    },
    headingStyle: {
        marginBottom: "0px",
        fontSize: "1.1em",
        fontWeight: "500",
        marginTop: "25px",
    },
    checkbox: {
        fontSize: "13px"
    },
    textfieldslno: {
        textAlign: "center !important",
        padding: "0px 5px!important"
    },
    AddButton: {
        padding: "0px 5px!important"
    },


};

class CreateContact extends Component {
    constructor (props) {
        super(props);
        this.state = {
            bankDetails: [{ name: '' }],
            reBankDetails: [{ name: '' }],
            contactDetails: [{ name: '' }],
            websiteDetails: [{ name: '' }],
            addressLineOne: '',
            addressLineTwo: '',
            postOffice: '',
            taluk: '',
            district: '',
            state: '',
            companyName: '',
            gstin: '',
            type: '',
            email: '',
            contactPersonName: '',
            contactPersonNumber: '',
            newUserId: '',
            border: "",
            borderColor: '',
            borderRadius: "",
            outline: "",
            accountNumber: '',
            reAccountNumber: '',
            errors: {
                email: "",
                gstin: "",
            }

        }
    }

    componentDidMount = () => {
        this.setState({ type: this.props.type });

    }

    addBank = () => {
        var row = {};
        var newStateArray = [...this.state.bankDetails];
        newStateArray.push(row);
        this.setState(() => {
            return {
                bankDetails: newStateArray
            };
        });


    }
    removeBank = (id) => {
        var newStateArray = [...this.state.bankDetails];
        if (newStateArray.length > 1) {
            newStateArray.pop();
        }
        this.setState(() => {
            return {
                bankDetails: newStateArray
            };
        });
    }

    addContact = () => {
        var row = {};
        var newStateArray = [...this.state.contactDetails];
        newStateArray.push(row);
        this.setState(() => {
            return {
                contactDetails: newStateArray
            };
        });

    }

    addWebsite = () => {
        var row = {};
        var newStateArray = [...this.state.websiteDetails];
        newStateArray.push(row);
        this.setState(() => {
            return {
                websiteDetails: newStateArray
            };
        });

    }

    removeWebSite = (id) => {
        var newStateArray = [...this.state.websiteDetails];
        if (newStateArray.length > 1) {
            newStateArray.pop();
        }
        this.setState(() => {
            return {
                websiteDetails: newStateArray
            };
        });

    }

    removeConatct = (id) => {

        var newStateArray = [...this.state.contactDetails];
        if (newStateArray.length > 1) {
            newStateArray.pop();
        }
        this.setState(() => {
            return {
                contactDetails: newStateArray
            };
        });
    }


    updateBankDetail(key, value, fieldName) {


        console.log(value);
        console.log(this.state.bankDetails);
        console.log("reBankDetails", this.state.reBankDetails);

        let lbankDetails = this.state.bankDetails;
        lbankDetails[key][fieldName] = value;
        this.setState({ bankDetails: lbankDetails });
        this.setState({ reBankDetails: lbankDetails });
        console.log(this.state.bankDetails);
        let num1 = 0;
        let num2 = 0;
        this.state.bankDetails.map(({ accountNumber }) => num1 = accountNumber);
        this.state.reBankDetails.map(({ reAccountNumber }) => num2 = reAccountNumber);
        console.log("Accoutnt Number", num1);
        console.log("Re-Account Number", num2);

        if (num1 === num2) {

            this.setState({
                reAccColor: '',

            });
        } else {
            this.setState({
                reAccColor: 'red',

            });
        }
    }


    editBankDetails = () => {

        const USER_ID = this.state.newUserId;

        for (let i = 0; i < this.state.bankDetails.length; i++) {
            if (!this.state.bankDetails[i].hasOwnProperty('userId')) {
                this.state.bankDetails[i].userId = USER_ID;
            }
        }
        console.log(this.state.bankDetails);
        let accNumber = this.state.accountNumber;
        let reAccNumber = this.state.reAccountNumber;

        if (accNumber === "" && reAccNumber === "") {

            this.setState({
                reAccColor: "red",
            });
            return -1;
        }
        axios.post(`${SERVER_URL}/api/bankdetails/add`, this.state.bankDetails)
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                alert("data submitted");
            }).catch(error => { console.log(error); })
    }


    renderBankAccountDetails = () => {
        const classes = this.props.classes;

        return <GridContainer className={ classes.gridcontainer }>
            <GridItem lg={ 12 } className={ classes.InsideCard } style={ { padding: "0px 5px!important" } } >
                { this.state.bankDetails.map((author, idx) => (
                    <Card key={ idx + 1 }>
                        <CardBody className={ classes.CardBody }>
                            <GridContainer className={ classes.gridcontainer }>
                                <GridItem lg={ 6 } md={ 6 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Bank Account Number" type="password"
                                        InputLabelProps={ {
                                            style: {
                                                color: this.state.reAccColor,
                                            },
                                        } }
                                        InputProps={ {
                                            classes: {

                                                notchedOutline: this.state.reAccColor && classes.notchedOutlineRed
                                            }

                                        } }
                                        variant="outlined"
                                        id="accountNumber"
                                        size="small"
                                        style={ { width: "100%" } }
                                        onChange={ (event) => { this.updateBankDetail(idx, event.target.value, "accountNumber") } }
                                        required />
                                </GridItem>

                                <GridItem lg={ 6 } md={ 6 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Re-enter Bank Account Number" type="text"
                                        InputLabelProps={ {
                                            style: {
                                                color: this.state.reAccColor,
                                            },
                                        } }
                                        InputProps={ {
                                            classes: {

                                                notchedOutline: this.state.reAccColor && classes.notchedOutlineRed
                                            }

                                        } }
                                        variant="outlined"
                                        id="reAccountNumber"
                                        size="small"
                                        style={ { width: "100%" } }
                                        onChange={ (event) => { this.updateBankDetail(idx, event.target.value, "reAccountNumber") } }
                                        required />

                                </GridItem>

                            </GridContainer>
                            <GridContainer className={ classes.gridcontainer }>
                                <GridItem lg={ 3 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Nick Name" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => { this.updateBankDetail(idx, event.target.value, "payeeName") } } />
                                </GridItem>
                                <GridItem lg={ 4 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="IFSC" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => { this.updateBankDetail(idx, event.target.value, "ifscCode") } } />
                                </GridItem>
                                <GridItem lg={ 4 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="SWIFT Code" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => { this.updateBankDetail(idx, event.target.value, "ifscSwiftCode") } } />
                                </GridItem>
                                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
                                    <TextField
                                        id="document-type"
                                        InputProps={ {
                                            autoComplete: 'off',
                                            readOnly: true,
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <AddIcon style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                                                </InputAdornment>
                                            ),
                                        } }
                                        label="Add"
                                        onClick={ () => { this.addBank() } }
                                        variant="outlined" />
                                </GridItem>
                                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
                                    <TextField
                                        id="document-type"
                                        InputProps={ {
                                            autoComplete: 'off',
                                            readOnly: true,
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <Remove style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                                                </InputAdornment>
                                            ),
                                        } }
                                        label="Remove"
                                        onClick={ () => { this.removeBank(idx) } }
                                        variant="outlined" />
                                </GridItem>


                            </GridContainer>

                        </CardBody>
                    </Card>
                )) }
            </GridItem>
        </GridContainer >
    }

    updatesmaplecontact(key, value, fieldName) {
        let lcontactDetails = this.state.contactDetails;
        lcontactDetails[key][fieldName] = value;
        this.setState({ contactDetails: lcontactDetails });
        console.log(this.state.contactDetails)
    }
    updateWebsite(key, value, fieldName) {
        let lwebsiteDetails = this.state.websiteDetails;
        // lwebsiteDetails[key][fieldName] = value;
        var lResult = document.getElementById("outlined-size-small1");
        var re = /^https:\/\/www.|www.|https:\/\/|\/$/;
        if (!re.test(value)) {

            lwebsiteDetails[key][fieldName] = value;

        } else {
            var result = lResult.value.split(re);
            console.log(result[1]);
            if (result[0] === "") {

                lwebsiteDetails[key][fieldName] = result[1];
                lResult.value = result[1];

            } else {

                lResult.lwebsiteDetails[key][fieldName] = result[0];
                lResult.value = result[0];
            }

        }

        this.setState({ websiteDetails: lwebsiteDetails });
        console.log(this.state.websiteDetails)
    }


    renderContactDetails = () => {
        const classes = this.props.classes;
        return <GridContainer className={ classes.gridcontainer }>
            <GridItem lg={ 12 } className={ classes.InsideCard } style={ { padding: "0px 5px!important" } } >
                { this.state.contactDetails.map((author, idx) => (
                    <Card>
                        <CardBody className={ classes.InsideCardBody }>
                            <GridContainer className={ classes.gridcontainer }>
                                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                                    <TextField className={ classes.textfieldslno } style={ { textAlign: "center !important" } }
                                        id="document-type"
                                        disabled="true"
                                        value="1"
                                        label="S No"
                                        variant="outlined" />
                                </GridItem>
                                <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Level" value="Level1" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                    />
                                </GridItem>
                                <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Name" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => { this.updatesmaplecontact(idx, event.target.value, "name") } } />
                                </GridItem>
                                <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Designation" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => { this.updatesmaplecontact(idx, event.target.value, "designation") } } />
                                </GridItem>
                                <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                                    <FormControl variant="outlined" className={ classes.formControl } >
                                        <InputLabel htmlFor="outlined-age-native-simple" >Select Reporting User</InputLabel>
                                        <Select className={ classes.SelectDropdown }
                                            native
                                            onChange={ (event) => { this.updatesmaplecontact(idx, event.target.value, "idReportingUserName") } }
                                            label="select"
                                            inputProps={ {
                                                name: 'reportingUserName',
                                            } }>
                                            <option aria-label="None" value="" />
                                            { this.state.contactDetails.map((item, key) => (
                                                <option value={ item.idx }  >{ item.username }</option>
                                            )) }

                                        </Select>

                                    </FormControl>
                                </GridItem>
                            </GridContainer>
                            <GridContainer className={ classes.gridcontainer }>
                                <GridItem lg={ 4 } md={ 4 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Contact 1" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => { this.updatesmaplecontact(idx, event.target.value, "contactNumberOne") } } />
                                </GridItem>
                                <GridItem lg={ 4 } md={ 4 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Contact 2" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => { this.updatesmaplecontact(idx, event.target.value, "contactNumberTwo") } } />
                                </GridItem>
                                <GridItem lg={ 4 } md={ 4 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Email Id" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => { this.updatesmaplecontact(idx, event.target.value, "email") } } />
                                </GridItem>
                                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
                                    <TextField
                                        id="document-type"
                                        InputProps={ {
                                            autoComplete: 'off',
                                            readOnly: true,
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <AddIcon style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                                                </InputAdornment>
                                            ),
                                        } }
                                        label="Add"
                                        onClick={ () => { this.addContact() } }
                                        variant="outlined" />
                                </GridItem>
                                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
                                    <TextField
                                        id="document-type"
                                        InputProps={ {
                                            autoComplete: 'off',
                                            readOnly: true,
                                            startAdornment: (
                                                <InputAdornment position="start">
                                                    <Remove style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                                                </InputAdornment>
                                            ),
                                        } }
                                        label="Remove"
                                        onClick={ () => { this.removeConatct(idx) } }
                                        variant="outlined" />
                                </GridItem>

                            </GridContainer>
                        </CardBody>
                    </Card>
                )) }
            </GridItem>
        </GridContainer>

    }

    editAccountDetails = () => {
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        console.log(this.state.type);
        var idRoles = 0;
        if (this.state.type === "advertiser") {
            idRoles = 2;
        }
        else if (this.state.type === "publisher") {
            idRoles = 3;
        }
        else {
            idRoles = 1;
        }

        console.log(idRoles);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        const pKey = this.state.userId;

        let emailId = this.state.email;
        let gstinNum = this.state.gstin;
        console.log(emailId);
        if (emailId === "" && gstinNum === "") {
            this.setState({
                gmailColor: "red",
                gstinColor: "red",
            });
            return -1;
        } else if (gstinNum === "") {
            this.setState({
                gstinColor: "red",
            });
            return -1;
        } else if (emailId === "") {

            this.setState({
                gmailColor: "red",
            });
            return -1;
        } else {

            console.log("both are filled");
        }

        axios.post(`${SERVER_URL}/api/users`, {
            "companyName": this.state.companyName,
            "gstin": this.state.gstin,
            "idRole": idRoles,
            "addressLineOne": this.state.addressLineOne,
            "addressLineTwo": this.state.addressLineTwo,
            "postOffice": this.state.postOffice,
            "taluk": this.state.taluk,
            "district": this.state.district,
            "state": this.state.state,
            "email": this.state.email,
            "password": this.state.email,
            "contactPersonName": this.state.contactPersonName,
            "contactPersonNumber": this.state.contactPersonNumber,
        })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                alert("data submitted");
                this.setState({ newUserId: data.id })
                console.log(this.state.newUserId)
            }).catch(error => {
                alert("Publisher Already Exist");
                console.log(error);
            })
    }

    editContactDetails = () => {

        const USER_ID = this.state.newUserId;

        for (let i = 0; i < this.state.contactDetails.length; i++) {
            if (!this.state.contactDetails[i].hasOwnProperty('userId')) {
                this.state.contactDetails[i].userId = USER_ID;
            }
        }
        console.log(this.state.contactDetails);
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.post(`${SERVER_URL}/api/usercontact/details`, this.state.contactDetails)
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                alert("data submitted");
            }).catch(error => { console.log(error); })
    }

    editWebsiteDetails = () => {
        const USER_ID = this.state.newUserId;

        for (let i = 0; i < this.state.websiteDetails.length; i++) {
            if (!this.state.websiteDetails[i].hasOwnProperty('userId')) {
                this.state.websiteDetails[i].userId = USER_ID;
            }
        }
        console.log(this.state.websiteDetails)

        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

        axios.post(`${SERVER_URL}/api/userwebsite/users`, this.state.websiteDetails)
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                alert("data submitted");

            }).catch(error => {
                alert("something went wrong, PLease try again");
                console.log(error);
            })
    }

    renderWebsites = () => {
        const classes = this.props.classes;
        const websites = this.state.websiteDetails;
        let websiteItems = websites.map((prop, key) => {
            var index = key + 1;
            var id = prop.id;
            console.log(id)
            console.log(key);
            console.log(prop);
            return <GridContainer key={ index } className={ classes.gridcontainer }>

                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                    <TextField className={ classes.textfieldslno } style={ { textAlign: "center !important" } }
                        id="document-type"
                        value={ index }
                        readOnly="true"
                        label="S No"
                        variant="outlined" />
                </GridItem>

                <GridItem lg={ 6 } md={ 6 } className={ classes.textfieldsgrid }>
                    <TextField className={ classes.textfields } label="Website URL" readOnly={ true } variant="outlined" id="outlined-size-small1" size="small" style={ { width: "100%" } }
                        onBlur={ (event) => { this.updateWebsite(key, event.target.value, "hostURL") } }
                    />
                </GridItem>
                <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                    <TextField className={ classes.textfields } label="Website  Name" readOnly={ true } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                        onChange={ (event) => { this.updateWebsite(key, event.target.value, "name") } } />
                </GridItem>

                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
                    <TextField
                        id="document-type"
                        InputProps={ {
                            autoComplete: 'off',
                            readOnly: true,
                            startAdornment: (
                                <InputAdornment position="start">
                                    <AddIcon style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                                </InputAdornment>
                            ),
                        } }
                        label="Add"
                        onClick={ () => { this.addWebsite() } }
                        variant="outlined" />
                </GridItem>

                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
                    <TextField
                        id="document-type"
                        InputProps={ {
                            autoComplete: 'off',
                            readOnly: true,
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Remove style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                                </InputAdornment>
                            ),
                        } }
                        label="Remove"
                        onClick={ () => { this.removeWebSite(key) } }
                        variant="outlined" />
                </GridItem>

                {/* <GridItem lg={5} md={5} className={classes.textfieldsgrid}>
                    <FormControl variant="outlined" className={classes.formControl}>
                        <InputLabel htmlFor="outlined-age-native-simple">Account Number</InputLabel>
                        <Select className={classes.SelectDropdown}
                            native
                            // value={item.accountNumber}
                            onChange={(event) => { this.updatesmaple(id, key, event.target.value, "bankId") }}
                            label="select"
                            inputProps={{
                                name: 'BankDetails',
                                id: 'outlined-age-native-simple',
                            }}>
                            <option aria-label="None" value="" />
                            {this.state.bankDetails.map((item, key) => (
                                <option value={item.id}  >{item.accountNumber}</option>
                            ))}
                        </Select>
                    </FormControl>
                </GridItem> */}

                {/* <GridItem lg={1} md={1} className={classes.AddButton} >
            <TextField className={classes.textfields}
              id="document-type"
              InputProps={{
                autoComplete: 'off',
                readOnly: true,
                startAdornment: (
                  <InputAdornment position="start">
                    <Add style={{ color: 'rgb(76, 175, 80)', cursor: 'pointer' }} className={classes.icon} />
                  </InputAdornment>
                ),
              }}
              label="Add"
              variant="outlined" />
            </GridItem> */}
            </GridContainer>
        })

        return <CardBody className={ classes.CardBody }>
            { websiteItems }
            <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
                <div className={ classes.root2 } >
                    <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="primary" onClick={ this.editWebsiteDetails } >
                        Submit
                    </MButton>
                    </span>
                    {/*
                        <MButton variant="outlined" color="secondary">
                          Reset
                        </MButton>
                        */}
                </div>
            </GridItem>
        </CardBody>

    }


    validateEmail = email => {
        console.log(email);
        if (email === "") {
            this.setState({
                gmailColor: '',

            });
        } else {
            const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (!re.test(email.toLowerCase())) {
                console.log("red");
                this.setState({
                    gmailColor: 'red',

                });
            } else {
                this.setState({ gmailColor: "" });
                console.log("white");
            }
        }

    };

    validateGST = gstin => {

        if (gstin === "") {
            this.setState({
                gstinColor: '',

            });
        } else {
            let regGstin = /\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}/;
            if (!regGstin.test(gstin)) {
                this.setState({ gstinColor: 'red', });
            } else {
                this.setState({ gstinColor: '', });

            }
        }
    }



    handleInputChange = e => {

        console.log(e);
        if (e.target.name === "email") {
            this.validateEmail(e.target.value);
            this.setState({
                email: e.target.value,

            });
        }
        if (e.target.name === "gstin") {

            this.validateGST(e.target.value);
            this.setState({
                gstin: e.target.value
            });
        }

    };


    render() {
        const classes = this.props.classes;

        return <div className={ classes.root }>
            <GridContainer>
                <GridItem lg={ 2 }></GridItem>
                <GridItem xs="12" md="8" lg="8">
                    <Card>
                        <CardHeader color="primary" icon>
                            <CardIcon color="primary">
                                <Profileicon />
                            </CardIcon>
                            <h4 className={ classes.heading }>Profile</h4>
                        </CardHeader>
                        <CardBody className={ classes.CardBody }>
                            <h4 className={ classes.headingStyle }>Primary Information</h4>
                            <GridContainer className={ classes.gridcontainer } style={ { margitnBottom: "15px" } } >
                                <GridItem lg={ 6 } xs={ 12 } md={ 6 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Name of the entity" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => {
                                            this.setState({ "companyName": event.target.value })
                                        } } />

                                </GridItem>

                                <GridItem lg={ 6 } xs={ 12 } md={ 3 } className={ classes.textfieldsgrid } >
                                    <TextField className={ classes.textfields } label="Email" variant="outlined" id="outlined-size-small" size="small"
                                        //style={ styles }
                                        InputLabelProps={ {
                                            style: {
                                                color: this.state.gmailColor,
                                            },
                                        } }
                                        InputProps={ {
                                            classes: {

                                                notchedOutline: this.state.gmailColor && classes.notchedOutlineRed
                                            }

                                        } }
                                        type="email"
                                        name="email"
                                        id="email"
                                        value={ this.state.email }
                                        onChange={ this.handleInputChange }
                                        onBlur={ e => this.validateEmail(e.target.value) }
                                        title="Email"
                                        autoComplete="off"
                                        required
                                    />
                                    <p class="error" style={ { color: 'red' } }>{ this.state.errors.email }</p>
                                </GridItem>
                                <GridItem lg={ 4 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid } >
                                    <TextField className={ classes.textfields } label="GST No" variant="outlined" id="outlined-size-small" size="small"
                                        InputLabelProps={ {
                                            style: {
                                                color: this.state.gstinColor,
                                            },
                                        } }
                                        InputProps={ {
                                            classes: {

                                                notchedOutline: this.state.gstinColor && classes.notchedOutlineRed
                                            }

                                        } }
                                        type="gstin"
                                        name="gstin"
                                        id="gstin"
                                        value={ this.state.gstin }
                                        onChange={ this.handleInputChange }
                                        onBlur={ e => this.validateGST(e.target.value) }
                                        title="GST"
                                        autoComplete="off"
                                        required

                                    />

                                    <p class="error" style={ { color: 'red' } } >{ this.state.errors.gstin }</p>
                                </GridItem>
                                <GridItem lg={ 4 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Contact Person Name" variant="outlined" id="outlined-size-small" size="small"
                                        onChange={ (event) => {
                                            this.setState({ "contactPersonName": event.target.value })
                                        } } />
                                </GridItem>
                                <GridItem lg={ 4 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Contact Person Number" variant="outlined" id="outlined-size-small" size="small"
                                        onChange={ (event) => {
                                            this.setState({ "contactPersonNumber": event.target.value })
                                        } } />
                                </GridItem>
                            </GridContainer>
                            <h4 className={ classes.headingStyle }>Address Details</h4>
                            <GridContainer className={ classes.gridcontainer }>
                                <GridItem lg={ 6 } xs={ 12 } md={ 6 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Address line1 " disabled={ this.state.disableAccountDetailsFields } value={ this.state.addressLineOne } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => {
                                            this.setState({ "addressLineOne": event.target.value })
                                        } } />
                                </GridItem>
                                <GridItem lg={ 6 } xs={ 12 } md={ 6 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Address line2" disabled={ this.state.disableAccountDetailsFields } value={ this.state.addressLineTwo } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => {
                                            this.setState({ "addressLineTwo": event.target.value })
                                        } } />
                                </GridItem>
                            </GridContainer>
                            <GridContainer className={ classes.gridcontainer }>
                                <GridItem lg={ 3 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="Post Office" disabled={ this.state.disableAccountDetailsFields } value={ this.state.postOffice } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                                        onChange={ (event) => {
                                            this.setState({ "postOffice": event.target.value })
                                        } } />
                                </GridItem>
                                <GridItem lg={ 3 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } className={ classes.taluk } disabled={ this.state.disableAccountDetailsFields } value={ this.state.taluk } label="Taluk" variant="outlined" id="outlined-size-small" size="small"
                                        onChange={ (event) => {
                                            this.setState({ "taluk": event.target.value })
                                        } } />
                                </GridItem>
                                <GridItem lg={ 3 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label="District" disabled={ this.state.disableAccountDetailsFields } value={ this.state.district } variant="outlined" id="outlined-size-small" size="small"
                                        onChange={ (event) => {
                                            this.setState({ "district": event.target.value })
                                        } } />
                                </GridItem>
                                <GridItem lg={ 3 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                                    <TextField className={ classes.textfields } label=" State " disabled={ this.state.disableAccountDetailsFields } value={ this.state.state } variant="outlined" id="outlined-size-small" size="small"
                                        onChange={ (event) => {
                                            this.setState({ "state": event.target.value })
                                        } } />
                                </GridItem>
                            </GridContainer>
                            <GridContainer >
                                <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
                                    <div className={ classes.root2 } >
                                        <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="primary" onClick={ this.editAccountDetails } >
                                            Submit  </MButton> </span>
                                        {/* <MButton variant="outlined" color="secondary" > Reset</MButton> */ }
                                    </div>
                                </GridItem>
                            </GridContainer>
                        </CardBody>

                    </Card>
                </GridItem>
                <GridItem lg={ 2 }></GridItem>
            </GridContainer>
            <GridContainer >
                <GridItem lg={ 2 } md={ 2 }></GridItem>
                <GridItem lg={ 8 } md={ 8 }>
                    <Card>
                        <CardHeader color="primary" icon>
                            <CardIcon color="primary">
                                <PermContactCalendarIcon />
                            </CardIcon>
                            <h4 className={ classes.heading }>Contacts</h4>
                        </CardHeader>
                        <CardBody>
                            { this.renderContactDetails() }
                            <GridContainer >
                                <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
                                    <div className={ classes.root2 } >
                                        <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="primary" onClick={ this.editContactDetails } >
                                            Submit </MButton></span>
                                        {/* <MButton variant="outlined" color="secondary" >Reset</MButton> */ }

                                    </div>
                                </GridItem>
                            </GridContainer>
                        </CardBody>
                    </Card>
                </GridItem>
                <GridItem lg={ 2 } md={ 2 }></GridItem>
            </GridContainer>

            {/*this.state.type !== 'advertiser' &&
            <GridContainer >
                    <GridItem lg={2} md={2}></GridItem>
                    <GridItem lg={8} md={8}>
                        <Card>
                            <CardHeader color="primary" icon>
                                <CardIcon color="primary">
                                    <Globe />
                                </CardIcon>
                                <h4 className={classes.heading}>Websites Details</h4>
                            </CardHeader>
                            {this.renderWebsites()}
                        </Card>
                    </GridItem>
                    <GridItem lg={2} md={2}></GridItem>
                                    </GridContainer>*/}



            { this.state.type !== 'advertiser' &&
                <GridContainer >
                    <GridItem lg={ 2 } md={ 2 }></GridItem>
                    <GridItem lg={ 8 } md={ 8 }>
                        <Card>
                            <CardHeader color="primary" icon>
                                <CardIcon color="primary">
                                    <Globe />
                                </CardIcon>
                                <h4 className={ classes.heading }>Add your websites</h4>
                            </CardHeader>
                            { this.renderWebsites() }

                        </Card>
                    </GridItem>
                    <GridItem lg={ 2 } md={ 2 }></GridItem>
                </GridContainer> }


            <GridContainer className={ classes.gridcontainer }>
                <GridItem lg={ 2 }></GridItem>
                <GridItem xs={ 12 } md={ 8 } lg={ 8 }>
                    <Card>
                        <CardHeader color="primary" icon>
                            <CardIcon color="primary">
                                <Bankicon />
                            </CardIcon>
                            <h4 className={ classes.heading }>Bank Account details</h4>
                        </CardHeader>
                        <CardBody className={ classes.CardBody }>

                            { this.renderBankAccountDetails() }

                            <GridContainer >
                                <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
                                    <div className={ classes.root2 } >

                                        <span style={ { paddingLeft: "10px" } }>
                                            <MButton variant="outlined" color="primary" onClick={ this.editBankDetails } >
                                                Submit </MButton></span>
                                        {/* <MButton variant="outlined" color="secondary">
                                            Reset
                                        </MButton> */}
                                    </div>
                                </GridItem>
                            </GridContainer>
                        </CardBody >

                    </Card>
                </GridItem>
                <GridItem lg={ 2 }>

                </GridItem>
            </GridContainer>
        </div>
    }
}


const CreateContactHOC = withStyles(styles)(CreateContact);
export default connect(mapStateToProps, mapDispatchToProps)((withStyles(styles)(CreateContactHOC)));