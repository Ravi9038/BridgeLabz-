import React, { Component } from 'react'
import ReactTable from "react-table";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import SlidingPane from "react-sliding-pane";

import Assignment from "@material-ui/icons/Assignment";
import Dvr from "@material-ui/icons/Dvr";
import Close from "@material-ui/icons/Close";
import Button from "components/CustomButtons/Button.js";
import axios from "axios";
import {SERVER_URL} from "../../variables/constants";

import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import { makeStyles } from "@material-ui/core/styles";
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
const styles = {
    customCardContentClass: {
        paddingLeft: "0",
        paddingRight: "0"
    },
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    }
};

const useStyles = makeStyles(styles);

export class Advertiser extends Component {
    state = {
            advertisers : [],
            isAdsTxtViewPaneOpen : false,
            isAdsTxtInsertPaneOpen : false,
            adsTxtRecords : "",
            newAdsTxtRecords : "",
    }
    
    
    
    componentDidMount() {
        
        const USER_ID = this.props.data.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        
    	axios.get(`${SERVER_URL}/api/users/advertisers`).then(response => response.data)
    	.then((data) => {
    		this.setState({ advertisers: data})
    	}).catch((error) => {
            console.error(error);
        });
    }
	
    editAdvertiser = (editObject) => {
    	this.props.history.push('/admin/edit-user',{editObject});
    }

    disableAdvertiser = (pKey) => {
    	console.log('id for delete', pKey);
     	
    	var url = `${SERVER_URL}/api/users/${pKey}` ;
    	axios.delete(url, {}).then(response => response.data)
		  .then((data) => {
		  this.setState({ advertisers: data})
		  }).catch(error => {console.log(error);})
    	
    }

    viewAdsTxtRecords = (pKey) =>{
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        
        axios.get(`${SERVER_URL}/api/adstxt/advertiser/${pKey}`, { headers: { "Authorization": TOKEN } })
            .then(res => {
                let strAdsTxtRecord = "";
                let adsTxtRecords = res.data;
                let adsHtmlRecords = "<ol>";
                adsTxtRecords.forEach(record =>{
                    let strRecord = record.exchange_domain_name + "," + record.account_id;
                    if(record.account_type)
                        strRecord = strRecord + "," + record.account_type;
                    if(record.certification_auth_id){
                        strRecord = strRecord + "," + record.certification_auth_id;
                        strAdsTxtRecord = strAdsTxtRecord + "\n" + strRecord;                        
                    }else{
                        strAdsTxtRecord = strAdsTxtRecord + "\n" + strRecord;
                    }
                    adsHtmlRecords = adsHtmlRecords + "<li>" + strRecord + "</li>";
                });
                
                adsHtmlRecords = adsHtmlRecords + "</ol>";
                this.setState({
                    isAdsTxtViewPaneOpen : true,
                    adsTxtRecords : strAdsTxtRecord
                });
            }).catch(function (error) {
                console.log(error);
            });
    }

    insertAdsTxtRecords = (pKey) =>{

    }

    render() {
        const classes = this.props.classes;
        //var classes = useStyles();
        return <GridContainer>
                <GridItem xs={12}>
                    <Card>
                        <CardHeader color="primary" icon>
                            <CardIcon color="primary">
                                <Assignment />
                            </CardIcon>
                            <h4>React Table</h4>
                        </CardHeader>
                        <CardBody>
                            <ReactTable
                                data={this.state.advertisers}
                                filterable
                                columns={[
                                    {
                                        Header: "Company Name",
                                        accessor: "companyName"
                                    },
                                    {
                                        Header: "Contact Person",
                                        accessor: "contactPersonName"
                                    },
                                    {
                                        Header: "Phone Number",
                                        accessor: "contactPersonNumber"
                                    },
                                    {
                                        Header: "Email",
                                        accessor: "email"
                                    },
                                    {
                                        Header: "View / Add Ads.Txt",
                                        accessor: "id",
                                        Cell: id => (
                                        		<div className="actions-right">
                                        		<Button
                                                justIcon
                                                round
                                                simple
                                                onClick={() => {
                                                  let obj = this.state.advertisers.find(o => o.id === id.original.id);
                                                  this.viewAdsTxtRecords(id.original.id);
                                                }}
                                        		color="warning"
                                                  className="edit"
                                              >
                                                <Dvr />
                                              </Button>
                                              {" "}
                                            {/* use this button to remove the data row */}
                                            <Button
                                              justIcon
                                              round
                                              simple
                                              onClick={() => {
                                                  this.insertAdsTxtRecords(id.original.id);
                                              }}
                                              color="danger"
                                              className="remove"
                                            >
                                              <Close />
                                            </Button>{" "}
                                            </div>
                                        ),
                                        sortable: false,
                                        filterable: false
                                    },
                                    {
                                        Header: "Edit/ Delete",
                                        accessor: "id",
                                        Cell: id => (
                                        		<div className="actions-right">
                                        		<Button
                                                justIcon
                                                round
                                                simple
                                                onClick={() => {
                                                  let obj = this.state.advertisers.find(o => o.id === id.original.id);
                                                  this.editAdvertiser(obj);
                                                }}
                                        		color="warning"
                                                  className="edit"
                                              >
                                                <Dvr />
                                              </Button>
                                              {" "}
                                            {/* use this button to remove the data row */}
                                            <Button
                                              justIcon
                                              round
                                              simple
                                              onClick={() => {
                                                  this.disableAdvertiser(id.original.id);
                                              }}
                                              color="danger"
                                              className="remove"
                                            >
                                              <Close />
                                            </Button>{" "}
                                            </div>
                                        ),
                                        sortable: false,
                                        filterable: false
                                    }
                                ]}
                                defaultPageSize={10}
                                showPaginationTop
                                showPaginationBottom={false}
                                className="-striped -highlight"
                            />
                        </CardBody>
                    </Card>
                </GridItem>

                <SlidingPane
            className={classes.ModalStyle +" panelHeaderClass"}
            overlayClassName={classes.panelClass}
            isOpen={this.state.isAdsTxtViewPaneOpen}
            title="Showing Ads-Txt Records "
            subtitle=""
            onRequestClose={() => {
              this.setState({ isAdsTxtViewPaneOpen: false });
            }}
          >

            <textarea rows={35} cols={75} value = {this.state.adsTxtRecords} disabled/>


          </SlidingPane>

          <SlidingPane
            className={classes.ModalStyle +" panelHeaderClass"}
            overlayClassName={classes.panelClass}
            isOpen={this.state.isAdsTxtInsertPaneOpen}
            title="Add new Ads-Txt Records"
            subtitle=""
            onRequestClose={() => {
              this.setState({ isAdsTxtInsertPaneOpen: false });
            }}
          >

          <textarea rows={20} value = {this.state.newAdsTxtRecords} onChange={(event) => {this.setState({newAdsTxtRecords:event.target.value })}} />
          <Button color="primary" onClick = {this.insertAdsTxtRecords}>Add Records</Button>              
                        </SlidingPane>
            </GridContainer>
        
    }
}

const AdvertiserHOC = withStyles(styles)(Advertiser);
export default connect(mapStateToProps, mapDispatchToProps)(AdvertiserHOC);

