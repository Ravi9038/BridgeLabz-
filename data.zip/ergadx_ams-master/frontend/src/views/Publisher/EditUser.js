import React, { Component } from 'react';

// @material-ui/icons
import Contacts from "@material-ui/icons/Contacts";
import {SERVER_URL} from "../../variables/constants";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import CustomInput from "components/CustomInput/CustomInput.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import { withStyles } from '@material-ui/styles';
import axios from "axios";

import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import { makeStyles } from "@material-ui/core/styles";
import SweetAlert from "react-bootstrap-sweetalert";

import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";


// style for this view
import styles from "assets/jss/material-dashboard-pro-react/views/validationFormsStyle.js";




export class EditUser extends Component {


	constructor(props) {
		super(props);

		this.state = {
			alert : null,
			companyName: '',
			idRole: '',
			roleText:'',
			email: '',
			gstin: '',
			contactPersonName: '',
			contactPersonNumber: '',
			companyNameState: null,
			emailState: null,
			gstinState: null,
			contactPersonNameState: null,
			contactPersonNumberState: null,
			id: null,
			editRoleEnabled: false
		};

		this.handleChange = this.handleChange.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	}

	setAlert = (pAlert) =>{
		this.setState({alert:pAlert});
	}
	hideAlert = () => {
		this.setState({alert:null});
	};

	componentDidMount() {

		const editState = this.props.location.state;

		if (editState && editState.editObject) {
			let roleText = "";
			if(editState.editObject.idRole ==1 ){
				roleText = "Administrator";
			}else if(editState.editObject.idRole ==2 ){
				roleText = "Advertiser";
			}else if(editState.editObject.idRole ==3 ){
				roleText = "Publisher";
			}else if(editState.editObject.idRole ==4 ){
				roleText = "AdOps";
			}

			this.setState({
				id: editState.editObject.id,
				companyName: editState.editObject.companyName,
				roleText:roleText,
				idRole: editState.editObject.idRole,
				email: editState.editObject.email,
				gstin: editState.editObject.gstin,
				contactPersonName: editState.editObject.contactPersonName,
				contactPersonNumber: editState.editObject.contactPersonNumber,
				companyNameState: 'success',
				emailState: 'success',
				gstinState: 'success',
				contactPersonNameState: 'success',
				contactPersonNumberState: 'success',
				editRoleEnabled: true
			});
		}

	}

	handleChange(evt) {
		console.log(evt.target.name); // the name of the form element
		console.log(evt.target.value); // the value of the form element
		this.setState({ [evt.target.name]: evt.target.value });
	}

	handleSubmit() {
		const { classes } = this.props;
		console.log('inside submit EditRole');
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
		axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
		
		if (this.state.companyNameState === "success" &&
			this.state.emailState === "success" &&
			this.state.gstinState === "success" &&
			this.state.contactPersonNameState === "success" &&
			this.state.contactPersonNumberState === "success") {
			const url = `${SERVER_URL}/api/users`;
			axios.post(url, {
				id: this.state.id,
				companyName: this.state.companyName,
				idRole: this.state.idRole,
				gstin: this.state.gstin,
				contactPersonName: this.state.contactPersonName,
				contactPersonNumber: this.state.contactPersonNumber,
				email: this.state.email,
				status: 'ACTIVE'
			}).then(response => response.data)
				.then((data) => {
					console.log('advertisers', data);
					alert("Updated Successfully");
					/*
					this.setAlert(
						<SweetAlert
						  style={{ display: "block", marginTop: "-100px" }}
						  title="User updated successfully!"
						  onConfirm={() => this.hideAlert()}
						  onCancel={() => this.hideAlert()}
						  confirmBtnCssClass={classes.button + " " + classes.success}
						/>
					  );
					this.setState({
						companyName: '',
						idRole: 'Advertiser',
						email: '',
						gstin: '',
						contactPersonName: '',
						contactPersonNumber: '',
						companyNameState: null,
						emailState: null,
						gstinState: null,
						contactPersonNameState: null,
						contactPersonNumberState: null,
						id: null
					});*/

				}).catch(error => { 
					console.log(error); 
					alert("Error while updating. Please try again");
				})
		} else {
			alert('Fill the *required fields ');
		}
	}



	render() {
		const { classes } = this.props;

		return (

			<GridContainer>
				<GridItem xs={12} sm={12} md={12}>
					<Card>
						<CardHeader color="rose" icon>
							<CardIcon color="rose">
								<Contacts />
							</CardIcon>
							<h4 className={classes.cardIconTitle}>Register User</h4>
						</CardHeader>
						<CardBody>
							<form>
								<GridContainer>

									<GridItem xs={12} sm={12} md={6}>
										<CustomInput
											success={this.state.companyNameState === "success"}
											error={this.state.companyNameState === "error"}
											labelText="Company Name"
											id="registercompanyName"
											formControlProps={{
												fullWidth: true
											}}
											inputProps={{
												value: this.state.companyName,
												disabled: true,
												onChange: event => {
													if (event.target.value.trim().length === 0)
														this.setState({ 'companyNameState': 'error' })
													else
														this.setState({ 'companyNameState': 'success' })
													event.target.name = "companyName"
													this.handleChange(event);
												},
												type: "text"
											}}
										/>
									</GridItem>

									<GridItem xs={12} sm={12} md={6}>
										<CustomInput
											success={this.state.emailState === "success"}
											error={this.state.emailState === "error"}
											labelText="Role"
											id="role"
											formControlProps={{
												fullWidth: true
											}}
											inputProps={{
												value: this.state.roleText,
												type: "text",
												disabled: true
											}}
										/>
									</GridItem>



								</GridContainer>
								<GridContainer>


									<GridItem xs={12} sm={12} md={6}>
										<CustomInput
											success={this.state.emailState === "success"}
											error={this.state.emailState === "error"}
											labelText="Email Address *"
											id="registeremail"
											formControlProps={{
												fullWidth: true
											}}
											inputProps={{
												value: this.state.email,
												onChange: event => {
													if (event.target.value.trim().length === 0)
														this.setState({ 'emailState': 'error' })
													else
														this.setState({ 'emailState': 'success' })
													event.target.name = "email"
													this.handleChange(event);
												},
												type: "text"
											}}
										/>
									</GridItem>


									<GridItem xs={12} sm={12} md={6}>
										<CustomInput
											success={this.state.gstinState === "success"}
											error={this.state.gstinState === "error"}
											labelText="GSTIN *"
											id="registergstin"
											formControlProps={{
												fullWidth: true
											}}
											inputProps={{
												value: this.state.gstin,
												onChange: event => {
													if (event.target.value.trim().length === 0)
														this.setState({ 'gstinState': 'error' })
													else
														this.setState({ 'gstinState': 'success' })
													event.target.name = "gstin"
													this.handleChange(event);
												},
												type: "text"
											}}
										/>
									</GridItem>


								</GridContainer>


								<GridContainer>


									<GridItem xs={12} sm={12} md={6}>
										<CustomInput
											success={this.state.contactPersonNameState === "success"}
											error={this.state.contactPersonNameState === "error"}
											labelText="Contact Person Name *"
											id="registercontactPersonName"
											formControlProps={{
												fullWidth: true
											}}
											inputProps={{
												value: this.state.contactPersonName,
												onChange: event => {
													if (event.target.value.trim().length === 0)
														this.setState({ 'contactPersonNameState': 'error' })
													else
														this.setState({ 'contactPersonNameState': 'success' })
													event.target.name = "contactPersonName"
													this.handleChange(event);
												},
												type: "text"
											}}
										/>
									</GridItem>


									<GridItem xs={12} sm={12} md={6}>
										<CustomInput
											success={this.state.contactPersonNumberState === "success"}
											error={this.state.contactPersonNumberState === "error"}
											labelText="Contact Person Number *"
											id="registercontactPersonNumber"
											formControlProps={{
												fullWidth: true
											}}
											inputProps={{
												value: this.state.contactPersonNumber,
												onChange: event => {
													if (event.target.value.trim().length === 0)
														this.setState({ 'contactPersonNumberState': 'error' })
													else
														this.setState({ 'contactPersonNumberState': 'success' })
													event.target.name = "contactPersonNumber"
													this.handleChange(event);
												},
												type: "text"
											}}
										/>
									</GridItem>


								</GridContainer>
								<div className={classes.formCategory}>
									<small>*</small> Required fields
</div>
								<Button color="rose" onClick={() => this.handleSubmit()}>Submit</Button>

							</form>
						</CardBody>
					</Card>
				</GridItem>
			</GridContainer>

		);

	}
}
const EditUserHOC = withStyles(styles)(EditUser);
export default connect(mapStateToProps, mapDispatchToProps)(EditUserHOC);