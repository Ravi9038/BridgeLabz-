import React, { Component } from 'react'
import { makeStyles } from "@material-ui/core/styles";

// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import axios from 'axios';
import { addDays } from 'date-fns'
import { DateRangePicker } from 'react-date-range';
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Datetime from "react-datetime";
import Table from "components/Table/Table.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import { SERVER_URL } from "../../variables/constants";
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import Button from "components/CustomButtons/Button.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import customCheckboxRadioSwitch from "assets/jss/material-dashboard-pro-react/customCheckboxRadioSwitch.js";
import 'react-date-range/dist/styles.css'; // main css file
import 'react-date-range/dist/theme/default.css'; // theme css file

const styles = {
    ...customSelectStyle,
    ...customCheckboxRadioSwitch,
    customCardContentClass: {
        paddingLeft: "0",
        paddingRight: "0"
    },
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    }
};

const useStyles = makeStyles(styles);
export class AdvertiserWiseReports extends Component {
    state = {
        websiteHeaders: ["Name", "Url", "Http Enabled", "Https Enabled", "Edit"],
        websiteData: [],
        websiteRevenueHeaders: ["Name", "URL", "Impression", "CPM", "Amount", "Date"],
        websiteRevenueData: [],
        simpleSelect: [],
        selectedWebsiteIds: [],
        selectedDuration: "",
        isAllWebsiteSelected: false,
        isReportDataVisible: false,
        dateRange: {
            startDate: new Date(),
            endDate: addDays(new Date(), 7),
            key: 'selection'
        }
    }

    handleSimple = event => {
        this.setState({ 'simpleSelect': event.target.value });
    }
    selectWebsite = event => {
        let selectedValues = event.target.value;
        let isAllWebsiteSelected = false;
        selectedValues.forEach(item => {
            if (item == -1) {
                isAllWebsiteSelected = true;
            }
        });
        if (isAllWebsiteSelected) {
            this.setState({ 'selectedWebsiteIds': [-1], isAllWebsiteSelected: true });
        } else {
            this.setState({ 'selectedWebsiteIds': event.target.value, isAllWebsiteSelected: false });
        }
    }

    componentDidMount() {
        const USER_ID = this.props.data.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';


        axios.get(`${SERVER_URL}/api/userwebsite/user/${USER_ID}`, { headers: { "Authorization": TOKEN } })
            .then(res => {
                let lWebsiteData = [];
                res.data.forEach(item => {
                    let lWebsite = [];
                    lWebsite.push(item.name);
                    lWebsite.push(item.hostURL);
                    item.httpEnabled ? lWebsite.push("Yes") : lWebsite.push("No");
                    item.httpsEnabled ? lWebsite.push("Yes") : lWebsite.push("No");
                    lWebsite.push(item.id);
                    lWebsiteData.push(lWebsite);

                });
                this.setState({ websiteData: lWebsiteData });
            }).catch(function (error) {
                console.log(error);
            });

    }

    viewReports = () => {
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        var requestData = {};
        let strWebsiteIds = "";
        if (this.state.isAllWebsiteSelected) {
            for (var index = 0; index < this.state.websiteData.length; ++index) {
                var lWebsiteRecord = this.state.websiteData[index];
                strWebsiteIds = strWebsiteIds + lWebsiteRecord[4];
                if (index + 1 != this.state.websiteData.length)
                    strWebsiteIds = strWebsiteIds + ",";
            }
        } else {
            for (var index = 0; index < this.state.selectedWebsiteIds.length; ++index) {
                strWebsiteIds = strWebsiteIds + this.state.selectedWebsiteIds[index];
                if (index + 1 != this.state.selectedWebsiteIds.length)
                    strWebsiteIds = strWebsiteIds + ",";
            }
        }

        requestData.start_date = '2020-08-01';
        requestData.end_date = '2020-08-31';
        requestData.website_ids = strWebsiteIds;
        axios.post(`${SERVER_URL}/api/website/revenue/`, requestData, { headers: { "Authorization": TOKEN } })
            .then(res => {
                this.setState({ websiteRevenueData: res.data, isReportDataVisible: true });
            }).catch(function (error) {
                console.log(error);
            });
    }

    downloadReport = () => {
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        var requestData = {};
        let strWebsiteIds = "";
        if (this.state.isAllWebsiteSelected) {
            for (var index = 0; index < this.state.websiteData.length; ++index) {
                var lWebsiteRecord = this.state.websiteData[index];
                strWebsiteIds = strWebsiteIds + lWebsiteRecord[4];
                if (index + 1 != this.state.websiteData.length)
                    strWebsiteIds = strWebsiteIds + ",";
            }
        } else {
            for (var index = 0; index < this.state.selectedWebsiteIds.length; ++index) {
                strWebsiteIds = strWebsiteIds + this.state.selectedWebsiteIds[index];
                if (index + 1 != this.state.selectedWebsiteIds.length)
                    strWebsiteIds = strWebsiteIds + ",";
            }
        }

        requestData.start_date = '2020-08-01';
        requestData.end_date = '2020-08-31';
        requestData.website_ids = strWebsiteIds;
        axios.post(`${SERVER_URL}/api/website/revenue/download`, requestData, { headers: { "Authorization": TOKEN, responseType: 'blob' } })
            .then(response => {
                let fileName = "report.xlsx";
                if (window.navigator && window.navigator.msSaveOrOpenBlob) { // IE variant
                    window.navigator.msSaveOrOpenBlob(new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
                        fileName);
                } else {
                    const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
                    const link = document.createElement('a');
                    link.href = url;
                    link.setAttribute('download', fileName);
                    document.body.appendChild(link);
                    link.click();
                }
            }).catch(function (error) {
                console.log(error);
            });
    }

    render() {


        const classes = this.props.classes;
        return (
            <GridContainer>
                <GridItem xs={12}>
                    <Card>
                        <CardHeader color="rose" icon>
                            <CardIcon color="rose">
                                <Assignment />
                            </CardIcon>
                            <h4 className={classes.cardIconTitle}>Download Reports</h4>
                        </CardHeader>

                        <CardHeader color="rose" icon>
                        </CardHeader>
                        <CardBody>
                            <GridItem xs={12} sm={12} md={6}>
                                <GridContainer>
                                    <GridItem xs={3} sm={6} md={3} lg={3}>

                                        <FormControl
                                            fullWidth
                                            className={classes.selectFormControl}
                                        >
                                            <InputLabel
                                                htmlFor="multiple-select"
                                                className={classes.selectLabel}
                                            >
                                                Select websites
                                            </InputLabel>
                                            <Select
                                                multiple
                                                value={this.state.selectedWebsiteIds}
                                                onChange={this.selectWebsite}
                                                MenuProps={{ className: classes.selectMenu }}
                                                classes={{ select: classes.select }}
                                                inputProps={{
                                                    name: "multipleSelect",
                                                    id: "multiple-select"
                                                }}
                                            >
                                                <MenuItem
                                                    classes={{
                                                        root: classes.selectMenuItem,
                                                        selected: classes.selectMenuItemSelectedMultiple
                                                    }}
                                                    value="-1"
                                                >
                                                    All Websites
                                                </MenuItem>
                                                {this.state.websiteData.map((lWebsite, i) => {
                                                    return (<MenuItem
                                                        classes={{
                                                            root: classes.selectMenuItem,
                                                            selected: classes.selectMenuItemSelectedMultiple
                                                        }}
                                                        value={lWebsite[4]}
                                                    >
                                                        {lWebsite[1]}
                                                    </MenuItem>)
                                                })}

                                            </Select>
                                        </FormControl>


                                    </GridItem>

                                    <GridItem xs={3} sm={6} md={3} lg={3}>

                                        <FormControl
                                            fullWidth
                                            className={classes.selectFormControl}
                                        >
                                            <InputLabel
                                                htmlFor="multiple-select"
                                                className={classes.selectLabel}
                                            >
                                                Select Duration
                                            </InputLabel>
                                            <Select
                                                value={this.state.selectedDuration}
                                                onChange={(event) => { this.setState({ selectedDuration: event.target.value }) }}
                                                MenuProps={{ className: classes.selectMenu }}
                                                classes={{ select: classes.selectLabel }}
                                                inputProps={{
                                                    name: "selectDuration",
                                                    id: "selectDuration"
                                                }}
                                            >
                                                <MenuItem
                                                    classes={{
                                                        root: classes.selectMenuItem,
                                                        selected: classes.selectMenuItemSelectedSelected
                                                    }}
                                                    value="1"
                                                >
                                                    Today
                                                </MenuItem>
                                                <MenuItem
                                                    classes={{
                                                        root: classes.selectMenuItem,
                                                        selected: classes.selectMenuItemSelectedSelected
                                                    }}
                                                    value="2"
                                                >
                                                    Yesterday
                                                </MenuItem>
                                                <MenuItem
                                                    classes={{
                                                        root: classes.selectMenuItem,
                                                        selected: classes.selectMenuItemSelectedSelected
                                                    }}
                                                    value="3"
                                                >
                                                    Last 7 Days
                                                </MenuItem>
                                                <MenuItem
                                                    classes={{
                                                        root: classes.selectMenuItem,
                                                        selected: classes.selectMenuItemSelectedSelected
                                                    }}
                                                    value="4"
                                                >
                                                    This month
                                                </MenuItem>
                                                <MenuItem
                                                    classes={{
                                                        root: classes.selectMenuItem,
                                                        selected: classes.selectMenuItemSelectedSelected
                                                    }}
                                                    value="5"
                                                >
                                                    Last 30 days
                                                </MenuItem>
                                                <MenuItem
                                                    classes={{
                                                        root: classes.selectMenuItem,
                                                        selected: classes.selectMenuItemSelectedSelected
                                                    }}
                                                    value="6"
                                                >
                                                    Custom Range
                                                </MenuItem>

                                            </Select>
                                        </FormControl>


                                    </GridItem>
                                    <GridItem xs={6} sm={6} md={6} lg={6}>

                                        <InputLabel className={classes.label}>
                                            Start Date
      </InputLabel>
                                        <br />
                                        <FormControl fullWidth>
                                            <Datetime
                                                inputProps={{ placeholder: "Select start date" }}
                                            />
                                        </FormControl>
                                        <InputLabel className={classes.label}>
                                            End Date
      </InputLabel>
                                        <FormControl fullWidth>
                                            <Datetime
                                                timeFormat={false}
                                                inputProps={{ placeholder: "Select end date" }}
                                            />
                                        </FormControl>
                                    </GridItem>
                                </GridContainer>
                            </GridItem>
                            <GridItem xs={12} sm={12} md={6}>

                                <div className={classes.cardContentRight}>

                                    <Button color="info" onClick={this.viewReports} className={classes.marginRight}>
                                        View
              </Button>
                                    <Button color="info" onClick={this.downloadReport} className={classes.marginRight}>
                                        Download
              </Button>
                                </div>
                            </GridItem>

                            {this.renderRevenueTable()}
                        </CardBody>
                    </Card>
                </GridItem>
            </GridContainer >
        )
    }

    renderRevenueTable = () => {
        if (this.state.isReportDataVisible) {
            return <Table
                tableHeaderColor="primary"
                tableHead={this.state.websiteRevenueHeaders}
                tableData={this.state.websiteRevenueData}
                coloredColls={[3]}
                colorsColls={["primary"]}
            />
        }
    }
}

const AdvertiserWiseReportsHOC = withStyles(styles)(AdvertiserWiseReports);
export default connect(mapStateToProps, mapDispatchToProps)(AdvertiserWiseReportsHOC);