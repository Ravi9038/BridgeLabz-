

import React, { Component } from "react";
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
// import InfoOutline from "@material-ui/icons/InfoOutline";

// core components
import InputBase from '@material-ui/core/InputBase';
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import axios from 'axios';
import { SERVER_URL } from "../../variables/constants";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import PermContactCalendarIcon from '@material-ui/icons/PermContactCalendar';
//import styles from "assets/jss/material-dashboard-pro-react/views/dashboardStyle.js";

// @material-ui/core components

// material-ui icons
import Globe from "@material-ui/icons/Public";
import Bankicon from "@material-ui/icons/AccountBalance";
import Profileicon from "@material-ui/icons/Person"
import MButton from '@material-ui/core/Button';
// core components

import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import InputAdornment from '@material-ui/core/InputAdornment';
import Add from '@material-ui/icons/Add';
import Remove from '@material-ui/icons/Remove';
import AddIcon from '@material-ui/icons/Add';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import NativeSelect from '@material-ui/core/NativeSelect';


const styles = {
  checkboxroot: {
    '& .MuiSvgIcon-root': {
      width: "0.7em",
      height: "0.7em"
    },
  },
  root: {
    '& .MuiIconButton-colorSecondary': {
      padding: "2px",
    },
    '& .PrivateSwitchBase-root-221': {
      padding: "2px",

    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "3px!important",
      marginRight: "3px!important",
      marginLeft: "0px !important"

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },
    '& .MuiFormControl-root': {
      //margin: theme.spacing(1),
      width: "100%",

    },
    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },
    '& .MuiGrid-grid-md-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-12': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-12': {
      padding: "0 5px !important"
    },
    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "23px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },

    '& .MuiGrid-grid-lg-1': {
      padding: "0 2px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-1': {
      padding: "0 2px !important",
      textAlign: "center"
    },
    '& #document-type': {
      textAlign: "center!important"
    },

    '&  .MuiFormLabel-root.Mui-disabled': {
      color: "#3f51b5"
    },
    '& .MuiInputBase-root.Mui-disabled ': {
      color: " #000000"

    }
  },

  root2: {
    '& > *': {
      //margin: theme.spacing(1),
      float: "right"
    },
  },
  heading: {
    color: "black!important"
  },
  InsideCard: {
    padding: "0 5px !important"
  },
  headingStyle: {
    marginBottom: "0px",
    fontSize: "1.1em",
    fontWeight: "500",
    marginTop: "25px",
  },
  checkbox: {
    fontSize: "13px"
  },
  textfieldslno: {
    textAlign: "center !important",
    padding: "0px 5px!important"
  },
  AddButton: {
    padding: "0px 5px!important"
  },

};


class ProfileView extends Component {

  constructor (props) {
    super(props);
    this.state = {
      accountDetails: [],
      userIDs: '',
      addRevData: [],
      erg_share: '',
      pub_share: '',
      websiteRev: '',
      disableAccountDetailsFields: true,
      disableContactFields: true,
      disableBankFields: true,
      disableWebsiteDetailsFields: true,
      accountEditButtonText: 'Edit',
      contactEditText: 'Edit',
      bankDeatilEditText: 'Edit',
      websiteEditButtonText: 'Edit',
      addAccountDeatils: 'Add',
      bankDetails: [{ names: " " }],
      contactDetails: [{ names: "" }],
      websiteDetails: [{ names: "" }],
      websites: [],
      accounts: [],
      revenueData: [],
      userId: '',
      addressLineOne: '',
      addressLineTwo: '',
      postOffice: '',
      taluk: '',
      district: '',
      state: '',
      companyName: '',
      gstin: '',
      managerName: '',
      id: '',
      IDS: 0,

      errors: {
        email: "",
        gstin: "",
      }
    }
  }


  componentDidMount = () => {
    console.log(this.props.idUser);
    this.setState({ userIDs: this.props.idUser })
    this.loadBankAccountData();
    this.loadWebsitesForUser();
    this.revenueForWebsite();
    this.addManagerDetails();
  }
  loadBankAccountData = () => {
    var USER_ID = 0;
    console.log(this.props.data.id)
    if (this.props.idUser != -1) {
      USER_ID = this.props.idUser;
    }
    else {
      USER_ID = this.props.data.id;
      this.setState({ IDS: this.props.data.id })
    }
    console.log(this.state.userIDs);
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/users/publishers/profile/${USER_ID}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        console.log(data);
        var newContactDetails = data.contactDetails;
        var lBankDetails = data.bankDetails;
        var lWebsiteDetails = data.websiteDetails;
        if (newContactDetails != '') {
          this.setState({ contactDetails: newContactDetails });
        }
        if (lBankDetails != '') {
          this.setState({ bankDetails: lBankDetails });
        }
        this.setState({ websiteDetails: lWebsiteDetails });
        this.setState({ userId: data.profileDetails.id });
        this.setState({ companyName: data.profileDetails.companyName });
        this.setState({ gstin: data.profileDetails.gstin })
        this.setState({ addressLineOne: data.profileDetails.addressLineOne });
        this.setState({ addressLineTwo: data.profileDetails.addressLineTwo });
        this.setState({ postOffice: data.profileDetails.postOffice });
        this.setState({ taluk: data.profileDetails.taluk });
        this.setState({ district: data.profileDetails.district });
        this.setState({ state: data.profileDetails.state });

      }).catch((error) => {
        console.error(error);
      });
  }
  loadWebsitesForUser = () => {
    const USER_ID = this.props.idUser;
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';


    axios.get(`${SERVER_URL}/api/userwebsite/`, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lWebsiteData = [];
        res.data.forEach(item => {
          let lWebsite = [];
          lWebsite.push(item.id);
          lWebsite.push(item.name);
          lWebsite.push(item.hostURL);
          lWebsiteData.push(lWebsite);
        });
        this.setState({ websites: lWebsiteData });
        console.log(this.state.websites);
      }).catch(function (error) {
        console.log(error);
      });
  }

  revenueForWebsite = () => {
    const USER_ID = this.props.idUser;
    console.log(this.state.userIDs);
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/website/revenue/${USER_ID}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        console.log(data);
        this.setState({ revenueData: data });
      }).catch((error) => {
        console.error(error);
      });

  }

  enableAccountDetails = () => {
    if (this.state.disableAccountDetailsFields) {
      this.setState({
        disableAccountDetailsFields: false,
        accountEditButtonText: 'Cancel'
      });
      alert("Do You want to Edit");
    }
    else {
      this.setState({
        disableAccountDetailsFields: true,
        accountEditButtonText: 'Edit'
      });
      alert("Do You want to Cancel");
    }
  }

  enableWebsiteDetails = () => {
    if (this.state.disableWebsiteDetailsFields) {
      this.setState({
        disableWebsiteDetailsFields: false,
        websiteEditButtonText: 'Cancel'
      });
      alert("Do You want to Edit");
    }
    else {
      this.setState({
        disableWebsiteDetailsFields: true,
        websiteEditButtonText: 'Edit'
      });
      alert("Do You want to Cancel");
    }
  }

  enableContactDetails = () => {
    if (this.state.disableContactFields) {
      this.setState({
        disableContactFields: false,
        contactEditText: 'Cancel'
      });
      alert("Do You want to Edit");
    }
    else {
      this.setState({
        disableContactFields: true,
        contactEditText: 'Edit'
      });
      alert("Do You want to Cancel");
    }
  }

  enableBankDetails = () => {

    if (this.state.disableBankFields) {
      this.setState({
        disableBankFields: false,
        bankDeatilEditText: 'Cancel'
      });
      alert("Do You want to Edit");
    }
    else {
      this.setState({
        disableBankFields: true,
        bankDeatilEditText: 'Edit'
      });
      alert("Do You want to Cancel");
    }

  }

  editAccountDetails = () => {
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    const pKey = this.state.userId
    axios.put(`${SERVER_URL}/api/users/${pKey}`, {
      "id": pKey,
      "companyName": this.state.companyName,
      "gstin": this.state.gstin,
      "addressLineOne": this.state.addressLineOne,
      "addressLineTwo": this.state.addressLineTwo,
      "postOffice": this.state.postOffice,
      "taluk": this.state.taluk,
      "district": this.state.district,
      "state": this.state.state
    }, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data submitted");
      }).catch(error => { console.log(error); })
  }

  addManagerDetails = () => {

    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    const pKey = 5;//this.state.idRole;
    axios.get(`${SERVER_URL}/api/users/role/${pKey}`, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        this.setState({ accountDetails: data });
      }).catch(error => { console.log(error); })

  }

  editContactDetails = () => {
    for (let i = 0; i < this.state.contactDetails.length; i++) {
      if (!this.state.contactDetails[i].hasOwnProperty('userId')) {
        this.state.contactDetails[i].userId = this.state.userId;
      }
    }
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.post(`${SERVER_URL}/api/usercontact/`, this.state.contactDetails, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data submitted");
      }).catch(error => { console.log(error); })
  }

  handScheduledBankholder = () => {
    let lauthorHolders = this.state.bankDetails;
    let lAuthor = {};
    lauthorHolders.push(lAuthor);
    this.setState({ bankDetails: lauthorHolders });
  }
  removeBankHolder(id, i) {
    const { bankDetails } = this.state;
    this.setState({
      bankDetails: bankDetails.filter((key, index) => index !== i),
    });
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.delete(`${SERVER_URL}/api/bankdetails/${id}`, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data deleted");
      }).catch(error => { console.log(error); })
  }

  handScheduledContactholder = () => {
    let lauthorHolders = this.state.contactDetails;
    let lAuthor = {};
    lauthorHolders.push(lAuthor);
    this.setState({ contactDetails: lauthorHolders });
    console.log(this.state.contactDetails)
  }
  removeContactHolder(id, i) {
    const { contactDetails } = this.state;
    this.setState({
      contactDetails: contactDetails.filter((key, index) => index !== i),
    });
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.delete(`${SERVER_URL}/api/usercontact/details/${id}`, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data deleted");
      }).catch(error => { console.log(error); })
  }

  renderBankAccountDetails = () => {
    const classes = this.props.classes;
    let lBankAccounts = this.state.bankDetails;
    let lJsxBankAccounts = lBankAccounts.map((prop, index) => {
      return <Card key={ index }>
        <CardBody className={ classes.CardBody }>
          <GridContainer className={ classes.gridcontainer }>
            <GridItem lg={ 6 } md={ 6 } className={ classes.textfieldsgrid } >
              <TextField className={ classes.textfields } value={ prop.accountNumber } disabled={ this.state.disableBankFields } label="Bank Account Number" type="password" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                onChange={ (event) => { this.updateBankDetail(prop.id, index, event.target.value, "accountNumber") } } required />
            </GridItem>
            <GridItem lg={ 6 } md={ 6 } className={ classes.textfieldsgrid }>
              <TextField className={ classes.textfields } value={ prop.accountNumber } disabled={ this.state.disableBankFields } label="Re-enter Bank Account Number" type="text" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                onChange={ (event) => { this.updateBankDetail(prop.id, index, event.target.value, "accountNumber") } }
              />
            </GridItem>
          </GridContainer>
          <GridContainer className={ classes.gridcontainer }>
            <GridItem lg={ 3 } className={ classes.textfieldsgrid }>
              <TextField className={ classes.textfields } value={ prop.payeeName } disabled={ this.state.disableBankFields } label="Nick Name" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                onChange={ (event) => { this.updateBankDetail(prop.id, index, event.target.value, "payeeName") } } />
            </GridItem>
            <GridItem lg={ 4 } className={ classes.textfieldsgrid }>
              <TextField className={ classes.textfields } value={ prop.ifscCode } disabled={ this.state.disableBankFields } label="IFSC" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                onChange={ (event) => { this.updateBankDetail(prop.id, index, event.target.value, "ifscCode") } } />
            </GridItem>
            <GridItem lg={ 4 } className={ classes.textfieldsgrid }>
              <TextField className={ classes.textfields } value={ prop.ifscSwiftCode } disabled={ this.state.disableBankFields } label="SWIFT Code" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                onChange={ (event) => { this.updateBankDetail(prop.id, index, event.target.value, "ifscSwiftCode") } } />
            </GridItem>
            <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
              <TextField
                id="document-type"
                InputProps={ {
                  autoComplete: 'off',
                  readOnly: true,
                  startAdornment: (
                    <InputAdornment position="start">
                      <AddIcon style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                    </InputAdornment>
                  ),
                } }
                label="Add"
                onClick={ () => { this.addBank() } }
                variant="outlined" />
            </GridItem>
            <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
              <TextField
                id="document-type"
                InputProps={ {
                  autoComplete: 'off',
                  readOnly: true,
                  startAdornment: (
                    <InputAdornment position="start">
                      <Remove style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                    </InputAdornment>
                  ),
                } }
                label="Remove"
                onClick={ () => { this.remove(prop.id) } }
                variant="outlined" />
            </GridItem>

          </GridContainer>

        </CardBody>
      </Card>
    });
    return <GridContainer className={ classes.gridcontainer }>
      <GridItem lg={ 12 } className={ classes.InsideCard } style={ { padding: "0px 5px!important" } } >
        { lJsxBankAccounts }
      </GridItem>
    </GridContainer>
  }
  renderWebsiteBankaccountMapping = () => {
    const classes = this.props.classes;
    return <GridContainer className={ classes.gridcontainer }>
      <GridItem lg={ 12 } className={ classes.InsideCard } style={ { padding: "0px 5px!important" } } >
        <Card>
          <CardBody className={ classes.CardBody }>
            <GridContainer className={ classes.gridcontainer }>
              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
                <TextField className={ classes.textfieldslno }
                  id="document-type"
                  value="1"
                  readOnly="true"
                  label="S No"
                  variant="outlined" />
              </GridItem>
              <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
                <TextField className={ classes.textfields } label=" Website Name" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } } />
              </GridItem>
              <GridItem lg={ 6 } md={ 6 } className={ classes.checkboxroot } >
                <RadioGroup row aria-label="nickname" name="nickname" defaultValue="Nickname1">
                  <FormControlLabel value="Nickname1" control={ <Radio /> } label="Nickname1" />
                  <FormControlLabel value="Nickname2" control={ <Radio /> } label="Nickname2" />
                  <FormControlLabel value="Nickname3" control={ <Radio /> } label="Nickname3" />
                  <FormControlLabel value="Nickname4" control={ <Radio /> } label="Nickname4" />
                  <FormControlLabel value="Nickname5" control={ <Radio /> } label="Nickname5" />
                </RadioGroup>
              </GridItem>
            </GridContainer>
          </CardBody>
        </Card>
      </GridItem>
    </GridContainer>
  }
  updatesmaplecontact(id, key, value, fieldName) {
    //  console.log(this.state.contactDetails);
    // const newInputFields = this.state.contactDetails.map(i => {
    // alert(keyvalue.length);
    // if ( id!=undefined && id === i.id) {
    //  key[fieldName] = event.target.value
    // }
    // else if(id===undefined){
    //   [fieldName] = event.target.value
    // }
    // console.log(this.state.contactDetails);
    //   return i;
    // })

    // this.setState({ contactDetails: newInputFields })

    let lcontactDetails = this.state.contactDetails;
    lcontactDetails[key][fieldName] = value;
    this.setState({ contactDetails: lcontactDetails });
    console.log(this.state.contactDetails)
  }

  updateBankDetail(id, key, value, fieldName) {
    /*     const newInputFields = this.state.bankDetails.map(i => {
          if (id === i.id) {
            i[fieldName] = value
          }
          return i;
          
        })
        this.setState({ bankDetails: newInputFields });
        console.log(this.state.bankDetails) */

    let lbankDetails = this.state.bankDetails;
    lbankDetails[key][fieldName] = value;
    this.setState({ bankDetails: lbankDetails });
  }

  editBankDetails = () => {
    for (let i = 0; i < this.state.bankDetails.length; i++) {
      if (!this.state.bankDetails[i].hasOwnProperty('userId')) {
        this.state.bankDetails[i].userId = this.state.userId;
      }
    }
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    console.log(this.state.bankDetails);
    axios.post(`${SERVER_URL}/api/bankdetails/`, this.state.bankDetails, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data submitted");
      }).catch(error => { console.log(error); })
  }



  renderContactDetails = () => {
    const classes = this.props.classes;
    return <GridContainer className={ classes.gridcontainer }>
      <GridItem lg={ 12 } className={ classes.InsideCard } style={ { padding: "0px 5px!important" } } >
        { this.state.contactDetails.map((item, key) => (

          <Card >
            <CardBody className={ classes.InsideCardBody }>
              <GridContainer className={ classes.gridcontainer }>
                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                  <TextField className={ classes.textfieldslno } style={ { textAlign: "center !important" } }
                    id="document-type"
                    disabled="true"
                    value={ key + 1 }
                    label="S No"
                    variant="outlined" />
                </GridItem>
                <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Level" value="Level1" disabled={ this.state.disableContactFields } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                  />
                </GridItem>
                <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Name" value={ item.name } disabled={ this.state.disableContactFields } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => { this.updatesmaplecontact(item.id, key, event.target.value, "name") } } />
                </GridItem>
                <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Designation" value={ item.designation } disabled={ this.state.disableContactFields } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => { this.updatesmaplecontact(item.id, key, event.target.value, "designation") } } />
                </GridItem>
                <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Reporting To" value={ item.idReportingUserName } disabled={ this.state.disableContactFields } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => { this.updatesmaplecontact(item.id, key, event.target.value, "idReportingUserName") } } />
                </GridItem>
              </GridContainer>
              <GridContainer className={ classes.gridcontainer }>
                <GridItem lg={ 4 } md={ 4 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Contact 1" value={ item.contactNumberOne } disabled={ this.state.disableContactFields } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => { this.updatesmaplecontact(item.id, key, event.target.value, "contactNumberOne") } } />
                </GridItem>
                <GridItem lg={ 4 } md={ 4 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Contact 2" value={ item.contactNumberTwo } disabled={ this.state.disableContactFields } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => { this.updatesmaplecontact(item.id, key, event.target.value, "contactNumberTwo") } } />
                </GridItem>
                <GridItem lg={ 4 } md={ 4 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Email Id" value={ item.email } disabled={ this.state.disableContactFields } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => { this.updatesmaplecontact(item.id, key, event.target.value, "email") } } />
                </GridItem>
                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
                  <TextField
                    id="document-type"
                    InputProps={ {
                      autoComplete: 'off',
                      readOnly: true,
                      startAdornment: (
                        <InputAdornment position="start">
                          <AddIcon style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                        </InputAdornment>
                      ),
                    } }
                    label="Add"
                    onClick={ () => { this.addContact() } }
                    variant="outlined" />
                </GridItem>
                <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
                  <TextField
                    id="document-type"
                    InputProps={ {
                      autoComplete: 'off',
                      readOnly: true,
                      startAdornment: (
                        <InputAdornment position="start">
                          <Remove style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                        </InputAdornment>
                      ),
                    } }


                    label="Remove"
                    onClick={ () => { this.removeConatct(item.id) } }
                    variant="outlined" />
                </GridItem>
                {/* <GridItem lg={1} md={1} className={classes.textfieldsgrid}>
              {(this.state.contactDetails.length - 1) == key ?
                <TextField
                  id="document-type"
                  InputProps={{
                    autoComplete: 'off',
                    readOnly: true,
                    startAdornment: (
                      <InputAdornment position="start">
                        <Add style={{ color: 'rgb(76, 175, 80)', cursor: 'pointer' }} className={classes.icon} />
                      </InputAdornment>
                    ),
                  }}
                  label="Add"
                  onClick={() => { this.handScheduledContactholder() }}
                  variant="outlined" /> :
                <TextField
                  id="document-type"
                  InputProps={{
                    autoComplete: 'off',
                    readOnly: true,
                    startAdornment: (
                      <InputAdornment position="start">
                        <Remove style={{ color: 'rgb(220, 53, 69)', cursor: 'pointer' }} className={classes.icon} />
                      </InputAdornment>
                    ),
                  }}
                  label="Del"
                  onClick={() => { this.removeContactHolder(item.id,key); }}
                  variant="outlined" />}
            </GridItem>
           */}
              </GridContainer>
            </CardBody>
          </Card>

        )) };
      </GridItem>
    </GridContainer>
  }

  updatesmaple(id, key, value, fieldName) {

    let lwebsiteDetails = this.state.websiteDetails;
    lwebsiteDetails[key][fieldName] = value;
    this.setState({ websiteDetails: lwebsiteDetails });
    console.log(this.state.websiteDetails)
  }

  updateManagerDetails(id, key, value, fieldName) {
    this.addManagerDetails();
    let lwebsiteDetails = this.state.websiteDetails;
    lwebsiteDetails[key][fieldName] = value;
    this.setState({ websiteDetails: lwebsiteDetails });
    console.log(this.state.websiteDetails)
  }
  editRevenueAvg = () => {
    console.log(this.state.revenueData);
    var data = this.state.revenueData;
    for (var key in data) {
      console.log(key);
      const dataPass = data[key];
      console.log(dataPass)
      const TOKEN = 'Bearer '.concat(this.props.data.token);
      axios.defaults.headers.common['Authorization'] = TOKEN;
      axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
      axios.post(`${SERVER_URL}/api/website/revenues/`, dataPass, { headers: { "Authorization": TOKEN } })
        .then(response => response.data)
        .then((data) => {
          console.log(data);
          alert("data Submitted")
        }).catch(error => { console.log(error); })
    }
  }
  editWebsiteDetails = () => {

    console.log(this.state.websiteDetails)
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    axios.put(`${SERVER_URL}/api/userwebsite/user/`, this.state.websiteDetails, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data submitted");
      }).catch(error => { console.log(error); })

  }

  putAccountDetails = () => {

    console.log(this.state.websiteDetails);
    const TOKEN = 'Bearer '.concat(this.props.data.token)
    const headers = {
      'Content-Type': 'application/json',
    }

    axios.put(`${SERVER_URL}/api/userwebsite/account`, this.state.websiteDetails, { headers: headers })
      .then(response => response.data)
      .then((data) => {
        console.log(data.id);
        alert("data submitted");
      }).catch(error => { console.log(error); })


  }


  renderWebsites = (id) => {
    const classes = this.props.classes;
    const websites = this.state.websiteDetails;
    let websiteItems = websites.map((prop, key) => {
      var index = key + 1;
      var id = prop.id;
      console.log(id)
      console.log(key);
      console.log(prop);
      return <GridContainer key={ index } className={ classes.gridcontainer } style={ { margitnBottom: "15px" } }>

        <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
          <TextField className={ classes.textfieldslno } value="/" style={ { textAlign: "center !important" } }
            id="document-type"
            value={ index }
            readOnly="true"
            label="S No"
            variant="outlined" />
        </GridItem>
        <GridItem lg={ 6 } md={ 6 } className={ classes.textfieldsgrid }>
          <TextField className={ classes.textfieldslno } label="Website URL" value={ this.state.hostURL } value={ prop.hostURL } readOnly={ true } disabled={ this.state.disableWebsiteDetailsFields } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
            onChange={ (event) => { this.updatesmaple(id, key, event.target.value, "hostURL") } } />
        </GridItem>
        <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
          <FormControl variant="outlined" className={ classes.formControl }>
            <InputLabel htmlFor="outlined-age-native-simple">Account Number</InputLabel>
            <Select className={ classes.SelectDropdown }
              native
              // value={item.accountNumber}
              onChange={ (event) => { this.updatesmaple(id, key, event.target.value, "bankId") } }
              label="select"
              inputProps={ {
                name: 'BankDetails',
                id: 'outlined-age-native-simple',
              } }>
              <option aria-label="None" value="" />
              { this.state.bankDetails.map((item, key) => (
                <option value={ item.id }  >{ item.accountNumber }</option>
              )) }
            </Select>
          </FormControl>
        </GridItem>

        {/* <GridItem lg={1} md={1} className={classes.AddButton} >
        <TextField className={classes.textfields}
          id="document-type"
          InputProps={{
            autoComplete: 'off',
            readOnly: true,
            startAdornment: (
              <InputAdornment position="start">
                <Add style={{ color: 'rgb(76, 175, 80)', cursor: 'pointer' }} className={classes.icon} />
              </InputAdornment>
            ),
          }}
          label="Add"
          variant="outlined" />
        </GridItem> */}
      </GridContainer>
    })
    return <CardBody className={ classes.CardBody }>
      { websiteItems }
      <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
        <div className={ classes.root2 } >

          <span style={ { paddingLeft: "10px" } } ><MButton variant="outlined" onClick={ this.enableWebsiteDetails }>{ this.state.websiteEditButtonText }</MButton>
          </span>
          <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="primary" onClick={ this.editWebsiteDetails } >
            Submit
          </MButton>
          </span>
          {/*
                    <MButton variant="outlined" color="secondary">
                      Reset
                    </MButton>
                    */}
        </div>
      </GridItem>
    </CardBody>

  }



  renderWebsitesManagerMapping = () => {

    const classes = this.props.classes;
    const websites = this.state.websiteDetails;
    //const websites = this.state.accountDetails;
    let websiteItems = websites.map((prop, key) => {
      var index = key + 1;
      var id = prop.id;
      console.log(id)
      console.log(key);
      console.log(prop);
      var messages = "Selected item is " + this.state.accountDetails;
      return <GridContainer key={ index } className={ classes.gridcontainer }>

        <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
          <TextField className={ classes.textfieldslno } style={ { textAlign: "center !important" } }
            id="document-type"
            value={ index }
            readOnly="true"
            label="S No"
            variant="outlined" />
        </GridItem>
        <GridItem lg={ 6 } md={ 6 } className={ classes.textfieldsgrid }>
          <TextField className={ classes.textfieldslno } label="Website URL" value={ this.state.hostURL } readOnly={ true } disabled={ this.state.disableWebsiteDetailsFields } value={ prop.hostURL } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
            onChange={ (event) => { this.updatesmaple(id, key, event.target.value, "hostURL") } } />
        </GridItem>
        <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
          <FormControl variant="outlined" className={ classes.formControl }>
            <InputLabel htmlFor="outlined-age-native-simple">Select Account Manager</InputLabel>

            <Select className={ classes.SelectDropdown }
              native
              onChange={ (event) => { this.updateManagerDetails(id, key, event.target.value, "managerId") } }
              label="select"
              inputProps={ {
                name: 'addManagerName',
              } }>
              <option aria-label="None" value="" />
              { this.state.accountDetails.map((item, key) => (
                <option value={ item.id }  >{ item.username }</option>
              )) }

            </Select>

          </FormControl>
        </GridItem>

        {/* <GridItem lg={1} md={1} className={classes.AddButton} >
        <TextField className={classes.textfields}
          id="document-type"
          InputProps={{
            autoComplete: 'off',
            readOnly: true,
            startAdornment: (
              <InputAdornment position="start">
                <Add style={{ color: 'rgb(76, 175, 80)', cursor: 'pointer' }} className={classes.icon} />
              </InputAdornment>
            ),
          }}
          label="Add"
          variant="outlined" />
        </GridItem> */}
      </GridContainer>
    })
    return <CardBody className={ classes.CardBody }>
      { websiteItems }
      <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
        <div className={ classes.root2 } >

          <span style={ { paddingLeft: "10px" } } ><MButton variant="outlined" onClick={ this.enableWebsiteDetails }>{ this.state.websiteEditButtonText }</MButton>
          </span>
          <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="primary" onClick={ this.putAccountDetails } >
            Submit
          </MButton>
          </span>
          {/*
                    <MButton variant="outlined" color="secondary">
                      Reset
                    </MButton>
                    */}
        </div>
      </GridItem>
    </CardBody>

  }
  addBank = () => {
    var row = {};
    var newStateArray = [...this.state.bankDetails];
    newStateArray.push(row);
    this.setState(() => {
      return {
        bankDetails: newStateArray
      };
    });

  }
  remove = (id) => {
    var newStateArray = [...this.state.bankDetails];
    if (newStateArray.length > 1) {
      newStateArray.pop();
    }
    this.setState(() => {
      return {
        bankDetails: newStateArray
      };
    });

    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.delete(`${SERVER_URL}/api/bankdetails/${id}`, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data deleted");
      }).catch(error => { console.log(error); })
  }

  addContact = () => {
    var row = {};
    var newStateArray = [...this.state.contactDetails];
    newStateArray.push(row);
    this.setState(() => {
      return {
        contactDetails: newStateArray
      };
    });

  }
  removeConatct = (id) => {

    var newStateArray = [...this.state.contactDetails];
    if (newStateArray.length > 1) {
      newStateArray.pop();
    }
    this.setState(() => {
      return {
        contactDetails: newStateArray
      };
    });
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.delete(`${SERVER_URL}/api/usercontact/details/${id}`, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data deleted");
      }).catch(error => { console.log(error); })
  }
  addWebsite = () => {
    var row = {};
    var newStateArray = [...this.state.websiteDetails];
    newStateArray.push(row);
    this.setState(() => {
      return {
        websiteDetails: newStateArray
      };
    });
  }

  updateRevenueDetail = (WebsiteId, index, value, fieldName) => {

    var lRevenueData = this.state.revenueData;
    var data = lRevenueData[WebsiteId];
    let a = parseFloat(value);
    let remainingShare = 1 - a;
    // for (let i = 0; i < data.length; i++) {
    //   if (fieldName === "erg_share") {
    //     data[index][fieldName] = value;
    //     data[index]["pub_share"] = remainingShare;

    //   }
    //   else if (fieldName === "pub_share") {
    //     data[index][fieldName] = value;
    //     data[index]["erg_share"] = remainingShare;
    //   }

    // }
    for (let i = 0; i < data.length; i++) {
      data[index][fieldName] = value;
    }
    lRevenueData[WebsiteId] = data;
    this.setState({ revenueDatas: lRevenueData });
    console.log(data);

  }

  renderRevAdvertiser = () => {
    const classes = this.props.classes;
    return <Card>
      <CardBody>
        <GridContainer>
          <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
            <FormControl variant="outlined" className={ classes.formControl }>
              <InputLabel htmlFor="outlined-age-native-simple"> </InputLabel>
              <Select className={ classes.SelectDropdown }
                native
                // value={item.accountNumber}
                onChange={ this.updateswebsiteRev }

                label="select"
                inputProps={ {
                  name: 'BankDetails',
                  id: 'outlined-age-native-simple',
                } }>
                <option aria-label="None" value="" />
                { this.state.websites.map((item, key) => (
                  <option value={ item[0] }  >{ item[2] }</option>
                )) }
              </Select>
            </FormControl>
          </GridItem>

          <GridItem lg={ 2 } md={ 2 } className={ classes.textfieldsgrid }>
            <TextField type="text" className={ classes.InputCenter } label=" My Share" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } }
              onChange={ (event) => this.updateShare(event.target.value, "erg_share") }
            />
          </GridItem>
          <GridItem lg={ 2 } md={ 3 } className={ classes.textfieldsgrid }>
            <TextField type="text" className={ classes.InputCenter } label=" Publisher Share" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%", textAlign: "center" } }
              onChange={ (event) => this.updateShare(event.target.value, "pub_share") }
            />
          </GridItem>
          <CardHeader style={ { float: "right!important" } }>
            <div className={ classes.root2 } >

              <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="primary"
                onClick={ this.addNewRev } >Add</MButton></span>
            </div>
          </CardHeader>
        </GridContainer>
      </CardBody>
    </Card>

  }

  renderRevenue = () => {
    const classes = this.props.classes;
    var data = this.state.revenueData;
    console.log(data)
    var lindex = 1;
    var lAccordingHtml = [];
    for (var websiteid in data) {
      console.log(websiteid);
      console.log(data[websiteid]);
      var lRevData = data[websiteid];
      var lData = lRevData.map((item, index) =>
        <Card>
          <CardBody className={ classes.InsideCardBody }>
            <GridContainer className={ classes.gridcontainer }>
              <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
                <InputBase className={ classes.marginSlno } style={ { textAlign: "center" } } value={ lindex } inputProps={ { 'aria-label': 'slno' } }
                />
              </GridItem>
              <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                <InputBase className={ classes.margin } defaultValue={ item.website_name } inputProps={ { 'aria-label': 'advertisername' } }
                  onChange={ (event) => { this.updateRevenueDetail(item.id_website, index, event.target.value, "website_name") } } />
              </GridItem>
              <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                <TextField className={ classes.textfields } label="My Share" defaultValue={ item.erg_share } disabled={ false } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                  onChange={ (event) => { this.updateRevenueDetail(item.id_website, index, event.target.value, "erg_share") } } />
              </GridItem>
              <GridItem lg={ 3 } md={ 3 } className={ classes.textfieldsgrid }>
                <TextField className={ classes.textfields } label=" Pub Share" defaultValue={ item.pub_share } disabled={ false } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                  onChange={ (event) => { this.updateRevenueDetail(item.id_website, index, event.target.value, "pub_share") } } />
              </GridItem>
            </GridContainer>
          </CardBody>
        </Card>

      )
      lindex++;
      lAccordingHtml.push(lData);
    }
    return lAccordingHtml;

  }
  updateswebsiteRev = (event) => {
    console.log(event.target.value)
    this.setState({ websiteRev: event.target.value })
  }

  updateShare = (value, fieldName) => {
    this.setState({ [fieldName]: value });
    console.log(this.state.erg_share)
    console.log(this.state.pub_share)
  }

  addNewRev = () => {
    console.log(this.state.websiteRev);
    console.log(this.state.userIDs);
    console.log(this.state.erg_share);
    console.log(this.state.pub_share);
    var obj = {
      "id_advertiser": this.state.userIDs,
      "id_website": this.state.websiteRev,
      "pub_share": this.state.pub_share,
      "erg_share": this.state.erg_share
    };
    var array = [];
    array.push(obj)
    console.log(array)
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.post(`${SERVER_URL}/api/website/revenues/add`, array)
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data submitted");
      }).catch(error => { console.log(error); })

  }


  renderWebsitesDetails = () => {
    const classes = this.props.classes;
    const websites = this.state.websiteDetails;
    let websiteItems = websites.map((prop, key) => {
      var index = key + 1;
      var id = prop.id;
      console.log(id)
      console.log(key);
      console.log(prop);
      return <GridContainer key={ index } className={ classes.gridcontainer }>

        <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid } >
          <TextField className={ classes.textfieldslno } style={ { textAlign: "center !important" } }
            id="document-type"
            value={ index }
            readOnly="false"
            label="S No"
            variant="outlined" />
        </GridItem>
        <GridItem lg={ 6 } md={ 6 } className={ classes.textfieldsgrid }>
          <TextField className={ classes.textfieldslno } label="Website URL" value={ this.state.hostURL } readOnly={ true } value={ prop.hostURL } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
            onChange={ (event) => { this.updatesmaple(id, key, event.target.value, "hostURL") } } />
        </GridItem>

        <GridItem lg={ 5 } md={ 5 } className={ classes.textfieldsgrid }>
          <TextField className={ classes.textfields } label="Name" readOnly={ true } value={ this.state.name } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
            onChange={ (event) => { this.updatesmaple(id, key, event.target.value, "name") } } />
        </GridItem>

        <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
          <TextField
            id="document-type"
            InputProps={ {
              autoComplete: 'off',
              readOnly: true,
              startAdornment: (
                <InputAdornment position="start">
                  <Add style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                </InputAdornment>
              ),
            } }
            label="Add"
            //onClick={() => { this.remove(prop.id) }}
            onClick={ () => { this.addWebsite() } }
            variant="outlined" />
        </GridItem>

        <GridItem lg={ 1 } md={ 1 } className={ classes.textfieldsgrid }>
          <TextField
            id="document-type"
            InputProps={ {
              autoComplete: 'off',
              readOnly: true,
              startAdornment: (
                <InputAdornment position="start">
                  <Remove style={ { color: 'rgb(253 44 11)', cursor: 'pointer' } } className={ classes.icon } />
                </InputAdornment>
              ),
            } }
            label="Remove"
            //onClick={() => { this.remove(prop.id) }}
            onClick={ () => { this.removeWebSite(key) } }
            variant="outlined" />
        </GridItem>
        {/*
        <GridItem lg={5} md={5} className={classes.textfieldsgrid}>
          <FormControl variant="outlined" className={classes.formControl}>
            <InputLabel htmlFor="outlined-age-native-simple">Name</InputLabel>
            <Select className={classes.SelectDropdown}
              native
              //value={item.accountNumber}
              onChange={(event) => { this.updatesmaple(id, key, event.target.value, "userId") }}
              label="select"
              inputProps={{
                name: 'WebsiteDetails',
                id: 'outlined-age-native-simple',
              }}>
              <option aria-label="None" value=""  />
              {this.state.websiteDetails.map((item, key) => (
                <option value={item.id} selected={item.id} >{item.name}</option>
              ))}

            </Select>
          </FormControl>
              </GridItem>  */}



        {/* <GridItem lg={1} md={1} className={classes.AddButton} >
        <TextField className={classes.textfields}
          id="document-type"
          InputProps={{
            autoComplete: 'off',
            readOnly: true,
            startAdornment: (
              <InputAdornment position="start">
                <Add style={{ color: 'rgb(76, 175, 80)', cursor: 'pointer' }} className={classes.icon} />
              </InputAdornment>
            ),
          }}
          label="Add"
          variant="outlined" />
        </GridItem> */}
      </GridContainer>
    })
    return <CardBody className={ classes.CardBody }>
      { websiteItems }
      <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
        <div className={ classes.root2 } >



          {/*
                        <MButton variant="outlined" color="secondary">
                          Reset
                        </MButton>
                        */}
        </div>
      </GridItem>
    </CardBody>
  }



  validateEmail = email => {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{ 1, 3 }\.[0-9]{ 1, 3 }\.[0-9]{ 1, 3 }\.[0-9]{ 1, 3 }\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{ 2,}))$/;
    if (!re.test(String(email).toLowerCase()))
      setTimeout(() => this.setErrors({ email: "Email is invalid" }), 800);
    else this.setErrors({ email: "" });
  };

  validateGST = gstin => {

    let regGstin = /\d{ 2 }[A-Z]{ 5 }\d{ 4 }[A-Z]{ 1 }[A-Z\d]{ 1 }[Z]{ 1 }[A-Z\d]{ 1 }/;
    if (!regGstin.test(gstin)) {
      setTimeout(() => this.setErrors({ gstin: "Invalid GSTIN Should enter e.g - 27AAPFU0939F1ZV" }), 800);
    } else {
      this.setErrors({ gstin: "" });
    }
  }
  setErrors = error =>
    this.setState({
      errors: { ...this.state.errors, ...error }
    });

  handleInputChange = e => {

    if (e.target.name === "email") {
      this.validateEmail(e.target.value);
      this.setState({
        email: e.target.value,

      });
    }
    if (e.target.name === "gstin") {

      this.validateGST(e.target.value);
      this.setState({
        gstin: e.target.value
      });
    }

  };


  render() {
    const classes = this.props.classes;

    console.log(this.state.userId);

    return <div className={ classes.root }>
      <GridContainer>
        <GridItem lg={ 2 }></GridItem>
        <GridItem xs="12" md="8" lg="8">
          <Card>
            <CardHeader color="primary" icon>
              <CardIcon color="primary">
                <Profileicon />
              </CardIcon>
              <h4 className={ classes.heading }>Profile</h4>
            </CardHeader>
            <CardBody className={ classes.CardBody }>
              <h4 className={ classes.headingStyle }>Primary Information</h4>
              <GridContainer className={ classes.gridcontainer } style={ { margitnBottom: "15px" } } >
                <GridItem lg={ 6 } xs={ 12 } md={ 6 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } disabled={ this.state.disableAccountDetailsFields } value={ this.state.companyName } label="Name of the entity" variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => {
                      this.setState({ "companyName": event.target.value })
                    } } />
                </GridItem>
                <GridItem lg={ 3 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } disabled={ this.state.disableAccountDetailsFields } value={ this.state.gstin } label="GST No" variant="outlined" id="outlined-size-small" size="small"
                    type="gstin"
                    name="gstin"
                    id="gstin"
                    value={ this.state.gstin }
                    onChange={ this.handleInputChange }
                    onBlur={ e => this.validateGST(e.target.value) }
                    title="GST"
                    autoComplete="off"
                    required />
                  <p class="error" style={ { color: 'red' } } >{ this.state.errors.gstin }</p>
                </GridItem>
                {/*<GridItem lg={3} xs={6} md={3} className={classes.textfieldsgrid}>
                  <TextField className={classes.textfields} label="PIN" variant="outlined" id="outlined-size-small" size="small" />
              </GridItem>*/}
              </GridContainer>
              <h4 className={ classes.headingStyle }>Address Details</h4>

              <GridContainer className={ classes.gridcontainer }>
                <GridItem lg={ 6 } xs={ 12 } md={ 6 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Address line1 " disabled={ this.state.disableAccountDetailsFields } value={ this.state.addressLineOne } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => {
                      this.setState({ "addressLineOne": event.target.value })
                    } } />
                </GridItem>
                <GridItem lg={ 6 } xs={ 12 } md={ 6 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Address line2" disabled={ this.state.disableAccountDetailsFields } value={ this.state.addressLineTwo } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => {
                      this.setState({ "addressLineTwo": event.target.value })
                    } } />
                </GridItem>
              </GridContainer>

              <GridContainer className={ classes.gridcontainer }>

                <GridItem lg={ 3 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="Post Office" disabled={ this.state.disableAccountDetailsFields } value={ this.state.postOffice } variant="outlined" id="outlined-size-small" size="small" style={ { width: "100%" } }
                    onChange={ (event) => {
                      this.setState({ "postOffice": event.target.value })
                    } } />
                </GridItem>
                <GridItem lg={ 3 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } className={ classes.taluk } disabled={ this.state.disableAccountDetailsFields } value={ this.state.taluk } label="Taluk" variant="outlined" id="outlined-size-small" size="small"
                    onChange={ (event) => {
                      this.setState({ "taluk": event.target.value })
                    } } />
                </GridItem>
                <GridItem lg={ 3 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label="District" disabled={ this.state.disableAccountDetailsFields } value={ this.state.district } variant="outlined" id="outlined-size-small" size="small"
                    onChange={ (event) => {
                      this.setState({ "district": event.target.value })
                    } } />
                </GridItem>
                <GridItem lg={ 3 } xs={ 6 } md={ 3 } className={ classes.textfieldsgrid }>
                  <TextField className={ classes.textfields } label=" State " disabled={ this.state.disableAccountDetailsFields } value={ this.state.state } variant="outlined" id="outlined-size-small" size="small"
                    onChange={ (event) => {
                      this.setState({ "state": event.target.value })
                    } } />
                </GridItem>
              </GridContainer>
              <GridContainer >
                <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
                  <div className={ classes.root2 } >
                    <span style={ { paddingLeft: "10px" } } ><MButton variant="outlined" onClick={ this.enableAccountDetails }>{ this.state.accountEditButtonText }</MButton>
                    </span>
                    <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="primary" onClick={ this.editAccountDetails } >
                      Submit
                    </MButton>
                    </span>

                    {/*
                    <MButton variant="outlined" color="secondary">
                      Reset
                    </MButton>
                    */}
                  </div>
                </GridItem>
              </GridContainer>

            </CardBody>

          </Card>
        </GridItem>
        <GridItem lg={ 2 }></GridItem>
      </GridContainer>

      <GridContainer >
        <GridItem lg={ 2 } md={ 2 }></GridItem>
        <GridItem lg={ 8 } md={ 8 }>
          <Card>
            <CardHeader color="primary" icon>
              <CardIcon color="primary">
                <PermContactCalendarIcon />
              </CardIcon>
              <h4 className={ classes.heading }>Contacts</h4>
            </CardHeader>
            <CardBody>
              { this.renderContactDetails() }
              <GridContainer >

                <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
                  <div className={ classes.root2 } >

                    <span style={ { paddingLeft: "10px" } } ><MButton variant="outlined" onClick={ this.enableContactDetails }>{ this.state.contactEditText }</MButton>
                    </span>
                    <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="primary" onClick={ this.editContactDetails } >
                      Submit
                    </MButton>
                    </span>

                    {/*
                    <MButton variant="outlined" color="secondary">
                      Reset
                    </MButton>
                    */}
                  </div>
                </GridItem>
              </GridContainer>
            </CardBody>
            {/*            
              <CardHeader style={{ float: "right!important" }}>
                <div className={classes.root2} >
                  <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" color="primary" >Edit</MButton></span>
                  <span style={{ paddingLeft: "10px" }}> <MButton variant="outlined" color="secondary" >Submit</MButton></span>
                </div>
              </CardHeader> */}
          </Card>
        </GridItem>
        <GridItem lg={ 2 } md={ 2 }></GridItem>
      </GridContainer>




      { this.props.type !== "Advertiser" &&
        <GridContainer >
          <GridItem lg={ 2 } md={ 2 }></GridItem>
          <GridItem lg={ 8 } md={ 8 }>
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">
                  <Globe />
                </CardIcon>
                <h4 className={ classes.heading }>Website Bank Account Mapping</h4>
              </CardHeader>
              { this.renderWebsites() }

            </Card>
          </GridItem>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
        </GridContainer> }

      { this.props.type !== "Advertiser" &&

        <GridContainer >
          <GridItem lg={ 2 } md={ 2 }></GridItem>
          <GridItem lg={ 8 } md={ 8 }>
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">
                  <Globe />
                </CardIcon>
                <h4 className={ classes.heading }>Website Details</h4>
              </CardHeader>
              { this.renderWebsitesDetails() }

              <GridContainer >
                <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
                  <div className={ classes.root2 } >


                    <span style={ { paddingLeft: "10px", marginBottom: "15px", marginRight: "10px" } } ><MButton variant="outlined" onClick={ this.enableWebsiteDetails }>{ this.state.websiteEditButtonText }</MButton>
                    </span>
                    <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" color="primary" onClick={ this.editWebsiteDetails } >
                      Submit
                    </MButton>
                    </span>
                  </div>
                </GridItem>
              </GridContainer>
            </Card>
          </GridItem>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
        </GridContainer>

      }


      { this.props.data.id === 1 && this.props.type !== "Advertiser" &&
        <GridContainer >
          <GridItem lg={ 2 } md={ 2 }></GridItem>
          <GridItem lg={ 8 } md={ 8 }>
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">
                  <Globe />
                </CardIcon>
                <h4 className={ classes.heading }>Website Account Manager Mapping</h4>
              </CardHeader>

              { this.renderWebsitesManagerMapping() }

            </Card>
          </GridItem>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
        </GridContainer>
      }

      { this.props.type == "Advertiser" &&
        <GridContainer >
          <GridItem lg={ 2 } md={ 2 }></GridItem>
          <GridItem lg={ 8 } md={ 8 }>
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">
                  <Globe />
                </CardIcon>
                <h4 className={ classes.heading }>Websites</h4>
              </CardHeader>
              <CardBody>
                {/* {this.props.type !== "Advertiser" &&
                this.renderRevenue()
              } */}
                {/*   {this.props.type == "Advertiser" && this.renderRevenue()}
            </CardBody>
            <CardHeader style={{ float: "right!important" }}>
              <div className={classes.root2} >
                <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" color="primary" >Edit</MButton></span>
                <span style={{ paddingLeft: "10px" }}> <MButton variant="outlined" color="secondary"
                  onClick={this.editRevenueAvg} >Submit</MButton></span>
              </div>
            </CardHeader>
            <CardBody> */}
                { this.renderRevAdvertiser() }
              </CardBody>
            </Card>

          </GridItem>

          <GridItem lg={ 2 } md={ 2 }></GridItem>
        </GridContainer>
      }
      <GridContainer className={ classes.gridcontainer }>

        <GridItem lg={ 2 }></GridItem>
        <GridItem xs={ 12 } md={ 8 } lg={ 8 }>
          <Card>
            <CardHeader color="primary" icon>
              <CardIcon color="primary">
                <Bankicon />
              </CardIcon>
              <h4 className={ classes.heading }>Bank Account details</h4>
            </CardHeader>
            <CardBody className={ classes.CardBody }>
              { this.renderBankAccountDetails() }

              <GridContainer >
                <GridItem xs={ 12 } md={ 12 } lg={ 12 } className={ classes.textfieldsgrid }>
                  <div className={ classes.root2 } >

                    <span style={ { paddingLeft: "10px" } }><MButton variant="outlined" onClick={ this.enableBankDetails } >{ this.state.bankDeatilEditText }</MButton></span>
                    <span style={ { paddingLeft: "10px" } }> <MButton variant="outlined" color="primary" onClick={ this.editBankDetails } >
                      Submit
                    </MButton></span>
                    {/*
                    <MButton variant="outlined" color="secondary">
                      Reset
                      </MButton>
                    */}
                  </div>
                </GridItem>
              </GridContainer>
            </CardBody >

          </Card>
        </GridItem>
        <GridItem lg={ 2 }>

        </GridItem>
      </GridContainer>

      {/* <GridContainer className={classes.gridcontainer}>

        <GridItem lg={2}></GridItem>
        <GridItem xs={12} md={8} lg={8}>
          <Card>
            <CardHeader color="primary" icon>
              <CardIcon color="primary">
                <Bankicon />
              </CardIcon>
              <h4 className={classes.heading}>Website - Bank account Mapping</h4>
            </CardHeader>
            <CardBody className={classes.CardBody}>
              {this.renderWebsiteBankaccountMapping()}
              <GridContainer >
                <GridItem xs={12} md={12} lg={12} className={classes.textfieldsgrid}>
                  <div className={classes.root2} >
                    <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" >Edit</MButton></span>
                    <span style={{ paddingLeft: "10px" }}> <MButton variant="outlined" color="primary" >
                      Submit
                    </MButton></span>
                    
                    <MButton variant="outlined" color="secondary">
                      Reset
                      </MButton>
                    
                  </div>
                </GridItem>
              </GridContainer>
            </CardBody >

          </Card>
        </GridItem>
        <GridItem lg={2}>

        </GridItem>
      </GridContainer>
       */}
      {/*
      <GridContainer className={classes.gridcontainer}>
        <GridItem lg={2} md={2} className={classes.textfieldsgrid}></GridItem>
        <GridItem lg={8} md={8} className={classes.textfieldsgrid}>
          <Card>
          <CardHeader color="primary" icon>
          <CardIcon color="primary">
            <Addpersonicon />
            </CardIcon>
            <h4 className={classes.heading}>Add more users</h4>
            </CardHeader>
            <CardBody className={classes.CardBody}>
            <GridContainer className={classes.gridcontainer}>
              
              <GridItem lg={12} md={12} className={classes.InsideCard} style={{padding:"0px 5px!important"}}>
                <Card>
                  <CardBody className={classes.CardBody}>
                    <GridContainer className={classes.gridcontainer}>
                      <GridItem lg={12} >
                      
                      <RadioGroup aria-label="user_permi" name="user_permi" style={{paddingLeft:"20px"}}>
                        <GridContainer className={classes.gridcontainer}>
                          <GridItem  lg={4} md={4}>
                          <h4 style={{paddingBottom:"0px",paddingTop:"0px!important",fontWeight:"500",fontSize:"1.1em",marginTop:"13px",marginBottom:"0px"}}>User permissions</h4>
                 
                          </GridItem> 
                          <GridItem  lg={8} md={8}>
                          <FormControlLabel value="Admin" control={<Radio />} label="Admin" />
                          
                          <FormControlLabel value="Read Only" control={<Radio />} label="Read Only" />
                          </GridItem>
                        </GridContainer>
                         
                    </RadioGroup>
                      </GridItem>
                    </GridContainer>
                    <GridContainer className={classes.gridcontainer}>
                      <GridItem lg={1} md={1} className={classes.textfieldsgrid}>
                      <TextField className={classes.textfieldslno}
                        id="document-type"   
                        value="1"
                        readOnly="true"
                        label="S No" 
                        variant="outlined" />
                     
                     
                      </GridItem>
                      <GridItem lg={5} md={5} className={classes.textfieldsgrid}>
                      <TextField className={classes.textfields} label="Username" variant="outlined" id="outlined-size-small"  size="small"  style={{width:"100%"}}/>
                      </GridItem>
                      <GridItem lg={5} md={5} className={classes.textfieldsgrid}>
                      <TextField className={classes.textfields} label="Mobile number" variant="outlined" id="outlined-size-small"  size="small"  style={{width:"100%"}}/>
                      </GridItem>
                      <GridItem lg={1} md={1} className={classes.textfieldsgrid}>
                      <TextField className={classes.textfields} 
                        id="document-type"   
                        InputProps={{
                        autoComplete: 'off', 
                        readOnly: true,
                        startAdornment: (
                        <InputAdornment position="start">
                        <Add style={{color:'rgb(76, 175, 80)', cursor:'pointer'}} className={classes.icon} />
                        </InputAdornment>
                        ),
                        }}
                        label="Add" 
                        variant="outlined" />
                      </GridItem>
                    </GridContainer>
                  </CardBody>
                </Card>
              </GridItem>
            </GridContainer>
            <GridContainer >
                      <GridItem xs={12} md={12} lg={12} className={classes.textfieldsgrid}>
                      <div  className={classes.root2} >
                      <MButton variant="outlined" >Edit</MButton>
                      <MButton variant="outlined" color="primary" >
                      Submit
                    </MButton>
                        <MButton variant="outlined" color="secondary">
                        Reset
                      </MButton>
                      </div>
                      </GridItem>
                    </GridContainer>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={2} md={2} className={classes.textfieldsgrid}></GridItem>
      </GridContainer>
        */}
    </div>
  }
}

const ProfileViewHOC = withStyles(styles)(ProfileView);
export default connect(mapStateToProps, mapDispatchToProps)(ProfileViewHOC);