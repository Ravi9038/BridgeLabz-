import React, { Component } from 'react'
import axios from 'axios';
import ReactTable from "react-table";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import Assignment from "@material-ui/icons/Assignment";
import Dvr from "@material-ui/icons/Dvr";
import Favorite from "@material-ui/icons/Favorite";
import Close from "@material-ui/icons/Close";
import Button from "components/CustomButtons/Button.js";
import { makeStyles } from "@material-ui/core/styles";
import { withStyles } from '@material-ui/styles';
import { SERVER_URL } from "../../variables/constants";
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'


const styles = {
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    }
};

const useStyles = makeStyles(styles);
export class Invoices extends Component {


    constructor(props) {
        super(props);
		/*
        this.state = {
            data : data.map((prop, key) => {
                return {
	
                  id: key,
                  userId: prop[0],
                  paymentCycleId: prop[1],
                  amount: prop[2],
                  deduction: prop[3],
                  currency: prop[],
                  status: prop[3]
                  
                };
              })
        };
		*/
        this.state = {
            data: [],
            bankDetails : [],
            contactDetails : [],
            websiteDetails : []
        };

    }

    componentDidMount() {
        
        const USER_ID = this.props.data.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);

        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
         var url = `${SERVER_URL}/api/invoicedetails/user/${USER_ID}`;
        
        axios.get(url).then(response => response.data)
            .then((data) => {
                console.log(data);
                this.setState({
                    data: data,
                    //bankDetails : lBankDetails,
                    //contactDetails :lContactDetails , 
                });
            }).catch((error) => console.log(error));
    }


    setData = (pData) => {
        this.setState({ data: pData });
    }

    
   /*  _renderContactDetails = () =>{
        var bankDetails = this.state.bankDetails;
        var items = bankdetails.forEach(item => {
            return <GridItem>

                </GridItem>
        })
        return <GridContainer>{items}</GridContainer>
    }
    _renderBankDetails = () =>{
        
    }
    _renderWebsiteDetails= () =>{
        
    } */


    render() {
        const { classes } = this.props;
        return <GridContainer>
            {/* {this._renderContactDetails()}
            {this._renderBankDetails()}
            {this._renderWebsiteDetails()} */}
            <GridItem xs={12}>
                <Card>
                    <CardHeader color="primary" icon>
                        <CardIcon color="primary">
                            <Assignment />
                        </CardIcon>
                        <h4 className={classes.cardIconTitle}>Invoices</h4>
                    </CardHeader>
                    <CardBody>
                        <ReactTable
                            data={this.state.data}
                            filterable
                            columns={[
                                {
                                    Header: "Invoice No.",
                                    accessor: "id"
                                },
                                {
                                    Header: "Payment Cycle",
                                    accessor: "paymentCycleId"
                                },
                                {
                                    Header: "Amount",
                                    accessor: "amount"
                                },
                                {
                                    Header: "Deduction",
                                    accessor: "deduction"
                                },
                                {
                                    Header: "Currency",
                                    accessor: "currency"
                                },
                                {
                                    Header: "Status",
                                    accessor: "status"
                                }


                            ]}
                            defaultPageSize={10}
                            showPaginationTop
                            showPaginationBottom={false}
                            className="-striped -highlight"
                        />
                    </CardBody>
                </Card>
            </GridItem>
        </GridContainer>

    }

}

const InvoicesHOC = withStyles(styles)(Invoices);
export default connect(mapStateToProps, mapDispatchToProps)(InvoicesHOC);

