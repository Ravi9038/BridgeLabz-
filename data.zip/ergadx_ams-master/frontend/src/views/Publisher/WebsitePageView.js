import React, { Component } from "react";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Checkbox from '@material-ui/core/Checkbox';
import Chip from '@material-ui/core/Chip';
import Autocomplete from '@material-ui/lab/Autocomplete';

import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import InputLabel from '@material-ui/core/InputLabel';
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import { connect } from 'react-redux';
import ListItemText from '@material-ui/core/ListItemText';
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import Card from "components/Card/Card.js";
import Paper from "@material-ui/core/Paper";
import Assignment from "@material-ui/icons/Assignment";
import Input from '@material-ui/core/Input';
import TagsInput from "react-tagsinput";
import { SERVER_URL } from "../../variables/constants";
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import MButton from '@material-ui/core/Button';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;
const styles = {
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    },
    root: {
        ' & .makeStyles-card-194': {
            width: "70%",
            marginLeft: "200px",
        }
    },
    selectedItem: {
        ' & .MuiPaper-elevation1': {
         
            padding: "10px",
            listStyleType: "none"
        },
        ' & .MuiChip-outlinedPrimary': {
            padding: "5px",
            margin: "5px",

        }
    },
    DeviceSelect: {
        '& .MuiChip-root': {
            display: 'none'
        }
    },
    adUnits:{
        '& .MuiChip-root': {
            display: 'none'
        }  
    }
}


class WebsitePageView extends Component {

    constructor(props) {
        super(props);
        this.state = {
            websitePageData: [],
            devices: 0,
            label: '',

            pageCheckValue: '',
            Dimention: [
                "Mobile",
                "Tablet",
                "DeskTop"
            ],
            selectedDimention: [],
            pageCheckType: [
                "Contains",
                "Equals",
                "Regex"
            ],
            
            pageCheckTypes: '',
            checkedValue: '',
            adUnitDetails: [],
            adUnitValues: [],
            selectedAdunit: [],
            emptyArray: [],
            adUnitId: [],
            recivedAdunit:[],
        }
    }


    componentDidMount = () => {
        const ID = this.props.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/websitepage/${ID}`, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                this.setState({ websitePageData: data });
                this.setState({ label: data.label })
                this.setState({ devices: data.devices });
                this.setState({ pageCheckTypes: data.pageCheckType })
                this.setState({ pageCheckValue: data.pageCheckValue })
                var valueToPass = [];
                const value = JSON.parse(this.state.devices)
                if (value.mobile) {
                    valueToPass.push("mobile")
                }
                if (value.tablet) {
                    valueToPass.push("tablet")
                }
                if (value.desktop) {
                    valueToPass.push("desktop")
                }

                console.log(valueToPass)
                //    this.setState({selectedDimention:valueToPass})
            }).catch(error => { console.log(error); })
        this.adUnitDetails();
        this.loadPageDetail();
    }

    loadPageDetail=()=>{
        const ID = this.props.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/ad/websitemap/get/${ID}`, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                // this.setState({ mappedDetails: data })
                var array = [];
                var idPage=[];
                // data.map((element) => {
                //     const nameSize = element.name;
                //     array.push({ name: nameSize })
                // })

                data.map((element) => {
                      
                        this.setState(prevState => ({
                            selectedAdunit: [...prevState.selectedAdunit,  element.name]
                        }))
                    })
             
                data.map((element) => {
                    const id = element.id;
                    idPage.push({ id: id })
                })
         console.log(array);
         console.log(idPage);
        //    this.setState({selectedAdunit:array})
            }).catch(error => { console.log(error); })
    }
    adUnitDetails = () => {
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/websitepagead`, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                this.setState({ adUnitDetails: data })
                var array = [];
                data.map((element) => {
                    const nameSize = element.name ;
                    array.push({ name: nameSize, id: element.id })
                })
                console.log(array)
                this.setState({ adUnitValues: array })
            }).catch(error => { console.log(error); })
    }
    updateForWebsite = (event, fieldName) => {
        if (fieldName === 'label') {
            this.setState({ label: event.target.value })
        }
        if (fieldName === 'pageCheckValue') {
            this.setState({ pageCheckValue: event.target.value })

        }
        console.log(this.state.label)
        console.log(this.state.pageCheckValue)
    }

    insertForWebsitePage = (event) => {
        this.setState({ selectedDimention: event.target.value });
        console.log(this.state.selectedDimention);

    }
    updateswebsiteData = (event) => {
        console.log(event.target.value);
        this.setState({ pageCheckTypes: event.target.value })

    }

    editAccountDetails = () => {
        console.log(this.state.selectedDimention)
        const IDwebsite = this.props.idWebsite;
        let Mobilestatus = false
        let tabletstatus = false
        let desktopstatus = false
        if (this.state.selectedDimention.includes("Mobile")) {
            Mobilestatus = true
        } if (this.state.selectedDimention.includes("Tablet")) {
            tabletstatus = true
        } if (this.state.selectedDimention.includes("DeskTop")) {
            desktopstatus = true
        }
        var deviceStatus = { "mobile": Mobilestatus, "tablet": tabletstatus, "desktop": desktopstatus }
        var obj = JSON.stringify(deviceStatus);
        console.log(obj)
        const IDS = this.props.id;
        var request = {};
        request.label = this.state.label;
        request.idWebsite = this.props.idWebsite;
        request.id = this.props.id;
        request.pageCheckType = this.state.pageCheckTypes;
        request.pageCheckValue = this.state.pageCheckValue;
        request.devices = obj;
        console.log(request)
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.put(`${SERVER_URL}/api/websitepage/${IDS}`, request, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                alert("data submitted");
            }).catch(error => { console.log(error); })

    }
    seletedAdUntUpdate = (option) => {
    

        
        this.setState(prevState => ({
            selectedAdunit: [...prevState.selectedAdunit, option.name]
        }))
        this.setState(prevState => ({
            adUnitId: [...prevState.adUnitId, option.id]
        })) 

    }

    submitDetails = () => {
        console.log(this.state.selectedAdunit);
        console.log(this.state.adUnitId);
        var request = this.state.adUnitId;
        const IDS = this.props.id
        console.log(IDS)
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.post(`${SERVER_URL}/api/ad/websitemap/${IDS}`, request, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                alert("data submitted");
            }).catch(error => { console.log(error); 
                alert("data is already exist")})
    }
    handleDelete = (i) => {
        const { selectedAdunit } = this.state;
        this.setState({
            selectedAdunit: selectedAdunit.filter((file, index) => index !== i),
        });
        const { adUnitId } = this.state;
        this.setState({
            adUnitId: adUnitId.filter((file, index) => index !== i),
        });
    }

    renderMappingAdunitToPage = () => {
        const classes = this.props.classes;
        return <GridContainer justify="center">
            <GridItem xs={12} sm={12} md={8} lg={8} >
                <Card>
                    <CardHeader color="rose" icon>
                        <CardIcon color="rose">
                            <Assignment />
                        </CardIcon>
                        <h4 className={classes.cardIconTitle}>Mapping Page With Adunit</h4>
                    </CardHeader>
                    <CardBody   >
                        <GridContainer>
                            <GridItem lg={5} md={5} className={classes.textfieldsgrid}>
                                <FormControl variant="outlined" className={classes.formControl}>
                                    {/* <InputLabel htmlFor="outlined-age-native-simple">Ad Unit</InputLabel> */}
                                    <Autocomplete
                                        multiple
                                        
                                        id="checkboxes-tags-demo"
                                        className={classes.adUnits}
                                        options={this.state.adUnitValues}
                                        disableCloseOnSelect
                                        getOptionLabel={(option) => option.name}
                                        renderOption={(option, { selected }) => (
                                            <React.Fragment key={option.name}  children={option.id}>
                                                <Checkbox
                                                    icon={icon}
                                                    
                                                    checkedIcon={checkedIcon}
                                                    style={{ marginRight: 8 }}
                                                    // checked={selected}
                                                    checked={this.state.selectedAdunit.includes(option.name)}
                                                    onClick={()=>this.seletedAdUntUpdate(option)}
                                                />
                                                {option.name}
                                            </React.Fragment>
                                        )}
                                        style={{ width:300}}
                                        renderInput={(params) => (
                                            <TextField {...params} variant="outlined" label="Ad unit "  />
                                        )}
                                    />
                                    {/*  <Select
                                        labelId="demo-mutiple-checkbox-label"
                                        id="demo-mutiple-checkbox"
                                        multiple
                                        className={classes.DeviceSelect}
                                        value={this.state.selectedAdunit}
                                        onChange={(event,child)=>this.seletedAdUntUpdate(event,child.props.id)}
                                        input={<Input id="select-multiple-chip" />}
                                        renderValue={(selected) => (
                                            <div className={classes.chips}>
                                                {selected.map((value) => (
                                                    <Chip key={value} label={value} className={classes.chip} />
                                                ))}
                                            </div>
                                        )}

                                    > 
                                    {this.state.adUnitValues.map((element) => (
                                        <MenuItem key={element.name} value={element.name} id={element.id}>
                                            <Checkbox checked={this.state.selectedAdunit.indexOf(element.name) > -1} />
                                            <ListItemText primary={element.name} />
                                        </MenuItem>
                                    ))}
                                  
                                     </Select>  */}
                                </FormControl>
                          
                            </GridItem>
                            <GridItem lg={1} md={5} className={classes.textfieldsgrid}></GridItem>
                             <GridItem lg={6} md={5} className={classes.textfieldsgrid + " " + classes.selectedItem} >
                                <InputLabel htmlFor="outlined-age-native-simple">Selected Adunit</InputLabel>
                                <Paper component="ul">
                                    {this.state.selectedAdunit.length > 0 && this.state.selectedAdunit.map((data, i) => {
                                        let icon = "";
                                        return (
                                            <li>
                                                <Chip
                                                    icon={icon}
                                                    variant="outline"
                                                    color="primary"
                                                    onDelete={() => this.handleDelete(i)}
                                                    label={data}
                                                    className="m-1"
                                                />
                                            </li>
                                        );
                                    })}

                                </Paper>

                            </GridItem>
                             
                            <GridContainer >
                                <GridItem xs={12} md={12} lg={12} className={classes.textfieldsgrid}>
                                    <div className={classes.root2} >
                                        <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" color="primary" onClick={this.submitDetails} >
                                            Submit  </MButton> </span>

                                    </div>
                                </GridItem>

                            </GridContainer>
                        </GridContainer>
                    </CardBody>
                </Card>
            </GridItem>
        </GridContainer >

    }

    render() {
        const classes = this.props.classes;
        return (
            <div className={classes.root}>
                <GridContainer justify="center">
                    <GridItem xs={12} sm={12} md={8} lg={8} >
                        <Card>
                            <CardHeader color="rose" icon>
                                <CardIcon color="rose">
                                    <Assignment />
                                </CardIcon>
                                <h4 className={classes.cardIconTitle}>Page Editing</h4>
                            </CardHeader>
                            <CardBody   >
                                <GridContainer className={classes.SelectCustom} style={{ margitnBottom: "15px" }} >
                                    <GridItem lg={6} xs={12} md={6} className={classes.textfieldsgrid}>
                                        <TextField className={classes.textfields} label="Page Name/ Label" variant="outlined" value={this.state.label} id="outlined-size-small" size="small" style={{ width: "100%" }}
                                            onChange={(event) => { this.updateForWebsite(event, "label") }} />
                                    </GridItem>
                                    <GridItem lg={6} md={5} className={classes.textfieldsgrid}>
                                        <FormControl variant="outlined" className={classes.formControl}>
                                            <InputLabel htmlFor="outlined-age-native-simple">Devices</InputLabel>
                                            <Select
                                                labelId="demo-mutiple-checkbox-label"
                                                id="demo-mutiple-checkbox"
                                                multiple
                                                variant="outlined"
                                                value={this.state.selectedDimention}
                                                onChange={this.insertForWebsitePage}
                                                input={<Input />}
                                                renderValue={(selected) => selected.join(', ')}

                                            >
                                                {this.state.Dimention.map((element) => (
                                                    <MenuItem key={element} value={element}>
                                                         <Checkbox  checked={this.state.selectedDimention.indexOf(element)>-1}  /> 
                                                      

                                                        <ListItemText primary={element} />
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>
                                    </GridItem>



                                </GridContainer>
                                <GridContainer className={classes.SelectCustom} style={{ margitnBottom: "15px" }}>
                                    <GridItem lg={6} xs={12} md={6} className={classes.textfieldsgrid}>
                                        <TextField className={classes.textfields} label="Page Check Value" variant="outlined" id="outlined-size-small" size="small" value={this.state.pageCheckValue} style={{ width: "100%" }}
                                            onChange={(event) => { this.updateForWebsite(event, "pageCheckValue") }} />
                                    </GridItem>
                                    <GridItem lg={6} md={5} className={classes.textfieldsgrid}>
                                        <FormControl variant="outlined" className={classes.formControl}>
                                            <InputLabel htmlFor="outlined-age-native-simple">Page Check Type</InputLabel>
                                            <Select className={classes.SelectDropdown}
                                                native
                                                value={this.state.pageCheckTypes}
                                                onChange={this.updateswebsiteData}
             
                                                label="select"
                                                inputProps={{
                                                    name: 'BankDetails',
                                                    id: 'outlined-age-native-simple',
                                                }}>
                                                <option aria-label="None" value="" />
                                                {this.state.pageCheckType.map((item, key) => (
                                                    <option value={item}  >{item}</option>
                                                ))}
                                            </Select>
                                        </FormControl>
                                    </GridItem>

                                </GridContainer>
                                <GridContainer >
                                    <GridItem xs={12} md={12} lg={12} className={classes.textfieldsgrid}>
                                        <div className={classes.root2} >
                                            <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" color="primary" onClick={this.editAccountDetails} >
                                                Submit  </MButton> </span>

                                        </div>
                                    </GridItem>
                                </GridContainer>
                            </CardBody>
                        </Card>
                    </GridItem>
                </GridContainer >

                {this.renderMappingAdunitToPage()}
            </div>
        )
    }
}
const WebsitePageViewHOC = withStyles(styles)(WebsitePageView);
export default connect(mapStateToProps, mapDispatchToProps)(WebsitePageViewHOC);