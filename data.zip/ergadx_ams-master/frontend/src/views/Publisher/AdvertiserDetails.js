import React, { Component } from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
// @material-ui/core components
import { withStyles, makeStyles } from "@material-ui/core/styles";
import TextField from '@material-ui/core/TextField';
import { MDBBtn } from 'mdb-react-ui-kit';


import ProfileView from './ProfileView.js';
import AdvertiserWebsiteMapping from './AdvertiserWebsiteMapping.js';
import View from "@material-ui/icons/Visibility";
import CreateContact from './CreateContact.js'

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import { dataTable } from "variables/AdvertiserDatatable";
import Switch from '@material-ui/core/Switch';

import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import MButton from '@material-ui/core/Button';

import Tooltip from '@material-ui/core/Tooltip';
// material-ui icons
import IconButton from '@material-ui/core/IconButton';

import Profileicon from "@material-ui/icons/Person"
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import PermContactCalendarIcon from '@material-ui/icons/PermContactCalendar';
import LedgerView from '@material-ui/icons/ListAlt';
import styles from "assets/jss/material-dashboard-pro-react/views/PublisherCustomStyle.js";
import Button from "components/CustomButtons/Button.js";
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Add from '@material-ui/icons/Add'
import AddContactButton from 'views/Publisher/AddContact.js'

import axios from "axios";
import { SERVER_URL } from "../../variables/constants";
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}))(Tooltip);

const useStyles = makeStyles(styles);
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="left" ref={ ref } { ...props } />;
});


export class Advertiser extends Component {
  state = {
    status: '',
    addCompanyName: '',
    profileKey: '',
    contactStatus: '',
    newAdsTxt: '',
    adId: '',
    newAds: '',
    completearrayData: '',
    publisherId: 0,
    adxDetails: [],
    expanded: false,
    arrayData: '',
    AdvertiserViewopen: false,
    AdvertiserProfileopen: false,
    AdvertiserWebsiteProfileViewOpen: false,
    AdvertiserProfileViewopen: false,
    Adstxtopen: false,
    LatestAdstxtOpen: false,
    AdstxtViewopen: false,
    AdstxtViewIconopen: false,
    Ledgeropen: false,
    ViewLedgeropen: false,
    CreateContact: false,
    tab: 'View',
    totalAdvertiser: '',
    data: dataTable.dataRows.map((prop, key) => {
      return {
        id: key,
        slno: prop[0],
        AdvertiserName: prop[1],
        contactName: prop[2],
        contactNumber: prop[3],
        email: prop[4],
        actions: prop[5],
        level: prop[5],
        designation: prop[6],
        reportingTo: prop[7],
        actionContactView: prop[8],
        WebsiteCount: prop[8],
        OneMRank: prop[9],
        ThreeMRank: prop[10],
        LifeTimeRank: prop[11],
        actionsAdvertiserProfile: prop[12],
        AdvertiserShare: prop[12],
        DomainName: prop[13],
        date: prop[14],
        particular: prop[15],
        debit: prop[16],
        credit: prop[17],
        balance: prop[18]


      };
    }),


    activeAdvertiser: dataTable.dataRows.map((prop, key) => {
      return {
        id: key,
        slno: prop[0],
        AdvertiserName: prop[1],
        contactName: prop[2],
        contactNumber: prop[3],
        email: prop[4],
        actions: prop[5],
        level: prop[5],
        designation: prop[6],
        reportingTo: prop[7],
        actionContactView: prop[8],
        WebsiteCount: prop[8],
        OneMRank: prop[9],
        ThreeMRank: prop[10],
        LifeTimeRank: prop[11],
        actionsAdvertiserProfile: prop[12],
        AdvertiserShare: prop[12],
        DomainName: prop[13],
        date: prop[14],
        particular: prop[15],
        debit: prop[16],
        credit: prop[17],
        balance: prop[18]


      };
    }),

    inActiveAdvertiser: dataTable.dataRows.map((prop, key) => {
      return {
        id: key,
        slno: prop[0],
        AdvertiserName: prop[1],
        contactName: prop[2],
        contactNumber: prop[3],
        email: prop[4],
        actions: prop[5],
        level: prop[5],
        designation: prop[6],
        reportingTo: prop[7],
        actionContactView: prop[8],
        WebsiteCount: prop[8],
        OneMRank: prop[9],
        ThreeMRank: prop[10],
        LifeTimeRank: prop[11],
        actionsAdvertiserProfile: prop[12],
        AdvertiserShare: prop[12],
        DomainName: prop[13],
        date: prop[14],
        particular: prop[15],
        debit: prop[16],
        credit: prop[17],
        balance: prop[18]


      };
    }),

    advertiserContactDetails: dataTable.dataRows.map((prop, key) => {
      return {
        id: key,
        slno: prop[0],
        publisherName: prop[1],
        designation: prop[2],
        contactNumber: prop[3],
        email: prop[4],
        reportingTo: prop[5]

      }
    }),
    activeAdvertiserContactDetails: dataTable.dataRows.map((prop, key) => {
      return {
        id: key,
        slno: prop[0],
        publisherName: prop[1],
        designation: prop[2],
        contactNumber: prop[3],
        email: prop[4],
        reportingTo: prop[5]

      }
    }),
    inAdvertiserContactDetails: dataTable.dataRows.map((prop, key) => {
      return {
        id: key,
        slno: prop[0],
        publisherName: prop[1],
        designation: prop[2],
        contactNumber: prop[3],
        email: prop[4],
        reportingTo: prop[5]

      }
    }),

  }

  filterCaseInsensitive = (filter, row) => {

    const id = filter.pivotId || filter.id;
    if (row[id] !== null) {
      return (
        row[id] !== undefined ?
          String(row[id].toString().toLowerCase())
            .includes(filter.value.toString().toLowerCase())
          :
          true
      );
    }
  }


  AdvertiserViewhandleClose = () => {
    this.setState({ AdvertiserViewOpen: false });
  };
  AdvertiserProfilehandleClickOpen = () => {
    this.setState({ AdvertiserProfileOpen: true }); //.AdvertiserProfileOpen(true);
  };

  AdvertiserProfilehandleClose = () => {
    this.setState({ AdvertiserProfileOpen: false });
  };
  AdvertiserProfileViewhandleClickOpen = (pkey) => {
    this.setState({ AdvertiserProfileViewOpen: true });
    this.setState({ profileKey: pkey })
  };

  AdvertiserWebsiteProfileViewhandleClickOpen = (pkey) => {
    this.setState({ AdvertiserWebsiteProfileViewOpen: true });
    this.setState({ profileKey: pkey })
  };
  AdvertiserWebsiteProfileViewhandleClose = () => {
    this.setState({ AdvertiserWebsiteProfileViewOpen: false });
  };
  AdvertiserProfileViewhandleClose = () => {
    this.setState({ AdvertiserProfileViewOpen: false });
  };
  AdstxthandleClickOpen = () => {
    this.setState({ Adstxtopen: true });//.AdstxtOpen(true);
  };

  AdstxthandleClose = () => {
    this.setState({ Adstxtopen: false })
  };
  LatestAdstxthandleClickOpen = () => {
    this.setState({ LatestAdstxtOpen: true });
  };

  LatestAdstxthandleClose = () => {
    this.setState({ LatestAdstxtOpen: false });
  };

  AdstxtViewhandleClickOpen = () => {
    this.setState({ AdstxtViewOpen: true })
  };

  AdstxtViewhandleClose = () => {
    this.setState({ AdstxtViewOpen: false })
  };
  AdstxtViewIconhandleClickOpen = () => {
    this.setState({ AdstxtViewIconOpen: true })
  };

  AdstxtViewIconhandleClose = () => {
    this.setState({ AdstxtViewIconOpen: false })
  };
  addAdstxtViewIconhandleClickOpen = (value, companyNames) => {
    this.setState({ addCompanyName: companyNames })
    this.setState({ addAdstxtViewIconOpen: true })
    this.setState({ adId: value })
  };

  addAdstxtViewIconhandleClose = () => {
    this.setState({ addAdstxtViewIconOpen: false })
  };


  LedgerhandleClickOpen = () => {
    this.setState({ Ledgeropen: true })
  };

  LedgerhandleClose = () => {
    this.setState({ Ledgeropen: false })
  };
  ViewLedgerhandleClickOpen = () => {
    this.setState({ ViewLedgeropen: true })
  };

  ViewLedgerhandleClose = () => {
    this.setState({ ViewLedgeropen: false })
  };

  handleChange = (panel) => (event, isExpanded) => {
    this.setState({ Expanded: (isExpanded ? panel : false) });
  };
  tabsetCreate = () => {
    
    const create = document.getElementById("create");
    const view = document.getElementById("view");
    create.style = "background-color:#1E90FF; color:#fff"; 
    view.style = "background-color:#fff; color:#000";

    this.setState({ tab: 'Create' });


  }
  tabsetView = () => {
    const create = document.getElementById("create");
    const view = document.getElementById("view");
    view.style = "background-color:#1E90FF; color:#fff"; 
    create.style = "background-color:#fff; color:#000";

    this.setState({ tab: 'View' });
  }

  componentDidMount() {
    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    axios.get(`${SERVER_URL}/api/users/advertisers`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        this.setState({
          data: data,
          totalAdvertiser: data.length
        })

        var active = [];
        var inActive = [];
        for (let one in data) {
          if (data[one].status === "ACTIVE") {
            active.push(data[one]);
          }
          else if (data[one].status === "INACTIVE") {
            inActive.push(data[one])
          }
        }
        this.setState({ activeAdvertiser: active })
        this.setState({ inActiveAdvertiser: inActive })

      }).catch((error) => {
        console.error(error);
      });

    axios.get(`${SERVER_URL}/api/adstxt/advertiser/get/`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        var array = [];

        for (let i = 0; i < data.length; i++) {

          if (data[i].certification_auth_id !== "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "," + data[i].certification_auth_id + "\n");

          }
          else if (data[i].certification_auth_id === "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "\n");

          }
        }
        var passingArray = array.join("\n");

        this.setState({ completearrayData: passingArray });


      }).catch((error) => {
        console.error(error);
      });


  }

  editAdvertiser = (editObject) => {
    this.props.history.push('/admin/edit-user', { editObject });
  }

  AdvertiserViewhandleClickOpen = (pKey) => {
    this.setState({ publisherId: pKey })

    this.setState({ AdvertiserViewOpen: true });
    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/usercontact/details/${pKey}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        this.setState({ advertiserContactDetails: data });
        var active = [];
        var inactive = [];

        for (let i = 0; i < data.length; i++) {
          if (data[i].status === "ACTIVE") {
            active.push(data[i]);
          }
          else if (data[i].status === "INACTIVE") {
            inactive.push(data[i]);
          }
        }

        this.setState({ activeAdvertiserContactDetails: active });
        this.setState({ inAdvertiserContactDetails: inactive });
      }).catch((error) => {
        console.error(error);
      });

  };


  sample = (id) => {

    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/adstxt/advertiser/${id}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        this.setState({ adxDetails: data })

        var array = [];

        for (let i = 0; i < this.state.adxDetails.length; i++) {

          if (data[i].certification_auth_id !== "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "," + data[i].certification_auth_id + "\n");

          }
          else if (data[i].certification_auth_id === "") {
            array.push(data[i].exchange_domain_name + "," + data[i].account_id + "," + data[i].account_type + "\n");

          }
        }
        var passingArray = array.join("\n");

        this.setState({ arrayData: passingArray });
        this.setState({ AdstxtViewIconOpen: true })

      }).catch((error) => {
        console.error(error);
      });
  }

  CreateNewContacthandleClickOpen = () => {
    this.setState({ CreateContact: true })
  };

  CreateNewContacthandleClose = () => {
    this.setState({ CreateContact: false })
  };

  copy = (text) => {
    var input = document.body.appendChild(document.createElement("input"));
    input.value = text;
    input.focus();
    input.select();
    document.execCommand("copy")
  }

  renderAdxDetails = () => {
    const classes = this.props.classes;
    let adxTxtDetails = this.state.adxDetails;

    return <GridContainer>
      <GridItem lg={ 3 } md={ 3 } ></GridItem>
      <GridItem lg={ 6 } md={ 6 } ><Card className={ classes.CustomCard }>
        <CardBody>
          <GridContainer>
            <GridItem lg={ 12 } md={ 12 }>
              <TextareaAutosize className={ classes.TextAreacustom } disabled="true" aria-label="minimum height" rowsMin={ 10 }
                defaultValue={ this.state.arrayData }
                ref={ (textarea) => this.textArea = textarea } />
            </GridItem>
          </GridContainer>
        </CardBody>
        <CardHeader >
          <div className={ classes.FloatLeft } >


            <span><MButton variant="outlined" color="primary" onClick={ () => { navigator.clipboard.writeText(this.state.arrayData) } } >Copy text to clipboard</MButton></span>
            <span className={ classes.ButtonLeftSpace }><MButton variant="outlined" color="primary" onClick={ () => { this.downloadTextFile(this.state.arrayData) } }>Download Ads.txt File</MButton></span>
          </div>
          {/*  <div className={classes.FloatRight} >
            <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
            <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="secondary" >Cancel</MButton></span>
          </div> */}
        </CardHeader>
      </Card></GridItem>
      <GridItem lg={ 3 } md={ 3 } ></GridItem>
    </GridContainer>

  }
  downloadTextFile = (value) => {
    const element = document.createElement("a");
    const file = new Blob([value], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = "ADS.txt";
    document.body.appendChild(element); // Required for this to work in FireFox
    element.click();
  }


  disableAdvertiser = (pKey) => {


    var url = `${SERVER_URL}/api/users/${pKey}`;
    axios.delete(url, {}).then(response => response.data)
      .then((data) => {
        this.setState({ data: data })
      }).catch(error => { console.log(error); })

  }


  updateAdxValue = (value) => {
    var id = this.state.adId;
    this.setState({ newAds: value })

  }

  submitNewAdsTxt = () => {
    var key = this.state.adId

    var data = {
      "id_advertiser": key,
      "ads_txt_records": this.state.newAds
    }
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.post(`${SERVER_URL}/api/adstxt/advertiser/${key}`, data, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {

        alert("data submitted");
      }).catch(error => { console.log(error); })
  }

  viewAdsTxtRecords = (pKey) => {
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    axios.get(`${SERVER_URL}/api/adstxt/advertiser/${pKey}`, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let strAdsTxtRecord = "";
        let adsTxtRecords = res.data;
        let adsHtmlRecords = "<ol>";
        debugger;
        adsTxtRecords.forEach(record => {
          let strRecord = record.exchange_domain_name + "," + record.account_id;
          if (record.account_type)
            strRecord = strRecord + "," + record.account_type;
          if (record.certification_auth_id) {
            strRecord = strRecord + "," + record.certification_auth_id;
            strAdsTxtRecord = strAdsTxtRecord + "\n" + strRecord;
          } else {
            strAdsTxtRecord = strAdsTxtRecord + "\n" + strRecord;
          }
          adsHtmlRecords = adsHtmlRecords + "<li>" + strRecord + "</li>";
        });

        adsHtmlRecords = adsHtmlRecords + "</ol>";
        this.setState({
          isAdsTxtViewPaneOpen: true,
          adsTxtRecords: strAdsTxtRecord
        });
      }).catch(function (error) {
        console.log(error);
      });
  }

  insertAdsTxtRecords = (pKey) => {

  }


  latestAllAds = () => {
    const classes = this.props.classes;
    return <GridContainer >
      <GridItem lg={ 3 } md={ 3 } ></GridItem>
      <GridItem lg={ 6 } md={ 6 } ><Card className={ classes.CustomCard }>
        <CardBody>
          <GridContainer>
            <GridItem lg={ 12 } md={ 12 }>
              <TextareaAutosize className={ classes.TextAreacustom } disabled="true" aria-label="minimum height" rowsMin={ 10 }
                value={ this.state.completearrayData }
              />
            </GridItem>
          </GridContainer>
        </CardBody>
        <CardHeader >
          <div className={ classes.FloatLeft } >
            <span><MButton variant="outlined" color="primary" onClick={ () => { navigator.clipboard.writeText(this.state.completearrayData) } } >Copy text to clipboard</MButton></span>
            <span className={ classes.ButtonLeftSpace }> <MButton variant="outlined" color="primary" onClick={ () => { this.downloadTextFile(this.state.completearrayData) } } >Download Ads.txt File</MButton></span>
          </div>
          {/* <div className={classes.FloatRight} >
          <span><MButton variant="outlined" color="secondary" >Edit</MButton></span>
          <span className={classes.ButtonLeftSpace}> <MButton variant="outlined" color="secondary" >Cancel</MButton></span>
        </div> */}
        </CardHeader>
      </Card></GridItem>
      <GridItem lg={ 3 } md={ 3 } ></GridItem>
    </GridContainer>

  }

  setrenderAdvertiserContactDetails = (value) => {
    const allBtn = document.getElementById("all_btn");
    const activeBtn = document.getElementById("active_btn");
    const inactiveBtn = document.getElementById("inactive_btn");

    if (value === "ALL") {
      allBtn.style = "background-color:#1E90FF; color:#fff"; 
      activeBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else if (value === "ACTIVE") { 
      activeBtn.style = "background-color:#1E90FF; color:#fff";
      allBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else{
      inactiveBtn.style = "background-color:#1E90FF; color:#fff";
      activeBtn.style = "background-color:#fff; color:#000";
      allBtn.style = "background-color:#fff; color:#000";
    }
    this.setState({ contactStatus: value })
  }
  renderPublisherContact = () => {
    const classes = this.props.classes;
    var data = 0;
    if (this.state.contactStatus === "ACTIVE") {
      data = this.state.activeAdvertiserContactDetails;
    }
    else if (this.state.contactStatus === "ALL") {
      data = this.state.advertiserContactDetails;
    }
    else if (this.state.contactStatus === "INACTIVE") {
      data = this.state.inAdvertiserContactDetails;
    }
    else {
      data = this.state.advertiserContactDetails;
    }

    return <CardBody>
      <ReactTable
        data={ data }
        filterable
        columns={ [
          {
            Header: "Sl No.",
            accessor: "id",
            Cell: (row) => {
              return <div>{ row.index + 1 }</div>;
            },
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Sl No"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Level",
            accessor: "level",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Level"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Name",
            accessor: "name",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Name"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),

          },
          {
            Header: "Designation",
            accessor: "designation",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Designation"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Contact Number",
            accessor: "contactNumberOne",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Contact Number"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Email ID",
            accessor: "email",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Email Id"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },
          {
            Header: "Reporting To",
            accessor: "idReportingUserName",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={ { textAlign: 'center' } }
                placeholder="Search Reporting To"
                value={ filter ? filter.value : '' }
                onChange={ event => onChange(event.target.value) }
              />
            ),
          },

          {
            Header: "Action",
            accessor: "actionContactView",
            Cell: id => (
              <div className={ classes.ActionsButton }>
                <LightTooltip title="Disable / Unable" aria-label="Disableunable" placement="top">
                  <Switch
                    name="Disableunable"
                    inputProps={ { 'aria-label': 'secondary checkbox' } }
                    size="small"
                  />
                </LightTooltip >
                { " " }

              </div>
            ),
            sortable: false,
            filterable: false
          }
        ] }
        defaultPageSize={ 5 }
        minRows={ 1 }
        defaultFilterMethod={ this.filterCaseInsensitive }
        showPaginationTop
        showPaginationBottom={ false }
        className="-highlight"
      />

    </CardBody>
      
  }

  setrenderAdvertiserProfileDetails=(value)=>{
    const allBtn = document.getElementById("all_btn");
    const activeBtn = document.getElementById("active_btn");
    const inactiveBtn = document.getElementById("inactive_btn");

    if (value === "ALL") {
      allBtn.style = "background-color:#1E90FF; color:#fff"; 
      activeBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else if (value === "ACTIVE") { 
      activeBtn.style = "background-color:#1E90FF; color:#fff";
      allBtn.style = "background-color:#fff; color:#000";
      inactiveBtn.style = "background-color:#fff; color:#000";
    } else{
      inactiveBtn.style = "background-color:#1E90FF; color:#fff";
      activeBtn.style = "background-color:#fff; color:#000";
      allBtn.style = "background-color:#fff; color:#000";
    }
   this.setState({status:value})
  }

  AdvertiserContactDeactivate=(id,e)=>{
    var status = ""
     console.log(e.target.checked)
       if(e.target.checked){
        status="INACTIVE"
       }
       else{
        status="ACTIVE"
       }
       var dataPass= {
        "status": status
    }
    debugger;
       console.log(status)
       var  ldata= this.state.advertiserContactDetails;
    
        ldata.forEach((element, index, array) => {
        if(element.id===id){
           element.status=status
        }       
       
    });
  
    this.setState({advertiserContactDetails:ldata})
    console.log(this.state.advertiserContactDetails)

        const TOKEN = 'Bearer '.concat(this.props.data.token);
       axios.defaults.headers.common['Authorization'] = TOKEN;
       axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
       axios.post(`${SERVER_URL}/api/usercontact/`, this.state.advertiserContactDetails, { headers: { "Authorization": TOKEN } })
         .then(response => response.data)
         .then((data) => {
           console.log(data);
 
         }).catch(error => { console.log(error); })  
  }
  AdvertiserDeactivate=(id,e)=>{
     var status = ""
     console.log(e.target.checked)
       if(e.target.checked){
        status="INACTIVE"
       }
       else{
        status="ACTIVE"
       }
       var dataPass= {
        "status": status
    }
    debugger;
       console.log(status)
       var  ldata= this.state.data;
    
       ldata.forEach((element, index, array) => {
        if(element.id===id){
           element.status=status
        }       
       
    });
  
    this.setState({data:ldata})
    console.log(this.state.data)

        const TOKEN = 'Bearer '.concat(this.props.data.token);
       axios.defaults.headers.common['Authorization'] = TOKEN;
       axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
       axios.put(`${SERVER_URL}/api/users/${id}`, dataPass, { headers: { "Authorization": TOKEN } })
         .then(response => response.data)
         .then((data) => {
           console.log(data);
 
         }).catch(error => { console.log(error); }) 
  }


  renderAdvertiserProfileDetails = () => {

    const classes = this.props.classes;
    var data = 0;
    if (this.state.status === "ACTIVE") {
      data = this.state.activeAdvertiser;
    }
    else if (this.state.status === "ALL") {
      data = this.state.data;
    }
    else if (this.state.status === "INACTIVE") {
      data = this.state.inActiveAdvertiser;
    }
    else {
      data = this.state.data;
    }

    return <div>
      <CardBody>
        <ReactTable
          data={ data }
          filterable
          columns={ [
            {
              Header: "Sl No.",
              accessor: " ",
              Cell: (row) => {
                return <div>{ row.index + 1 }</div>;
              },
              Filter: ({ filter, onChange }) => (
                <input type='text' style={ { textAlign: 'center' } }
                  placeholder="Search Sl No"
                  value={ filter ? filter.value : '' }
                  onChange={ event => onChange(event.target.value) }
                />
              ),
            },
            {
              Header: "SSP Name",
              accessor: "companyName",
              Filter: ({ filter, onChange }) => (
                <input type='text' style={ { textAlign: 'Left' } }
                  placeholder="Search Adv Name"
                  value={ filter ? filter.value : '' }
                  onChange={ event => onChange(event.target.value) }
                />
              ),
              getProps: () => {
                return {
                  style: {
                    textAlign: 'Left'
                  },
                }
              }
            },
            {
              Header: "GSTIN",
              accessor: "gstin",
              Filter: ({ filter, onChange }) => (
                <input type='text' style={ { textAlign: 'center' } }
                  placeholder="Search GSTIN"
                  value={ filter ? filter.value : '' }
                  onChange={ event => onChange(event.target.value) }
                />
              ),
            },
            {
              Header: "Contact Person",
              accessor: "contactPersonName",
              Filter: ({ filter, onChange }) => (
                <input type='text' style={ { textAlign: 'left' } }
                  placeholder="Search Person"
                  value={ filter ? filter.value : '' }
                  onChange={ event => onChange(event.target.value) }
                />
              ),
              getProps: () => {
                return {
                  style: {
                    textAlign: 'Left'
                  },
                }
              }

            },
            {
              Header: "Contact Number",
              accessor: "contactPersonNumber",
              Filter: ({ filter, onChange }) => (
                <input type='text' style={ { textAlign: 'center' } }
                  placeholder="Search Contact No"
                  value={ filter ? filter.value : '' }
                  onChange={ event => onChange(event.target.value) }
                />
              ),
            },
            {
              Header: "email",
              accessor: "email",
              Filter: ({ filter, onChange }) => (
                <input type='text' style={ { textAlign: 'center' } }
                  placeholder="Search email"
                  value={ filter ? filter.value : '' }
                  onChange={ event => onChange(event.target.value) }
                />
              ),
            },

            {
              Header: "SSP Profile",
              accessor: "actionsAdvertiserProfile",
              Cell: id => (
                <div className={ classes.ActionsButton }>
                  <LightTooltip title="View" aria-label="view" placement="top">
                    <MButton onClick={ () => this.AdvertiserProfileViewhandleClickOpen(id.original.id) }
                      justIcon
                      round
                      simple
                      color="secondary"
                      className="view"

                    >
                      <View />
                    </MButton>
                  </LightTooltip>

                </div>
              ),
              sortable: false,
              filterable: false
            },
            {
              Header: "Mapped Website",
              accessor: "actionsAdvertiserProfile",
              Cell: id => (
                <div className={ classes.ActionsButton }>
                  <LightTooltip title="View" aria-label="view" placement="top">
                    <MButton onClick={ () => this.AdvertiserWebsiteProfileViewhandleClickOpen(id.original.id) }
                      justIcon
                      round
                      simple
                      color="secondary"
                      className="view"

                    >
                      <View />
                    </MButton>
                  </LightTooltip>

                </div>
              ),
              sortable: false,
              filterable: false
            }
          ] }
          defaultPageSize={ 5 }
          minRows={ 1 }
          defaultFilterMethod={ this.filterCaseInsensitive }
          showPaginationTop
          showPaginationBottom={ false }
          className="-highlight"
        />
      </CardBody>

    </div>
  }

  render() {
    const classes = this.props.classes;
    return <div>
      <GridContainer >
        <GridItem lg={ 3 } md={ 3 } sm={ 12 } xs={ 12 }>
          <Card>
            <CardBody className={ classes.AdvCardBody }>
              <h4 className={ classes.CardHeading }>Total Advertiser</h4>
              <h4 className={ classes.CardHeading }>{ this.state.totalAdvertiser }</h4>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 } sm={ 12 } xs={ 12 }>
          <Card>
            <CardBody className={ classes.AdvCardBody }>
              <h4 className={ classes.CardHeading }>Total Website</h4>
              <h4 className={ classes.CardHeading }>0</h4>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 } sm={ 12 } xs={ 12 }>
          <Card>
            <CardBody className={ classes.AdvCardBody }>
              <h4 className={ classes.CardHeading }>Received FY</h4>
              <h4 className={ classes.CardHeading }>0</h4>
            </CardBody>
          </Card>
        </GridItem>
        <GridItem lg={ 3 } md={ 3 } sm={ 12 } xs={ 12 }>
          <Card>
            <CardBody className={ classes.AdvCardBody }>
              <h4 className={ classes.CardHeading }>Outstanding Receivable</h4>
              <h4 className={ classes.CardHeading }>0</h4>
            </CardBody>
          </Card>
        </GridItem>
      </GridContainer>
      <GridContainer style={ { paddingTop: "10px" } }>
        <GridItem xs={ 12 } md={ 4 } lg={ 4 }>
          <button className={ classes.CardButton } onClick={ this.AdvertiserProfilehandleClickOpen } >
            SSP Profile
          </button>
        </GridItem>
        <GridItem xs={ 12 } md={ 4 } lg={ 4 }>
          <button className={ classes.CardButton } onClick={ this.AdstxthandleClickOpen } >
            Ads.txt
          </button>
        </GridItem>
        <GridItem xs={ 12 } md={ 4 } lg={ 4 }>
          <button className={ classes.CardButton } onClick={ this.LedgerhandleClickOpen } >
            Ledger
          </button>
        </GridItem>
      </GridContainer>
      <GridContainer style={ { paddingTop: "3%" } }>
        <GridItem lg={ 12 }>
          <Card>
            <CardHeader color="primary" icon>
              <CardIcon color="primary">
                <PermContactCalendarIcon style={ { color: "white" } } />
              </CardIcon>
              <h4 className={ classes.cardIconTitle } style={ { marginTop: "0px!important,", color: "black" } }>Contact</h4>
            </CardHeader>
            <CardBody>
              <ReactTable
                data={ this.state.data }
                filterable
                columns={ [
                  {
                    Header: "Sl No.",
                    id: "row",
                    accessor: "id",
                    Cell: (row) => {
                      return <div>{ row.index + 1 }</div>;
                    },
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'center' } }
                        placeholder="Search Sl No"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                  },
                  {
                    Header: "SSP Name",
                    accessor: "companyName",
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'Left' } }
                        placeholder="Search Name"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                    getProps: () => {
                      return {
                        style: {
                          textAlign: 'Left'
                        },
                      }
                    }
                  },
                  {
                    Header: "Contact Person",
                    accessor: "contactPersonName",
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'left' } }
                        placeholder="Search Person"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                    getProps: () => {
                      return {
                        style: {
                          textAlign: 'Left'
                        },
                      }
                    }

                  },
                  {
                    Header: "Contact Number",
                    accessor: "contactPersonNumber",
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'center' } }
                        placeholder="Search Contact Number"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                  },
                  {
                    Header: "Email ID",
                    accessor: "email",
                    Filter: ({ filter, onChange }) => (
                      <input type='text' style={ { textAlign: 'center' } }
                        placeholder="Search Email Id"
                        value={ filter ? filter.value : '' }
                        onChange={ event => onChange(event.target.value) }
                      />
                    ),
                  },

                  {
                    Header: "Actions",
                    accessor: "actions",
                    Cell: id => (
                      <div className={ classes.ActionsButton }>
                        <LightTooltip title="View" aria-label="view" placement="top">
                          <MButton onClick={ () =>
                            this.AdvertiserViewhandleClickOpen(id.original.id) }
                            justIcon
                            round
                            simple
                            color="secondary"
                            className="view"

                          >
                            <View />
                          </MButton>
                        </LightTooltip>
                        { " " }

                      </div>
                    ),
                    sortable: false,
                    filterable: false
                  }
                ] }
                defaultPageSize={ 5 }
                minRows={ 1 }
                defaultFilterMethod={ this.filterCaseInsensitive }
                showPaginationTop
                showPaginationBottom={ false }
                className="-highlight"
              />
            </CardBody>

          </Card>
        </GridItem>

      </GridContainer>
      <Dialog fullScreen open={ this.state.AdvertiserViewOpen } onClose={ this.AdvertiserViewhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.AdvertiserViewhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              SSP Name
            </h4>
          </Toolbar>
        </AppBar>
        <GridContainer style={ { paddingTop: "3%" } }>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
          <GridItem lg={ 10 } md={ 10 } >
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">
                  <Profileicon />
                </CardIcon>
                <h4 className={ classes.heading }>
                  <div className={ classes.ButtonRightCard } >
                    <span style={ { paddingLeft: "10px" } }>
                      <MButton id="all_btn" color="primary" variant="outlined"
                      onClick={ () => { this.setrenderAdvertiserContactDetails("ALL") } } >
                      All
                    </MButton></span>
                    <span style={ { paddingLeft: "10px" } }>
                      <MButton style={{'background':'#1E90FF', 'color':'#fff'}} id="active_btn" variant="outlined"
                      onClick={ () => { this.setrenderAdvertiserContactDetails("ACTIVE") } }>
                      Active
                    </MButton></span>
                    <span style={ { paddingLeft: "10px" } }> 
                    <MButton color="primary" id="inactive_btn" variant="outlined"
                      onClick={ () => { this.setrenderAdvertiserContactDetails("INACTIVE") } }>
                      Inactive
                    </MButton></span>
                  </div>
                </h4>
              </CardHeader>
              { this.renderPublisherContact() }
              <CardHeader className={ classes.SimpleButton } >
                <AddContactButton id={ this.state.publisherId } />
                <div className={ classes.root2 } >
                  <span style={ { paddingLeft: "10px" } }><MButton color="secondary" variant="outlined" >
                    <a href={ SERVER_URL + "/api/usercontact/details/download/" + this.state.publisherId }>
                      Export</a>
                  </MButton></span>
                </div>

              </CardHeader>

            </Card>
          </GridItem>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
        </GridContainer>

      </Dialog>

      <Dialog fullScreen open={ this.state.AdvertiserProfileOpen } onClose={ this.AdvertiserProfilehandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.AdvertiserProfilehandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              SSP Profile
            </h4>
            <ButtonGroup  aria-label="outlined secondary button group" style={ { paddingLeft: "70%" } }>
              <MButton onClick={ this.tabsetCreate } id="create" >Create</MButton>
              <MButton onClick={ this.tabsetView } id="view" style={{'background':'#1E90FF', 'color':'#fff'} } variant="outlined">View</MButton>
            </ButtonGroup>
          </Toolbar>
        </AppBar>
        { this.state.tab == 'Create' &&
          <div>
            <CreateContact type="advertiser"></CreateContact>
          </div> }
        { this.state.tab == 'View' &&
          <div>
            <GridContainer style={ { paddingTop: "3%" } }>
              <GridItem lg={ 1 } md={ 1 }></GridItem>
              <GridItem lg={ 10 } md={ 10 } >
                <Card>
                  <CardHeader color="primary" icon>
                    <CardIcon color="primary">
                      <Profileicon />
                    </CardIcon>
                    <h4 className={classes.heading}>SSP Profile View
        <div className={classes.ButtonRightCard} >
         
                        <span style={{ paddingLeft: "10px" }}>
                          <MButton color='primary'  id="all_btn" variant="outlined"
                            onClick={()=>{this.setrenderAdvertiserProfileDetails("ALL")}}>
                          All
                        </MButton>
                        </span>
                        <span style={{ paddingLeft: "10px"}}>
                          <MButton color="primary" style={{'background':'#1E90FF', 'color':'#fff'}} id="active_btn" variant="outlined"
                         onClick={()=>{this.setrenderAdvertiserProfileDetails("ACTIVE")}}>
                          Active
                        </MButton>
                        </span>
                        <span style={{ paddingLeft: "10px"}}> 
                        <MButton color="primary" id="inactive_btn" variant="outlined"
                        onClick={()=>{this.setrenderAdvertiserProfileDetails("INACTIVE")} }>
                          Inactive
                        </MButton></span>
                      </div>
                    </h4>
                  </CardHeader>

                  { this.renderAdvertiserProfileDetails() }
                  <CardHeader className={ classes.SimpleButton } >
                    <div className={ classes.root2 } >
                      <span style={ { paddingLeft: "10px" } }><MButton color="secondary" variant="outlined" >
                        <a href={ SERVER_URL + "/api/users/details/download/" }>
                          Export</a>
                      </MButton></span>
                    </div>
                  </CardHeader>
                </Card>
              </GridItem>
              <GridItem lg={ 1 } md={ 1 }></GridItem>
            </GridContainer>
          </div> }


      </Dialog>

      <Dialog fullScreen open={ this.state.AdvertiserProfileViewOpen } onClose={ this.AdvertiserProfileViewhandleClose } TransitionComponent={ Transition } className={ classes.PublisherViewSlider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.AdvertiserProfileViewhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              SSP Profile View
            </h4>
          </Toolbar>
        </AppBar>
        <ProfileView idUser={ this.state.profileKey } type="Advertiser" action="view"></ProfileView>

        <GridContainer style={ { marginBottom: "20px" } }>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
          <GridItem lg={ 8 } md={ 8 }>
            <button className={ classes.CardButton } onClick={ this.ViewLedgerhandleClickOpen } >
              <LedgerView style={ { verticalAlign: "bottom" } } />
              View Ledger
            </button>
          </GridItem>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
        </GridContainer>
      </Dialog>



      <Dialog fullScreen open={ this.state.AdvertiserWebsiteProfileViewOpen } onClose={ this.AdvertiserWebsiteProfileViewhandleClose } TransitionComponent={ Transition } className={ classes.PublisherViewSlider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.AdvertiserWebsiteProfileViewhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Advertiser Mapped Websites
            </h4>
          </Toolbar>
        </AppBar>
        <AdvertiserWebsiteMapping id={ this.state.profileKey }></AdvertiserWebsiteMapping>

      </Dialog>




      <Dialog fullScreen open={ this.state.Adstxtopen } onClose={ this.AdstxthandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.AdstxthandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Ads.txt
            </h4>
          </Toolbar>
        </AppBar>

        <GridContainer>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
          <GridItem lg={ 8 } md={ 8 }>
            <Card>
              <CardBody>
                <ReactTable
                  data={ this.state.data }
                  filterable
                  columns={ [
                    {
                      Header: "Sl No",
                      accessor: "id",
                      Cell: (row) => {
                        return <div>{ row.index + 1 }</div>;
                      },
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Sl No"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                    },

                    {
                      Header: "SSP Name",
                      accessor: "companyName",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'Left' } }
                          placeholder="Search SSP Name"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      getProps: () => {
                        return {
                          style: {
                            textAlign: 'Left'
                          },
                        }
                      }
                    },
                    {
                      Header: "Actions",
                      accessor: "id",
                      Cell: id => (
                        <div className={ classes.ActionsButton }>
                          <LightTooltip title="View" aria-label="view" placement="top">
                            <Button onClick={ () => { this.sample(id.original.id) } }
                              justIcon
                              round
                              simple
                              color="success"
                              className="view"
                            >
                              <View />
                            </Button>
                          </LightTooltip>
                          <Dialog fullScreen open={ this.state.AdstxtViewIconOpen } onClose={ this.AdstxtViewIconhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
                            <AppBar className={ classes.CustomappBar }>
                              <Toolbar>
                                <IconButton edge="start" color="inherit" onClick={ this.AdstxtViewIconhandleClose } aria-label="close" className={ classes.CloseButton }>
                                  <LeftAorrow />
                                </IconButton>
                                <h4 className={ classes.SliderTitle }>
                                  All Ads.txt
                                </h4>
                              </Toolbar>
                            </AppBar>
                            { this.renderAdxDetails() }

                          </Dialog>
                          { " " }

                        </div>
                      ),
                      sortable: false,
                      filterable: false
                    },
                    {
                      Header: "Add",
                      accessor: "id",
                      Cell: id => (
                        <div className={ classes.ActionsButton }>

                          <Button onClick={ () => { this.addAdstxtViewIconhandleClickOpen(id.original.id, id.original.companyName) } }
                            justIco
                            round
                            simple >
                            <Add style={ { color: 'rgb(76, 175, 80)', cursor: 'pointer' } } className={ classes.icon } />
                          </Button>
                          { " " }
                        </div>
                      ),
                      sortable: false,
                      filterable: false
                    }
                  ] }
                  defaultPageSize={ 5 }
                  minRows={ 1 }
                  defaultFilterMethod={ this.filterCaseInsensitive }
                  showPaginationTop
                  showPaginationBottom={ false }
                  className="-striped -highlight"
                />
              </CardBody>
            </Card>
          </GridItem>
          <GridItem lg={ 2 } md={ 2 }></GridItem>
        </GridContainer>
      </Dialog>
      <Dialog fullScreen open={ this.state.addAdstxtViewIconOpen } onClose={ this.AdstxtViewIconhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.addAdstxtViewIconhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Add Ads.txt for { this.state.addCompanyName }
            </h4>
          </Toolbar>
        </AppBar>

        <GridContainer>
          <GridItem lg={ 3 } md={ 3 } ></GridItem>
          <GridItem lg={ 6 } md={ 6 } >
            <Card className={ classes.CustomCard }>
              <CardBody>
                <GridContainer>
                  <GridItem lg={ 12 } md={ 12 }>
                    <TextareaAutosize className={ classes.TextAreacustom } aria-label="minimum height" rowsMin={ 10 }
                      onChange={ (event) => { this.updateAdxValue(event.target.value) } }
                    />
                  </GridItem>
                </GridContainer>
              </CardBody>
              <CardHeader >
                <div className={ classes.FloatRight } >
                  <span><MButton variant="outlined" color="primary" onClick={ () => { this.submitNewAdsTxt() } } >Save</MButton></span>
                  {/* <span className={classes.ButtonLeftSpace}><MButton variant="outlined" color="primary" >Reset</MButton></span> */ }
                </div>
              </CardHeader>
            </Card>
          </GridItem>
          <GridItem lg={ 3 } md={ 3 } ></GridItem>
        </GridContainer>
      </Dialog>

      <Dialog fullScreen open={ this.state.Ledgeropen } onClose={ this.LedgerhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.LedgerhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              Ledger
            </h4>
          </Toolbar>
        </AppBar>
        <GridContainer style={ { paddingTop: "3%" } }>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
          <GridItem lg={ 10 } md={ 10 } >
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">
                  <LedgerView />
                </CardIcon>
                <h4 className={ classes.heading }>Ledger
                  <div className={ classes.ButtonRightCard } >
                    <span style={ { paddingLeft: "10px" } }>
                      <MButton color="primary" id="all_btn" variant="outlined" >
                      All
                    </MButton></span>
                    <span style={ { paddingLeft: "10px" } }>
                      <MButton color="primary" style={{'background':'#1E90FF', 'color':'#fff'}} id="active_btn" variant="outlined">
                      Active
                    </MButton></span>
                    <span style={ { paddingLeft: "10px" } }> 
                    <MButton color="primary" id="inactive_btn" variant="outlined" >
                      Inactive
                    </MButton></span>
                  </div>
                </h4>
              </CardHeader>
              <CardBody>
                <ReactTable
                  data={ this.state.data }
                  filterable
                  columns={ [
                    {
                      Header: "Date",
                      accessor: "date",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Date"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>Total</strong>
                        </span>
                      )
                    },

                    {
                      Header: "SSP Name",
                      accessor: "AdvertiserName",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'Left' } }
                          placeholder="Search Name"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      getProps: () => {
                        return {
                          style: {
                            textAlign: 'Left'
                          },
                        }
                      }
                    },
                    {
                      Header: "Particular",
                      accessor: "particular",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Particular"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                    },
                    {
                      Header: "Debit",
                      accessor: "debit",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Debit"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>59,000</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Credit",
                      accessor: "credit",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Amount"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>0</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Balance",
                      accessor: "balance",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Balance"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>0</strong>
                        </span>
                      )
                    },


                  ] }
                  defaultPageSize={ 5 }
                  minRows={ 1 }
                  defaultFilterMethod={ this.filterCaseInsensitive }
                  showPaginationTop
                  showPaginationBottom={ false }
                  className="-highlight"
                />
              </CardBody>
              <CardHeader className={ classes.SimpleButton } >

                <div className={ classes.root2 } >
                  <span style={ { paddingLeft: "10px" } }><MButton color="secondary" variant="outlined" >
                    Export
                  </MButton></span>
                </div>

              </CardHeader>
            </Card>
          </GridItem>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
        </GridContainer>
      </Dialog>
      <Dialog fullScreen open={ this.state.ViewLedgeropen } onClose={ this.ViewLedgerhandleClose } TransitionComponent={ Transition } className={ classes.rootslider }>
        <AppBar className={ classes.CustomappBar }>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={ this.ViewLedgerhandleClose } aria-label="close" className={ classes.CloseButton }>
              <LeftAorrow />
            </IconButton>
            <h4 className={ classes.SliderTitle }>
              View Ledger
            </h4>
          </Toolbar>
        </AppBar>
        <GridContainer style={ { paddingTop: "3%" } }>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
          <GridItem lg={ 10 } md={ 10 } >
            <Card>
              <CardHeader color="primary" icon>
                <CardIcon color="primary">

                  <LedgerView />
                </CardIcon>
                <h4 className={ classes.heading }>View Ledger
                  <div className={ classes.ButtonRightCard } >
                    <span style={ { paddingLeft: "10px" } }><MButton color="primary" variant="outlined" >
                      All
                    </MButton></span>
                    <span style={ { paddingLeft: "10px" } }><MButton color="primary" variant="outlined">
                      Active
                    </MButton></span>
                    <span style={ { paddingLeft: "10px" } }> <MButton color="primary" variant="outlined" >
                      Inactive
                    </MButton></span>
                  </div>
                </h4>
              </CardHeader>
              <CardBody>
                <ReactTable
                  data={ this.state.data }
                  filterable
                  columns={ [
                    {
                      Header: "Date",
                      accessor: "date",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Date"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>Total</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Particular",
                      accessor: "particular",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Particular"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                    },
                    {
                      Header: "Debit",
                      accessor: "debit",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Debit"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>59,000</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Credit",
                      accessor: "credit",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Amount"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>0</strong>
                        </span>
                      )
                    },
                    {
                      Header: "Balance",
                      accessor: "balance",
                      Filter: ({ filter, onChange }) => (
                        <input type='text' style={ { textAlign: 'center' } }
                          placeholder="Search Balance"
                          value={ filter ? filter.value : '' }
                          onChange={ event => onChange(event.target.value) }
                        />
                      ),
                      Footer: (
                        <span>
                          <strong>0</strong>
                        </span>
                      )
                    },


                  ] }
                  defaultPageSize={ 5 }
                  minRows={ 1 }
                  defaultFilterMethod={ this.filterCaseInsensitive }
                  showPaginationTop
                  showPaginationBottom={ false }
                  className="-highlight"
                />
              </CardBody>
              <CardHeader className={ classes.SimpleButton } >

                <div className={ classes.root2 } >
                  <span style={ { paddingLeft: "10px" } }><MButton color="secondary" variant="outlined" >
                    Export
                  </MButton></span>
                </div>

              </CardHeader>
            </Card>
          </GridItem>
          <GridItem lg={ 1 } md={ 1 }></GridItem>
        </GridContainer>
      </Dialog>
    </div>



  }
}

const AdvertiserHOC = withStyles(styles)(Advertiser);
export default connect(mapStateToProps, mapDispatchToProps)(AdvertiserHOC);
