import React, { Component } from "react";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Checkbox from '@material-ui/core/Checkbox';
import ReactTable from "react-table";
import View from "@material-ui/icons/Visibility";
import InputLabel from '@material-ui/core/InputLabel';
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import { connect } from 'react-redux';
import ListItemText from '@material-ui/core/ListItemText';
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import Card from "components/Card/Card.js";
import IconButton from '@material-ui/core/IconButton';
import Assignment from "@material-ui/icons/Assignment";
import Input from '@material-ui/core/Input';
import Toolbar from "@material-ui/core/Toolbar";
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Dialog from '@material-ui/core/Dialog';
import AdUnitPageView from './AdUnitPageView.js';
import AdUnit from './AdUnit.js';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import AppBar from "@material-ui/core/AppBar";
import { SERVER_URL } from "../../variables/constants";
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import MButton from '@material-ui/core/Button';
import Tooltip from '@material-ui/core/Tooltip';
import Switch from '@material-ui/core/Switch';
import Slide from '@material-ui/core/Slide';
import styles from "assets/jss/material-dashboard-pro-react/views/PublisherCustomStyle.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
const LightTooltip = withStyles((theme) => ({
    tooltip: {
      backgroundColor: theme.palette.common.white,
      color: 'rgba(0, 0, 0, 0.87)',
      boxShadow: theme.shadows[1],
      fontSize: 11,
    },
  }))(Tooltip);
  
  const useStyles = makeStyles(styles);
  const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="left" ref={ref} {...props} />;
  });
  
class AdunitView extends Component {

    constructor(props) {
        super(props);
        this.state = {
            adunitData:[],
            adUnitHandelOpen:false,
            adUnitHandelviewOpen:false,
            adUnitId:'',
            tab: 'View',
            CreateAdUnit:'',

        }
    }


    componentDidMount = () => {
        const ID=this.props.id;
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/websitepagead`,  { headers: { "Authorization": TOKEN } })
          .then(response => response.data)
          .then((data) => {
            console.log(data);
            this.setState({adunitData:data})
          }).catch(error => { console.log(error); })
      
    }
    adUnitPageViewHandel=(id)=>{
    console.log(id)

    }
    adUnitPageViewHandel = () => {
        this.setState({ adUnitHandelOpen: true });
       
    
      };
      adUnitPageViewHandelClose = () => {
        this.setState({ adUnitHandelOpen: false });
        
    
      }; adUnitPageViewHandelview = (id) => {
        this.setState({ adUnitHandelviewOpen: true });
        this.setState({adUnitId:id})
    
      };
      adUnitPageViewHandelviewClose = () => {
        this.setState({ adUnitHandelviewOpen: false });
        
    
      };
      
  tabsetCreate = () => {
    this.setState({ tab: 'Create' });


  }
  tabsetView = () => {
    this.setState({ tab: 'View' });
  }
    renderPage = () => {
        const classes = this.props.classes;
        return <CardBody>
          <ReactTable
            data={this.state.adunitData}
            filterable
            columns={[
              {
                Header: "Sl No",
                accessor: "id",
                Filter: ({ filter, onChange }) => (
                  <input type='text' style={{ textAlign: 'center' }}
                    placeholder=" Search SlNo"
                    value={filter ? filter.value : ''}
                    onChange={event => onChange(event.target.value)}
                  />
                ),
                Footer: (
                  <span><strong></strong></span>
                )
              },
              {
                Header: "Adunit Name",
                accessor: "name",
                Filter: ({ filter, onChange }) => (
                  <input type='text' style={{ textAlign: 'center' }}
                    placeholder="Search Name/Label"
                    value={filter ? filter.value : ''}
                    onChange={event => onChange(event.target.value)}
                  />
                ),
                Footer: (
                  <span><strong></strong></span>
                )
    
    
              },
              {
                Header: "Adunit Format",
                accessor: "adFormat",
                Filter: ({ filter, onChange }) => (
                  <input type='text' style={{ textAlign: 'center' }}
                    placeholder="Search CheckType"
                    value={filter ? filter.value : ''}
                    onChange={event => onChange(event.target.value)}
                  />
                ),
    
                Footer: (
                  <span><strong></strong></span>
                )
    
              },
              {
                Header: "Type",
                accessor: "type",
                Filter: ({ filter, onChange }) => (
                  <input type='text' style={{ textAlign: 'center' }}
                    placeholder="Search CheckValue"
                    value={filter ? filter.value : ''}
                    onChange={event => onChange(event.target.value)}
                  />
                ),
    
                Footer: (
                  <span><strong></strong></span>
                )
    
              },
              {
                Header: "Refresh Duration",
                accessor: "refreshDurtion",
                Filter: ({ filter, onChange }) => (
                  <input type='text' style={{ textAlign: 'center' }}
                    placeholder="Search Devices"
                    value={filter ? filter.value : ''}
                    onChange={event => onChange(event.target.value)}
                  />
    
                ),
                Cell: this.deviceName
                ,
                Footer: (
                  <span><strong></strong></span>
                )
    
              },
              {
                Header: "Action",
                accessor: "actionsPublisherProfile",
                Cell: id => (
                  <div className={classes.ActionsButton}>
                    <LightTooltip title="View" aria-label="view" placement="top">
                      <MButton onClick={() => this.adUnitPageViewHandelview(id.original.id)}
                        justIcon
                        round
                        simple
                        color="secondary"
                        className="view"
    
                      >
                        <View />
                      </MButton>
                    </LightTooltip>
    
    
                  </div>
                ),
                sortable: false,
                filterable: false
              },
             
    
    
            ]}
            defaultPageSize={5}
            showPaginationTop
            showPaginationBottom={false}
            className="-highlight"
          />
        </CardBody>
    
      }
      renderView = () => {

        const classes = this.props.classes;
    
        return <Dialog fullScreen open={this.state.adUnitHandelOpen} onClose={this.adUnitPageViewHandelClose} TransitionComponent={Transition} className={classes.PageCreationSlider}>
          <AppBar className={classes.CustomappBar}>
            <Toolbar>
              <IconButton edge="start" color="inherit" onClick={this.adUnitPageViewHandelClose} aria-label="close" className={classes.CloseButton}>
                <LeftAorrow />
              </IconButton>
              <h4 className={classes.SliderTitle}>  Ad Unit Create </h4>
              
            </Toolbar>
          </AppBar>
          
            <AdUnit></AdUnit>
      
        </Dialog>
    
    
      }

      renderViewPage = () => {

        const classes = this.props.classes;
    
        return <Dialog fullScreen open={this.state.adUnitHandelviewOpen} onClose={this.adUnitPageViewHandelviewClose} TransitionComponent={Transition} className={classes.PageCreationSlider}>
          <AppBar className={classes.CustomappBar}>
            <Toolbar>
              <IconButton edge="start" color="inherit" onClick={this.adUnitPageViewHandelviewClose} aria-label="close" className={classes.CloseButton}>
                <LeftAorrow />
              </IconButton>
              <h4 className={classes.SliderTitle}>  Ad Unit View </h4>
              
            </Toolbar>
          </AppBar>
          
            <AdUnitPageView id={this.state.adUnitId}></AdUnitPageView>
      
        </Dialog>
    
    
      }
    render() {
        const classes = this.props.classes;
        return (
            <div>
            <GridContainer justify="center">
            <GridItem xs={12} sm={12} md={12} lg={12}>
              <Card>
                <CardHeader color="rose" icon>
                  <div className={classes.ButtonGroup} style={{float:"right" ,marginTop:"10px"}}>
                  <ButtonGroup color="secondary" aria-label="outlined secondary button group">
                  <MButton onClick={() => this.adUnitPageViewHandel()} >Create</MButton>
                  </ButtonGroup>
                  </div>
                  <CardIcon color="rose">
                    <Assignment />
                  </CardIcon>
                  <h4 className={classes.cardIconTitle} style={{color:"black"}}>Ad Unit </h4>
                </CardHeader>
    
                {this.renderPage()}
    
              </Card>
            </GridItem>
          </GridContainer >
          {this.renderView()}
          {this.renderViewPage()}
          </div>
        )
    }
}
const AdunitViewHOC = withStyles(styles)(AdunitView);
export default connect(mapStateToProps, mapDispatchToProps)(AdunitViewHOC);