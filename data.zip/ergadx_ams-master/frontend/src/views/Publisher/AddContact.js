import React, { Component } from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
// @material-ui/core components
import { withStyles, makeStyles } from "@material-ui/core/styles";

import ProfileView from './ProfileView.js'
import View from "@material-ui/icons/Visibility";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import { dataTable } from "variables/Publisherdatatable";
import Switch from '@material-ui/core/Switch';
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import MButton from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import InputBase from '@material-ui/core/InputBase';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormLabel from '@material-ui/core/FormLabel';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import Tooltip from '@material-ui/core/Tooltip';
// material-ui icons
import IconButton from '@material-ui/core/IconButton';
import Publishicon from "@material-ui/icons/Group";
import Globe from "@material-ui/icons/Public";
import Bankicon from "@material-ui/icons/AccountBalance";
import Profileicon from "@material-ui/icons/Person"
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import Mappingicon from '@material-ui/icons/LinearScale';
import PermContactCalendarIcon from '@material-ui/icons/PermContactCalendar';
import ViewOff from "@material-ui/icons/VisibilityOff";
import CheckIcon from "@material-ui/icons/Done";
import UncheckIcon from "@material-ui/icons/Close";
import LedgerView from '@material-ui/icons/ListAlt';
import styles from "assets/jss/material-dashboard-pro-react/views/PublisherCustomStyle.js";
import Addcontact from "@material-ui/icons/PersonAdd";
import Button from "components/CustomButtons/Button.js";
import ButtonGroup from '@material-ui/core/ButtonGroup';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import InputAdornment from '@material-ui/core/InputAdornment';
import Add from '@material-ui/icons/Add'

import axios from "axios";
import { SERVER_URL } from "../../variables/constants";

import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}))(Tooltip);

const useStyles = makeStyles(styles);
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="left" ref={ref} {...props} />;
});

export class AddcontactDialog extends Component {
  constructor(props) {
    super(props);
    this.state = {
      setCreateContactopen: false,
      contactDetails:{},
    }
  }
  componentDidMount = () => {
    console.log(this.props.id);
   
 }
 submitContactDetails = () => {
  
      if (!this.state.contactDetails.hasOwnProperty('userId')) {
          this.state.contactDetails.userId = this.props.id;
      }

  console.log(this.state.contactDetails);
  let array=[];
  array.push(this.state.contactDetails);
  console.log(array);
  axios.post(`${SERVER_URL}/api/usercontact/`, array)
      .then(response => response.data)
      .then((data) => {
          console.log(data);
          alert("data submitted");
      }).catch(error => { console.log(error); })
}

  CreateContacthandleClickOpen = () => {
    this.setState({ setCreateContactopen: true });
  };

  CreateContacthandleClose = () => {
    this.setState({ setCreateContactopen: false });
  };

  updateDetail( value, fieldName) {
    let lcontactDetails = this.state.contactDetails;
    lcontactDetails[fieldName] = value;
    this.setState({ contactDetails: lcontactDetails });
    console.log(this.state.contactDetails);
}
  render() {
    const classes = this.props.classes;
    return (

      <span className={classes.root}>
        <MButton color="primary" variant="outlined" onClick={this.CreateContacthandleClickOpen}>
          Add New Contact
        </MButton>
        <Dialog fullScreen open={this.state.setCreateContactopen} onClose={this.CreateContacthandleClose} TransitionComponent={Transition} className={classes.CreateContactslider}>
          <AppBar className={classes.CustomappBar}>
            <Toolbar>
              <IconButton edge="start" color="inherit" onClick={this.CreateContacthandleClose} aria-label="close" className={classes.CloseButton}>
                <LeftAorrow />
              </IconButton>
              <h4 className={classes.SliderTitle}>
                Create Contact
      </h4>
            </Toolbar>
          </AppBar>
          <GridContainer style={{ paddingTop: "3%" }}>

            <GridItem lg={12} md={12} >
              <Card>
                <CardHeader color="primary" icon>
                  <CardIcon color="primary">
                    <Addcontact />
                  </CardIcon>
                  <h4 className={classes.heading}>
                    Create Contact
        </h4>
                </CardHeader>
                <CardBody>
                  <GridContainer>
                    <GridItem lg={12}>
                      <TextField
                        className={classes.textfields}
                        label="Level"
                        variant="outlined"
                        id="outlined-size-small"
                        size="small"
                        style={{ width: "100%" }}
                        />
                    </GridItem>
                    <GridItem lg={12}>
                      <TextField
                        className={classes.textfields}
                        label="Name"
                        variant="outlined"
                        id="outlined-size-small"
                        size="small"
                        style={{ width: "100%" }} 
                        onChange={(event) => { this.updateDetail( event.target.value, "name") }}/>
                    </GridItem>
                    <GridItem lg={6}>
                      <TextField
                        className={classes.textfields}
                        label="Designation"
                        variant="outlined"
                        id="outlined-size-small"
                        size="small"
                        style={{ width: "100%" }} 
                        onChange={(event) => { this.updateDetail( event.target.value, "designation") }}/>
                    </GridItem>
                    <GridItem lg={6}>
                      <TextField
                        className={classes.textfields}
                        label="Email ID"
                        variant="outlined"
                        id="outlined-size-small"
                        size="small"
                        style={{ width: "100%" }} 
                        onChange={(event) => { this.updateDetail( event.target.value, "email") }}/>
                    </GridItem>
                    <GridItem lg={6}>
                      <TextField
                        className={classes.textfields}
                        label="Primary Contact"
                        variant="outlined"
                        id="outlined-size-small"
                        size="small"
                        style={{ width: "100%" }} 
                        onChange={(event) => { this.updateDetail( event.target.value, "contactNumberOne") }}/>
                    </GridItem>
                    <GridItem lg={6}>
                      <TextField
                        className={classes.textfields}
                        label="Secondary Contact"
                        variant="outlined"
                        id="outlined-size-small"
                        size="small"
                        style={{ width: "100%" }} 
                        onChange={(event) => { this.updateDetail( event.target.value, "contactNumberTwo") }}/>
                    </GridItem>
                    <GridItem lg={12}>
                      <TextField
                        className={classes.textfields}
                        label="Reporting To"
                        variant="outlined"
                        id="outlined-size-small"
                        size="small"
                        style={{ width: "100%" }} 
                        onChange={(event) => { this.updateDetail( event.target.value, "idReportingUserName") }}/>
                    </GridItem>
                  </GridContainer>
                </CardBody>
                <CardHeader className={classes.SimpleButton} >
                  <div className={classes.root2} >
                    <span style={{ paddingLeft: "10px" }}><MButton className={classes.submitbutton} variant="outlined"
                    onClick={this.submitContactDetails} >
                      Submit
               </MButton></span>
                  </div>
                </CardHeader>
              </Card>
            </GridItem>
          </GridContainer>
        </Dialog>

      </span>
    );
  }
}
const AddcontactDialogHOC = withStyles(styles)(AddcontactDialog);
export default connect(mapStateToProps, mapDispatchToProps)(AddcontactDialogHOC);
