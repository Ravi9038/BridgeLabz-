import React, { Component } from 'react'
// react component for creating dynamic tables
import ReactTable from "react-table";
import { makeStyles } from '@material-ui/styles';
import { withStyles } from "@material-ui/core/styles";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import styles from "assets/jss/material-dashboard-pro-react/views/paymentcustomstyle.js";
import HeaderCard from 'views/Widgets/HeaderCards.js'; 
import SettlmentButton from 'views/Widgets/SettlmentButtonDialog.js';
import ViewPaymentsButton from 'views/Widgets/ViewPaymentsButton.js';
import CurrencyConverterDialog from 'views/Widgets/CurrencyConverterDialog.js';
import PaymentOverview from 'views/Widgets/PaymentOverview.js';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
import { connect } from 'react-redux';

const useStyles = makeStyles(styles);
export class Payments extends Component { 

render(){
  const classes = this.props.classes;
  return (
     <div className={classes.root}>
       <HeaderCard type="payment"/>
     <GridContainer style={{marginTop:"10px",marginBottom:"10px"}}>
       <GridItem lg={4} md={4}>
         <SettlmentButton />
       </GridItem>
       <GridItem lg={4} md={4}>
       <ViewPaymentsButton />
       </GridItem>
       <GridItem lg={4} md={4}>
       <CurrencyConverterDialog />
       </GridItem> 
     </GridContainer>
     <PaymentOverview />
    </div>
    );
}
}
const PaymentsHOC = withStyles(styles)(Payments);
export default connect(mapStateToProps, mapDispatchToProps)(PaymentsHOC);
 