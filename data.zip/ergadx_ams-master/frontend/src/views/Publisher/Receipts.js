import React, { Component } from 'react'
import { makeStyles } from "@material-ui/core/styles";
import ReactTable from "react-table";
import TextField from '@material-ui/core/TextField';
// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import Paymenticon from "@material-ui/icons/Payment";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import MButton from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import Tooltip from '@material-ui/core/Tooltip';
import Button from "components/CustomButtons/Button.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from '@material-ui/core/IconButton';
import { withStyles } from '@material-ui/styles';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import { connect } from 'react-redux';
import { Receipt } from '@material-ui/icons';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import styles from "assets/jss/material-dashboard-pro-react/views/paymentcustomstyle.js";
import HeaderCards from 'views/Widgets/HeaderCards.js';
import ReceiptSettlmentButton from 'views/Widgets/ReceiptSettlmentButton.js';

const useStyles = makeStyles(styles);

export class Receipts extends Component {
  
    render() {
    const classes = this.props.classes;
     return ( 
    <div className={classes.root}>
        <HeaderCards type="receipt"/>
      <GridContainer style={{marginTop:"10px",marginBottom:"10px"}}>
       <GridItem lg={6} md={6}>
       <ReceiptSettlmentButton />
        </GridItem>
        <GridItem lg={6} md={6}>
        <button className={classes.CardButton}>
         View
        </button>
        </GridItem>
        </GridContainer>
         
         </div>
        )
    }
}

const ReceiptsHOC = withStyles(styles)(Receipts);
export default connect(mapStateToProps, mapDispatchToProps)(ReceiptsHOC);