import React, { Component } from "react";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import Select from "@material-ui/core/Select";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Checkbox from '@material-ui/core/Checkbox';
import Chip from '@material-ui/core/Chip';
import InputLabel from '@material-ui/core/InputLabel';
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import { connect } from 'react-redux';
import ListItemText from '@material-ui/core/ListItemText';
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import Card from "components/Card/Card.js";
import Button from "components/CustomButtons/Button.js";
import Assignment from "@material-ui/icons/Assignment";
import Input from '@material-ui/core/Input';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import { SERVER_URL } from "../../variables/constants";
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import MButton from '@material-ui/core/Button';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
const styles = {
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    },
    root: {
        ' & .makeStyles-card-194': {
            width: "70%",
            marginLeft: "200px",
        }
    }
}

class PageCreation extends Component {

    constructor(props) {
        super(props);
        this.state = {
            pageCheckType: [
                "contains",
                "equals",
                "regex"
            ],
            Type: [
                "DFP",
                "CUSTOM_JS"
            ],
            adFormat: [
                "Banner",
                "Video",
                "Interstitial",
                "inImage",
                "Sticky"
            ]
            ,
            Dimention: [
                { name: "Mobile", status: false },
                { name: "Tablet", status: false },
                { name: "DeskTop", status: false }
            ],
            selectedDimention: [],
            refreshEnable: [
                "Yes",
                "No"
            ],
            selectedRefreshEnable: [],
            label: '',
            pageCheckValue: '',
            pageCheckTypes: '',

        }
    }


    componentDidMount = () => {
        console.log(this.props.id)

    }
    insertForWebsitePage = (event) => {
        this.setState({ selectedDimention: event.target.value });
        console.log(this.state.selectedDimention);

    }
    updateForWebsite = (event, fieldName) => {
        if (fieldName === 'label') {
            this.setState({ label: event.target.value })
        }
        if (fieldName === 'pageCheckValue') {
            this.setState({ pageCheckValue: event.target.value })

        }
        console.log(this.state.label)
        console.log(this.state.pageCheckValue)
    }
    updateswebsiteData = (event) => {
        console.log(event.target.value);
        this.setState({ pageCheckTypes: event.target.value })

    }

   

    editAccountDetails = () => {
        console.log(this.state.selectedDimention)
        let Mobilestatus = false
        let tabletstatus = false
        let desktopstatus = false
        if (this.state.selectedDimention.includes("Mobile")) {
            Mobilestatus = true
        } if (this.state.selectedDimention.includes("Tablet")) {
            tabletstatus = true
        } if (this.state.selectedDimention.includes("DeskTop")) {
            desktopstatus = true
        }
        var deviceStatus = { "mobile": Mobilestatus, "tablet": tabletstatus, "desktop": desktopstatus }
        var obj = JSON.stringify(deviceStatus);
        console.log(obj)

        var request = {};
        request.label = this.state.label;
        request.idWebsite = this.props.id;
        request.pageCheckType = this.state.pageCheckTypes;
        request.pageCheckValue = this.state.pageCheckValue;
        request.devices = obj;
        console.log(request)
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.post(`${SERVER_URL}/api/websitepage`, request, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                alert("data submitted");
            }).catch(error => { console.log(error); })

    }
    render() {
        const classes = this.props.classes;
        return (
            <div className={classes.root}>
                <GridContainer justify="center">
                    <GridItem xs={12} sm={12} md={8} lg={8} >
                        <Card>
                            <CardHeader color="rose" icon>
                                <CardIcon color="rose">
                                    <Assignment />
                                </CardIcon>
                                <h4 className={classes.cardIconTitle}>Page Creation</h4>
                            </CardHeader>
                            <CardBody   >
                                <GridContainer className={classes.SelectCustom} style={{ margitnBottom: "15px" }} >
                                    <GridItem lg={6} xs={12} md={6} className={classes.textfieldsgrid}>
                                        <TextField className={classes.textfields} label="Page Name/ Label" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                            onChange={(event) => { this.updateForWebsite(event, "label") }} />
                                    </GridItem>
                                    <GridItem lg={6} md={5} className={classes.textfieldsgrid}>
                                        <FormControl variant="outlined" className={classes.formControl}>
                                            <InputLabel htmlFor="outlined-age-native-simple">Devices</InputLabel>
                                            <Select
                                                labelId="demo-mutiple-checkbox-label"
                                                id="demo-mutiple-checkbox"
                                                multiple
                                                variant="outlined"
                                                value={this.state.selectedDimention}
                                                onChange={this.insertForWebsitePage}
                                                input={<Input />}
                                                renderValue={(selected) => selected.join(', ')}

                                            >
                                                {this.state.Dimention.map((element) => (
                                                    <MenuItem key={element.name} value={element.name}>
                                                        <Checkbox checked={this.state.selectedDimention.indexOf(element.name) > -1} />
                                                        <ListItemText primary={element.name} />
                                                    </MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>
                                    </GridItem>

                                </GridContainer>
                                <GridContainer className={classes.SelectCustom} style={{ margitnBottom: "15px" }}>
                                    <GridItem lg={6} xs={12} md={6} className={classes.textfieldsgrid}>
                                        <TextField className={classes.textfields} label="Page Check Value" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                                            onChange={(event) => { this.updateForWebsite(event, "pageCheckValue") }} />
                                    </GridItem>
                                    <GridItem lg={6} md={5} className={classes.textfieldsgrid}>
                                        <FormControl variant="outlined" className={classes.formControl}>
                                            <InputLabel htmlFor="outlined-age-native-simple">Page Check Type</InputLabel>
                                            <Select className={classes.SelectDropdown}
                                                native
                                               
                                                onChange={this.updateswebsiteData}

                                                label="select"
                                                inputProps={{
                                                    name: 'BankDetails',
                                                    id: 'outlined-age-native-simple',
                                                }}>
                                                <option aria-label="None" value="" />
                                                {this.state.pageCheckType.map((item, key) => (
                                                    <option value={item}  >{item}</option>
                                                ))}
                                            </Select>
                                        </FormControl>
                                    </GridItem>

                                </GridContainer>
                                <GridContainer >
                                    <GridItem xs={12} md={12} lg={12} className={classes.textfieldsgrid}>
                                        <div className={classes.root2} >
                                            <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" color="primary" onClick={this.editAccountDetails} >
                                                Submit  </MButton> </span>

                                        </div>
                                    </GridItem>
                                </GridContainer>
                            </CardBody>
                        </Card>
                    </GridItem>
                </GridContainer >

            </div>
        )
    }
}
const PageCreationHOC = withStyles(styles)(PageCreation);
export default connect(mapStateToProps, mapDispatchToProps)(PageCreationHOC);