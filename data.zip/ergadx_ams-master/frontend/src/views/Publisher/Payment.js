import React from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";
import { makeStyles } from '@material-ui/core/styles';
// @material-ui/core components

// @material-ui/icons
import Assignment from "@material-ui/icons/Assignment";
import Dvr from "@material-ui/icons/Dvr";
import Favorite from "@material-ui/icons/Favorite";
import Close from "@material-ui/icons/Close";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import Paymenticon from "@material-ui/icons/Payment";
import { dataTable } from "variables/Paymentdatatable";

import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import FormControl from "@material-ui/core/FormControl";
// material-ui icons
import Checkbox from '@material-ui/core/Checkbox';
import MButton from '@material-ui/core/Button';
import FormControlLabel from '@material-ui/core/FormControlLabel';
const styles = {
  cardIconTitle: {
    ...cardTitle,
    marginTop: "15px",
    marginBottom: "0px"
  },
  ActionsButton :{
    '& .MuiCheckbox-root' :{
        minWidth:" 0px",
        height: "0px"
    },
   
   
},
root2: {
    float: "right",
    Primary:{
      color: "#1976d2",
      border: "1px solid #1976d2"
  }
},
root :{
 '& .rt-th' :{
  lineHeight:'1em !important'
 },
 '& .MuiFormControlLabel-label' :{
   color:"black",
   fontWeight:"400",
 
 }
}
};

const useStyles = makeStyles(styles);

export default function Payments() {

  const [data, setData] = React.useState(
    dataTable.dataRows.map((prop, key) => {
      return {
        id: key,
        Select: prop[0],
        PublisherName: prop[0],
        InvoiceDate: prop[1],
        NetAmount: prop[2],
        GST: prop[3],
        TDS: prop[4],
        GrossPayable: prop[5],
        Status: prop[6],
        
      };
    })
  );
  const classes = useStyles();
  return (
    <GridContainer>
      
      <GridItem lg={12}>
        <Card>
          <CardHeader color="primary" icon>
          <CardIcon color="primary">
         <Paymenticon style={{color:"white"}} />
         
         </CardIcon>
            <h4 className={classes.cardIconTitle} style={{marginTop:"0px!important"}} >Payments</h4>
            
          </CardHeader>
          <CardBody className={classes.root}>
            <ReactTable
              data={data}
              filterable
              columns={[
                {
                  Header:<FormControlLabel className={classes.ActionsButton}
                  label="Select" 
                  labelPlacement="top"  
                  control={<Checkbox  name="selectAll" />}
                  
                 /> , 
                  accessor: "Select",
                  Cell: id => (
                  <div className={classes.ActionsButton}>
                 <Checkbox
                    size="small"
                    inputProps={{ 'aria-label': 'Select' }}
                  />
                </div>
                  ),
                  sortable: false,
                  filterable: false
                  },
                  {
                    Header: "Publisher",
                    accessor: "PublisherName",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Publisher"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                  
  
                    },
               
                {
                  Header: "Invoice Date",
                  accessor: "InvoiceDate",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Date"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                 

                },
                {
                    Header: "Net Amount",
                    accessor: "NetAmount",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Amount"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                  {
                    Header: "GST",
                    accessor: "GST",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search GST"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                  {
                    Header: "TDS",
                    accessor: "TDS",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search TDS"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                  {
                    Header: "Gross Payable",
                    accessor: "GrossPayable",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Gross"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                  {
                    Header: "Status",
                    accessor: "Status",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Status"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
                  },
              ]}
              defaultPageSize={5}
              showPaginationTop 
              showPaginationBottom={false}
              className="-highlight"
            />
          </CardBody>
          <CardHeader style={{float:"right!important"}}>
          <div className={classes.root2} >
            <strong>Paying Rs:10000</strong>
          <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined" >
            Export
           </MButton></span>
           <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined">
            Download Payments
           </MButton></span>
           <span style={{paddingLeft:"10px"}}> <MButton  color="secondary" variant="outlined" >
            Upload Payments
           </MButton></span>
          </div>
         
          </CardHeader>
        </Card>
      </GridItem>
     
    </GridContainer>
  );
}
