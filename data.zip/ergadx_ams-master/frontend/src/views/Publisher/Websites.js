import React, { Component } from 'react'
import { withStyles, makeStyles } from "@material-ui/core/styles";

// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import axios from 'axios';
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Table from "components/Table/Table.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import { SERVER_URL } from "../../variables/constants";
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import Button from "components/CustomButtons/Button.js";
import ReactTable from "react-table";
import ButtonGroup from '@material-ui/core/ButtonGroup';
import MButton from '@material-ui/core/Button';
import Slide from '@material-ui/core/Slide';
import CopyrightIcon from '@material-ui/icons/Copyright';
import DeleteForeverOutlinedIcon from '@material-ui/icons/DeleteForeverOutlined';
import CreateContact from './PageCreation.js';
import WebsitePageView from './WebsitePageView.js';
import AdUnit from './AdUnit.js';
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import Tooltip from '@material-ui/core/Tooltip';
import Switch from '@material-ui/core/Switch';
import View from "@material-ui/icons/Visibility";
import CreateIcon from '@material-ui/icons/Create';
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Dialog from '@material-ui/core/Dialog';
import IconButton from '@material-ui/core/IconButton';
import Profileicon from "@material-ui/icons/Person"
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import styles from "assets/jss/material-dashboard-pro-react/views/PublisherCustomStyle.js";

import { idText } from 'typescript';
import { parseJSON } from 'date-fns/esm';
import Add from '@material-ui/icons/Add';
import TextField from '@material-ui/core/TextField';
import NoteAddIcon from '@material-ui/icons/NoteAdd';
import RateReviewIcon from '@material-ui/icons/RateReview';
import MonetizationOnIcon from '@material-ui/icons/MonetizationOn';
import Checkbox from '@material-ui/core/Checkbox';
import Chip from '@material-ui/core/Chip';
import Autocomplete from '@material-ui/lab/Autocomplete';
import FormControl from "@material-ui/core/FormControl";
import InputBase from '@material-ui/core/InputBase';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import InputLabel from '@material-ui/core/InputLabel';
import Paper from "@material-ui/core/Paper"
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}))(Tooltip);

const useStyles = makeStyles(styles);
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="left" ref={ref} {...props} />;
});


export class Websites extends Component {
  state = {
    values: "123",
    websiteData: [],
    tab: 'View',
    PublisherViewopen: false,
    addPagesViewopen: false,
    revenueShareOpen: false,
    pageDetails: [],
    websiteID: '',
    websitePageViewHandelOpen: false,
    adUnitHandelOpen: false,
    pageId: '',
    setScriptopen: false,
    advertiser: [],
    selectedAdvertiser: '',
    revenueDatas: [],
    expanded: 1,
    revenueEditText: "Edit",
    IDWEBSITE: '',
    erg_share: 0,
    pub_share: 0,

    rev_erg_share:0,
    rev_pub_share:0,
    existingAdvertiser: []


  }
  handleChange = (panel) => (event, isExpanded) => {
    //debugger;

    this.setState({ expanded: (isExpanded ? panel : false) })

  };
  tabsetCreate = () => {
    this.setState({ tab: 'Create' });


  }
  tabsetView = () => {
    this.setState({ tab: 'View' });
  }

  addPagesToWebsitesViewhandleClose = () => {
    this.setState({ addPagesViewopen: false });
  };

  revenueShareViewhandleClose = () => {
    this.setState({ revenueShareOpen: false });
  };
  addPagesToWebsites = (id) => {
    this.setState({ addPagesViewopen: true });
    this.setState({ websiteID: id })
    this.getDataforWebsiteId(id)
  };

  revenueShareDetails = (id) => {
    this.getRevenueDataForWebsiteId(id);
    this.setState({ revenueShareOpen: true });

    const classes = this.props.classes;
    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    axios.get(`${SERVER_URL}/api/users/advertisers/`, { headers: { "Authorization": TOKEN } })
      .then(res => {
        this.setState({ advertiser: res.data })
        let allAdvertiser = [];

        for (let i = 0; i < res.data.length; i++) {

          allAdvertiser.push(res.data[i])
        }
        console.log(allAdvertiser)

        var existingAdvertiser = this.state.existingAdvertiser;
        console.log(existingAdvertiser)
        /*  const filterArray = (arr1, arr2) => {
           const filtered = arr1.filter(el => {
              return arr2.indexOf(el) === 1;
           });
           return filtered;
        };
        console.log(filterArray(allAdvertiser, existingAdvertiser)); */
        function comparer(otherArray) {
          return function (current) {
            return otherArray.filter(function (other) {
              return other.id === current.id_advertiser && other.companyName === current.Advertiser_name
            }).length == 0;
          }
        }

        var onlyInA = allAdvertiser.filter(comparer(allAdvertiser));
        var onlyInB = existingAdvertiser.filter(comparer(existingAdvertiser));

        var result = onlyInA.concat(onlyInB);

        console.log(result);

      }).catch(function (error) {
        console.log(error);
      });


    this.getRevenueDataForWebsiteId(id);

    this.setState({ IDWEBSITE: id })
  }
  websitePageViewHandel = (id) => {
    this.setState({ websitePageViewHandelOpen: true });
    this.setState({ pageId: id })

  };
  addAdunitIconhandleClickOpen = () => {
    this.setState({ adUnitHandelOpen: true });

  };
  addAdunitIconhandleClickCose = () => {
    this.setState({ adUnitHandelOpen: false });


  };
  websitePageViewHandelclose = () => {
    this.setState({ websitePageViewHandelOpen: false });

  };

  getDataforWebsiteId = (id) => {
    const classes = this.props.classes;
    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    axios.get(`${SERVER_URL}/api/websitepage/get/${id}`, { headers: { "Authorization": TOKEN } })
      .then(res => {
        this.setState({ pageDetails: res.data })
        console.log(res.data)
      }).catch(function (error) {
        console.log(error);
      });
  }


  getRevenueDataForWebsiteId = (pKey) => {
    console.log('id for user	', pKey);
    const classes = this.props.classes;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/singlewebsite/revenue/${pKey}`, { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
        console.log(data);
        this.setState({ revenueDatas: data });
        for (let i = 0; i < data.length; i++) {
          this.setState(prevState => ({
            existingAdvertiser: [...prevState.existingAdvertiser, data[i]]
          }));
        }
        console.log(this.state.existingAdvertiser)
        this.renderRevenuedata();


      }).catch((error) => {
        console.error(error);
      });
  }
  deviceName = (cellInfo) => {
    var valueToPass = '';
    const cellValue = this.state.pageDetails[cellInfo.index][cellInfo.column.id];
    const value = JSON.parse(cellValue)
    if (value.mobile) {
      valueToPass = valueToPass + " mobile "
    }
    if (value.tablet) {
      valueToPass = valueToPass + " tablet "
    }
    if (value.desktop) {
      valueToPass = valueToPass + " desktop "
    }
    var wsr = valueToPass.trim();
    var deviceValue = wsr.split(/[ ,]+/).join(',')
    console.log(deviceValue)
    return deviceValue;
  }
  componentDidMount() {
    const classes = this.props.classes;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/userwebsite`, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lWebsiteData = [];
        this.setState({ websiteData: res.data });
      }).catch(function (error) {
        console.log(error);
      });
  }



  renderPage = () => {
    const classes = this.props.classes;
    return <CardBody>
      <ReactTable
        data={this.state.pageDetails}
        filterable
        columns={[
          {
            Header: "Sl No",
            accessor: "id",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={{ textAlign: 'center' }}
                placeholder=" Search SlNo"
                value={filter ? filter.value : ''}
                onChange={event => onChange(event.target.value)}
              />
            ),
            Footer: (
              <span><strong></strong></span>
            )
          },
          {
            Header: "Page Name/Label",
            accessor: "label",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={{ textAlign: 'center' }}
                placeholder="Search Name/Label"
                value={filter ? filter.value : ''}
                onChange={event => onChange(event.target.value)}
              />
            ),
            Footer: (
              <span><strong></strong></span>
            )

          },
          {
            Header: "Page Check Type",
            accessor: "pageCheckType",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={{ textAlign: 'center' }}
                placeholder="Search CheckType"
                value={filter ? filter.value : ''}
                onChange={event => onChange(event.target.value)}
              />
            ),

            Footer: (
              <span><strong></strong></span>
            )

          },
          {
            Header: "Page Check Value",
            accessor: "pageCheckValue",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={{ textAlign: 'center' }}
                placeholder="Search CheckValue"
                value={filter ? filter.value : ''}
                onChange={event => onChange(event.target.value)}
              />
            ),

            Footer: (
              <span><strong></strong></span>
            )

          },
          {
            Header: "Devices",
            accessor: "devices",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={{ textAlign: 'center' }}
                placeholder="Search Devices"
                value={filter ? filter.value : ''}
                onChange={event => onChange(event.target.value)}
              />

            ),
            Cell: this.deviceName
            ,
            Footer: (
              <span><strong></strong></span>
            )


          },
          {
            Header: "Action",
            accessor: "actionsPublisherProfile",
            Cell: id => (
              <div className={classes.ActionsButton}>
                <LightTooltip title="View" aria-label="view" placement="top">

                  <MButton onClick={() => this.websitePageViewHandel(id.original.id)}
                    justIcon
                    round
                    simple
                    color="secondary"
                    className="view"
                  >
                    <View />
                  </MButton>
                </LightTooltip>


              </div>
            ),
            sortable: false,
            filterable: false
          },



        ]}
        defaultPageSize={5}
        showPaginationTop
        showPaginationBottom={false}
        className="-highlight"
      />
    </CardBody>

  }

  purgeUrl = (id) => {

    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.delete(`${SERVER_URL}/api/website/purge/${id}`, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("Purged successfully");
      }).catch(error => { console.log(error); })
  }

  renderTable = () => {

    const classes = this.props.classes;
    return <CardBody>
      <ReactTable
        data={this.state.websiteData}
        filterable
        columns={[
          {
            Header: "Sl No",
            accessor: "id",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={{ textAlign: 'center' }}
                placeholder="Search Sl No"
                value={filter ? filter.value : ''}
                onChange={event => onChange(event.target.value)}
              />
            ),
            Footer: (
              <span><strong></strong></span>
            )
          },
          {
            Header: "Website Name",
            accessor: "name",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={{ textAlign: 'center' }}
                placeholder="Search Website Name"
                value={filter ? filter.value : ''}
                onChange={event => onChange(event.target.value)}
              />
            ),
            Footer: (
              <span><strong></strong></span>
            )
          },
          {
            Header: "Website URL",
            accessor: "hostURL",
            Filter: ({ filter, onChange }) => (
              <input type='text' style={{ textAlign: 'center' }}
                placeholder="Search Website URL"
                value={filter ? filter.value : ''}
                onChange={event => onChange(event.target.value)}
              />
            ),

            Footer: (
              <span><strong></strong></span>
            )

          },
          {
            Header: "Create JSON",
            accessor: "",
            Cell: id => (
              <div className={classes.ActionsButton}>

                <LightTooltip title="View" aria-label="view" placement="top">
                  <MButton onClick={() => { this.createJson(id.original.id) }}
                    justIcon
                    round
                    simple
                    color="secondary"
                    className="view"
                  >
                    <CreateIcon />
                  </MButton>
                </LightTooltip>
              </div>
            ),
            sortable: false,
            filterable: false
          },

          {
            Header: "View Script",
            accessor: "",
            Cell: id => (
              <div className={classes.ActionsButton}>


                <LightTooltip title="View" aria-label="view" placement="top">
                  <MButton onClick={() => { this.createScript(id.original.id); this.CreateContacthandleClickOpen() }}
                    justIcon
                    round
                    simple
                    color="secondary"
                    className="view"

                  >

                    <View />





                  </MButton>
                </LightTooltip>









              </div>
            ),
            sortable: false,
            filterable: false
          },
          {
            Header: "Add Pages",
            accessor: "Add Pages",
            Cell: id => (
              <div className={classes.ActionsButton}>
                <LightTooltip title="View" aria-label="view" placement="top">
                  <MButton onClick={() => this.addPagesToWebsites(id.original.id)}
                    justIcon
                    round
                    simple
                    color="secondary"
                    className="view"

                  >
                    <NoteAddIcon />
                  </MButton>
                </LightTooltip>















              </div>
            ),
            sortable: false,
            filterable: false
          },
          {
            Header: "Revnue Share",
            accessor: "",
            Cell: id => (
              <div className={classes.ActionsButton}>

                <LightTooltip title="View" aria-label="view" placement="top">
                  <MButton onClick={() => { this.revenueShareDetails(id.original.id) }}
                    justIcon
                    round
                    simple
                    color="secondary"
                    className="view"

                  >

                    <RateReviewIcon />







                  </MButton>
                </LightTooltip>




              </div>
            ),
            sortable: false,
            filterable: false
          },
          {
            Header: "Purge Website",
            accessor: "",
            Cell: id => (
              <div className={classes.ActionsButton}>
                <LightTooltip title="Purge" aria-label="view" placement="top">
                  <MButton onClick={() => this.purgeUrl(id.original.id)}
                    justIcon
                    round
                    simple
                    color="secondary"
                    className="view"
                  >
                    <DeleteForeverOutlinedIcon />
                  </MButton>
                </LightTooltip>
              </div>
            ),
            sortable: false,
            filterable: false
          }

        ]}
        defaultPageSize={5}
        showPaginationTop
        showPaginationBottom={false}
        className="-highlight"
      />
    </CardBody>

  }

  /* createJson=(id)=>{
    axios({
      url: `${SERVER_URL}/api/websitepage/get/ad/${id}`,
      method: 'GET',
      responseType: 'blob', // important
  }).then((response) => {
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'Report.json');
       link.setAttribute('target',"D://Workspaces");
      document.body.appendChild(link);
      link.click();
  });

  } */




  createJson = (id) => {
    const ID = id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';










    axios.get(`${SERVER_URL}/api/websitepage/get/ad/${ID}`, { headers: { "Authorization": TOKEN } })
      .then(res => {
        console.log(res.data);
      }).catch(function (error) {
        console.log(error);
      });



  }
  createScript = (id) => {
    const ID = id;
    var script = '<script type="text/javascript" src="//cdn.ergadx.com/js/' + ID + '/ads.js"></script>';
    console.log(script)
    this.setState({ values: script })
  }

  CreateContacthandleClickOpen = () => {
    this.setState({ setScriptopen: true });

  };
  CreateScriptTagClose = () => {
    this.setState({ setScriptopen: false });
  };
  renderJSScript = () => {
    const classes = this.props.classes;
    return <div>
      <span className={classes.root}>

        <Dialog fullScreen open={this.state.setScriptopen} onClose={this.CreateScriptTagClose} TransitionComponent={Transition} className={classes.CreateContactslider}>
          <AppBar className={classes.CustomappBar}>
            <Toolbar>
              <IconButton edge="start" color="inherit" onClick={this.CreateScriptTagClose} aria-label="close" className={classes.CloseButton}>
                <LeftAorrow />
              </IconButton>
              <h4 className={classes.SliderTitle}>
                Copy The Script
              </h4>
            </Toolbar>
          </AppBar>
          <GridContainer style={{ paddingTop: "3%" }}>
            <GridItem lg={12} md={12} >
              <Card>
                <CardHeader color="primary" icon>
                  <CardIcon color="primary">
                    <CopyrightIcon />
                  </CardIcon>
                  <h4 className={classes.heading}>
                    Copy the below Script place before end of the body tag
                  </h4>
                </CardHeader>
                <CardBody>
                  <GridContainer>
                    <GridItem lg={12}>
                      <TextField
                        className={classes.textfields}
                        label="script Tag"
                        variant="outlined"
                        id="outlined-size-small"
                        size="large"
                        multiline
                        rows={3}
                        value={this.state.values}
                        style={{ width: "100%" }}
                      />
                    </GridItem>
                  </GridContainer>
                </CardBody>

              </Card>
            </GridItem>

          </GridContainer>
        </Dialog>

      </span>
    </div>
  }

  insertNewRevenue = (value, filedName) => {
    const remainingShare = 1.00 - value;
    if (filedName === "erg_share") {
      this.setState({ erg_share: value })
      this.setState({ pub_share: remainingShare })
    } else {
      this.setState({ pub_share: value })
      this.setState({ erg_share: remainingShare })
    }
  }


  addNewRevenueShare = () => {
    const classes = this.props.classes;
    const revenueDropdown = this.state.advertiser.filter(x => !this.state.revenueDatas.find(revenueData => revenueData.Advertiser_name == x.companyName));

    return <div>
      <GridContainer>
        <GridItem lg={1} md={1} className={classes.textfieldsgrid}></GridItem>
        <GridItem lg={5} md={5} >
          <FormControl variant="outlined" justify="center" >

            <Autocomplete
              options={revenueDropdown}
              disableCloseOnSelect
              onChange={(event, value, reason) => this.deleteAdvertiser(event, value, reason)}
              getOptionLabel={(option) => option.companyName}

              renderOption={(option, { selected }) => (

                <React.Fragment>
                  {option.companyName}
                </React.Fragment>
              )
          }
              

              style={{ width: 250 }}
              renderInput={(params) => (
                <TextField {...params} variant="outlined" label="Advertiser " />
              )}
            />

          </FormControl>

        </GridItem>
        <GridItem lg={2} md={2} className={classes.textfieldsgrid}>

          <TextField type="text" value={this.state.erg_share} className={classes.InputCenter} style={{ height: "33px" }} label=" My Share" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%", textAlign: "center" }}

            onChange={(event) => { this.insertNewRevenue(event.target.value, "erg_share") }} />
        </GridItem>

        <GridItem lg={2} md={2} className={classes.textfieldsgrid}>

          <TextField type="text" value={this.state.pub_share} className={classes.InputCenter} style={{ height: "33px" }} label=" Publisher Share" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%", textAlign: "center" }}

            onChange={(event) => { this.insertNewRevenue(event.target.value, "pub_share") }} />
        </GridItem>

      </GridContainer>

      <GridContainer style={{ marginLeft: "645px " }}>
        <CardHeader >
          <div className={classes.root2} style={{ marginBottom: "5px !important" }} >
            <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" color="secondary" onClick={this.submitRevenue} >Submit</MButton></span>

          </div>

        </CardHeader>
      </GridContainer>


    </div>
  }


  renderView = () => {

    const classes = this.props.classes;

    return <Dialog fullScreen open={this.state.websitePageViewHandelOpen} onClose={this.websitePageViewHandelclose} TransitionComponent={Transition} className={classes.PageCreationSlider}>
      <AppBar className={classes.CustomappBar}>
        <Toolbar>
          <IconButton edge="start" color="inherit" onClick={this.websitePageViewHandelclose} aria-label="close" className={classes.CloseButton}>
            <LeftAorrow />
          </IconButton>
          <h4 className={classes.SliderTitle}> Page Edit </h4>

        </Toolbar>
      </AppBar>
      <WebsitePageView id={this.state.pageId} idWebsite={this.state.websiteID}></WebsitePageView>
    </Dialog>


  }
  renderRevenue = () => {
    const classes = this.props.classes;

    return <div>
      <GridContainer justify="center" style={{ marginTop: "60px" }}>
        <GridItem xs={8} >
          <Card>
            <CardHeader color="rose" icon>
              <CardIcon color="rose">
                <MonetizationOnIcon />
              </CardIcon>
              <h4 className={classes.cardIconTitle} style={{ color: "black" }}>Revenue Share</h4>

            </CardHeader>
            {this.revenueViewAdd()}

          </Card>
        </GridItem>
      </GridContainer >

      <GridContainer justify="center" style={{ marginTop: "60px" }}>
        <GridItem xs={8} >
          <Card>
            <CardHeader color="rose" icon>
              <CardIcon color="rose">
                <MonetizationOnIcon />


              </CardIcon>
              <h4 className={classes.cardIconTitle} style={{ color: "black" }}> Add Revenue Share</h4>
            </CardHeader>
            {this.addNewRevenueShare()}
          </Card>

        </GridItem>
      </GridContainer >

    </div>
  }

  seletedAdUntUpdate = (option) => {



    this.setState(prevState => ({
      selectedAdunit: [...prevState.seletedAdUntUpdate, option]
    }))


  }
  enableRevenueDetails = () => {
    if (this.state.RevenueshareEnable) {
      alert("Do you want to Edit");
      this.setState({
        RevenueshareEnable: false,
        revenueEditText: 'Cancel'
      });


    }
    else {
      this.setState({
        RevenueshareEnable: true,
        revenueEditText: 'Edit'
      });
      alert("Do You want to Cancel");
    }
  }
  deleteAdvertiser = (event, value, reason) => {
    console.log(value)
    console.log(value.id)
    this.setState({ selectedAdvertiser: value.id })
  }
  submitRevenue = () => {
    var data = [{
      pub_share: this.state.pub_share,
      erg_share: this.state.erg_share,
      id_website: this.state.IDWEBSITE,
      id_advertiser: this.state.selectedAdvertiser
    }]
    console.log(data)
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.post(`${SERVER_URL}/api/website/revenues/add`, data, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        alert("data Submitted")
      }).catch(error => {
        console.log(error);
        alert("duplicate Entry!")
      })

  }
  renderRevenuedata = () => {
    const classes = this.props.classes;
    return this.state.revenueDatas.map((item, key) =>
      <GridContainer>
        <GridItem lg={2} md={2} className={classes.textfieldsgrid} >
          <InputBase className={classes.margin} value={item.id_advertiser} inputProps={{ 'aria-label': 'slno' }}
          />
        </GridItem>
        <GridItem lg={5} md={5} className={classes.textfieldsgrid}>
          <InputBase className={classes.margin} value={item.Advertiser_name} inputProps={{ 'aria-label': 'advertisername' }}
          />
        </GridItem>
        <GridItem lg={2} md={2} className={classes.textfieldsgrid}>

          <TextField type="text" id={`erg_share_${key}`} defaultValue={item.erg_share} className={classes.InputCenter} label=" My Share" variant="outlined"  size="small" style={{ width: "100%", textAlign: "center" }}
            onChange={(event) => this.updateShare(event.target.value, item.id_advertiser, item.id_website, key, "erg_share", this.handleChange)}
          />
        </GridItem>

        <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField type="text" id={`pub_share_${key}`}  defaultValue={item.pub_share} className={classes.InputCenter} label=" Publisher Share" variant="outlined"  size="small" style={{ width: "100%", textAlign: "center" }}
            onChange={(event) => this.updateShare(event.target.value, item.id_advertiser, item.id_website, key, "pub_share", this.handleChange)}
          />
        </GridItem>

        <AccordionDetails className={classes.AccordionInsideinput}>
          <Card>



          </Card>
        </AccordionDetails>
      </GridContainer>
    );

  }
  submitData = () => {
    console.log(this.state.revenueDatas);
    var data = this.state.revenueDatas;
    var id = this.state.IDWEBSITE;
  
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.post(`${SERVER_URL}/api/website/revenues/${id}`, data, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        //console.log(data);
        alert("data Submitted")
      }).catch(error => { console.log(error); })
  }

  updateShare = (value, advertiserId, WebsiteId, key, fieldName) => {
    const eshare = document.getElementById(`erg_share_${key}`);
    const pshare = document.getElementById(`pub_share_${key}`);
    console.log(eshare.value, pshare.value)
    
    var data = this.state.revenueDatas;
    // console.log("berfore", data)
    //  var data=lRevenueData[WebsiteId];

     for (let i = 0; i < data.length; i++) {

      const remainingShare = 1.00 - value;
       if(i === key && fieldName==="erg_share"){
         pshare.value = remainingShare;
        //  this.setState({rev_erg_share:value})
        //  this.setState({rev_pub_share:remainingShare})

       } else if (i === key && fieldName==="pub_share") {
        eshare.value = remainingShare;
        //  this.setState({rev_pub_share:value})
        //  this.setState({rev_erg_share:remainingShare})
       }
       data[key][fieldName] = value;
      }

     this.setState({ revenueDatas: data });
    console.log(this.state.revenueDatas);
  }


  revenueViewAdd = () => {
    const classes = this.props.classes;
    return <CardBody>
      {this.renderRevenuedata()}
      <CardHeader style={{ float: "right!important" }}>
        <div className={classes.root2} >
          <span style={{ paddingLeft: "10px" }}><MButton variant="outlined" color="secondary" onClick={this.submitData} >Confirm</MButton></span>
          <span style={{ paddingLeft: "10px" }}> <MButton variant="outlined" color="secondary"
            onClick={this.enableRevenueDetails} >{this.state.revenueEditText}</MButton></span>
        </div>
      </CardHeader>
    </CardBody >



  }


  render() {


    const classes = this.props.classes;
    return <div>


      <GridContainer justify="center">
        <GridItem xs={12} sm={12} md={12} lg={12}>
          <Card>
            <CardHeader color="rose" icon>
              <CardIcon color="rose">
                <Assignment />
              </CardIcon>
              <h4 className={classes.cardIconTitle}>Websites</h4>

            </CardHeader>

            {this.renderTable()}

          </Card>
        </GridItem>
      </GridContainer >



      <Dialog fullScreen open={this.state.addPagesViewopen} onClose={this.addPagesToWebsitesViewhandleClose} TransitionComponent={Transition} className={classes.PageCreationSlider}>
        <AppBar className={classes.CustomappBar}>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={this.addPagesToWebsitesViewhandleClose} aria-label="close" className={classes.CloseButton}>
              <LeftAorrow />
            </IconButton>
            <h4 className={classes.SliderTitle}> Page List </h4>
            <GridContainer>
              <ButtonGroup color="secondary" aria-label="outlined secondary button group" style={{ paddingLeft: "80%" }}>
                <MButton onClick={this.tabsetCreate} >Create</MButton>
                <MButton onClick={this.tabsetView}>View</MButton>
              </ButtonGroup>
            </GridContainer>
          </Toolbar>
        </AppBar>
        {this.state.tab == 'Create' &&
          <div>
            <CreateContact id={this.state.websiteID}></CreateContact>
          </div>}
        {this.state.tab == 'View' &&
          <div>
            <GridContainer style={{ paddingTop: "3%" }}>
              <GridItem lg={1} md={1}></GridItem>
              <GridItem lg={10} md={10} >
                <Card>
                  {this.renderPage()}
                  <CardHeader className={classes.SimpleButton} >
                    {/*  <div className={classes.root2} >
                      <span style={{ paddingLeft: "10px" }}><MButton color="secondary" variant="outlined" >
                        <a >
                          Export</a>
                      </MButton></span>
                    </div> */}
                  </CardHeader>
                </Card>
              </GridItem>
              <GridItem lg={1} md={1}></GridItem>
            </GridContainer>
          </div>}
      </Dialog>




      <Dialog fullScreen open={this.state.revenueShareOpen} onClose={this.revenueShareViewhandleClose} TransitionComponent={Transition} className={classes.PageCreationSlider}>
        <AppBar className={classes.CustomappBar}>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={this.revenueShareViewhandleClose} aria-label="close" className={classes.CloseButton}>
              <LeftAorrow />
            </IconButton>
            <h4 className={classes.SliderTitle}> Revenue Share </h4>

          </Toolbar>
        </AppBar>
        {this.renderRevenue()}

      </Dialog>








      {this.renderView()}
      {this.renderJSScript()}
    </div>

  }
}

const WebsitesHOC = withStyles(styles)(Websites);
export default connect(mapStateToProps, mapDispatchToProps)(WebsitesHOC);