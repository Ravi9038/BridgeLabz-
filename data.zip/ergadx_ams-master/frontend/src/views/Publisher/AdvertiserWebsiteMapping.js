import React, { Component } from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";

// @material-ui/core components
import { withStyles, makeStyles } from "@material-ui/core/styles";

import View from "@material-ui/icons/Visibility";

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";

import Slide from '@material-ui/core/Slide';
import MButton from '@material-ui/core/Button';

import Tooltip from '@material-ui/core/Tooltip';
// material-ui icons

import styles from "assets/jss/material-dashboard-pro-react/views/PublisherCustomStyle.js";
import axios from "axios";
import { SERVER_URL } from "../../variables/constants";
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}))(Tooltip);

const useStyles = makeStyles(styles);
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="left" ref={ref} {...props} />;
});


export class AdvertiserWebsiteMapping extends Component {
  state = {
   
    mappedDetails:[],
  }

  componentDidMount() {

    const USER_ID = this.props.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/website/advertiser/${USER_ID}` , { headers: { "Authorization": TOKEN } }).then(response => response.data)
      .then((data) => {
       this.setState({mappedDetails:data})
      }).catch((error) => {
        console.error(error);
      }); 
     
  }

  filterCaseInsensitive = (filter, row) =>{

    const id = filter.pivotId || filter.id;
    if (row[id] !== null) {
        return (
            row[id] !== undefined ?
                String(row[id].toString().toLowerCase())
                    .includes(filter.value.toString().toLowerCase())
            :
                true
        );
    }
  }

  renderAdvertiserWebsiteDetails = () => {
  
    const classes = this.props.classes;
    
    return <div>
      <CardBody>
        <ReactTable
          filterable
          data={this.state.mappedDetails}
          columns={[
            {
              Header: "Sl No.",
              accessor: " ",
              Cell: (row) => {
                return <div>{row.index+1}</div>;
            },
              Filter: ({ filter, onChange }) => (
                <input type='text' style={{ textAlign: 'center' }}
                  placeholder="Search Sl No"
                  value={filter ? filter.value : ''}
                  onChange={event => onChange(event.target.value)}
                />
              ),
            },
            {
              Header: "Publisher Name",
              accessor: "company_name",
              Filter: ({ filter, onChange }) => (
                <input type='text' style={{ textAlign: 'Left' }}
                  placeholder="Search Publisher Name"
                  value={filter ? filter.value : ''}
                  onChange={event => onChange(event.target.value)}
                />
              ),
              getProps: () => {
                return {
                    style: {
                        textAlign:'Left'
                    },
                }
            }
            },
            {
              Header: "Website Name",
              accessor: "website_url",
              Filter: ({ filter, onChange }) => (
                <input type='text' style={{ textAlign: 'center' }}
                  placeholder="Search Website Name"
                  value={filter ? filter.value : ''}
                  onChange={event => onChange(event.target.value)}
                />
              ),
              
            
            },
           
            {
              Header: "Pulisher Share %",
              accessor: "pub_share",
              Filter: ({ filter, onChange }) => (
                <input type='text' style={{ textAlign: 'center' }}
                  placeholder="Search Pulisher Share"
                  value={filter ? filter.value : ''}
                  onChange={event => onChange(event.target.value)}
                />
              ),
              Cell: (id) => {
                return <div>{id.original.pub_share *100 +"%"}</div>;
            },
            
            },
            {
              Header: "eRGAdX Share %",
              accessor: "erg_share",
              Filter: ({ filter, onChange }) => (
                <input type='text' style={{ textAlign: 'center' }}
                  placeholder="Search My  Share"
                  value={filter ? filter.value : ''}
                  onChange={event => onChange(event.target.value)}
                />
              ),
              Cell: (id) => {
                return <div>{id.original.erg_share *100 +"%"}</div>;
            },
            },
            

            {
              Header: "View Ledger",
              accessor: "actionsAdvertiserProfile",
              Cell: id => (
                <div className={classes.ActionsButton}>
                  <LightTooltip title="View" aria-label="view" placement="top">
                    <MButton 
                      justIcon
                      round
                      simple
                      color="secondary"
                      className="view"
                     
                    >
                      <View />
                    </MButton>
                  </LightTooltip>

                </div>
              ),
              sortable: false,
              filterable: false
            }
            
          ]}
          defaultPageSize={5}
          minRows = {1}
          defaultFilterMethod={this.filterCaseInsensitive}
          showPaginationTop 
          showPaginationBottom={false}
          className="-highlight"
        />
      </CardBody>

    </div>
  }

  render() {
    const classes = this.props.classes;
    return <div>
     <GridContainer style={{ paddingTop: "3%" }}>
          <GridItem lg={1} md={1}></GridItem>
          <GridItem lg={10} md={10} >
            <Card>
             
            {this.renderAdvertiserWebsiteDetails()}

            </Card>
          </GridItem>
          <GridItem lg={1} md={1}></GridItem>
        </GridContainer>
  
    </div>
  }
}

const AdvertiserWebsiteMappingHOC = withStyles(styles)(AdvertiserWebsiteMapping);
export default connect(mapStateToProps, mapDispatchToProps)(AdvertiserWebsiteMappingHOC);
