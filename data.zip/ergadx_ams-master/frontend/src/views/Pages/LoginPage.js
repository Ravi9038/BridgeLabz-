import React from "react";

// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
import InputAdornment from "@material-ui/core/InputAdornment";
import Icon from "@material-ui/core/Icon";

// @material-ui/icons
import Email from "@material-ui/icons/Email";
// import LockOutline from "@material-ui/icons/LockOutline";
import axios from 'axios';
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import CustomInput from "components/CustomInput/CustomInput.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardHeader from "components/Card/CardHeader.js";
import {SERVER_URL} from "../../variables/constants";
import { withStyles } from '@material-ui/styles';
import styles from "assets/jss/material-dashboard-pro-react/views/loginPageStyle.js";
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'

const useStyles = makeStyles(styles);
class LoginPage extends React.Component {
  //export default function LoginPage() {
  constructor(props) {
    super(props);
    this.state = {
      cardAnimation: 'cardHidden',
      loading: false,
      email : null,
      password : null,
      loginEmailState: null,
      error : null
    }
    this.handleKeyPress = this.handleKeyPress.bind(this);
  }

  componentDidMount() {
    let that = this;
    setTimeout(function () {
      that.setState({ "cardAnimation": "" });
    }, 700);
    
  }

  handleLogin = () => {
    console.log(this.state.email);
    console.log(this.state.password);
    var postData = {};
    this.setState({
      loading : true
    })
    postData.username = this.state.email;
    postData.password = this.state.password;
    axios({
      method: 'post',
      headers: { 'Content-Type': 'application/json' },
      url: `${SERVER_URL}/api/authenticate`,
      data: postData
    }).then((response) => {
      if(response.status==200 && response.data.id !=''){
        this.setState({
          loading : false
        })
        this.props.setUserData(response.data);
        debugger;
        if(response.data.idRole == 3)
          this.props.history.push('/admin/publisher-dashboard');
        else  if(response.data.idRole == 5)
          this.props.history.push('/admin/dashboard'); 
          else
          this.props.history.push('/admin/dashboard'); 
      }else{
        this.setState({
          error:'Something went wrong. Please try again later.',
          loading : false
        })
      }
     
    }).catch(error => {
      this.setState({
        error:'Something went wrong. Please try again later.',
        loading : false
      });
    }); 
  }

  verifyEmail = (value) => {
    var emailRex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var phonenoRex = /^\d{10}$/;
    if (emailRex.test(value) || phonenoRex.test(value) || value.length=='5') {
      return true;
    }
    return false;
  }
  componentWillMount() {
    document.addEventListener('keydown', this.handleKeyPress);

 }
 
 handleKeyPress(event) {
    if (event.keyCode !== 13) return;
 
    const {handleLogin, username, password} = this.props;
 
    this.handleLogin(username, password);
 }
 
 componentWillUnmount() {
    document.removeEventListener('keydown', this.handleKeyPress);
 }

  render() {
    const classes = this.props.classes;
    return (
      <div className={classes.container}>
        <GridContainer justify="center">
          <GridItem xs={12} sm={6} md={4}>

            <Card login className={classes[this.state.cardAnimaton]}>
              <CardHeader
                className={`${classes.cardHeader} ${classes.textCenter}`}
                color="rose"
              >
                <h4 className={classes.cardTitle}>Log in</h4>

              </CardHeader>
              <CardBody>
                <CustomInput
                  success={this.state.loginEmailState === "success"}
                  error={this.state.loginEmailState === "error"}
                  labelText="Email..."
                  id="email"
                  formControlProps={{
                    fullWidth: true
                  }}
                  inputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <Email className={classes.inputAdornmentIcon} />
                      </InputAdornment>
                    ),
                    onChange: event => {
                      if (this.verifyEmail(event.target.value)) {
                        this.setState({'loginEmailState':'success'});
                      } else {
                        this.setState({'loginEmailState':'error'});
                      }
                      this.setState({'email':event.target.value});
                    }
                  }}
                />
                <CustomInput
                  labelText="Password"
                  id="password"
                  formControlProps={{
                    fullWidth: true
                  }}
                  inputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <Icon className={classes.inputAdornmentIcon}>
                          lock_outline
                        </Icon>
                      </InputAdornment>
                    ),
                    type: "password",
                    autoComplete: "off",
                    onChange: event => {
                      this.setState({'password':event.target.value});
                    }
                  }}
                />
                 
                {this.state.error && <><small style={{ color: 'red' }}>{this.state.error}</small><br /></>}<br />
                <div className={classes.center}>
                  <Button simple size="lg" block color="rose" value={this.state.loading ? 'Loading...' : 'Login'} onClick={this.handleLogin.bind(this)} disabled={this.state.loading}
                  >
                    Login
                </Button>
                </div>
              </CardBody>
            </Card>

          </GridItem>
        </GridContainer>
      </div>
    );
  }
}

const LoginPageHOC = withStyles(styles)(LoginPage);
export default connect(mapStateToProps, mapDispatchToProps)(LoginPageHOC);