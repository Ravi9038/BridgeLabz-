import React, { Component } from "react";
// @material-ui/core components
import { makeStyles } from '@material-ui/core/styles';
import Icon from "@material-ui/core/Icon";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { SERVER_URL } from "../../variables/constants";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import styles from "assets/jss/material-dashboard-pro-react/views/dashboardStyle.js";
import DateSelectionDropDown from "../Widgets/DateSelectionDropdown.js";
import axios from 'axios';
// material-ui icons
import Menu from "@material-ui/icons/Menu";
import Graph from 'views/Publisher/Graph.js'
import Slide from '@material-ui/core/Slide';
import Button from "components/CustomButtons/Button.js";
import Hidden from "@material-ui/core/Hidden";
import * as moment from 'moment';
const useStyles = makeStyles((theme)=> ({

  root: {
    '& .MuiInputBase-inputSelect' :{
      fontSize:"15px !important",
      fontWeight:"400 !important",
      textAlign:"left !important"
    },
  },
 
    })); 
    const Transition = React.forwardRef(function Transition(props, ref) {
      return <Slide direction="left" ref={ref} {...props} />;
    });


class AdminDashboard extends Component {

  constructor(props) {
    super(props);
    this.state = {
      todaysDate : new moment().utcOffset('GMT-00:00').format("YYYY-MM-DD"),
      open : false,
      cardAnimation: 'cardHidden',
      loading: false,
      todaysRevenue: 0.0,
      yesterdaysRevenue: 0.0,
      lastWeekYesterday : 0.0,
      current7DaysRevenue:0.0,
      last7DaysRevenue: 0.0,
      current30DaysRevenue :0.0,
      last30DaysRevenue: 0.0,
      yesterdayDifference : 0.0,
      last7DaysDifference : 0.0,
      last30DaysDifferene : 0.0,
      yesterdayDifferencePercentage : 0.0,
      last7DaysDifferencePercentage : 0.0,
      last30DaysDifferenePercentage : 0.0,
      paymentData : [],
      selectWebsiteRevenueDuration : 'Today',
      selectDateRevenueDuration : 'Today',
      publisherHtml : '',
      advertiserHtml : '',
      websiteHtml : '',
      dateWiseHtml : '',
      mediaHtml:'',
      siteDropDownReport: 'Last7Days',
    }

  }

  openReport = (pReportPage) => {
    console.log(pReportPage);
    this.props.history.push({
      pathname: pReportPage,
      state: { siteDropDownReport: this.state.siteDropDownReport }
    });
  }

  handleClickOpen = (event) =>{
    this.setState({open:true});
  }
  handleClose = (event) =>{
    this.setState({open:false});
  }

  handleWebsiteDropDownChange = (pStartDate,pEndDate, lSelectedDropdownValue)=>{
    console.log(lSelectedDropdownValue);
    this.setState({ siteDropDownReport: lSelectedDropdownValue });
    this.renderWebsiteWiseData(pStartDate,pEndDate);
  } 
  handleVideoDropDownChange = (pStartDate,pEndDate, lSelectedDropdownValue)=>{
    this.setState({ siteDropDownReport: lSelectedDropdownValue });
    this.renderVideoWiseData(pStartDate,pEndDate);
  }
  handleDateDropDownChange = (pStartDate,pEndDate)=>{
    this.renderDateWiseData(pStartDate,pEndDate);
  }
  handleAdvertiserDropDownChange = (pStartDate,pEndDate, lSelectedDropdownValue)=>{
    this.setState({ siteDropDownReport: lSelectedDropdownValue });
      this.renderAdvertiserWiseData(pStartDate,pEndDate);
  }
  handlePublisherDropDownChange = (pStartDate,pEndDate, lSelectedDropdownValue)=>{
    this.setState({ siteDropDownReport: lSelectedDropdownValue });
    this.renderPublisherWiseData(pStartDate,pEndDate);
  }

  componentDidMount() {

    const USER_ID = this.props.data.id;
    const USER_ID_ROLE = this.props.data.idRole;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    var url = "";
    if (USER_ID_ROLE == 1 || USER_ID_ROLE == 4) {
      url = `${SERVER_URL}/api/users/admin/dashboard/${USER_ID}`;
    } else {
      url = `${SERVER_URL}/api/users/dashboard/${USER_ID}`;
    }

    axios.get(url, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let responseData = res.data;
        let todaysRevenue = 0.0;
        let yesterdaysRevenue = 0.0;
        let lastWeekYesterday = 0.0;
        let current7DaysRevenue = 0.0;
        let last7DaysRevenue = 0.0;
        let current30DaysRevenue = 0.0;
        let last30DaysRevenue = 0.0;
        let  yesterdayDifference = 0.0;
        let last7DaysDifference = 0.0;
        let last30DaysDifferene = 0.0;
        let yesterdayDifferencePercentage = 0.0;
        let last7DaysDifferencePercentage = 0.0;
        let last30DaysDifferenePercentage = 0.0;

        if (responseData.revenue_data) {
          todaysRevenue = responseData.revenue_data.today;
          yesterdaysRevenue = responseData.revenue_data.yesterday;
          lastWeekYesterday = responseData.revenue_data.lastweek_sameday;
          yesterdayDifference = yesterdaysRevenue - lastWeekYesterday;
          yesterdayDifferencePercentage = (( yesterdayDifference / lastWeekYesterday ) * 100).toFixed(2);

          current7DaysRevenue = responseData.revenue_data.current7day; 
          last7DaysRevenue = responseData.revenue_data.last7day;
          last7DaysDifference = current7DaysRevenue - last7DaysRevenue;
          last7DaysDifferencePercentage = (( last7DaysDifference / last7DaysRevenue ) * 100).toFixed(2) ;

          current30DaysRevenue = responseData.revenue_data.current30day;
          last30DaysRevenue = responseData.revenue_data.last30day;
          last30DaysDifferene = current30DaysRevenue - last30DaysRevenue;
          last30DaysDifferenePercentage = (( last30DaysDifferene / last30DaysRevenue ) * 100).toFixed(2) ;
        }
        this.setState({
          todaysRevenue: todaysRevenue,
          yesterdaysRevenue: yesterdaysRevenue,
          lastWeekYesterday : lastWeekYesterday,
          current7DaysRevenue: current7DaysRevenue,
          last7DaysRevenue: last7DaysRevenue,
          current30DaysRevenue:current30DaysRevenue,
          last30DaysRevenue: last30DaysRevenue,
          yesterdayDifference : yesterdayDifference,
          last7DaysDifference : last7DaysDifference,
          last30DaysDifferene : last30DaysDifferene,
          yesterdayDifferencePercentage : yesterdayDifferencePercentage,
          last7DaysDifferencePercentage : last7DaysDifferencePercentage,
          last30DaysDifferenePercentage : last30DaysDifferenePercentage
        });
      }).catch(function (error) {
        console.log(error);
      });

      /*this.renderPublisherWiseData(this.state.todaysDate,this.state.todaysDate);
      this.renderAdvertiserWiseData(this.state.todaysDate,this.state.todaysDate);
      this.renderWebsiteWiseData(this.state.todaysDate,this.state.todaysDate);
      this.renderVideoWiseData(this.state.todaysDate,this.state.todaysDate);

      */
      this.renderDateWiseData(this.state.todaysDate,this.state.todaysDate);

  }

  
  renderWebsiteWiseData = (pStartDate,pEndDate) =>{
    
    const classes = this.props.classes;
    const USER_ID = this.props.data.id;
    const USER_ID_ROLE = this.props.data.idRole;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    var url = `${SERVER_URL}/api/revenueprocessor/query`;
    var queryId = "";
    if (USER_ID_ROLE == 1 || USER_ID_ROLE == 4) {
      queryId = "GET_WEBSITE_WISE_DATA_FOR_ADMIN";
    
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    paramData.push(startDateParam);
    paramData.push(endDateParam);
   
    requestData.param_data = paramData;

    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        console.log(res);
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[0]);
          var lImpressions =  Number(prop[1]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[3],
            //Date: prop[4],
            Revenue: prop[0],
            Impression: prop[1],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
    
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        
        )
        var lWebsiteHtml  = <tbody>{items}</tbody>;
        this.setState({websiteHtml:lWebsiteHtml});
        
      }).catch(function (error) {
        console.log(error);
      });
    }
   else if (USER_ID_ROLE == 5) {
      queryId = "GET_WEBSITE_WISE_DATA_FOR_ACCOUNTMANAGER";

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    var userIdParam = {};
    userIdParam.type="int";
    userIdParam.value=USER_ID;
    paramData.push(userIdParam);

    paramData.push(startDateParam);
    paramData.push(endDateParam);
    
    requestData.param_data = paramData;

    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[0]);
          var lImpressions =  Number(prop[1]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[3],
            //Date: prop[4],
            Revenue: prop[0],
            Impression: prop[1],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        );
        var lWebsiteHtml  = <tbody>{items}</tbody>;
        this.setState({websiteHtml:lWebsiteHtml});
                  
      }).catch(function (error) {
        console.log(error);
      });
    }
  }
  renderVideoWiseData = (pStartDate,pEndDate) =>{
    const classes = this.props.classes;
    const USER_ID = this.props.data.id;
    const USER_ID_ROLE = this.props.data.idRole;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    var url = `${SERVER_URL}/api/revenueprocessor/query`;
    var queryId = "";

     if (USER_ID_ROLE == 1 || USER_ID_ROLE == 4) {
      queryId = "GET_ADTYPE_WISE_DATA_FOR_ADMIN";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    paramData.push(startDateParam);
    paramData.push(endDateParam);

    
    requestData.param_data = paramData;
    
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
      
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[0]);
          var lImpressions =  Number(prop[1]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[3],
            //Date: prop[4],
            Revenue: prop[0],
            Impression: prop[1],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        );
        var lWebsiteHtml  = <tbody>{items}</tbody>;
        this.setState({mediaHtml:lWebsiteHtml});
                  
      }).catch(function (error) {
        console.log(error);
      });
    } 
   else if (USER_ID_ROLE == 5) {
      queryId = "GET_ADTYPE_WISE_DATA_FOR_ACCOUNTMANAGER";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    var userIdParam = {};
    userIdParam.type="int";
    userIdParam.value=USER_ID;
    paramData.push(userIdParam);
    paramData.push(startDateParam);
    paramData.push(endDateParam);

    
    requestData.param_data = paramData;
    
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
      
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[0]);
          var lImpressions =  Number(prop[1]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[3],
            //Date: prop[4],
            Revenue: prop[0],
            Impression: prop[1],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        );
        var lWebsiteHtml  = <tbody>{items}</tbody>;
        this.setState({mediaHtml:lWebsiteHtml});
                  
      }).catch(function (error) {
        console.log(error);
      });
    } 
  }


  renderDateWiseData = (pStartDate,pEndDate) =>{
    const classes = this.props.classes;
    const USER_ID = this.props.data.id;
    const USER_ID_ROLE = this.props.data.idRole;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    var url = `${SERVER_URL}/api/revenueprocessor/query`;
    var queryId = "";
    if (USER_ID_ROLE == 1 || USER_ID_ROLE == 4) {
      queryId = "GET_DATE_WISE_DATA_FOR_ADMIN_DASHBOARD";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    //paramData.push(startDateParam);
    //paramData.push(endDateParam);

    
    
    requestData.param_data = paramData;
    
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[0]);
          var lImpressions =  Number(prop[1]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[3],
            //Date: prop[4],
            Revenue: prop[0],
            Impression: prop[1],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        );
        var lDateWiseHtml  = <tbody>{items}</tbody>;
        this.setState({dateWiseHtml:lDateWiseHtml});
                  
      }).catch(function (error) {
        console.log(error);
      });
    }
   else if (USER_ID_ROLE == 5) {
      queryId = "GET_DATE_WISE_DATA_FOR_ACCOUNTNAMAGER_DASHBOARD";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    //paramData.push(startDateParam);
    //paramData.push(endDateParam);

    var userIdParam = {};
    userIdParam.type="int";
    userIdParam.value=USER_ID;
    paramData.push(userIdParam);
    
    requestData.param_data = paramData;
    
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[0]);
          var lImpressions =  Number(prop[1]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[3],
            //Date: prop[4],
            Revenue: prop[0],
            Impression: prop[1],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        );
        var lDateWiseHtml  = <tbody>{items}</tbody>;
        this.setState({dateWiseHtml:lDateWiseHtml});
                  
      }).catch(function (error) {
        console.log(error);
      });
    }
  }

  renderPublisherWiseData = (pStartDate,pEndDate) =>{
    const classes = this.props.classes;
    const USER_ID = this.props.data.id;
    const USER_ID_ROLE = this.props.data.idRole;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    var url = `${SERVER_URL}/api/revenueprocessor/query`;
    var queryId = "";
    if (USER_ID_ROLE == 1 || USER_ID_ROLE == 4) {
      queryId = "GET_PUBLISHER_WISE_DATA_FOR_ADMIN";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    paramData.push(startDateParam);
    paramData.push(endDateParam);

    
    requestData.param_data = paramData;
    
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[1]);
          var lImpressions =  Number(prop[2]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[0],
            //Date: prop[4],
            Revenue: prop[1],
            Impression: prop[2],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        );
        var lPublisherHtml  = <tbody>{items}</tbody>;
        this.setState({publisherHtml:lPublisherHtml});
                  
      }).catch(function (error) {
        console.log(error);
      });
    }
   else if (USER_ID_ROLE == 5 ) {
      queryId = "GET_PUBLISHER_WISE_DATA_FOR_ACCOUNTMANAGER";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    paramData.push(startDateParam);
    paramData.push(endDateParam);
   
    var userIdParam = {};
    userIdParam.type="int";
    userIdParam.value=USER_ID;
    paramData.push(userIdParam);
    
    requestData.param_data = paramData;
    
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[1]);
          var lImpressions =  Number(prop[2]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[0],
            //Date: prop[4],
            Revenue: prop[1],
            Impression: prop[2],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        );
        var lPublisherHtml  = <tbody>{items}</tbody>;
        this.setState({publisherHtml:lPublisherHtml});
                  
      }).catch(function (error) {
        console.log(error);
      });
    }
  }

  renderAdvertiserWiseData = (pStartDate,pEndDate) =>{
    const USER_ID = this.props.data.id;
    const classes = this.props.classes;
    const USER_ID_ROLE = this.props.data.idRole;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    var url = `${SERVER_URL}/api/revenueprocessor/query`;
    var queryId = "";
    if (USER_ID_ROLE == 1 || USER_ID_ROLE == 4) {
      queryId = "GET_ADVERTISER_WISE_DATA_FOR_ADMIN";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    paramData.push(startDateParam);
    paramData.push(endDateParam);

    
    requestData.param_data = paramData;
  
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[1]);
          var lImpressions =  Number(prop[2]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[0],
            //Date: prop[4],
            Revenue: prop[1],
            Impression: prop[2],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        );
        var lAdvertiserHtml  = <tbody>{items}</tbody>;
        this.setState({advertiserHtml:lAdvertiserHtml});
        
       
      }).catch(function (error) {
        console.log(error);
      });
    }
    else if (USER_ID_ROLE == 5) {
      queryId = "GET_ADVERTISER_WISE_DATA_FOR_ACCOUNTMANAGER";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    paramData.push(startDateParam);
    paramData.push(endDateParam);

    var userIdParam = {};
    userIdParam.type="int";
    userIdParam.value=USER_ID;
    paramData.push(userIdParam);
    
    requestData.param_data = paramData;
   
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[1]);
          var lImpressions =  Number(prop[2]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var eCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          return {
            id: key,
            Name:prop[0],
            //Date: prop[4],
            Revenue: prop[1],
            Impression: prop[2],
            eCPM: eCpm
          
          };
        })
        var nf = new Intl.NumberFormat('en-NZ', {
          minimumFractionDigits: 2,
        });
        var n = new Intl.NumberFormat();
        const items = lData.map((item) =>
        <tr key={item.id}>
          <td className={classes.borderfirstcol}>{item.Name}</td>
          <td className={classes.backgroundcolortr}>${nf.format(item.Revenue)}</td>
          <td className={classes.backgroundcolorfourthhigh}>{n.format(item.Impression)}</td>
          <td className={classes.backgroundcolorfourthhigh}>${item.eCPM}</td>
        </tr>
        );
        var lAdvertiserHtml  = <tbody>{items}</tbody>;
        this.setState({advertiserHtml:lAdvertiserHtml});
        
       
      }).catch(function (error) {
        console.log(error);
      });
    }
  }

  renderPaymentData = () => {
    
    const classes = this.props.classes;
    return <GridContainer>
          <GridItem xs={12} sm={12} md={6} >
            <Card>
              <CardHeader>
                <CardIcon >
                  <GridContainer >
                    <GridItem xs={6} sm={6} md={6} lg={6}>
                      <h3 style={{ fontSize: "18px", fontWeight: "400", color: "#4e4b4b" }}>Payments</h3>
                    </GridItem>
                    <GridItem xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'right' }}>
                      <div className={classes.flex}>
                        <Button href="#" className={classes.title} color="transparent" style={{ textAlign: 'right', paddingTop: "20px", paddingRight: "10px" }}>
                          <Icon >more_vert</Icon>
                        </Button>
                      </div>

                      
                    </GridItem>
                  </GridContainer>

                </CardIcon>
              </CardHeader>

              <GridContainer>
                <GridItem xs={12} md={12} lg={12}>
                  <table width={"100%"} cellPadding={"6"} cellSpacing={"0"}>
                    <thead>
                      <th width={"25%"} className={classes.thead}>Date</th>
                      <th className={classes.thead}>Amount</th>
                      <th className={classes.thead}>Transaction ID</th>

                    </thead>

                  </table>
                </GridItem>
              </GridContainer>
              <CardFooter>
                <a onClick={() => this.viewPaymentReport('/admin/paymentwisereport')} style={{ color: "#0b4abdf7", fontWeight: "400", cursor: "pointer" }}>View report</a>
              </CardFooter>
            </Card>
          </GridItem>
        </GridContainer>
  }

    
  render() {
    
    const classes = this.props.classes;
    return (
      
      <div className={classes.root} style={{ marginTop: "-10px" }}>
        <GridContainer>
          <GridItem xs={12} sm={12} md={9} lg={9}>
            <Card style={{ backgroundColor: "#0b4abdf7", color: "white" }}>
              <CardHeader >
                <CardIcon >
                  <GridContainer>
                    <GridItem xs={6} sm={12} md={6} lg={6} >
                      <p style={{ fontSize: "18px", marginTop: "15px", fontWeight: "400", }}>Estimated earnings</p>
                    </GridItem>
                    <GridItem xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'right' }}>
                      <Button href="#" className={classes.title} color="transparent" style={{ textAlign: 'right', paddingTop: "20px", paddingRight: "10px" }}>
                        <Icon >more_vert</Icon>
                      </Button>


                    </GridItem>
                  </GridContainer>

                </CardIcon>
                <p className={classes.cardCategory}></p>
              </CardHeader>
              <CardBody style={{ marginTop: "-20px", marginBottom: "10px" }}>
                <GridContainer>
                  <GridItem xs={6} sm={6} md={6} lg={3}>
                    Today so far
                <h3 className={classes.cardTitle} style={{ color: "white", fontWeight: "400" }}>
                      ${this.state.todaysRevenue}
              </h3>
                  </GridItem>
                  <GridItem xs={6} sm={6} md={6} lg={3} >
                    Yesterday
              <h3 className={classes.cardTitle} style={{ color: "white", fontWeight: "400" }}>
                      ${this.state.yesterdaysRevenue}
              </h3>
              <p style={{ lineHeight: "1px" }}>
                {this.state.yesterdayDifference < 0 ? <Icon style={{ verticalAlign: "middle" }}>keyboard_arrow_down</Icon> : <Icon style={{ verticalAlign: "middle" }}>keyboard_arrow_up</Icon> } 
                ${this.state.yesterdayDifference.toFixed(2)}
                ({this.state.yesterdayDifferencePercentage}%)
                </p>
                    <p style={{ lineHeight: "1px" }}>vs same day last week</p>

                  </GridItem>
                  <GridItem xs={6} sm={6} md={6} lg={3} >
                    Last 7 Days
              <h3 className={classes.cardTitle} style={{ color: "white", fontWeight: "400" }}>
                      ${this.state.current7DaysRevenue}
                </h3>
              <p style={{ lineHeight: "1px" }}>
                {this.state.last7DaysDifference < 0 ? <Icon style={{ verticalAlign: "middle" }}>keyboard_arrow_down</Icon> : <Icon style={{ verticalAlign: "middle" }}>keyboard_arrow_up</Icon> } 
                ${this.state.last7DaysDifference.toFixed(2)}
                ({this.state.last7DaysDifferencePercentage}%)
                </p>
                    <p style={{ lineHeight: "1px" }}>vs previous 7 days</p>
                  </GridItem>
                  <GridItem xs={6} sm={6} md={6} lg={3} >
                    This month
              <h3 className={classes.cardTitle} style={{ color: "white", fontWeight: "400" }}>
                      ${this.state.current30DaysRevenue}
                </h3>
                  <p style={{ lineHeight: "1px" }}>
                    {this.state.last30DaysDifferene < 0 ? <Icon style={{ verticalAlign: "middle" }}>keyboard_arrow_down</Icon> : <Icon style={{ verticalAlign: "middle" }}>keyboard_arrow_up</Icon> } 
                    ${this.state.last30DaysDifferene.toFixed(2)}
                    ({this.state.last30DaysDifferenePercentage}%)
                  </p>
                    <p style={{ lineHeight: "1px" }}>vs same period last year</p>
                  </GridItem>
                </GridContainer>
              </CardBody>

            </Card>

          </GridItem>
          <GridItem xs={12} sm={12} md={6} lg={3}>
            <Card style={{ backgroundColor: "#0b4abdf7", color: "white" }}>
              <CardHeader >

                <CardIcon >
                  <GridContainer>
                    <GridItem xs={6} sm={6} md={6} lg={6} >
                      <p style={{ fontSize: "18px", marginTop: "15px", fontWeight: "400", }}>Balance</p>
                    </GridItem>
                    <GridItem xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'right' }}>

                      {/* Here we create navbar brand, based on route name */}
                      <Button href="#" className={classes.title} color="transparent" style={{ textAlign: 'right', paddingTop: "20px", paddingRight: "10px" }}>
                        <Icon >more_vert</Icon>
                      </Button>
                    </GridItem>
                  </GridContainer>
                </CardIcon>
                <p className={classes.cardCategory}></p>
              </CardHeader>
              <CardBody style={{ marginTop: "-20px", marginBottom: "10px" }}>
                <GridContainer>
                  <GridItem xs={12} sm={6} md={6} lg={12}>

                    <h3 className={classes.cardTitle} style={{ color: "white", fontWeight: "400", paddingTop: "22px" }}>
                      $0
                </h3>
                    <p>Last payment</p>
                    <p style={{ lineHeight: "1px" }}>$0</p>

                  </GridItem>
                </GridContainer>
              </CardBody>
            </Card>
          </GridItem>
        </GridContainer>

      <Graph></Graph> 




        <GridContainer>
          <GridItem xs={12} sm={12} md={6} >
            <Card>
              <CardHeader>
                <CardIcon >
                  <GridContainer>
                    <GridItem xs={6} sm={6} md={6} lg={6}>
                      <p style={{ fontSize: "18px", fontWeight: "400", color: "#4e4b4b",paddingTop:"10px" }}>Sites</p>
                    </GridItem>
                    <GridItem xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'right', display: "inline-flex" }}>
                      
                    <DateSelectionDropDown id="websiteDropDown" customStyle={{ width: "100%", float: "right", paddingRight: "20px"}} defaultValue={this.state.siteDropDownReport}
                     classes={{
                      select: classes.select
                  }} onDropDownChange={this.handleWebsiteDropDownChange}/>
                     
                    </GridItem>
                  </GridContainer>

                </CardIcon>
              </CardHeader>

              <GridContainer>
                <GridItem xs={12} md={12} lg={12}>
                
                    <table width={"100%"} cellPadding={"6"} cellSpacing={"0"} >
                    <thead>
                      <th  className={classes.thead}></th>
                      <th className={classes.thead}>Estimate</th>
                      <th className={classes.thead}>Impressions</th>
                      <th className={classes.thead}>eCPM</th>
                    </thead> 

                    {this.state.websiteHtml}

                  </table>
                
                </GridItem>
              </GridContainer>
              <CardFooter>
                <a onClick={() => this.openReport('/admin/sitereport')} style={{ color: "#0b4abdf7", fontWeight: "400", cursor: "pointer" }}>View report</a>
              </CardFooter>
            </Card>
          </GridItem>
          
        
          
          
          
          
          <GridItem xs={12} sm={12} md={6} >
            <Card>
              <CardHeader>
                <CardIcon >
                  <GridContainer >
                    <GridItem xs={6} sm={6} md={6} lg={6}>
                    <p style={{ fontSize: "18px", fontWeight: "400", color: "#4e4b4b",paddingTop:"10px" }}>Date</p>
                    </GridItem>
                    <GridItem xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'right', display: "inline-flex" }}>
                     </GridItem>
                  </GridContainer>

                </CardIcon>
              </CardHeader>

              <GridContainer>
                <GridItem xs={12} md={12} lg={12}>
                  <table width={"100%"} cellPadding={"6"} cellSpacing={"0"}>
                    <thead>
                      <th  className={classes.thead}></th>
                      <th className={classes.thead}>Estimate</th>
                      <th className={classes.thead}>Impressions</th>
                      <th className={classes.thead}>eCPM</th>
                    </thead>

                    {this.state.dateWiseHtml}

                  </table>
                </GridItem>
              </GridContainer>
              <CardFooter>
                <a onClick={() => this.openReport('/admin/datewisereport')} style={{ color: "#0b4abdf7", fontWeight: "400", cursor: "pointer" }}>View report</a>
              </CardFooter>
            </Card>
          </GridItem>
        </GridContainer>
        <GridContainer>
          <GridItem xs={12} sm={12} md={6} >
          <Card>
            <CardHeader>
            <CardIcon >
              <GridContainer> 
              <GridItem xs={6} sm={6} md={6} lg={6}>
              <p style={{ fontSize: "18px", fontWeight: "400", color: "#4e4b4b",paddingTop:"10px" }}>Advertisers</p> 
              </GridItem>
              <GridItem xs={6} sm={6} md={6} lg={6} style={{textAlign: 'right',display:"inline-flex"}}>
              <DateSelectionDropDown id="advertiserDropDown" customStyle={{ width: "100%", float: "right", paddingRight: "20px"}} onDropDownChange={this.handleAdvertiserDropDownChange} defaultValue="Last7Days"
               classes={{
                select: classes.select
            }}/>
          
          {/*<Button href="#" className={classes.title} color="transparent" style={{textAlign: 'right',paddingTop:"20px",paddingRight:"10px"}}>
          <Icon >more_vert</Icon>
    </Button>*/}
       
        <Hidden mdUp implementation="css">
          <Button
            className={classes.appResponsive}
            color="transparent"
            justIcon
            aria-label="open drawer"
          >
            <Menu />
          </Button>
        </Hidden>
              </GridItem>
           </GridContainer>
           
                </CardIcon> 
            </CardHeader>
            
              <GridContainer>
                <GridItem xs={12} md={12} lg={12}>
                <table width={"100%"} cellPadding={"6"} cellSpacing={"0"}>
                  <thead>
                    <th  className={classes.thead}>Name</th>
                    <th  className={classes.thead}>Revenue</th> 
                    <th  className={classes.thead}>Impressions</th>
                    <th  className={classes.thead}>eCPM</th>
                  </thead>
                {this.state.advertiserHtml}
                </table>
            
                </GridItem>
              </GridContainer>
            <CardFooter>
            <a onClick={()=>this.openReport('/admin/advertiserwisereport')} style={{color:"#0b4abdf7",fontWeight:"400",cursor:"pointer"}}>View report</a>
            </CardFooter>
          </Card>
          </GridItem>
          <GridItem xs={12} sm={12} md={6} >
          <Card>
            <CardHeader>
            <CardIcon >
              <GridContainer>
              <GridItem xs={6} sm={6} md={6} lg={6}>
              <p style={{ fontSize: "18px", fontWeight: "400", color: "#4e4b4b",paddingTop:"10px" }}>Publishers</p> 
          
              </GridItem>
              <GridItem xs={6} sm={6} md={6} lg={6} style={{textAlign: 'right',display:"inline-flex"}}>
              <DateSelectionDropDown id="publisherDropdown" customStyle={{ width: "100%", float: "right", paddingRight: "20px"}} onDropDownChange={this.handlePublisherDropDownChange} defaultValue="Last7Days"
               classes={{
                select: classes.select
            }}/>
          
          {/*<Button href="#" className={classes.title} color="transparent" style={{textAlign: 'right',paddingTop:"20px",paddingRight:"10px"}}>
          <Icon >more_vert</Icon>
  </Button>*/}
       
        <Hidden mdUp implementation="css">
          <Button
            className={classes.appResponsive}
            color="transparent"
            justIcon
            aria-label="open drawer"
          >
            <Menu />
          </Button>
        </Hidden>
              </GridItem>
           </GridContainer>
           
                </CardIcon> 
            </CardHeader>
            
              <GridContainer>
                <GridItem xs={12} md={12} lg={12}>
                <table width={"100%"} cellPadding={"6"} cellSpacing={"0"}>
                  <thead>
                    <th  className={classes.thead}>Name</th>
                    <th  className={classes.thead}>Revenue</th> 
                    <th  className={classes.thead}>Impressions</th>
                    <th  className={classes.thead}>eCPM</th>
                  </thead>
                  {this.state.publisherHtml}
                </table>
            
                </GridItem>
              </GridContainer>
            <CardFooter>
            <a onClick={()=>this.openReport('/admin/publisherwisereport')} style={{color:"#0b4abdf7",fontWeight:"400",cursor:"pointer"}}>View report</a>
            </CardFooter>
          </Card>
          </GridItem>

          <GridItem xs={12} sm={12} md={6} >
            <Card>
              <CardHeader>
                <CardIcon >
                  <GridContainer>
                    <GridItem xs={6} sm={6} md={6} lg={6}>
                      <p style={{ fontSize: "18px", fontWeight: "400", color: "#4e4b4b",paddingTop:"10px" }}>Media </p>
                    </GridItem>
                    <GridItem xs={6} sm={6} md={6} lg={6} style={{ textAlign: 'right', display: "inline-flex" }}>
                      
                    <DateSelectionDropDown id="websiteDropDown" customStyle={{ width: "100%", float: "right", paddingRight: "20px"}} onDropDownChange={this.handleVideoDropDownChange} defaultValue="Last7Days"
                     classes={{
                      select: classes.select
                  }}/>
                    
                    </GridItem>
                  </GridContainer>

                </CardIcon>
              </CardHeader>

              <GridContainer>
                <GridItem xs={12} md={12} lg={12}>
                
                    <table width={"100%"} cellPadding={"6"} cellSpacing={"0"} >
                    <thead>
                      <th  className={classes.thead}></th>
                      <th className={classes.thead}>Estimate</th>
                      <th className={classes.thead}>Impressions</th>
                      <th className={classes.thead}>eCPM</th>
                    </thead> 

                    {this.state.mediaHtml}

                  </table>
                
                </GridItem>
              </GridContainer>
              <CardFooter>
                <a onClick={() => this.openReport('/admin/VideoDisplayreport')} style={{ color: "#0b4abdf7", fontWeight: "400", cursor: "pointer" }}>View report</a>
              </CardFooter>
            </Card>
          </GridItem>
        
          
          


          </GridContainer>
        {/*this.renderPaymentData()*/}

      </div>
    );

  }

}

const AdminDashboardHOC = withStyles(styles)(AdminDashboard);
export default connect(mapStateToProps, mapDispatchToProps)(AdminDashboardHOC);
