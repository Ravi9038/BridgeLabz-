import React, { Component } from "react";
import { VectorMap } from "react-jvectormap";

// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
import Icon from "@material-ui/core/Icon";

// @material-ui/icons
// import ContentCopy from "@material-ui/icons/ContentCopy";
import Store from "@material-ui/icons/Store";
// import InfoOutline from "@material-ui/icons/InfoOutline";
import Warning from "@material-ui/icons/Warning";
import DateRange from "@material-ui/icons/DateRange";
import LocalOffer from "@material-ui/icons/LocalOffer";
import Update from "@material-ui/icons/Update";
import Language from "@material-ui/icons/Language";

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Table from "components/Table/Table.js";
import Danger from "components/Typography/Danger.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { SERVER_URL } from "../../variables/constants";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import CustomTabs from "components/CustomTabs/CustomTabs.js";
import Tasks from "components/Tasks/Tasks.js";
import styles from "assets/jss/material-dashboard-pro-react/views/dashboardStyle.js";
import BugReport from "@material-ui/icons/BugReport";
import Code from "@material-ui/icons/Code";
import Cloud from "@material-ui/icons/Cloud";
import axios from 'axios';

const useStyles = makeStyles(styles);

class AdminDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cardAnimation: 'cardHidden',
      loading: false,
      todaysRevenue: 0.0,
      yesterdaysRevenue: 0.0,
      last7DaysRevenue: 0.0,
      last30DaysRevenue: 0.0,
      websiteRevenueHeaders: ["Website Name","Amount", "Impressions", "cpm"],
      AdvertiserRevenueHeaders: ["Advertiser Name ","Amount", "Impressions", "cpm"],

      todaysWebsiteRevenueData: [],
      yesterdaysWebsiteRevenueData: [],
      last7daysWebsiteRevenueData: [],
      lst30daysWebsiteRevenueData: [],
      todaysAdvertiserRevenueData: [],
      yesterdaysAdvertiserRevenueData: [],
      last7daysAdvetiserRevenueData: [],
      lst30daysAdvertiserRevenueData: [],
     
    }
  }

  componentDidMount() {
    const USER_ID = this.props.data.id;
    const USER_ID_ROLE = this.props.data.idRole;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    let url = `${SERVER_URL}/api/users/admin/dashboard/${USER_ID}`;
    axios.get(url, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let responseData = res.data;
        let todaysRevenue = 0.0;
        let yesterdaysRevenue = 0.0;
        let last7DaysRevenue = 0.0;
        let last30DaysRevenue = 0.0;
        let todaysWebsiteRevenueData = [];
        let yesterdaysWebsiteRevenueData = [];
        let last7daysWebsiteRevenueData = [];
        let lst30daysWebsiteRevenueData = [];
        let todaysAdvertiserRevenueData = [];
        let yesterdaysAdvertiserRevenueData = [];
        let last7daysAdvetiserRevenueData = [];
        let lst30daysAdvertiserRevenueData = [];
        if (responseData.revenue_data) {
          todaysRevenue = responseData.revenue_data.today;
          yesterdaysRevenue = responseData.revenue_data.yesterday;
          last7DaysRevenue = responseData.revenue_data.last7day;
          last30DaysRevenue = responseData.revenue_data.last30day;
        }
        if(responseData.today_revenue_data){
          todaysWebsiteRevenueData = responseData.today_revenue_data
        }
        if(responseData.yesterday_revenue_data){
          yesterdaysWebsiteRevenueData = responseData.yesterday_revenue_data
        }
        if(responseData.last7days_revenue_data){
          last7daysWebsiteRevenueData = responseData.last7days_revenue_data
        }
        if(responseData.last30days_revenue_data){
          lst30daysWebsiteRevenueData = responseData.last30days_revenue_data
        }

        if(responseData.today_revenue_data_advertiser){
          todaysAdvertiserRevenueData = responseData.today_revenue_data_advertiser;
        }  
        if(responseData.yesterday_revenue_data_advertiser){
          yesterdaysAdvertiserRevenueData = responseData.yesterday_revenue_data_advertiser;
        }  
        if(responseData.last7days_revenue_data_advertiser){
          last7daysAdvetiserRevenueData = responseData.last7days_revenue_data_advertiser;
        }  
        if(responseData.last30days_revenue_data_advertiser){
          lst30daysAdvertiserRevenueData = responseData.last30days_revenue_data_advertiser;
        }  

        this.setState({
          todaysRevenue: todaysRevenue,
          yesterdaysRevenue: yesterdaysRevenue,
          last7DaysRevenue: last7DaysRevenue,
          last30DaysRevenue: last30DaysRevenue,
          todaysWebsiteRevenueData: todaysWebsiteRevenueData,
          yesterdaysWebsiteRevenueData: yesterdaysWebsiteRevenueData,
          last7daysWebsiteRevenueData: last7daysWebsiteRevenueData,
          lst30daysWebsiteRevenueData: lst30daysWebsiteRevenueData,
          todaysAdvertiserRevenueData: todaysAdvertiserRevenueData,
          yesterdaysAdvertiserRevenueData: yesterdaysAdvertiserRevenueData,
          last7daysAdvetiserRevenueData: last7daysAdvetiserRevenueData,
          lst30daysAdvertiserRevenueData: lst30daysAdvertiserRevenueData,
        });
      }).catch(function (error) {
        console.log(error);

      });
    

  }
  render() {
    const classes = this.props.classes;
    return (
      <div>
        <GridContainer>
          <GridItem xs={12} sm={6} md={6} lg={3}>
            <Card>
              <CardHeader color="warning" stats icon>
                <CardIcon color="warning">
                  <Icon>content_copy</Icon>
                </CardIcon>
                <p className={classes.cardCategory}></p>
                <h3 className={classes.cardTitle}>
                  {this.state.todaysRevenue}
              </h3>
              </CardHeader>
              <CardFooter stats>
                <div className={classes.stats}>
                  <DateRange />
                  <a href="#pablo" onClick={e => e.preventDefault()}>
                    Today
                </a>
                </div>
              </CardFooter>
            </Card>
          </GridItem>
          <GridItem xs={12} sm={6} md={6} lg={3}>
            <Card>
              <CardHeader color="success" stats icon>
                <CardIcon color="success">
                  <Store />
                </CardIcon>
                <p className={classes.cardCategory}></p>
                <h3 className={classes.cardTitle}>{this.state.yesterdaysRevenue}</h3>
              </CardHeader>
              <CardFooter stats>
                <div className={classes.stats}>
                  <DateRange />
                Yesterday
              </div>
              </CardFooter>
            </Card>
          </GridItem>
          <GridItem xs={12} sm={6} md={6} lg={3}>
            <Card>
              <CardHeader color="danger" stats icon>
                <CardIcon color="danger">
                  <Icon>info_outline</Icon>
                </CardIcon>
                <p className={classes.cardCategory}></p>
                <h3 className={classes.cardTitle}>{this.state.last7DaysRevenue}</h3>
              </CardHeader>
              <CardFooter stats>
                <div className={classes.stats}>
                  <DateRange />
                Last 7 Days
              </div>
              </CardFooter>
            </Card>
          </GridItem>
          <GridItem xs={12} sm={6} md={6} lg={3}>
            <Card>
              <CardHeader color="info" stats icon>
                <CardIcon color="info">
                  <i className="fab fa-twitter" />
                </CardIcon>
                <p className={classes.cardCategory}></p>
                <h3 className={classes.cardTitle}>{this.state.last30DaysRevenue}</h3>
              </CardHeader>
              <CardFooter stats>
                <div className={classes.stats}>
                  <DateRange />
                Last 30 days
              </div>
              </CardFooter>
            </Card>
          </GridItem>
        </GridContainer>
        <GridContainer>
          <GridItem xs={12} sm={12} md={12}>
            <CustomTabs
              title="Duration :"
              headerColor="info"
              tabs={[
                {
                  tabName: "Today",
                  tabIcon: BugReport,
                  tabContent: (
                    <Table tableHead={this.state.websiteRevenueHeaders} tableData={this.state.todaysWebsiteRevenueData} />
                  )
                },
                {
                  tabName: "Yesterday",
                  tabIcon: Code,
                  tabContent: (
                    <Table tableHead={this.state.websiteRevenueHeaders} tableData={this.state.yesterdaysWebsiteRevenueData} />
                  )
                },
                {
                  tabName: "Last Week",
                  tabIcon: Cloud,
                  tabContent: (
                    <Table tableHead={this.state.websiteRevenueHeaders} tableData={this.state.last7daysWebsiteRevenueData} />
                  )
                },
                {
                  tabName: "Last 30 Days",
                  tabIcon: Cloud,
                  tabContent: (
                    <Table tableHead={this.state.websiteRevenueHeaders} tableData={this.state.lst30daysAdvertiserRevenueData} />
                  )
                }
              ]}
            />
          </GridItem>
        </GridContainer>

        <GridContainer>
          <GridItem xs={12} sm={12} md={12}>
            <CustomTabs
              title="Duration :"
              headerColor="info"
              tabs={[
                {
                  tabName: "Today",
                  tabIcon: BugReport,
                  tabContent: (
                    <Table tableHead={this.state.AdvertiserRevenueHeaders} tableData={this.state.todaysAdvertiserRevenueData} />
                  )
                },
                {
                  tabName: "Yesterday",
                  tabIcon: Code,
                  tabContent: (
                    <Table tableHead={this.state.AdvertiserRevenueHeaders} tableData={this.state.yesterdaysAdvertiserRevenueData} />
                  )
                },
                {
                  tabName: "Last Week",
                  tabIcon: Cloud,
                  tabContent: (
                    <Table tableHead={this.state.AdvertiserRevenueHeaders} tableData={this.state.last7daysAdvetiserRevenueData} />
                  )
                },
                {
                  tabName: "Last 30 Days",
                  tabIcon: Cloud,
                  tabContent: (
                    <Table tableHead={this.state.AdvertiserRevenueHeaders} tableData={this.state.lst30daysAdvertiserRevenueData} />
                  )
                }
              ]}
            />
          </GridItem>
        </GridContainer>
        <GridContainer>
          <GridItem xs={12} sm={12} md={6} >
          <Card>
            <CardHeader>
            <CardIcon >
              <GridContainer>
              <GridItem xs={6} sm={6} md={6} lg={6}>
               <h3 style={{fontSize:"18px",fontWeight:"400",color:"#4e4b4b"}}>Advertisers</h3> 
              </GridItem>
              <GridItem xs={6} sm={6} md={6} lg={6} style={{textAlign: 'right',display:"inline-flex"}}>
              <FormControl fullWidth className={classes.selectFormControl} style={{marginTop:"-10px"}}>
              <InputLabel style={{fontSize:"14px",color:"#4e4b4b",fontWeight:"400"}}
                    htmlFor="simple-select"
                    className={classes.selectLabel}
                  >
                Select 
                  </InputLabel>
           <Select 
             MenuProps={{
               className: classes.selectMenu
             }}
             classes={{
               select: classes.select
             }}
            
           >
             <MenuItem style={{fontSize:"14px"}}
              
               classes={{
                root: classes.selectMenuItem,
                selected: classes.selectMenuItemSelected
               }}
                value="Last 7 Days"
             >
              Last 7 Days
             </MenuItem>
             <MenuItem style={{fontSize:"14px"}}
               classes={{
                 root: classes.selectMenuItem,
                 selected: classes.selectMenuItemSelected
               }}
               value="This Month"
             >
              This Month
             </MenuItem>
             <MenuItem style={{fontSize:"14px"}}
               classes={{
                 root: classes.selectMenuItem,
                 selected: classes.selectMenuItemSelected
               }}
               value="Last Month"
             >
               Last Month
             </MenuItem>
             <MenuItem style={{fontSize:"14px"}}
               classes={{
                 root: classes.selectMenuItem,
                 selected: classes.selectMenuItemSelected
               }}
               value="Custom Date"
             >
              Custom Date
             </MenuItem>
           </Select>
         </FormControl>
          <Button href="#" className={classes.title} color="transparent" style={{textAlign: 'right',paddingTop:"20px",paddingRight:"10px"}}>
          <Icon >more_vert</Icon>
          </Button>
       
        <Hidden mdUp implementation="css">
          <Button
            className={classes.appResponsive}
            color="transparent"
            justIcon
            aria-label="open drawer"
          >
            <Menu />
          </Button>
        </Hidden>
              </GridItem>
           </GridContainer>
           
                </CardIcon> 
            </CardHeader>
            
              <GridContainer>
                <GridItem xs={12} md={12} lg={12}>
                <table width={"100%"} cellPadding={"10"} cellSpacing={"0"}>
                  <thead>
                    <th width={"30%"}  className={classes.thead}>Name</th>
                    
                    <th  className={classes.thead}>Revenue</th> 
                    <th  className={classes.thead}>Impressions</th>
                    <th  className={classes.thead}>eCPM</th>
                  </thead>
                <tbody>
                  <tr>
                    <td className={classes.borderfirstcol }>Advertiser1</td>
                    <td className={classes.backgroundcolortr}>$9.44</td>
                    <td className={classes.backgroundcolorfourthhigh}>58.4K</td>
                    <td className={classes.backgroundcolorfourthhigh}>$0.16</td>
                  </tr>
                  <tr>
                    <td className={classes.borderfirstcol }>Advertiser2</td>
                    <td className={classes.backgroundcolorSecondhigh}>$4.60</td>
                    <td className={classes.backgroundcolorhigh}>7.15K</td>
                    <td className={classes.textright}>$0.06</td>
                  </tr>
                  <tr>
                    <td className={classes.borderfirstcol }>Advertiser3</td>
                    <td className={classes.backgroundcolorthirdhigh}>$1.32</td>
                    <td className={classes.textright}>7.84K</td>
                    <td className={classes.backgroundcolorhigh}>$0.17</td>
                  </tr>
                  <tr>
                    <td className={classes.borderfirstcol }>Advertiser4</td>
                    <td className={classes.backgroundcolorthirdhigh}>$0.74</td>
                    <td className={classes.textright}>5.86K</td>
                    <td className={classes.backgroundcolorfourthhigh}>$0.13</td>
                  </tr>
                  <tr>
                    <td className={classes.borderfirstcol }>Advertiser5</td>
                    <td className={classes.backgroundcolorthirdhigh}>$0.59</td>
                    <td className={classes.textright}>11.5K</td>
                    <td className={classes.textright}>$0.05</td>
                  </tr> 
                </tbody>
                </table>
            
                </GridItem>
              </GridContainer>
            <CardFooter>
            <a onClick={()=>this.viewAdvertiserReport()} style={{color:"#0b4abdf7",fontWeight:"400",cursor:"pointer"}}>View report</a>
            </CardFooter>
          </Card>
          </GridItem>
          <GridItem xs={12} sm={12} md={6} >
          <Card>
            <CardHeader>
            <CardIcon >
              <GridContainer>
              <GridItem xs={6} sm={6} md={6} lg={6}>
               <h3 style={{fontSize:"18px",fontWeight:"400",color:"#4e4b4b"}}>Publishers</h3> 
              </GridItem>
              <GridItem xs={6} sm={6} md={6} lg={6} style={{textAlign: 'right',display:"inline-flex"}}>
              <FormControl fullWidth className={classes.selectFormControl} >
              <InputLabel style={{fontSize:"14px",color:"#4e4b4b",fontWeight:"400"}}
                    htmlFor="simple-select"
                    className={classes.selectLabel}
                  >
                Select 
                  </InputLabel>
           <Select 
             MenuProps={{
               className: classes.selectMenu
             }}
             classes={{
               select: classes.select
             }}
            
           >
             <MenuItem style={{fontSize:"14px"}}
              
               classes={{
                root: classes.selectMenuItem,
                selected: classes.selectMenuItemSelected
               }}
                value="Last 7 Days"
             >
              Last 7 Days
             </MenuItem>
             <MenuItem style={{fontSize:"14px"}}
               classes={{
                 root: classes.selectMenuItem,
                 selected: classes.selectMenuItemSelected
               }}
               value="This Month"
             >
              This Month
             </MenuItem>
             <MenuItem style={{fontSize:"14px"}}
               classes={{
                 root: classes.selectMenuItem,
                 selected: classes.selectMenuItemSelected
               }}
               value="Last Month"
             >
               Last Month
             </MenuItem>
             <MenuItem style={{fontSize:"14px"}}
               classes={{
                 root: classes.selectMenuItem,
                 selected: classes.selectMenuItemSelected
               }}
               value="Custom Date"
             >
              Custom Date
             </MenuItem>
           </Select>
         </FormControl>
          <Button href="#" className={classes.title} color="transparent" style={{textAlign: 'right',paddingTop:"20px",paddingRight:"10px"}}>
          <Icon >more_vert</Icon>
          </Button>
       
        <Hidden mdUp implementation="css">
          <Button
            className={classes.appResponsive}
            color="transparent"
            justIcon
            aria-label="open drawer"
          >
            <Menu />
          </Button>
        </Hidden>
              </GridItem>
           </GridContainer>
           
                </CardIcon> 
            </CardHeader>
            
              <GridContainer>
                <GridItem xs={12} md={12} lg={12}>
                <table width={"100%"} cellPadding={"10"} cellSpacing={"0"}>
                  <thead>
                    <th width={"30%"}  className={classes.thead}>Name</th>
                    
                    <th  className={classes.thead}>Revenue</th> 
                    <th  className={classes.thead}>Impressions</th>
                    <th  className={classes.thead}>eCPM</th>
                  </thead>
                <tbody>
                  <tr>
                    <td className={classes.borderfirstcol }>Publisher1</td>
                    <td className={classes.backgroundcolortr}>$9.44</td>
                    <td className={classes.backgroundcolorfourthhigh}>58.4K</td>
                    <td className={classes.backgroundcolorfourthhigh}>$0.16</td>
                  </tr>
                  <tr>
                    <td className={classes.borderfirstcol }>Publisher2</td>
                    <td className={classes.backgroundcolorSecondhigh}>$4.60</td>
                    <td className={classes.backgroundcolorhigh}>7.15K</td>
                    <td className={classes.textright}>$0.06</td>
                  </tr>
                  <tr>
                    <td className={classes.borderfirstcol }>Publisher3</td>
                    <td className={classes.backgroundcolorthirdhigh}>$1.32</td>
                    <td className={classes.textright}>7.84K</td>
                    <td className={classes.backgroundcolorhigh}>$0.17</td>
                  </tr>
                  <tr>
                    <td className={classes.borderfirstcol }>Publisher4</td>
                    <td className={classes.backgroundcolorthirdhigh}>$0.74</td>
                    <td className={classes.textright}>5.86K</td>
                    <td className={classes.backgroundcolorfourthhigh}>$0.13</td>
                  </tr>
                  <tr>
                    <td className={classes.borderfirstcol }>Publisher5</td>
                    <td className={classes.backgroundcolorthirdhigh}>$0.59</td>
                    <td className={classes.textright}>11.5K</td>
                    <td className={classes.textright}>$0.05</td>
                  </tr>
                </tbody>
                </table>
            
                </GridItem>
              </GridContainer>
            <CardFooter>
            <a onClick={()=>this.viewPublisherReport()} style={{color:"#0b4abdf7",fontWeight:"400",cursor:"pointer"}}>View report</a>
            </CardFooter>
          </Card>
          </GridItem>
          </GridContainer>
      </div>
    );
  }
}

const AdminDashboardHOC = withStyles(styles)(AdminDashboard);
export default connect(mapStateToProps, mapDispatchToProps)(AdminDashboardHOC);
