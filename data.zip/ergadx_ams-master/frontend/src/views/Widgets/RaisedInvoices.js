import React, { Component } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Store from "@material-ui/icons/Store";
// import InfoOutline from "@material-ui/icons/InfoOutline";
import Warning from "@material-ui/icons/Warning";
import DateRange from "@material-ui/icons/DateRange";
import LocalOffer from "@material-ui/icons/LocalOffer";
import Update from "@material-ui/icons/Update";
import Language from "@material-ui/icons/Language";

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Table from "components/Table/Table.js";
import Newtable from "components/Table/Newtable.js";
import dropdown from "components/CustomDropdown/CustomDropdown.js";
import Danger from "components/Typography/Danger.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";

import CardFooter from "components/Card/CardFooter.js";
import { withStyles } from '@material-ui/styles';

import { SERVER_URL } from "../../variables/constants";

import CustomTabs from "components/CustomTabs/CustomTabs.js";
import Tasks from "components/Tasks/Tasks.js";

import BugReport from "@material-ui/icons/BugReport";
import Code from "@material-ui/icons/Code";
import Cloud from "@material-ui/icons/Cloud";
import axios from 'axios';

// @material-ui/core components

import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import FormControl from "@material-ui/core/FormControl";
// material-ui icons
import Menu from "@material-ui/icons/Menu";
import Globe from "@material-ui/icons/Public";
import Bankicon from "@material-ui/icons/AccountBalance";
import Addpersonicon from "@material-ui/icons/PersonAdd";
import Profileicon from "@material-ui/icons/Person"
import MButton from '@material-ui/core/Button';
import ImageUpload from "components/CustomUpload/ImageUpload.js";
// core components

import { cardHeader } from "assets/jss/material-dashboard-pro-react";
import { ArrowDropDown } from "@material-ui/icons";
import { card } from "assets/jss/material-dashboard-pro-react";
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import Checkbox from '@material-ui/core/Checkbox';
import FormLabel from '@material-ui/core/FormLabel';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import InputAdornment from '@material-ui/core/InputAdornment';
import Add from '@material-ui/icons/Add';
import Dialog from '@material-ui/core/Dialog';
import ListItemText from '@material-ui/core/ListItemText';
import ListItem from '@material-ui/core/ListItem';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';

import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import AddInvoice from '@material-ui/icons/AddToQueue';
import Slide from '@material-ui/core/Slide';
import ReactTable from "react-table";
import { dataTable } from "variables/Invoicetable.js";
//import { dataTable } from "variables/paymentreportdatatable.js";
import Attachmentsicon from "@material-ui/icons/AttachFile";
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
import styles from "assets/jss/material-dashboard-pro-react/views/InvoiceStyle.js";
import data from "views/DataFile/HeaderData";
import { EditorLinearScale } from 'material-ui/svg-icons';

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="left" ref={ref} {...props} />;
});
const useStyles = makeStyles(styles);
// const InoviseRaisedData = data.RaisedInvoices;
export class RaisedInvoices extends Component {
  state = {
    AttachInvoice: false,
    InvoiceDetails: [],
    month: [],
    Reciefile: '',
    invoiceId: '',
    invoiceNumber: '',
    date:new Date(),
    viewImage:'',
    setCreateContactopen: false,
    types:'',
  }
  componentDidMount() {
    const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
  console.log(this.state.date)
    axios.defaults.headers.common['Authorization'] = TOKEN
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/invoicedetails/user/${USER_ID}`).then(response => response.data)
      .then((data) => {
        var array = [];
        const monthNames = ["January", "February", "March", "April", "May", "June",
          "July", "August", "September", "October", "November", "December"
        ];
        console.log(data);
        for (let i = 0; i < data.length; i++) {
          array.push((new Date(data[i].startDate)).getMonth() );
        }
        var monthArray = [];
        for (let i = 0; i < array.length; i++) {
          monthArray.push(monthNames[array[i]]);

        }
        this.setState({ month: monthArray });
        console.log(this.state.month)
        this.setState({ InvoiceDetails: data });
      }).catch((error) => {
        console.error(error);
      });


  }
  AttachInvoicehandleClickOpen = (id) => {
    console.log(id);
    this.setState({ invoiceId: id });

    this.setState({ AttachInvoice: true });

  };
  AttachInvoicehandleClose = () => {
    this.setState({ AttachInvoice: false });
  };

  handleInvoiceUpload = (pFile) => {
    console.log(pFile);
    this.setState({ Reciefile: pFile });


  }
  updateInvoiceDetail = (value) => {
    this.setState({ invoiceNumber: value })
  }
  submitAttachment = () => {
    const formData = new FormData();
    formData.append('file', this.state.Reciefile);
    const USER_ID = this.props.data.id;
    const Invoice_ID = this.state.invoiceId;
    const Invoice_Number = this.state.invoiceNumber;
    formData.append('invoiceNumber', Invoice_Number);
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.post(`${SERVER_URL}/api/invoice/pdf/${Invoice_ID}`, formData).then(response => response.data)
      .then((data) => {
        console.log(data);
        alert(" Invoice submitted ")
        this.AttachInvoicehandleClose();

      }).catch((error) => {
        console.error(error);
        alert("Please Fill all the Field")
      });
    console.log(this.state.InvoiceDetails[0].attachedFileName);

  }
 

  ViewFile=(id)=>{
    var URL=SERVER_URL+"/api/invoice/"+this.props.data.id+"/view/"+id;
    axios({
      url: URL,
      method: 'GET',
      responseType: 'blob', 
      
  }).then((response) => {
      const url = window.URL.createObjectURL(new Blob([response.data]));
      var type=response.data.type;
      this.setState({types:type})
      console.log(this.state.types)
      window.open(url);
          this.setState({viewImage:url})
          
      
  
      //link.click();
  });
  }

  CreateContacthandleClickOpen = () => {
    this.setState({ setCreateContactopen: true });
  };
 
  CreateContacthandleClose = () => {
    this.setState({ setCreateContactopen: false });
  };


  _renderDetails = () => {

    const classes = this.props.classes;
    return this.state.InvoiceDetails.map((item, index) => (
      <Card>
        <CardBody className={classes.RaisedInvoiceCardbody}>
          <GridContainer>
            <GridItem xs={12} md={2} lg={2}>
              <a className={classes.CardHeading} >
                <h4 className={classes.CardHeading}>Month</h4>
                <h4 className={classes.SmallText}>{this.state.month[index]}</h4>
              </a>

            </GridItem>
            <GridItem xs={12} md={2} lg={2}>
              <a className={classes.CardHeading} >
                <h4 className={classes.CardHeading}>Impression</h4>
                <h4 className={classes.SmallText}>{item.impression}</h4>
              </a>

            </GridItem>
            <GridItem xs={12} md={2} lg={2}>
              <a className={classes.CardHeading} >
                <h4 className={classes.CardHeading}>Net Amount</h4>
                <h4 className={classes.SmallText}>{item.netAmount}</h4>
              </a>

            </GridItem>
            <GridItem xs={12} md={2} lg={2}>
              <a className={classes.CardHeading} >
                <h4 className={classes.CardHeading}>GST</h4>
                <h4 className={classes.SmallText}>{item.tax}</h4>
              </a>
            </GridItem>

            <GridItem xs={12} md={2} lg={2}>
              <a className={classes.CardHeading} >
                <h4 className={classes.CardHeading}>Gross Amount</h4>
                <h4 className={classes.SmallText}>{item.amount}</h4>
              </a>
            </GridItem>
            {this.state.InvoiceDetails[index].attachedFileName === null &&
              <GridItem xs={12} md={2} lg={2}>
                <MButton color="secondary" variant="outlined" style={{ float: "right", marginTop: "5px" }} onClick={() => this.AttachInvoicehandleClickOpen(item.id)}  >
                  Attach Invoice
              </MButton>
              </GridItem>}

            {this.state.InvoiceDetails[index].attachedFileName !== null &&
              <GridItem xs={12} md={2} lg={2}>
               
                 <MButton color="secondary" variant="outlined" style={{ float: "right", marginTop: "18px" }}> 
                 

                    <a style={{ color: "#f50057" }} href={SERVER_URL+"/api/invoice/"+this.props.data.id+"/view/"+item.id} target="_blank">View</a> 
                </MButton>

              </GridItem>}

          </GridContainer>
        </CardBody>
      </Card>
    ))
  };

  render() {

    const classes = this.props.classes;
    return (

      <div className={classes.root}>

        {this._renderDetails()}
        {/*  {InoviseRaisedData.map((item)=>(
        <GridItem xs={12} md={2} lg={2}>
            <a className={classes.CardHeading} >
                     <h4 className={classes.CardHeading}>{item.Value}</h4> 
                     <h4 className={classes.SmallText}>{item.Head}</h4>
                    </a>
         </GridItem>
         ))} */}
        {/*   <GridItem xs={12} md={2} lg={2}>
         <MButton color="secondary" variant="outlined" style={{float:"right",marginTop:"5px"}} onClick={this.AttachInvoicehandleClickOpen}  >
                    Attach Invoice
        </MButton> 
         </GridItem> */}

        <Dialog fullScreen open={this.state.AttachInvoice} onClose={this.AttachInvoicehandleClose} TransitionComponent={Transition} className={classes.rootslider} >
          <AppBar className={classes.CustomappBar}>
            <Toolbar>
              <IconButton edge="start" color="inherit" onClick={this.AttachInvoicehandleClose} aria-label="close" className={classes.CloseButton}>
                <LeftAorrow />
              </IconButton>
              <h4 className={classes.SliderTitle}>
                New Invoice
                        </h4>

            </Toolbar>
          </AppBar>
          <GridContainer>
            <GridItem></GridItem>
            <GridItem lg={10}>
            </GridItem>
          </GridContainer>
          <GridContainer style={{ paddingTop: "3%" }}>
            <GridItem lg={2} md={2}></GridItem>
            <GridItem lg={5} md={5}>
              <Card style={{ height: "315px" }}>
                <CardHeader color="primary" icon>
                  <CardIcon color="primary">
                    <AddInvoice style={{ color: "white" }} />
                  </CardIcon>
                  <h4 className={classes.heading} style={{ marginTop: "10px!important" }}>New Invoices</h4>
                </CardHeader>
                <CardBody>
                  <GridContainer style={{ paddingTop: "30px" }}>
                    <GridItem lg={1} md={1} className={classes.textfieldsgrid}></GridItem>
                    <GridItem lg={5} xs={6} md={5} className={classes.textfieldsgrid}>
                      <TextField className={classes.textfields} type="date" id="date" defaultValue={this.state.date}
                        InputLabelProps={{ shrink: true, }} label="Invoice Date" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }} />
                    </GridItem>
                    <GridItem lg={5} xs={6} md={5} className={classes.textfieldsgrid}>
                      <TextField className={classes.textfields} label="Number" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }}
                        onChange={(event) => { this.updateInvoiceDetail(event.target.value) }} />
                    </GridItem>
                    <GridItem lg={1} md={1} className={classes.textfieldsgrid}></GridItem>
                  </GridContainer>
                </CardBody>
                <CardFooter>
                  <GridContainer >
                    <GridItem xs={12} md={12} lg={12} className={classes.textfieldsgrid}>
                      <div className={classes.root2} >

                        <MButton variant="outlined" className={classes.submitbutton} onClick={this.submitAttachment}  >
                          Submit
                    </MButton>

                      </div>
                    </GridItem>
                  </GridContainer>
                </CardFooter>
              </Card>
            </GridItem>
            <GridItem lg={3} md={3}>
              <Card>
                <CardHeader color="primary" icon>
                  <CardIcon color="primary">
                    <Attachmentsicon style={{ color: "white" }} />
                  </CardIcon>
                  <h4 className={classes.heading} style={{ marginTop: "10px!important" }}>Attachment</h4>
                </CardHeader>
                <CardBody>
                  <GridItem xs={12} sm={12} md={12}>

                    <ImageUpload
                      addButtonProps={{
                        color: "rose",
                        round: true
                      }}
                      changeButtonProps={{
                        color: "rose",
                        round: true
                      }}
                      removeButtonProps={{
                        color: "danger",
                        round: true
                      }}

                      onImageUpload={this.handleInvoiceUpload}

                    />
                  </GridItem>
                </CardBody>
              </Card>
            </GridItem>
            <GridItem lg={2} md={2}></GridItem>
          </GridContainer>
        </Dialog>
      </div>
    );
  }
}
const RaisedInvoicesHOC = withStyles(styles)(RaisedInvoices);
export default connect(mapStateToProps, mapDispatchToProps)(RaisedInvoicesHOC);
