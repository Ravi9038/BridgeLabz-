
// react component for creating dynamic tables
import React, { Component } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";

import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
// @material-ui/core components
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
// material-ui icons
import MButton from '@material-ui/core/Button';
import ImageUpload from "components/CustomUpload/ImageUpload.js";
// core components
import Dialog from '@material-ui/core/Dialog';
import IconButton from '@material-ui/core/IconButton';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import AddInvoice from '@material-ui/icons/AddToQueue';
import Slide from '@material-ui/core/Slide';
import ReactTable from "react-table";
import { dataTable } from "variables/Invoicetable.js";
//import { dataTable } from "variables/paymentreportdatatable.js";
import Paymenticon from "@material-ui/icons/Money";
import Invoiceicon from "@material-ui/icons/Receipt";
import Attachmentsicon from "@material-ui/icons/AttachFile";
import styles from "assets/jss/material-dashboard-pro-react/views/InvoiceStyle.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
import { connect } from 'react-redux';
import { withStyles } from "@material-ui/core/styles";
const useStyles = makeStyles(styles);
const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="left" ref={ref} {...props} />;
  });
export class ReceivedAmountDialog extends Component {
state = {
    OpenReceivedAmount:false,
    data: dataTable.dataRows.map((prop, key) => {
        return {
            id: key,
            SNo: prop[0],
            InvoiceName: prop[1],
            InvoiceDate: prop[2],
            NetAmount: prop[3],
            Tax: prop[4],
            TotalAmount: prop[5],
            Status: prop[6]
    
          };
      })
}
ReceviedAmounthandleClickOpen = () => {
    this.setState({OpenReceivedAmount:true});
  };
ReceviedAmounthandleClose = () => {
    this.setState({OpenReceivedAmount:false}); 
  };
    render(){
        const classes = this.props.classes;
        return ( 
        <div className={classes.root}>
         <Card>
                 <CardBody>
                 <a  className={classes.CardHeading} variant="outlined" color="primary" onClick={this.ReceviedAmounthandleClickOpen} >
                 <h4 className={classes.CardHeading}>Received Amount .</h4>
                     <h4 className={classes.CardHeading}>0</h4>
                </a>
                <Dialog fullScreen open={this.state.OpenReceivedAmount} onClose={this.ReceviedAmounthandleClose} TransitionComponent={Transition} className={classes.rootslider}>
                    <AppBar className={classes.CustomappBar}>
                    <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={this.ReceviedAmounthandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                        Received Amount
                        </h4>
                    
                    </Toolbar>
                    </AppBar>
        <GridContainer style={{paddingTop:"3%"}} className={classes.SliderBackground}>
            <GridItem lg={1} md={1}></GridItem>
            <GridItem lg={10} md={10}>
            <Card>
          <CardHeader color="primary" icon>
          <CardIcon color="primary">
         <Paymenticon style={{color:"white"}} />
         
         </CardIcon>
            <h4 className={classes.heading} style={{marginTop:"10px!important"}} >Received Amount</h4>
          </CardHeader>
          <CardBody>
         
          <ReactTable
              data={this.data}
              filterable
              columns={[
               
                {
                  Header: "Date",
                  accessor: "Date",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Date"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                 
                },
                {
                  Header: "Amount",
                  accessor: "Amount",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Amount"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                 

                },
                {
                  Header: "TransactionID",
                  accessor: "TransactionID",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Transaction ID"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                

                }
                
              ]}
              defaultPageSize={5}
              showPaginationTop 
              showPaginationBottom={false}
              className="-highlight"
            />
          </CardBody>
          
        </Card>
            </GridItem>
            <GridItem lg={1} md={1}></GridItem>
        </GridContainer>
      </Dialog>
                 </CardBody>
             </Card>
    </div>
    );
}
}
const ReceivedAmountDialogHOC = withStyles(styles)(ReceivedAmountDialog);
export default connect(mapStateToProps, mapDispatchToProps)(ReceivedAmountDialogHOC);
 