
// react component for creating dynamic tables
import React, { Component } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import axios from 'axios';
import { SERVER_URL } from "../../variables/constants";

import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
// @material-ui/core components
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
// material-ui icons
import MButton from '@material-ui/core/Button';
import ImageUpload from "components/CustomUpload/ImageUpload.js";
// core components
import Dialog from '@material-ui/core/Dialog';
import IconButton from '@material-ui/core/IconButton';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import AddInvoice from '@material-ui/icons/AddToQueue';
import Slide from '@material-ui/core/Slide';
import ReactTable from "react-table";
import { dataTable } from "variables/Invoicetable.js";
//import { dataTable } from "variables/paymentreportdatatable.js";
import Paymenticon from "@material-ui/icons/Money";
import Invoiceicon from "@material-ui/icons/Receipt";
import Attachmentsicon from "@material-ui/icons/AttachFile";
import styles from "assets/jss/material-dashboard-pro-react/views/InvoiceStyle.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
import { connect } from 'react-redux';
import { withStyles } from "@material-ui/core/styles";
const useStyles = makeStyles(styles);
const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="left" ref={ref} {...props} />;
  });
export class TotalAmountDialog extends Component {
state = {
    OpenTotalAmount:false,
     totalAmount:0,
    data: dataTable.dataRows.map((prop, key) => {
        return {
            id: key,
            SNo: prop[0],
            InvoiceName: prop[1],
            InvoiceDate: prop[2],
            NetAmount: prop[3],
            Tax: prop[4],
            TotalAmount: prop[5],
            Status: prop[6]
    
          };
      })
}
componentDidMount() {   
   const USER_ID = this.props.data.id;
  //const USER_ID=2;
  const TOKEN = 'Bearer '.concat(this.props.data.token);

  axios.defaults.headers.common['Authorization'] = TOKEN
  axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
  if(USER_ID !==1){
  axios.get(`${SERVER_URL}/api/invoicedetails/user/${USER_ID}`).then(response => response.data)
    .then((data) => {
      console.log(data);
      let total=0;
      for(let i=0;i<data.length;i++){
        total+=data[i].amount;
      }
    
     const lTotal=Math.ceil(total);
      this.setState({totalAmount:lTotal});
      this.setState({ data: data });
     
    }).catch((error) => {
      console.error(error);
    });
  }

  else if(USER_ID ===1){
    axios.get(`${SERVER_URL}/api/invoicedetails/`).then(response => response.data)
    .then((data) => {
      console.log(data);
      let total=0;
      for(let i=0;i<data.length;i++){
        total+=data[i].amount;
      }
    
     const lTotal=Math.ceil(total);
      this.setState({totalAmount:lTotal});
      this.setState({ data: data });
     
    }).catch((error) => {
      console.error(error);
    });
  }

  }
TotalAmounthandleClickOpen = () => {
    this.setState({OpenTotalAmount:true});
  };
TotalAmounthandleClose = () => {
    this.setState({OpenTotalAmount:false}); 
  };
    render(){
        const classes = this.props.classes;
        return ( 
        <div className={classes.root}>
          <Card>
          <CardBody>
                    <a className={classes.CardHeading} variant="outlined" color="primary" onClick={this.TotalAmounthandleClickOpen} > 
                    <h4 className={classes.CardHeading}>Total Amount.</h4>
        <h4 className={classes.CardHeading}>{this.state.totalAmount}</h4>
                     </a>
                     <Dialog fullScreen open={this.state.OpenTotalAmount} onClose={this.TotalAmounthandleClose} TransitionComponent={Transition} className={classes.rootslider}>
                    <AppBar className={classes.CustomappBar}>
                    <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={this.TotalAmounthandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                        Total Amount $
                        </h4>
                    
                    </Toolbar>
                    </AppBar>
        <GridContainer style={{paddingTop:"3%"}} className={classes.SliderBackground}>
            <GridItem lg={1} md={1}></GridItem>
            <GridItem lg={10} md={10}>
            <Card>
          <CardHeader color="primary" icon>
          <CardIcon color="primary">
         <Paymenticon style={{color:"white"}} />
         
         </CardIcon>
            <h4 className={classes.heading} style={{marginTop:"10px!important"}} >Total Amount</h4>
          </CardHeader>
          <CardBody>
         
            <ReactTable
              data={this.state.data}
              filterable
              columns={[
               
                {
                  Header: "S No",
                  accessor: "id",
                },
                {
                  Header: "Invoice Name",
                  accessor: "companyName",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Invoice Name"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                },
                {
                    Header: "Invoice Date",
                    accessor: "startDate",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Invoice Date"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                  },
                  {
                    Header: "Net Amount (Rs.)",
                    accessor: "netAmount",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Net Amount"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                  },
                  {
                    Header: "Tax (Rs.)",
                    accessor: "tax",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Tax"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                  },
                  {
                    Header: "Total Amount(Rs.)",
                    accessor: "amount",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Total Amount"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                {
                  Header: "Status",
                  accessor: "status",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Status"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                

                }
                
              ]}
              defaultPageSize={5}
              showPaginationTop 
              showPaginationBottom={false}
              className="-highlight"
            />
          </CardBody>
          
        </Card>
            </GridItem>
            <GridItem lg={1} md={1}></GridItem>
        </GridContainer>
      </Dialog>
            </CardBody>
             </Card>
    </div>
    );
}
}
const TotalAmountDialogHOC = withStyles(styles)(TotalAmountDialog);
export default connect(mapStateToProps, mapDispatchToProps)(TotalAmountDialogHOC);
 