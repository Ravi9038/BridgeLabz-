
// react component for creating dynamic tables
import React, { Component } from 'react'
import ReactTable from "react-table";
import { makeStyles } from '@material-ui/styles';
import { withStyles } from "@material-ui/core/styles";
// @material-ui/core components

import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import TextField from '@material-ui/core/TextField';
import InputBase from '@material-ui/core/InputBase';
import Paymenticon from "@material-ui/icons/Payment";
import { dataTable } from "variables/Paymentdatatable.js";

import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";

import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import FormControl from "@material-ui/core/FormControl";
import Dialog from '@material-ui/core/Dialog';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';

import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import AddCurrencyIcon from '@material-ui/icons/AddBox';
import ViewCurrecncy from '@material-ui/icons/Visibility';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import EditSettlementicon from '@material-ui/icons/Edit';
import AddInvoice from '@material-ui/icons/AddToQueue';
import Slide from '@material-ui/core/Slide';
import Tooltip from '@material-ui/core/Tooltip';
// material-ui icons
import Checkbox from '@material-ui/core/Checkbox';
import MButton from '@material-ui/core/Button';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Select from '@material-ui/core/Select';
import NativeSelect from '@material-ui/core/NativeSelect';
import ButtonGroup from '@material-ui/core/ButtonGroup'
import styles from "assets/jss/material-dashboard-pro-react/views/paymentcustomstyle.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
import { connect } from 'react-redux';
import * as moment from 'moment';
import { SERVER_URL } from "../../variables/constants";
import axios from 'axios';
const useStyles = makeStyles(styles);

const LightTooltip = withStyles((theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.white,
    color: 'rgba(0, 0, 0, 0.87)',
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}))(Tooltip);
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="left" ref={ref} {...props} />;
});
export class ViewPaymentDialog extends Component {
  state = {
    setOpen: false,
    setPaidOpen: false,
    invoiceDetails: [],
    unpayedInvoice:[],
    payedInvoice:[],
    filter:'',
  }

  componentDidMount = () => {

    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    axios.get(`${SERVER_URL}/api/invoicedetails`, { headers: { "Authorization": TOKEN } })
      .then(response => response.data)
      .then((data) => {
        console.log(data);
        this.setState({ invoiceDetails: data })
        data.forEach(element => {
          if(element.status ==="DRAFT" || element.status ==="RECEVIED" ){
            this.setState(prevState => ({
              unpayedInvoice: [...prevState.unpayedInvoice, element]
            }))
          }
          if(element.status==="PAID"){
            this.setState(prevState => ({
              payedInvoice: [...prevState.payedInvoice, element]
            }))
          }
        });
      }).catch(error => { console.log(error); })

  }

  handleClickOpen = () => {
    this.setState({ setOpen: true });
  };

  handleClose = () => {
    this.setState({ setOpen: false });
  };
  PaidhandleClickOpen = () => {
    this.setState({ setPaidOpen: true });
  };

  PaidhandleClose = () => {
    this.setState({ setPaidOpen: false });
  };
  setFilter=(value)=>{
this.setState({filter:value})
  }
  renderTable=()=>{
    var data=0;
    if(this.state.filter==="PAID"){
      data=this.state.payedInvoice;
    }
    else if(this.state.filter==="UNPAID"){
      data=this.state.unpayedInvoice;
    }
   
    else{
     data=this.state.invoiceDetails;
    }
    const classes = this.props.classes;
    return <CardBody className={classes.root}>
    <ReactTable
      data={data}
      filterable
      columns={[
        {
          Header: <FormControlLabel className={classes.ActionsButton}
            label="Select"
            labelPlacement="top"
            control={<Checkbox name="selectAll" />}

          />,
          accessor: "Select",
          Cell: id => (
            <div className={classes.ActionsButton}>
              <Checkbox
                size="small"
                inputProps={{ 'aria-label': 'Select' }}
              />
            </div>
          ),
          sortable: false,
          filterable: false
        },
        {
          Header: "Publisher",
          accessor: "companyName",
          Filter: ({ filter, onChange }) => (
            <input type='text' style={{ textAlign: 'center' }}
              placeholder="Search Publisher"
              value={filter ? filter.value : ''}
              onChange={event => onChange(event.target.value)}
            />
          ),


        },

        {
          Header: "Invoice Date",
          accessor: "endDate",
          Filter: ({ filter, onChange }) => (
            <input type='text' style={{ textAlign: 'center' }}
              placeholder="Search Date"
              value={filter ? filter.value : ''}
              onChange={event => onChange(event.target.value)}
            />
          ),


        },
        {
          Header: "InvoiceNumber",
          accessor: "invoiceNumber",
          Filter: ({ filter, onChange }) => (
            <input type='text' style={{ textAlign: 'center' }}
              placeholder="Search Date"
              value={filter ? filter.value : ''}
              onChange={event => onChange(event.target.value)}
            />
          ),


        },
        {
          Header: "Net Amount",
          accessor: "netAmount",
          Filter: ({ filter, onChange }) => (
            <input type='text' style={{ textAlign: 'center' }}
              placeholder="Search Amount"
              value={filter ? filter.value : ''}
              onChange={event => onChange(event.target.value)}
            />
          ),


        },
        {
          Header: "GST",
          accessor: "tax",
          Filter: ({ filter, onChange }) => (
            <input type='text' style={{ textAlign: 'center' }}
              placeholder="Search GST"
              value={filter ? filter.value : ''}
              onChange={event => onChange(event.target.value)}
            />
          ),


        },
        {
          Header: "TDS",
          accessor: "TDS",
          Filter: ({ filter, onChange }) => (
            <input type='text' style={{ textAlign: 'center' }}
              placeholder="Search TDS"
              value={filter ? filter.value : ''}
              onChange={event => onChange(event.target.value)}
            />
          ),


        },
        {
          Header: "Gross Payable",
          accessor: "amount",
          Filter: ({ filter, onChange }) => (
            <input type='text' style={{ textAlign: 'center' }}
              placeholder="Search Gross"
              value={filter ? filter.value : ''}
              onChange={event => onChange(event.target.value)}
            />
          ),


        },
        {
          Header: "Status",
          accessor: "status",
          Cell: id => (
            <div className={classes.StatusButton}>
              { id.original.status === "PAID" &&
                <Button onClick={this.PaidhandleClickOpen}
                  simple
                  color="success"
                >Paid
       </Button>
              }
              <Dialog fullScreen open={this.state.paidopen} onClose={this.PaidhandleClose} TransitionComponent={Transition} className={classes.rootslider}>
                <AppBar className={classes.CustomappBar}>
                  <Toolbar>
                    <IconButton edge="start" color="inherit" onClick={this.PaidhandleClose} aria-label="close" className={classes.CloseButton}>
                      <LeftAorrow />
                    </IconButton>
                    <h4 className={classes.SliderTitle}>
                      Paid Details
          </h4>
                  </Toolbar>
                </AppBar>

                <GridContainer>
                  <GridItem lg={3} md={3} ></GridItem>
                  <GridItem lg={6} md={6} ><Card className={classes.PaidDetailsCard}>
                    <CardBody>
                      <GridContainer>
                        <GridItem lg={12} md={12}>
                          <p>Transaction Type: PMT</p>
                          <p>Total Amount: INR | 13743.0</p>
                          <p>Host Reference Number: 23008078131</p>
                          <p>Transaction Remarks: SISTER2000070 AWS eReleGo</p>
                          <p>Transaction Status: FAI</p>
                          <p>Transaction Status Remarks: <span className={classes.SuccessColor}>Payment Success</span> </p>
                        </GridItem>

                      </GridContainer>

                    </CardBody>

                  </Card></GridItem>
                  <GridItem lg={3} md={3} ></GridItem>
                </GridContainer>

              </Dialog>
              { id.original.status !== "PAID" &&
                <Button
                  simple
                  color="danger"
                >Unpaid
       </Button>
              }
            </div>
          ),
          Filter: ({ filter, onChange }) => (
            <input type='text' style={{ textAlign: 'center' }}
              placeholder="Search Status"
              value={filter ? filter.value : ''}
              onChange={event => onChange(event.target.value)}
            />
          ),

        },
      ]}
      defaultPageSize={5}
      showPaginationTop
      showPaginationBottom={false}
      className="-highlight"
    />
  </CardBody>

  }
  render() {
    const classes = this.props.classes;
    return (
      <div className={classes.root}>
        <button className={classes.CardButton} onClick={this.handleClickOpen}>
          View
        </button>
        <Dialog fullScreen open={this.state.setOpen} onClose={this.handleClose} TransitionComponent={Transition} className={classes.rootslider}>
          <AppBar className={classes.CustomappBar}>
            <Toolbar>
              <IconButton edge="start" color="inherit" onClick={this.handleClose} aria-label="close" className={classes.CloseButton}>
                <LeftAorrow />
              </IconButton>
              <h4 className={classes.SliderTitle}>
                Payments
                        </h4>
            </Toolbar>
          </AppBar>
          <GridContainer style={{ paddingTop: "3%" }} className={classes.SliderBackground}>
            <GridItem lg={1} md={1}></GridItem>
            <GridItem lg={10} md={10}>
              <Card>
                <CardHeader color="primary" icon >
                  <CardIcon color="primary">
                    <Paymenticon style={{ color: "white" }} />

                  </CardIcon>
                  <h4 className={classes.heading} style={{ marginTop: "10px!important" }} >Payments
         <div className={classes.ButtonRightCard} >
                      <span style={{ paddingLeft: "10px" }}><MButton color="primary" variant="outlined" onClick={()=>this.setFilter("ALL")} >
                        All
           </MButton></span>
                      <span style={{ paddingLeft: "10px" }}><MButton color="primary" variant="outlined" onClick={()=>this.setFilter("PAID")}>
                        Paid
           </MButton></span>
                      <span style={{ paddingLeft: "10px" }}> <MButton color="primary" variant="outlined" onClick={()=>this.setFilter("UNPAID")}>
                        Un Paid
           </MButton></span>
                    </div>
                  </h4>
                </CardHeader>
                {this.renderTable()}
                <CardHeader >
                  <strong>Paying Rs:10000</strong>
                  <div className={classes.root2} >
                    <span style={{ paddingLeft: "10px" }}><MButton color="secondary" variant="outlined" >
                      Export
           </MButton></span>
                    <span style={{ paddingLeft: "10px" }}><MButton color="secondary" variant="outlined">
                      Download Payments
           </MButton></span>
                    <span style={{ paddingLeft: "10px" }}> <MButton color="secondary" variant="outlined" >
                      Upload Payments
           </MButton></span>
                  </div>

                </CardHeader>
              </Card>
            </GridItem>
            <GridItem lg={1} md={1}></GridItem>
          </GridContainer>
        </Dialog>
      </div>
    );
  }
}
const ViewPaymentDialogHOC = withStyles(styles)(ViewPaymentDialog);
export default connect(mapStateToProps, mapDispatchToProps)(ViewPaymentDialogHOC);
