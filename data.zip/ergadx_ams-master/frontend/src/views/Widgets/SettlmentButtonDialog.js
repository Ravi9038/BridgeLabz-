
// react component for creating dynamic tables
import React, { Component } from 'react'
import ReactTable from "react-table";
import { makeStyles } from '@material-ui/styles';
import { withStyles } from "@material-ui/core/styles";
// @material-ui/core components

// @material-ui/icons
import Assignment from "@material-ui/icons/Assignment";
import Dvr from "@material-ui/icons/Dvr";
import Favorite from "@material-ui/icons/Favorite";
import Close from "@material-ui/icons/Close";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import TextField from '@material-ui/core/TextField';
import InputBase from '@material-ui/core/InputBase';
import Paymenticon from "@material-ui/icons/Payment";
import { dataTable } from "variables/Paymentdatatable.js";

import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";

import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import FormControl from "@material-ui/core/FormControl";
import Dialog from '@material-ui/core/Dialog';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';

import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import AddCurrencyIcon from '@material-ui/icons/AddBox';
import ViewCurrecncy from '@material-ui/icons/Visibility';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import EditSettlementicon from '@material-ui/icons/Edit';
import AddInvoice from '@material-ui/icons/AddToQueue';
import Slide from '@material-ui/core/Slide';
import Tooltip from '@material-ui/core/Tooltip';
// material-ui icons
import Checkbox from '@material-ui/core/Checkbox';
import MButton from '@material-ui/core/Button';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Select from '@material-ui/core/Select';
import NativeSelect from '@material-ui/core/NativeSelect';
import ButtonGroup from '@material-ui/core/ButtonGroup'
import styles from "assets/jss/material-dashboard-pro-react/views/paymentcustomstyle.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
import { connect } from 'react-redux';
import { SERVER_URL } from "../../variables/constants";
import * as moment from 'moment';
import axios from 'axios';
const useStyles = makeStyles(styles);

const LightTooltip = withStyles((theme) => ({
    tooltip: { 
      backgroundColor: theme.palette.common.white,
      color: 'rgba(0, 0, 0, 0.87)',
      boxShadow: theme.shadows[1],
      fontSize: 11,
    },
  }))(Tooltip);
  const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="left" ref={ref} {...props} />;
  });
export class SettlementDialog extends Component { 
state = {
    setSettelmentSlideropen:false,
    setEditSettelmentOpen:false,
    invoiceDetails:[],
    filterForSettlement:'',
    paidPaymentRecipt:[],
    pendingPaymentRecipt:[],
}
componentDidMount = () => {
       
  const TOKEN = 'Bearer '.concat(this.props.data.token);
  axios.defaults.headers.common['Authorization'] = TOKEN;
  axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
  axios.get(`${SERVER_URL}/api/invoicedetails`,  { headers: { "Authorization": TOKEN } })
    .then(response => response.data)
    .then((data) => {
      console.log(data);
      this.setState({invoiceDetails:data})
      data.forEach(element => {
        if(element.status=="PAID"){
          this.setState(prevState => ({
            paidPaymentRecipt: [...prevState.paidPaymentRecipt, element]
          }))
        }
        if(element.status=="DRAFT" || element.status=="RECIVED"){
          this.setState(prevState => ({
            pendingPaymentRecipt: [...prevState.pendingPaymentRecipt, element]
          }))
        }
      });

    }).catch(error => { console.log(error); })

}

SettelmentSliderhandleClickOpen = () => {
 // alert(123);
    this.setState({setSettelmentSlideropen:true});
  };

SettlementhandleClose = () => {
	  this.setState({setSettelmentSlideropen:false});
};
EditSettlementhandleClickOpen = () => {
    this.setState({setEditSettelmentOpen:true});
  };
 
EditSettlementhandleClose = () => {
    this.setState({setEditSettelmentOpen:false}); 
  };

  setFilter=(value)=>{
    this.setState({filterForSettlement:value})
  }

    render(){
      var data=0;
    if(this.state.filterForSettlement==="Settled"){
      data=this.state.paidPaymentRecipt;
    }
    else if(this.state.filterForSettlement==="Pending"){
      data=this.state.pendingPaymentRecipt;
    }
   
    else{
     data=this.state.invoiceDetails;
    }


        const classes = this.props.classes;
        return ( 
        <div className={classes.root}>
            <div>
            <button className={classes.CardButton} onClick={this.SettelmentSliderhandleClickOpen}>
            Settlement
           </button>
            </div>
          <Dialog fullScreen open={this.state.setSettelmentSlideropen} onClose={this.SettlementhandleClose} TransitionComponent={Transition} className={classes.rootslider}>
          <AppBar className={classes.CustomappBar}>
          <Toolbar>
            <IconButton edge="start" color="inherit" onClick={this.SettlementhandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                        Settlment Details
                        </h4>
                        </Toolbar>
                        </AppBar>
                                    
                       <GridContainer style={{paddingTop:"3%"}} className={classes.SliderBackground}>
                        <GridItem lg={1} md={1} ></GridItem>  
                         <GridItem lg={10} md={10}>
                         <Card>
                        <CardHeader color="primary" icon >
                        <CardIcon color="primary">
                      <Paymenticon style={{color:"white"}} />
                      
                      </CardIcon>
         <h4 className={classes.heading} style={{marginTop:"10px!important"}} > Settlment Details
         <div className={classes.ButtonRightCard} >
          <span style={{paddingLeft:"10px"}}><MButton color="primary" variant="outlined" onClick={()=>this.setFilter("Alll")}>
            All
           </MButton></span>
           <span style={{paddingLeft:"10px"}}><MButton color="primary" variant="outlined" onClick={()=>this.setFilter("Settled")}>
            Settled
           </MButton></span>
           <span style={{paddingLeft:"10px"}}> <MButton  color="primary" variant="outlined" onClick={()=>this.setFilter("Pending")}>
            Pending
           </MButton></span>
          </div>
          </h4>
          </CardHeader>
          <CardBody className={classes.root}>
            <ReactTable
              data={data}
              filterable
              columns={[
                
                  {
                    Header: "Publisher",
                    accessor: "companyName",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Publisher"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                  
  
                    },
                    {
                      Header: "Month/Year",
                      accessor: "startDate",
                      Filter: ({filter, onChange}) => (
                        <input type='text' style={{textAlign:'center'}}
                               placeholder="Search Publisher"
                               value={filter ? filter.value : ''}
                                   onChange={event => onChange(event.target.value)}
                        />
                      ),
                      Cell:id=>(
                        new moment(id.original.startDate).format("MMMM/YYYY")
                       )
    
                      },
               
                {
                  Header: "Gross USD",
                  accessor: "amount",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search USD"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                 

                },
                {
                    Header: "Net USD",
                    accessor: "netAmount",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search USD"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                  {
                    Header: "USD To INR",
                    accessor: "USDtoINR",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search USD"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                  {
                    Header: "Net INR",
                    accessor: "NetINR",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search INR"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                  {
                    Header: "Status",
                    accessor: "status",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Status"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                  {
                    Header: "Action",
                    accessor: "Action",
                    Cell: id => (
                      <div className={classes.StatusButton}>
                      <LightTooltip  title="Edit" aria-label="view"  placement="top"><Button onClick={this.EditSettlementhandleClickOpen}
                     simple 
                     color="primary"
                     >
                       <EditSettlementicon />
                     </Button>
                     </LightTooltip>
                     <Dialog fullScreen open={this.state.setEditSettelmentopen} onClose={this.EditSettlementhandleClose} TransitionComponent={Transition} className={classes.rootslider}>
                    <AppBar className={classes.CustomappBar}>
                    <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={this.EditSettlementhandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                        Publisher Name
                        </h4>
                    
                    </Toolbar>
                    </AppBar> 
                    <GridContainer  className={classes.SliderBackground}>
                      <GridItem lg={2} md={2}></GridItem>  
                      <GridItem lg={8} md={8}>
                      <Card>
          <CardBody>
          <GridContainer>
          <GridItem lg={1} md={1} className={classes.textfieldsgrid} >
          <InputBase className={classes.margin} value="1" inputProps={{ 'aria-label': 'slno' }}
          /> 
          </GridItem>
          <GridItem lg={3} md={3} className={classes.textfieldsgrid}>
          <InputBase className={classes.margin} value="Advertiser 1" inputProps={{ 'aria-label': 'advertisername' }}
          /> 
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Sharing" variant="outlined" id="outlined-size-small" size="small" defaultValue="70:30" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Gross USD" defaultValue="300" variant="outlined"  id="outlined-size-small" size="small" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Net USD"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="200" style={{ width: "100%" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Payable INR"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="400" style={{ width: "100%" }} />
          </GridItem>
          </GridContainer>  
          <GridContainer>
          <GridItem lg={1} md={1} className={classes.textfieldsgrid} >
          <InputBase className={classes.margin} value="2" inputProps={{ 'aria-label': 'slno' }}
          /> 
          </GridItem>
          <GridItem lg={3} md={3} className={classes.textfieldsgrid}>
          <InputBase className={classes.margin} value="Advertiser 2" inputProps={{ 'aria-label': 'advertisername' }}
          /> 
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Sharing" variant="outlined" id="outlined-size-small" size="small" defaultValue="70:30" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Gross USD" defaultValue="300" variant="outlined"  id="outlined-size-small" size="small" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Net USD"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="200" style={{ width: "100%" }} />
          </GridItem>
          
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Payable INR"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="400" style={{ width: "100%" }} />
          </GridItem>
          </GridContainer>  
          <GridContainer>
          <GridItem lg={1} md={1} className={classes.textfieldsgrid} >
          <InputBase className={classes.margin} value="3" inputProps={{ 'aria-label': 'slno' }}
          /> 
          </GridItem>
          <GridItem lg={3} md={3} className={classes.textfieldsgrid}>
          <InputBase className={classes.margin} value="Advertiser 3" inputProps={{ 'aria-label': 'advertisername' }}
          /> 
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Sharing" variant="outlined" id="outlined-size-small" size="small" defaultValue="70:30" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Gross USD" defaultValue="300" variant="outlined"  id="outlined-size-small" size="small" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Net USD"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="200" style={{ width: "100%" }} />
          </GridItem>
          
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Payable INR"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="400" style={{ width: "100%" }} />
          </GridItem>
          </GridContainer>  
          <GridContainer>
          <GridItem lg={1} md={1} className={classes.textfieldsgrid} >
          <InputBase className={classes.margin} value="4" inputProps={{ 'aria-label': 'slno' }}
          /> 
          </GridItem>
          <GridItem lg={3} md={3} className={classes.textfieldsgrid}>
          <InputBase className={classes.margin} value="Advertiser 4" inputProps={{ 'aria-label': 'advertisername' }}
          /> 
          </GridItem>
          <GridItem lg={2} md={21} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Sharing" variant="outlined" id="outlined-size-small" size="small" defaultValue="70:30" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Gross USD" defaultValue="300" variant="outlined"  id="outlined-size-small" size="small" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Net USD"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="200" style={{ width: "100%" }} />
          </GridItem>
          <GridItem lg={2} md={12} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Payable INR"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="400" style={{ width: "100%" }} />
          </GridItem>
          </GridContainer>  
          <GridContainer>
          <GridItem lg={1} md={1} className={classes.textfieldsgrid} >
          <InputBase className={classes.margin} value="5" inputProps={{ 'aria-label': 'slno' }}
          /> 
          </GridItem>
          <GridItem lg={3} md={3} className={classes.textfieldsgrid}>
          <InputBase className={classes.margin} value="Advertiser 5" inputProps={{ 'aria-label': 'advertisername' }}
          /> 
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Sharing" variant="outlined" id="outlined-size-small" size="small" defaultValue="70:30" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.InputCenter} label="Gross USD" defaultValue="300" variant="outlined"  id="outlined-size-small" size="small" style={{ width: "100%",textAlign:"center" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Net USD"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="200" style={{ width: "100%" }} />
          </GridItem>
          <GridItem lg={2} md={2} className={classes.textfieldsgrid}>
          <TextField className={classes.textfields} label="Payable INR"   
           variant="outlined" id="outlined-size-small" size="small" defaultValue="400" style={{ width: "100%" }} />
          </GridItem>
          </GridContainer>  
          
          </CardBody>
          <CardHeader >
            <GridContainer>
            <GridItem lg={4} md={4} >
            <p style={{paddingTop:"10px"}}><strong>Total Net INR : 200000</strong> </p>
              </GridItem>
            <GridItem lg={4} md={4}  className={classes.checkboxroot} >
          
          <RadioGroup row aria-label="settlement" name="settlement" defaultValue="Settle">
            <FormControlLabel value="Settle" control={<Radio />} label="Settle" />
            <FormControlLabel value="Pending" control={<Radio />} label="Pending" />
            
            </RadioGroup>
              </GridItem>
              <GridItem lg={4} md={4} >
              <div className={classes.root2} >
          <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined" >
            Export
           </MButton></span>
           <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined">
            Submit
           </MButton></span>
           
          </div>

              </GridItem>
            </GridContainer>
          </CardHeader>
        </Card>
                      </GridItem>
                      <GridItem lg={2} md={2}></GridItem>
                  </GridContainer>
                  </Dialog>
                    </div>
                      ),
                  },
              ]}
              defaultPageSize={5}
              showPaginationTop 
              showPaginationBottom={false}
              className="-highlight"
            />
          </CardBody>
          <CardHeader >
           
          <div className={classes.root2} >
          <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined" >
            Export
           </MButton></span>
           <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined">
            Download
           </MButton></span>
           <span style={{paddingLeft:"10px"}}> <MButton  color="secondary" variant="outlined" >
            Upload
           </MButton></span>
          </div>
         
          </CardHeader>
        </Card>
         </GridItem>
         <GridItem lg={1} md={1} ></GridItem> 
        </GridContainer> 
                                                        
        </Dialog>
       
    </div>
    );
}
}
const SettlementDialogHOC = withStyles(styles)(SettlementDialog);
export default connect(mapStateToProps, mapDispatchToProps)(SettlementDialogHOC);
 