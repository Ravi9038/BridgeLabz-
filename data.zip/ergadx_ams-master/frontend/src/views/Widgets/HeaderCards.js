import React, { Component } from 'react'
import { makeStyles } from "@material-ui/core/styles";
import ReactTable from "react-table";
import TextField from '@material-ui/core/TextField';
// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import Paymenticon from "@material-ui/icons/Payment";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import MButton from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import Tooltip from '@material-ui/core/Tooltip';
import Button from "components/CustomButtons/Button.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from '@material-ui/core/IconButton';
import { withStyles } from '@material-ui/styles';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import { connect } from 'react-redux';
import { Receipt } from '@material-ui/icons';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
import styles from "assets/jss/material-dashboard-pro-react/views/paymentcustomstyle.js";
import data from "views/DataFile/HeaderData";
import { SERVER_URL } from "../../variables/constants";
import axios from 'axios';
import * as moment from 'moment';
const useStyles = makeStyles(styles);

class HeaderCards extends Component {

    constructor(props) {
        super(props);
        this.state = {
            AdvertiserReceipt: [],
            ReceiptHeaderData: [
                {
                    "Title": "Unpaid",
                    "Value": ""
                },
                {
                    "Title": "This Month",
                    "Value": ""
                },
                {
                    "Title": "Last Month",
                    "Value": ""
                },
                {
                    "Title": "This FY",
                    "Value": ""
                }
            ]
        }

    }




    componentDidMount = () => {
        var month = new moment().subtract(1, 'months').date(1).utcOffset('GMT-00:00').format("YYYY-MM-DD");
        console.log(month)
        var lastMonth = new moment().subtract(2, 'months').date(1).utcOffset('GMT-00:00').format("YYYY-MM-DD");
        console.log(lastMonth);
        var year = new moment().utcOffset('GMT-00:00').format("YYYY");
        console.log(year);
        console.log(this.props.type)
        if(this.props.type==="receipt"){
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/receipt`, { headers: { "Authorization": TOKEN } })
            .then(response => response.data)
            .then((data) => {
                console.log(data);
                var unpaid = 0;
                this.setState({ AdvertiserReceipt: data })
                data.forEach(element => {
                    if (element.status == "DRAFT") {
                        unpaid++;
                    }

                });
                var totalAmount = 0;
                data.forEach(element => {
                    if (element.startDate == month) {
                        totalAmount += element.amount;
                    }

                });
                var lastMonthAmount = Math.round(totalAmount);
                console.log(lastMonthAmount);
                var previousMonthAmont = 0;
                data.forEach(element => {
                    if (element.startDate == lastMonth) {
                        previousMonthAmont += element.amount;
                    }

                });
                var lpreviousMonthAmont = Math.round(previousMonthAmont);
                console.log(lpreviousMonthAmont);
                var WholeYear=0;
                data.forEach(element => {
                    var date=element.startDate;
                    var lYear = new moment(date).utcOffset('GMT-00:00').format("YYYY");
                    if (lYear===year) {
                        WholeYear += element.amount;
                    }

                });
                var lWholeYear = Math.round(WholeYear);
                console.log(lWholeYear);
            
                var array = [
                    {
                        "Title": "Unpaid",
                        "Value": unpaid
                    },
                    {
                        "Title": "This Month",
                        "Value": lastMonthAmount
                    },
                    {
                        "Title": "Last Month",
                        "Value": lpreviousMonthAmont
                    },
                    {
                        "Title": "This FY",
                        "Value": lWholeYear
                    }
                ];
                this.setState({ ReceiptHeaderData: array })
            }).catch(error => { console.log(error); })
        }

        if(this.props.type==="payment"){
            const TOKEN = 'Bearer '.concat(this.props.data.token);
            axios.defaults.headers.common['Authorization'] = TOKEN;
            axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
            axios.get(`${SERVER_URL}/api/invoicedetails`, { headers: { "Authorization": TOKEN } })
                .then(response => response.data)
                .then((data) => {
                    console.log(data);
                    var unpaid = 0;
                    this.setState({ AdvertiserReceipt: data })
                    data.forEach(element => {
                        if (element.status == "DRAFT") {
                            unpaid++;
                        }
    
                    });
                    var totalAmount = 0;
                    data.forEach(element => {
                        if (element.startDate == month) {
                            totalAmount += element.amount;
                        }
    
                    });
                    var lastMonthAmount = Math.round(totalAmount);
                    console.log(lastMonthAmount);
                    var previousMonthAmont = 0;
                    data.forEach(element => {
                        if (element.startDate == lastMonth) {
                            previousMonthAmont += element.amount;
                        }
    
                    });
                    var lpreviousMonthAmont = Math.round(previousMonthAmont);
                    console.log(lpreviousMonthAmont);
                    var WholeYear=0;
                    data.forEach(element => {
                        var date=element.startDate;
                        var lYear = new moment(date).utcOffset('GMT-00:00').format("YYYY");
                        if (lYear===year) {
                            WholeYear += element.amount;
                        }
    
                    });
                    var lWholeYear = Math.round(WholeYear);
                    console.log(lWholeYear);
                
                    var array = [
                        {
                            "Title": "Unpaid",
                            "Value": unpaid
                        },
                        {
                            "Title": "This Month",
                            "Value": lastMonthAmount
                        },
                        {
                            "Title": "Last Month",
                            "Value": lpreviousMonthAmont
                        },
                        {
                            "Title": "This FY",
                            "Value": lWholeYear
                        }
                    ];
                    this.setState({ ReceiptHeaderData: array })
                }).catch(error => { console.log(error); })
            }
    }


    render() {
        const classes = this.props.classes;
        return (

            <div className={classes.root}>
                <GridContainer>
                    {this.state.ReceiptHeaderData.map((item) => (
                        <GridItem xs={12} md={3} lg={3}>
                            <Card>
                                <CardBody>
                                    <a className={classes.CardHeading} >
                                        <h4 className={classes.CardHeading}>{item.Title}</h4>
                                        <h4 className={classes.CardHeading}>{item.Value}</h4>
                                    </a>
                                </CardBody>
                            </Card>
                        </GridItem>
                    ))}
                </GridContainer>
            </div>
        );
    }
}
const HeaderCardsHOC = withStyles(styles)(HeaderCards);
export default connect(mapStateToProps, mapDispatchToProps)(HeaderCardsHOC);
