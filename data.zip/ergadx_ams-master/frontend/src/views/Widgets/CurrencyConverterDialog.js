
// react component for creating dynamic tables
import React, { Component } from 'react'
import ReactTable from "react-table";
import { makeStyles } from '@material-ui/styles';
import { withStyles } from "@material-ui/core/styles";
// @material-ui/core components

// @material-ui/icons
import Assignment from "@material-ui/icons/Assignment";
import Dvr from "@material-ui/icons/Dvr";
import Favorite from "@material-ui/icons/Favorite";
import Close from "@material-ui/icons/Close";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import TextField from '@material-ui/core/TextField';
import InputBase from '@material-ui/core/InputBase';
import Paymenticon from "@material-ui/icons/Payment";
import { dataTable } from "variables/Paymentdatatable.js";

import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";
 
import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import FormControl from "@material-ui/core/FormControl";
import Dialog from '@material-ui/core/Dialog';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';

import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import AddCurrencyIcon from '@material-ui/icons/AddBox';
import ViewCurrecncy from '@material-ui/icons/Visibility';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import EditSettlementicon from '@material-ui/icons/Edit';
import AddInvoice from '@material-ui/icons/AddToQueue';
import Slide from '@material-ui/core/Slide';
import Tooltip from '@material-ui/core/Tooltip';
// material-ui icons
import Checkbox from '@material-ui/core/Checkbox';
import MButton from '@material-ui/core/Button';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Select from '@material-ui/core/Select';
import NativeSelect from '@material-ui/core/NativeSelect';
import ButtonGroup from '@material-ui/core/ButtonGroup'
import styles from "assets/jss/material-dashboard-pro-react/views/paymentcustomstyle.js";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js';
import { connect } from 'react-redux';
const useStyles = makeStyles(styles);

const LightTooltip = withStyles((theme) => ({
    tooltip: { 
      backgroundColor: theme.palette.common.white,
      color: 'rgba(0, 0, 0, 0.87)',
      boxShadow: theme.shadows[1],
      fontSize: 11,
    },
  }))(Tooltip);
  const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="left" ref={ref} {...props} />;
  });
export class CurrencyConverterDialog extends Component {
state = {
    setCurrencyConversionOpen:false,
    setEditCurrencyOpen:false,
    tab:'Create',
    data: dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          Select: prop[0],
          PublisherName: prop[0],
          InvoiceDate: prop[1],
          NetAmount: prop[2],
          GST: prop[3],
          TDS: prop[4],
          GrossPayable: prop[5],
          Status: prop[6],
          monthyear:prop[6],
          GrossUSD : prop[7],
          NetUSD : prop[8],
          USDtoINR : prop[9],
          NetINR : prop[10],
          Settlementstatus : prop[11],
          Action : prop[12],
          month :prop[12],
          year:prop[13],
          currency:prop[14],
          ininr :prop[15],
          action:prop[16]
          
        }; 
      })
}
CurrencyConversionhandleClickOpen = () => {
    this.setState({setCurrencyConversionOpen:true});
  };
CurrencyConversionhandleClose = () => {
    this.setState({setCurrencyConversionOpen:false}); 
  };
EditCurrencyhandleClickOpen = () => {
    this.setState({setEditCurrencyOpen:true});
  };

EditCurrencyhandleClose = () => {
    this.setState({setEditCurrencyOpen:false}); 
};
tabsetCreate =() =>{
 this.setState({tab:'Create'});
 
}
tabsetView =() =>{
    this.setState({tab:'View'});
   }
    render(){
        const classes = this.props.classes;
        return ( 
        <div className={classes.root}>
          <button className={classes.CardButton} onClick={this.CurrencyConversionhandleClickOpen}> 
            Currency Conversion
        </button>
        <Dialog fullScreen open={this.state.setCurrencyConversionOpen} onClose={this.CurrencyConversionhandleClose} TransitionComponent={Transition} className={classes.rootslider}>
                    <AppBar className={classes.CustomappBar}>
                    <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={this.CurrencyConversionhandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                         Currency Conversion
                        </h4>
                        <ButtonGroup color="secondary" aria-label="outlined secondary button group" style={{paddingLeft:"67%"}}>
                        <MButton onClick={this.tabsetCreate}>Create</MButton>
                        <MButton onClick={this.tabsetView}>View</MButton>
                      </ButtonGroup>
                      
                    </Toolbar>
                    </AppBar> 
                    {this.state.tab == 'Create' && 
                    <div>
                    <GridContainer  style={{paddingTop:"3%"}}  className={classes.SliderBackground}>
                      <GridItem lg={3} md={3}></GridItem>  
                      <GridItem lg={6} md={6}>
                      <Card>
                      <CardHeader color="primary" icon >
                        <CardIcon color="primary">
                      <AddCurrencyIcon style={{color:"white"}} />
                      
                      </CardIcon>
                      <h4 className={classes.heading} style={{marginTop:"10px!important"}} >Create</h4>
                      </CardHeader>
                    <CardBody>
                      <GridContainer>
                        <GridItem lg={2} md={2}></GridItem>
                        <GridItem lg={4} md={4}>
                        <TextField className={classes.textfields} label="Month"   
                          variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }} />
                        </GridItem>
                        <GridItem lg={4} md={4}>
                        <TextField className={classes.textfields} label="Year"   
                          variant="outlined" id="outlined-size-small" size="small"  style={{ width: "100%" }} />
                        </GridItem>
                        <GridItem lg={2} md={2}></GridItem>
                      </GridContainer>
                      <GridContainer>
                        <GridItem lg={2} md={2}></GridItem>
                        <GridItem lg={4} md={4}>
                        <InputBase className={classes.margin} value="USD" inputProps={{ 'aria-label': 'usd' }}
                       /> 
                        </GridItem>
                        <GridItem lg={4} md={4}>
                        <TextField className={classes.textfields} label="In INR"   
                          variant="outlined" id="outlined-size-small" size="small"  style={{ width: "100%" }} />
                        </GridItem>
                        <GridItem lg={2} md={2}></GridItem>
                      </GridContainer>
                      <GridContainer>
                        <GridItem lg={2} md={2}></GridItem>
                        <GridItem lg={4} md={4}>
                        <InputBase className={classes.margin} value="EURO" inputProps={{ 'aria-label': 'usd' }}
                       /> 
                        </GridItem>
                        <GridItem lg={4} md={4}>
                        <TextField className={classes.textfields} label="In INR"   
                          variant="outlined" id="outlined-size-small" size="small"  style={{ width: "100%" }} />
                        </GridItem>
                        <GridItem lg={2} md={2}></GridItem>
                      </GridContainer>
                      <GridContainer>
                        <GridItem lg={2} md={2}></GridItem>
                        <GridItem lg={4} md={4}>
                        <InputBase className={classes.margin} value="POUND" inputProps={{ 'aria-label': 'usd' }}
                       /> 
                        </GridItem>
                        <GridItem lg={4} md={4}>
                        <TextField className={classes.textfields} label="In INR"   
                          variant="outlined" id="outlined-size-small" size="small"  style={{ width: "100%" }} />
                        </GridItem>
                        <GridItem lg={2} md={2}></GridItem>
                      </GridContainer>
                     </CardBody>
                    <CardHeader >
            
              <div className={classes.root2} >
           <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined">
            Submit
           </MButton></span>
           
          </div>
          </CardHeader>
        </Card>
          </GridItem>
                      <GridItem lg={3} md={3}></GridItem>
                  </GridContainer>
                  </div>}
                  {this.state.tab == 'View' && 
                    <div>
                  <GridContainer  style={{paddingTop:"3%"}} className={classes.SliderBackground}>
                      <GridItem lg={3} md={3}></GridItem>  
                      <GridItem lg={6} md={6}>
                      <Card>
                      <CardHeader color="primary" icon >
                        <CardIcon color="primary">
                      <ViewCurrecncy style={{color:"white"}} />
                      </CardIcon>
                      <h4 className={classes.heading} style={{marginTop:"10px!important"}} >View</h4>
                      </CardHeader>
                    <CardBody>
                    <ReactTable
              data={this.data}
              filterable
              columns={[
                {
                  Header: "Month",
                  accessor: "month",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Month"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                

                  },
                  {
                    Header: "Year",
                    accessor: "year",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Year"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                  
  
                    },
               
                {
                  Header: "Currency",
                  accessor: "currency",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Currency"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                  Footer: (
                    <span>
                    <p><strong>USD</strong></p>
                    <p><strong>EURO</strong></p>
                    <p><strong>POUND</strong></p>
                    </span>
                  )

                },
                {
                    Header: "In INR",
                    accessor: "ininr",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Amount"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                    Footer: (
                      <span>
                      <p><strong>100</strong></p>
                      <p><strong>200</strong></p>
                      <p><strong>300</strong></p>
                      </span>
                    )
  
                  },
                 
                  {
                    Header: "Action",
                    accessor: "Action",
                    Cell: id => (
                      <div className={classes.StatusButton}>
                      <LightTooltip  title="Edit" aria-label="view"  placement="top"><Button onClick={this.EditCurrencyhandleClickOpen}
                     simple 
                     color="primary"
                     >
                       <EditSettlementicon />
                     </Button>
                     </LightTooltip>
                     <Dialog fullScreen open={this.state.seteditCurrencyonopen} onClose={this.EditCurrencyhandleClose} TransitionComponent={Transition} className={classes.EditCurrencyrootslider}>
                        <AppBar className={classes.CustomappBar}>
                        <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={this.EditCurrencyhandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                        Edit Rate
                        </h4>
                        </Toolbar>
                        </AppBar>
                        <GridContainer  style={{paddingTop:"3%"}}  className={classes.SliderBackground}>
                      
                      <GridItem lg={12} md={12}>
                      <Card>
                    <CardBody>
                      <GridContainer  style={{paddingTop:"20px"}}>
                        
                        <GridItem lg={3} md={3}>
                        <InputBase className={classes.margin} value="USD" inputProps={{ 'aria-label': 'usd' }}
                       /> 
                        </GridItem>
                      <GridItem lg={9} md={9}>
                      <TextField className={classes.textfields} label="In INR"   
                          variant="outlined" id="outlined-size-small" size="small"  style={{ width: "100%" }} />
                      </GridItem>
                      </GridContainer>
                      
                     </CardBody>
                    <CardHeader >
            
              <div className={classes.root2} >
           <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined">
            Submit
           </MButton></span>
           
          </div>
          </CardHeader>
        </Card>
                      </GridItem>
                      
                  </GridContainer>  
                                               
                        </Dialog>
                        
                    </div>
                      ),
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Status"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
                  },
              ]}
              defaultPageSize={5}
              showPaginationTop 
              showPaginationBottom={false}
              className="-highlight"
            />
            </CardBody>
            <CardHeader >
            <div className={classes.root2} >
           <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined">
            Submit
           </MButton></span>
           
          </div>
          </CardHeader>
        </Card>
         </GridItem>
              <GridItem lg={3} md={3}></GridItem>
                  </GridContainer>
        </div>}
    </Dialog>

    </div>
    );
}
}
const CurrencyConverterDialogHOC = withStyles(styles)(CurrencyConverterDialog);
export default connect(mapStateToProps, mapDispatchToProps)(CurrencyConverterDialogHOC);
 