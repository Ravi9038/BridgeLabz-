import React, { Component } from 'react'
import { makeStyles } from "@material-ui/core/styles";
import ReactTable from "react-table";
import TextField from '@material-ui/core/TextField';
// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import Paymenticon from "@material-ui/icons/Payment";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import MButton from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import Tooltip from '@material-ui/core/Tooltip';
import Button from "components/CustomButtons/Button.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from '@material-ui/core/IconButton';
import { withStyles } from '@material-ui/styles';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import { connect } from 'react-redux';
import { Receipt } from '@material-ui/icons';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import styles from "assets/jss/material-dashboard-pro-react/views/paymentcustomstyle.js";
import HeaderCards from 'views/Widgets/HeaderCards.js';
import * as moment from 'moment';
import { SERVER_URL } from "../../variables/constants";
import axios from 'axios';
const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="left" ref={ref} {...props} />;
  });

const useStyles = makeStyles(styles);

export class SettlementDialog extends Component {
    constructor(props) {
        super(props);
        this.state = {
          open : false,
           ReceivedAmountOpen :false,
           AdvertiserReceipt:[],
           receivedAmount:0,
           ID:'',
           date:'',
        }
    
      } 
      handleClickOpen = (event) =>{
        this.setState({open:true});
      }
      handleClose = (event) =>{
        this.setState({open:false});
      }
      ReceviedAmounthandleClickOpen = (id) =>{
        this.setState({ReceivedAmountOpen:true});
        this.setState({ID:id})
      }
      ReceviedAmounthandleClose = (event) =>{
        this.setState({ReceivedAmountOpen:false});
      }

      componentDidMount = () => {
       
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/receipt`,  { headers: { "Authorization": TOKEN } })
          .then(response => response.data)
          .then((data) => {
            console.log(data);
            this.setState({AdvertiserReceipt:data})
          }).catch(error => { console.log(error); })
     
    }

    handleStartDateChange=(value)=>{
  console.log(value)
  this.setState({date:value})
    }
    RecviedAmountDetails=(value)=>{
 this.setState({receivedAmount:value})
    }

    submitRecivedmount=()=>{
      var req={};
      var id=this.state.ID;
      req.receivedAmount=this.state.receivedAmount;
      req.receivedDate=this.state.date;
      req.status="RECEIVED"
      console.log(req);
      const TOKEN = 'Bearer '.concat(this.props.data.token);
      axios.defaults.headers.common['Authorization'] = TOKEN;
      axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
      axios.post(`${SERVER_URL}/api/receipt/${id}`, req, { headers: { "Authorization": TOKEN } })
        .then(response => response.data)
        .then((data) => {
          alert("Data Submitted")
        }).catch(error => { console.log(error); })
    }
    render(){
        const classes = this.props.classes;
        return ( 
        <div className={classes.root}>
            <button className={classes.CardButton} onClick={this.handleClickOpen}>
                 Settlement
            </button>
            <Dialog fullScreen open={this.state.open} onClose={this.handleClose} TransitionComponent={Transition} className={classes.rootslider}>
        <AppBar className={classes.CustomappBar}>
        <Toolbar>
        <IconButton edge="start" color="inherit" onClick={this.handleClose} aria-label="close" className={classes.CloseButton}>
        <LeftAorrow />
        </IconButton>
        <h4 className={classes.SliderTitle}>
        Settlment Details
        </h4>
        </Toolbar>
        </AppBar>                     
        <GridContainer style={{paddingTop:"3%"}} className={classes.SliderBackground}>
        <GridItem lg={1} md={1} ></GridItem>  
        <GridItem lg={10} md={10}>
        <Card>
        <CardHeader color="primary" icon >
        <CardIcon color="primary">
        <Paymenticon style={{color:"white"}} />
        </CardIcon>
        <h4 className={classes.heading} style={{marginTop:"10px!important"}} > Settlment Details
        
          </h4>
          </CardHeader>
          <CardBody className={classes.root}>
          <ReactTable
              data={this.state.AdvertiserReceipt}
              filterable
              columns={[
                
                  {
                    Header: "Advetiser",
                    accessor: "companyName",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Advertiser"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                  
  
                    },
                    {
                      Header: "Month",
                      accessor: "endDate",
                      Filter: ({filter, onChange}) => (
                        <input type='text' style={{textAlign:'center'}}
                               placeholder="Search Month"
                               value={filter ? filter.value : ''}
                                   onChange={event => onChange(event.target.value)}
                        />
                      ),
                      Cell:id=>(
                        new moment(id.original.startDate).format("MMMM")
                       )
                    
    
                      },
                      {
                        Header: "Year",
                        accessor: "startDate",
                        Filter: ({filter, onChange}) => (
                          <input type='text' style={{textAlign:'center'}}
                                 placeholder="Search Year"
                                 value={filter ? filter.value : ''}
                                     onChange={event => onChange(event.target.value)}
                          />
                        ),
                        Cell:id=>(
                          new moment(id.original.startDate).format("YYYY")
                         )
                      
      
                        },
               
                {
                  Header: "Currency",
                  accessor: "currency",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Currency"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                 

                },
                {
                    Header: "Gross Amount",
                    accessor: "amount",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Gross Amount"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
                  },
                  {
                    Header: "Received Amount",
                    accessor: "receivedAmount",
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Amount"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
  
                  },
                  {
                    Header: "Status",
                    accessor: "status",
                    Cell: id => (
                   
                      <div className={classes.StatusButton}>
                           {id.original.status=="DRAFT" &&
                               <Button onClick={()=>this.ReceviedAmounthandleClickOpen(id.original.id)}
                               simple
                               color="danger"
                               >Pending
                               </Button> } 
                               {id.original.status!="DRAFT" &&
                     <Button 
                     simple  
                     color="success"
                     >Received 
                     </Button>
                  }
                    </div>
                      ),
                    Filter: ({filter, onChange}) => (
                      <input type='text' style={{textAlign:'center'}}
                             placeholder="Search Status"
                             value={filter ? filter.value : ''}
                                 onChange={event => onChange(event.target.value)}
                      />
                    ),
                   
                  },
             
                ]}
                defaultPageSize={5}
                showPaginationTop 
                showPaginationBottom={false}
                className="-highlight"
              />
             
           </CardBody>
           <CardHeader >
           
          <div className={classes.root2} >
          <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined" >
            Export
           </MButton></span>
           <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined">
            Download
           </MButton></span>
           <span style={{paddingLeft:"10px"}}> <MButton  color="secondary" variant="outlined" >
            Upload
           </MButton></span>
          </div>
         
          </CardHeader>
           </Card>
           </GridItem>
           </GridContainer>
           </Dialog>
           <Dialog fullScreen open={this.state.ReceivedAmountOpen} onClose={this.ReceviedAmounthandleClose} TransitionComponent={Transition} className={classes.ReceivedAmountSlider}>
                        <AppBar className={classes.CustomappBar}>
                        <Toolbar>
                        <IconButton edge="start" color="inherit" onClick={this.ReceviedAmounthandleClose} aria-label="close" className={classes.CloseButton}>
                        <LeftAorrow />
                        </IconButton>
                        <h4 className={classes.SliderTitle}>
                       Received Amount Details
                        </h4>
                        </Toolbar> 
                        </AppBar>
                                     
                       <GridContainer>
                          
                           <GridItem lg={12} md={12} ><Card>
                        <CardBody>
                        <GridContainer>
                            <GridItem lg={12}>
                            <TextField className={classes.textfields}  type="date"  id="date" onChange={(event)=>this.handleStartDateChange(event.target.value)} 
                            InputLabelProps={{shrink: true,}}  label="Date of Received" 
                            variant="outlined" id="outlined-size-small"  
                            size="small"  style={{width:"100%"}}/>
                            </GridItem>
                            <GridItem lg={12}>
                             <TextField className={classes.textfields}  label="Amount in USD" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }} 
                             onChange={(event)=>this.RecviedAmountDetails(event.target.value)}/>
                            </GridItem>
                            <GridItem lg={12}>
                            <TextField className={classes.textfields}   label="Amount in Rupees" variant="outlined" id="outlined-size-small" size="small" style={{ width: "100%" }} />
                            </GridItem>
                         </GridContainer>
                        </CardBody>
                        <CardHeader>
                     <div className={classes.root2} >
                     <span style={{paddingLeft:"10px"}}><MButton color="secondary" variant="outlined" className={classes.submitbutton} 
                     onClick={this.submitRecivedmount} >
                        Submit
                        </MButton>
                        </span>
                        <span style={{paddingLeft:"10px"}}><MButton color="primary" variant="outlined">
                        Edit
                        </MButton>
                        </span>
                    </div>
                   </CardHeader>
             </Card></GridItem>  
            </GridContainer>                             
            </Dialog>
    </div>
    );
}
}
const SettlementDialogHOC = withStyles(styles)(SettlementDialog);
export default connect(mapStateToProps, mapDispatchToProps)(SettlementDialogHOC);
 