import React, { Component } from 'react'
import { makeStyles } from "@material-ui/core/styles";
import ReactTable from "react-table";
import TextField from '@material-ui/core/TextField';
// material-ui icons
import Assignment from "@material-ui/icons/Assignment";
import Paymenticon from "@material-ui/icons/Payment";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import MButton from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Slide from '@material-ui/core/Slide';
import Tooltip from '@material-ui/core/Tooltip';
import Button from "components/CustomButtons/Button.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from '@material-ui/core/IconButton';
import { withStyles } from '@material-ui/styles';
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import { connect } from 'react-redux';
import { Receipt } from '@material-ui/icons';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import styles from "assets/jss/material-dashboard-pro-react/views/paymentcustomstyle.js";
import data from "views/DataFile/HeaderData";
import * as moment from 'moment';
import { SERVER_URL } from "../../variables/constants";
import axios from 'axios';
const useStyles = makeStyles(styles);
const PaymentOverviewData = data.PaymentOverview;


class PaymentOverview extends Component {

    constructor(props) {
        super(props);
        this.state = {
    
            invoiceDetails:[],
            PaymentOverview:[
                {
                    "Head":"Month",
                    "Value" :""
                },
                {
                    "Head":"Gross Amount",
                    "Value" :""
                },
                {
                    "Head":"GST",
                    "Value" :""
                },
                {
                    "Head":"TDS",
                    "Value" :""
                },
                {
                    "Head":"Net Payable",
                    "Value" :""
                },
                {
                    "Head":"Pending Payment",
                    "Value" :""
                }
            ]
        }
    
      }
    componentDidMount = () => {
       
        const TOKEN = 'Bearer '.concat(this.props.data.token);
        axios.defaults.headers.common['Authorization'] = TOKEN;
        axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
        axios.get(`${SERVER_URL}/api/invoicedetails`,  { headers: { "Authorization": TOKEN } })
          .then(response => response.data)
          .then((data) => {
            console.log(data);
            this.setState({invoiceDetails:data})
            var grossAmonut=0;
            var tax=0;
            var netPayble=0;
            var month="";
            data.forEach(element => {
                grossAmonut+=element.amount;
                tax+=element.tax;
                netPayble+=element.netAmount;
                month=new moment(element.startDate).format("MMMM")
            });
            var lgrossAmount=Math.round(grossAmonut);
            var ltax=Math.round(tax);
            var lnetPayble=Math.round(netPayble);
            console.log(lgrossAmount);
            console.log(ltax);
            console.log(lnetPayble);
            console.log(month);
            var unpaidAmount=0
            data.forEach(element => {
                if(element.status==="DRAFT"){
                    unpaidAmount+=element.amount;
                }
            });
           var lunpaidAmount=Math.round(unpaidAmount);

           var array=[
            {
                "Head":"Month",
                "Value" :month
            },
            {
                "Head":"Gross Amount",
                "Value" :lgrossAmount
            },
            {
                "Head":"GST",
                "Value" :ltax
            },
            {
                "Head":"TDS",
                "Value" :0
            },
            {
                "Head":"Net Payable",
                "Value" :lnetPayble
            },
            {
                "Head":"Pending Payment",
                "Value" :lunpaidAmount
            }
        ];

           this.setState({PaymentOverview:array})

          }).catch(error => { console.log(error); })
      
      }
      

render(){
const classes = this.props.classes;
return ( 
<div className={classes.root}>
<GridContainer>
<GridItem lg={12}>
    <h4  className={classes.MainHeading}>Payment Overview</h4>
</GridItem>
<GridItem lg={1}></GridItem>

<GridItem lg={10}>
    <Card>
        <CardBody  className={classes.PaymentOverviewCardBody}>
            <GridContainer>
            {this.state.PaymentOverview.map((item)=>(
            <GridItem lg={2} className={classes.TextCenter}>
            <h5>{item.Value}</h5>
            <span className={classes.SmallText}>{item.Head}</span>
            </GridItem>
            ))}
        </GridContainer>
        </CardBody>
    </Card>
</GridItem>

<GridItem lg={1}></GridItem>
</GridContainer> 
</div>
);
}
}
const PaymentOverviewHOC = withStyles(styles)(PaymentOverview);
export default connect(mapStateToProps, mapDispatchToProps)(PaymentOverviewHOC);
 