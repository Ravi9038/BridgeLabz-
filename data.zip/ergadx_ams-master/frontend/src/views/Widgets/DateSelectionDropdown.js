import React, { Component } from "react";
import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'
import FormControl from "@material-ui/core/FormControl";
import * as moment from 'moment';
import MButton from '@material-ui/core/Button';
// material-ui icons
import Menu from "@material-ui/icons/Menu";
import LeftAorrow from '@material-ui/icons/KeyboardArrowLeft';
import Calender from '@material-ui/icons/Event';
import Dialog from '@material-ui/core/Dialog';
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import CardIcon from "components/Card/CardIcon.js";
import CardBody from "components/Card/CardBody.js";
import CardFooter from "components/Card/CardFooter.js";
import TextField from '@material-ui/core/TextField';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Slide from '@material-ui/core/Slide';
import InputLabel from "@material-ui/core/InputLabel";
const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="left" ref={ ref } { ...props } />;
});
const styles = {
    cardIconTitle: {
        ...cardTitle,
        marginTop: "15px",
        marginBottom: "0px"
    },
    rootselect: {
        fontSize: "14px !important",
        fontWeight: "400 !important",
        textAlign: "left !important"
    },
    rootslider: {
        '& .MuiGrid-container': {
            width: "100% !important",
            margin: "0 0px"
        },
        '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
            transform: "translate(14px, -6px) scale(0.85)"
        },
        '& .MuiInputLabel-outlined': {
            transform: "translate(14px, 14px) scale(1)",
            fontSize: "0.9rem !important"
        },
        '& .MuiOutlinedInput-input': {
            paddingTop: "10px",
            paddingBottom: "10px",
            paddingLeft: "6px",
            paddingRight: "6px"
        },
        '& .MuiGrid-grid-lg-6': {
            padding: "0 3px !important"
        },
        '& .MuiGrid-grid-md-6': {
            padding: "0 3px !important"
        },
        '& .MuiDialog-paperFullScreen': {
            width: "100% !important",
            backgroundColor: "#dddddd!important",
            overflowX: " hidden !important",
            float: "right !important",
        },
        '& .MuiPaper-root': {
            width: "30%",
            float: "right"
        },
        '& .MuiDialog-container': {
            width: "30%",
            float: "right"
        }
    }, cardTitle: {
        ...cardTitle,
        marginTop: "0px",
        marginBottom: "3px"
    },
    CustomappBar: {
        display: "flex",
        flex: " 0 0 64px",
        background: "#ebebeb",
        height: " 64px",
        borderBottom: "1px solid rgb(0 0 0 / 10%)",


    },
    CloseButton: {
        backgroundColor: "white",
        borderRadius: "30px",
        color: "black",
        width: "41px",
        height: "41px",

        minWidth: "41px",
        paddingLeft: "12px",
        paddingRight: "12px"
    },
    SliderTitle: {
        fontSize: "16px",
        paddingLeft: "30px",
        color: "black !important",
        fontWeight: "400"

    },
    submitbutton: {
        color: " #4caf50",
        border: "1px solid #4caf50"
    },
};


class DateSelectionDropdown extends Component {

    constructor (props) {
        super(props);

        var defaultDateValue = props.defaultValue ? props.defaultValue : 'Last7Days';
        // debugger;
        this.state = {
            selectWebsiteRevenueDuration: defaultDateValue,
            startDate: new moment().utcOffset('GMT-00:00').format("YYYY-MM-DD"),
            endDate: new moment().utcOffset('GMT-00:00').format("YYYY-MM-DD"),
            isPopupOpen: false
        };
        this.updateState(defaultDateValue);
    }

    handleWebsiteSelect = (event) => {
        let lSelectedDropdownValue = event.target.value;
        this.setState({ 'selectWebsiteRevenueDuration': event.target.value });
        this.updateState(lSelectedDropdownValue);

    }

    updateState = (lSelectedDropdownValue) => {
        var todayDate = new moment().utcOffset('GMT-00:00');
        var startDate = this.state.startDate;
        var endDate = this.state.endDate;
        if (lSelectedDropdownValue == 'Last7Days') {
            endDate = todayDate.format("YYYY-MM-DD");
            startDate = todayDate.subtract(6, 'days').format("YYYY-MM-DD");
        } else if (lSelectedDropdownValue == 'Yesterday') {
            startDate = todayDate.subtract(1, 'days').format("YYYY-MM-DD");
            endDate = startDate;
        } else if (lSelectedDropdownValue == 'Today') {
            startDate = todayDate.format("YYYY-MM-DD");
            endDate = todayDate.format("YYYY-MM-DD");
        } else if (lSelectedDropdownValue == 'ThisMonth') {
            endDate = todayDate.format("YYYY-MM-DD");
            startDate = todayDate.startOf('month').format("YYYY-MM-DD");
        } else if (lSelectedDropdownValue == 'LastMonth') {
            startDate = todayDate.subtract(1, 'months').startOf('month').format("YYYY-MM-DD");
            endDate = todayDate.endOf('month').format("YYYY-MM-DD");
        } else if (lSelectedDropdownValue == 'CustomDate') {
            this.setState({ isPopupOpen: true });

        }
        if (lSelectedDropdownValue != 'CustomDate') {
            console.log('DateSelectionDropDown' + startDate + endDate);
            this.props.onDropDownChange.call(this, startDate, endDate, lSelectedDropdownValue);
        }

        this.setState({ selectWebsiteRevenueDuration: lSelectedDropdownValue });
    }

    closeDialogBox = () => {
        this.setState({ isPopupOpen: false });
    }

    setCustomDate = () => {
        var startDate = this.state.startDate;
        var endDate = this.state.endDate;
        var DateSelectionDropdown = this.state.selectWebsiteRevenueDuration;
        //console.log(DateSelectionDropdown);   
        if (this.props.onDropDownChange)
            this.props.onDropDownChange.call(this, startDate, endDate, DateSelectionDropdown);
        this.setState({ isPopupOpen: false });
    }
    handleStartDateChange = (event) => {
        this.setState({ startDate: event.target.value });
    }
    handleEndDateChange = (event) => {
        this.setState({ endDate: event.target.value });
    }
    renderCustomDateDialog = () => {
        const classes = this.props.classes;
        return <Dialog fullScreen open={ this.state.isPopupOpen } onClose={ this.closeDialogBox } TransitionComponent={ Transition } className={ classes.rootslider } >
            <AppBar className={ classes.CustomappBar }>
                <Toolbar>
                    <IconButton edge="start" color="inherit" onClick={ this.closeDialogBox } aria-label="close" className={ classes.CloseButton }>
                        <LeftAorrow />
                    </IconButton>
                    <h4 className={ classes.SliderTitle }>
                        Custom Date
                    </h4>

                </Toolbar>
            </AppBar>
            <GridContainer style={ { paddingTop: "23%" } } className={ classes.SliderBackground }>

                <GridItem lg={ 12 } md={ 12 }>
                    <Card>
                        <CardHeader color="primary" icon>
                            <CardIcon color="primary">
                                <Calender style={ { color: "white" } } />

                            </CardIcon>
                            <h4 className={ classes.heading } style={ { marginTop: "10px!important" } } >Custom Date</h4>
                        </CardHeader>
                        <CardBody>
                            <GridContainer style={ { paddingTop: "15px" } }>
                                <GridItem lg={ 6 } md={ 6 }>
                                    <TextField className={ classes.textfields } type="date" id="date" onChange={ this.handleStartDateChange } value={ this.state.startDate } defaultValue={ this.state.startDate }
                                        InputLabelProps={ { shrink: true, } } label="From"
                                        variant="outlined" id="outlined-size-small"
                                        size="small" style={ { width: "100%" } } />
                                </GridItem>
                                <GridItem lg={ 6 } md={ 6 }>
                                    <TextField className={ classes.textfields } type="date" id="date" onChange={ this.handleEndDateChange } value={ this.state.endDate } defaultValue={ this.state.endDate }
                                        InputLabelProps={ { shrink: true, } } label="To" variant="outlined"
                                        id="outlined-size-small" size="small" style={ { width: "100%" } } />
                                </GridItem>
                            </GridContainer>
                        </CardBody>
                        <CardHeader>
                            <MButton onClick={ this.setCustomDate } variant="outlined" className={ classes.submitbutton } style={ { float: "right" } }>
                                Submit
                            </MButton>
                        </CardHeader>
                    </Card>
                </GridItem>

            </GridContainer>
        </Dialog>
    }

    render() {
        const classes = this.props.classes;
        var customStyle = this.props.customStyle;

        if (!customStyle.width) customStyle.width = "150px";
        if (!customStyle.height) customStyle.height = "30px";
        console.log(this.state.selectWebsiteRevenueDuration)
        console.log(this.state.startDate)
        console.log(this.state.endDate)
        return <FormControl variant="outlined" className={ classes.selectFormControl } style={ customStyle }>
            <InputLabel id={ this.props.id } classes={ {
                label: classes.labels
            } }>Select a date</InputLabel>
            <Select className={ classes.rootselect }

                MenuProps={ {
                    className: classes.selectMenu
                } }
                classes={ {
                    select: classes.select
                } }
                id={ this.props.id }
                value={ this.state.selectWebsiteRevenueDuration }
                onChange={ this.handleWebsiteSelect }
                onLoad={ () => { this.updateState(this.state.selectWebsiteRevenueDuration) } }
                label="Select A Date"
            >
                {/* <MenuItem style={{ fontSize: "14px" }}

classes={{
    root: classes.selectMenuItem,
    selected: classes.selectMenuItemSelected
}}
value=""
>
<em>Select a date</em>
</MenuItem> */}
                <MenuItem style={ { fontSize: "14px" } }

                    classes={ {
                        root: classes.selectMenuItem,
                        selected: classes.selectMenuItemSelected
                    } }
                    value="Today"
                >
                    Today
                </MenuItem>
                <MenuItem style={ { fontSize: "14px" } }

                    classes={ {
                        root: classes.selectMenuItem,
                        selected: classes.selectMenuItemSelected
                    } }
                    value="Yesterday"
                >
                    Yesterday
                </MenuItem>
                <MenuItem style={ { fontSize: "14px" } }
                    classes={ {
                        root: classes.selectMenuItem,
                        selected: classes.selectMenuItemSelected
                    } }
                    value="Last7Days"
                >
                    Last 7 Days
                </MenuItem>
                <MenuItem style={ { fontSize: "14px" } }
                    classes={ {
                        root: classes.selectMenuItem,
                        selected: classes.selectMenuItemSelected
                    } }
                    value="ThisMonth"
                >
                    This Month
                </MenuItem>
                <MenuItem style={ { fontSize: "14px" } }
                    classes={ {
                        root: classes.selectMenuItem,
                        selected: classes.selectMenuItemSelected
                    } }
                    value="LastMonth"
                >
                    Last Month
                </MenuItem>
                <MenuItem style={ { fontSize: "14px" } }
                    classes={ {
                        root: classes.selectMenuItem,
                        selected: classes.selectMenuItemSelected
                    } }
                    value="CustomDate"
                >
                    <a style={ { color: "black" } } onClick={ this.handleClickOpen }> Custom Date </a>
                </MenuItem>
            </Select>
            { this.renderCustomDateDialog() }
        </FormControl>



    }
}
const DateSelectionDropdownHOC = withStyles(styles)(DateSelectionDropdown);
export default connect(mapStateToProps, mapDispatchToProps)(DateSelectionDropdownHOC);
