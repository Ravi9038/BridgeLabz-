import React, { Component } from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";

// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
// @material-ui/icons
import Assignment from "@material-ui/icons/Assignment";
import Globe from "@material-ui/icons/Language";
import Dvr from "@material-ui/icons/Dvr";
import Favorite from "@material-ui/icons/Favorite";
import Close from "@material-ui/icons/Close";
import axios from 'axios';
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import DateSelectionDropDown from "../Widgets/DateSelectionDropdown.js";
import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { SERVER_URL } from "../../variables/constants";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'

import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import FormControl from "@material-ui/core/FormControl";
import CardFooter from "components/Card/CardFooter.js";
// material-ui icons
import Menu from "@material-ui/icons/Menu";
import MButton from '@material-ui/core/Button';
import * as moment from 'moment';
const styles = {
  cardIconTitle: {
    ...cardTitle,
    marginTop: "3px",
    marginBottom: "0px"
  },

  rootselect:{
    fontSize:"15px !important",
    fontWeight:"400 !important",
    textAlign:"left !important"
  },
};

const useStyles = makeStyles(styles);
function filterCaseInsensitive(filter, row) {

  const id = filter.pivotId || filter.id;
  if (row[id] !== null) {
    return (
      row[id] !== undefined ?
        String(row[id].toString().toLowerCase())
          .includes(filter.value.toString().toLowerCase())
        :
        true
    );
  }
}
const dataTable = {
  dataRows: []
};
class DowloadReport extends Component {

  constructor(props) {
    super(props);
    this.state = {
     
  }
  }
  componentDidMount = () => {
  

  }

  

  handleWebsiteSelect = (event) => {
    this.setState({ 'selectWebsiteRevenueDuration': event.target.value });
  }
  downloadReport = () => {
    
  }

  handleDropDownChange = (pStartDate,pEndDate)=>{
    this.setState({
      startDate : pStartDate,
      endDate : pEndDate
    });
    this.loadSiteWiseData(pStartDate,pEndDate);
  }


  render() {
    const classes = this.props.classes;
    return <GridContainer>
      <GridItem xs={12}  >
        <Card>
          <CardHeader  color="primary" icon>
            <CardIcon color="primary">
              <Globe style={{ color: "white" }} />

            </CardIcon>


            <h4 className={classes.cardIconTitlecustom} style={{ marginTop: "0px!important" }} >Download Report</h4>

            <DateSelectionDropDown customStyle={{ width: "30%", float: "right", paddingRight: "20px" , marginTop:"-25px"}} onDropDownChange={this.handleDropDownChange}/>

          </CardHeader>
          <CardBody>
            <ReactTable
              data={this.state.data}
              filterable
              columns={[
                {
                  Header: "Sites",
                  accessor: "Sites",
                  Filter: ({ filter, onChange }) => (
                    <input type='text' style={{ textAlign: 'center' }}
                      placeholder="Search Sites"
                      value={filter ? filter.value : ''}
                      onChange={event => onChange(event.target.value)}
                    />
                  ),
                  Footer: (
                    <span><strong>Total</strong></span>
                  )



                },
                {
                  Header: "Date",
                  accessor: "Date",
                  Filter: ({ filter, onChange }) => (
                    <input type='text' style={{ textAlign: 'center' }}
                      placeholder="Search Date"
                      value={filter ? filter.value : ''}
                      onChange={event => onChange(event.target.value)}
                    />
                  ),
                  Footer: (
                    <span><strong></strong></span>
                  )


                },
                {
                  Header: "Revenue",
                  accessor: "Revenue",
                  Filter: ({ filter, onChange }) => (
                    <input type='text' style={{ textAlign: 'center' }}
                      placeholder="Search Revenue"
                      value={filter ? filter.value : ''}
                      onChange={event => onChange(event.target.value)}
                    />
                  ),

                  Footer: (
                    <span><strong>${this.state.totalRevenue}</strong></span>
                  )

                },
                {
                  Header: "Impression",
                  accessor: "Impression",
                  Filter: ({ filter, onChange }) => (
                    <input type='text' style={{ textAlign: 'center' }}
                      placeholder="Search Impression"
                      value={filter ? filter.value : ''}
                      onChange={event => onChange(event.target.value)}
                    />
                  ),

                  Footer: (
                    <span><strong>{this.state.totalImpressions}</strong></span>
                  )
                },
                {
                  Header: "eCPM",
                  accessor: "eCPM",
                  Filter: ({ filter, onChange }) => (
                    <input type='text' style={{ textAlign: 'center' }}
                      placeholder="Search eCPM"
                      value={filter ? filter.value : ''}
                      onChange={event => onChange(event.target.value)}
                    />
                  ),
                  Footer: (
                    <span><strong>${this.state.totaleCpm}</strong></span>
                  )

                }
              ]}
              defaultPageSize={25}
              defaultFilterMethod={filterCaseInsensitive}
              showPaginationTop
              showPaginationBottom={false}
              className="-highlight"
            />
          </CardBody>
          <CardHeader style={{ float: "right!important" }}>
            <MButton onClick={this.downloadReport} color="secondary" variant="outlined" style={{ float: "right" }}>
              Download
         </MButton>
          </CardHeader>
        </Card>
      </GridItem>s
    </GridContainer>
  }
}
const DowloadReportHOC= withStyles(styles)(DowloadReport);
export default connect(mapStateToProps, mapDispatchToProps)(DowloadReportHOC);
