import React, { Component } from "react";
import ReactTable from "react-table";
import axios from 'axios';
// @material-ui/core components

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";

import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";
import DateSelectionDropDown from "../Widgets/DateSelectionDropdown.js";

import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";

import { withStyles } from '@material-ui/styles';
import { connect } from 'react-redux';
import { SERVER_URL } from "../../variables/constants";
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'

// material-ui icons

import MButton from '@material-ui/core/Button';
import Dateicon from '@material-ui/icons/Event';
import * as moment from 'moment';
const styles = {
  cardIconTitle: {
    ...cardTitle,
    marginTop: "15px",
    marginBottom: "0px"
  },
  rootselect:{
    fontSize:"15px !important",
    fontWeight:"400 !important",
    textAlign:"left !important"
  },
  select:{
    padding:"10px"
  }
};

const dataTable = {
  dataRows: []
};
class Publisherwisereports extends Component {

  constructor(props) {
    super(props);
    this.state = {
      selectWebsiteRevenueDuration : this.props.location.state.siteDropDownReport || 'Last7Days',
      tablePageSize : 25,
      totalRevenue : 0.0,
      totalImpressions : 0,
      totaleCpm : 0.0,
      startDate : new moment().utcOffset('GMT-05:30').format("YYYY-MM-DD"),
      endDate : new moment().utcOffset('GMT-05:30').format("YYYY-MM-DD"),
      data : dataTable.dataRows.map((prop, key) => {
        return {
          id: key,
          Date: prop[0],
          Revenue: prop[1],
          Impression: prop[2],
          eCPM: prop[3]
        
        };
      })
    };
  }
  handleWebsiteSelect = (event) =>{
    this.setState({'selectWebsiteRevenueDuration' : event.target.value});
  }

  componentDidMount = () =>{
    this.loadPublisherWiseData(this.state.startDate,this.state.endDate);
    
  }
  openReport = (pReportPage) => {
    this.props.history.push(pReportPage);
  }
  loadPublisherWiseData = (pStartDate,pEndDate) =>{
    const USER_ID = this.props.data.id;
    const USER_ID_ROLE = this.props.data.idRole;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    var url = `${SERVER_URL}/api/revenueprocessor/query`;
    var queryId = "";
    if (USER_ID_ROLE == 1 || USER_ID_ROLE == 4) {
      queryId = "GET_PUBLISHER_DATE_WISE_DATA_FOR_ADMIN";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    paramData.push(startDateParam);
    paramData.push(endDateParam);

    
    requestData.param_data = paramData;
    console.log(requestData);
    
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        var eCPM=0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[0]);
          var lImpressions =  Number(prop[1]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var leCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          if(leCpm !=="NaN"){
            eCPM=leCpm;
          } 
          else{
            eCPM=0; 
          }
          return {
            id: key,
            Name:prop[3],
            Date: prop[4],
            Revenue: prop[0],
            Impression: prop[1],
            eCPM: eCPM
          
          };
        })
        let lTotalECpm = ( lTotalRevenue / (lTotalImpressions / 1000)).toFixed(2);
        this.setState({
          data : lData,
          tablePageSize : lData.length > 25 ? 25 : lData.length,
          totalImpressions : lTotalImpressions,
          totalRevenue : lTotalRevenue.toFixed(2),
          totaleCpm : lTotalECpm
        });
       
      }).catch(function (error) {
        console.log(error);
      });
    }

   else if (USER_ID_ROLE == 5) {
      queryId = "GET_PUBLISHER_DATE_WISE_DATA_FOR_ACCOUNTMANAGER";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = pStartDate;

    endDateParam.type = "string";
    endDateParam.value = pEndDate;

    requestData.query_id = queryId;
    paramData.push(startDateParam);
    paramData.push(endDateParam);

    var userIdParam = {};
    userIdParam.type="int";
    userIdParam.value=USER_ID;
    paramData.push(userIdParam);
    
    requestData.param_data = paramData;
    console.log(requestData);
    
    axios.post(url, requestData, { headers: { "Authorization": TOKEN } })
      .then(res => {
        let lTotalImpressions = 0;
        let lTotalRevenue = 0;
        var eCPM=0;
        let lData = res.data.map((prop, key) => {
          var lRevenue =  Number(prop[0]);
          var lImpressions =  Number(prop[1]);
          lTotalImpressions = lTotalImpressions + lImpressions;
          lTotalRevenue = lTotalRevenue + lRevenue;
          var leCpm = (lRevenue / (lImpressions / 1000)).toFixed(2);
          if(leCpm !=="NaN"){
            eCPM=leCpm;
          } 
          else{
            eCPM=0; 
          }
          return {
            id: key,
            Name:prop[3],
            Date: prop[4],
            Revenue: prop[0],
            Impression: prop[1],
            eCPM: eCPM
          
          };
        })
        let lTotalECpm = ( lTotalRevenue / (lTotalImpressions / 1000)).toFixed(2);
        this.setState({
          data : lData,
          tablePageSize : lData.length > 25 ? 25 : lData.length,
          totalImpressions : lTotalImpressions,
          totalRevenue : lTotalRevenue.toFixed(2),
          totaleCpm : lTotalECpm
        });
       
      }).catch(function (error) {
        console.log(error);
      });
    }
  }
  downloadReport = () => {

    const USER_ID = this.props.data.id;
    const USER_ID_ROLE = this.props.data.idRole;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    var url = `${SERVER_URL}/api/revenueprocessor/query`;
    var queryId = "";
    if (USER_ID_ROLE == 1 || USER_ID_ROLE == 4) {
      queryId = "GET_PUBLISHER_DATE_WISE_DATA_FOR_ADMIN";
    

    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

    var requestData = {};
    var paramData = [];
    var startDateParam = {};
    var endDateParam = {};
    startDateParam.type = "string";
    startDateParam.value = this.state.startDate;

    endDateParam.type = "string";
    endDateParam.value = this.state.endDate;

    requestData.query_id = queryId;
    paramData.push(startDateParam);
    paramData.push(endDateParam);

    var userIdParam = {};
    userIdParam.type="int";
    userIdParam.value=USER_ID;
    paramData.push(userIdParam)
    
    requestData.param_data = paramData;
    console.log(requestData);
    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var name="Publisherwise Report"+" "+ date +" " +time;
     var reportname=name+".xlsx"
    axios({
      url: `${SERVER_URL}/api/users/admin/dashboard/publisherwisereport/download/${USER_ID}`,
      method: 'POST',
      data: requestData,
      responseType: 'blob', // important
  }).then((response) => {
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', reportname);
      document.body.appendChild(link);
      link.click();
  });
}

else if (USER_ID_ROLE == 5) {
  queryId = "GET_PUBLISHER_DATE_WISE_DATA_FOR_ACCOUNTMANAGER";


axios.defaults.headers.common['Authorization'] = TOKEN;
axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';

var requestData = {};
var paramData = [];
var startDateParam = {};
var endDateParam = {};
startDateParam.type = "string";
startDateParam.value = this.state.startDate;

endDateParam.type = "string";
endDateParam.value = this.state.endDate;

requestData.query_id = queryId;
paramData.push(startDateParam);
paramData.push(endDateParam);

var userIdParam = {};
userIdParam.type="int";
userIdParam.value=USER_ID;
paramData.push(userIdParam)

requestData.param_data = paramData;
console.log(requestData);
var today = new Date();
var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
var name="Publisherwise Report"+" "+ date +" " +time;
 var reportname=name+".xlsx"
axios({
  url: `${SERVER_URL}/api/users/admin/dashboard/publisherwisereport/download/${USER_ID}`,
  method: 'POST',
  data: requestData,
  responseType: 'blob', // important
}).then((response) => {
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', reportname);
  document.body.appendChild(link);
  link.click();
});
}

    /* const USER_ID = this.props.data.id;
    const TOKEN = 'Bearer '.concat(this.props.data.token);
    axios.defaults.headers.common['Authorization'] = TOKEN;
    axios.defaults.headers.common['Access-Control-Allow-Headers'] = 'Authorization';
    var requestData = {};
    requestData.reportDuration = this.state.selectWebsiteRevenueDuration;
    axios.post(`${SERVER_URL}/api/users/admin/dashboard/websitewisereport/download/${USER_ID}`, requestData, { headers: { "Authorization": TOKEN, responseType: 'blob' } })
            .then(response => {
                let fileName = "report.xlsx";
                if (window.navigator && window.navigator.msSaveOrOpenBlob) { // IE variant
                    window.navigator.msSaveOrOpenBlob(new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
                        fileName);
                } else {
                    const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
                    const link = document.createElement('a');
                    link.href = url;
                    link.setAttribute('download', fileName);
                    document.body.appendChild(link);
                    link.click();
                }
            }).catch(function (error) {
                console.log(error);
            }); */
  }
filterCaseInsensitive = (filter, row) =>{

    const id = filter.pivotId || filter.id;
    if (row[id] !== null) {
        return (
            row[id] !== undefined ?
                String(row[id].toString().toLowerCase())
                    .includes(filter.value.toString().toLowerCase())
            :
                true
        );
    }
  }
  handleDropDownChange = (pStartDate,pEndDate)=>{
    this.setState({
      startDate : pStartDate,
      endDate : pEndDate
    });
    this.loadPublisherWiseData(pStartDate,pEndDate);
  }
  computeSum = (arr, totalFieldName) => {
    const { length } = arr;
    let count = 0;
    var nf = new Intl.NumberFormat();
    for (let i = 0; i < length; i += 1) {
      count += Number((typeof arr[i][totalFieldName] === 'object')
        ? arr[i][totalFieldName].name : arr[i][totalFieldName] || 0);
    }
    return nf.format(count);
  };
   computeAvg = (arr, totalFieldName) => {
    const { length } = arr;
    const sum = arr.map(element => element.Impression).reduce((a, b) => Number(a) + Number(b), 0);
    console.log(sum);
    const revenue = arr.map(element => element.Revenue).reduce((a, b) => Number(a) + Number(b), 0);
    console.log(revenue);
    let avg=(revenue/(sum/1000)).toFixed(2);
    return avg;
  };
  
  render(){
    const classes = this.props.classes;
    var nf = new Intl.NumberFormat();
    return <GridContainer>
    <GridItem xs={12}>
      <Card>
        <CardHeader color="primary" icon>
            
        <CardIcon color="primary">
       <Dateicon style={{color:"white"}} />
       
       </CardIcon>
          <h4 className={classes.cardIconTitle} style={{marginTop:"0px!important"}} >Publishers Report</h4>
          <DateSelectionDropDown customStyle={{ width: "180px", float: "right", paddingRight: "5px" , marginTop:"-25px"}} onDropDownChange={this.handleDropDownChange} defaultValue={this.state.selectWebsiteRevenueDuration}
            classes={{
              select: classes.select
          }}/>
        </CardHeader>
        <CardBody>
          <ReactTable
            data={this.state.data}
            filterable
            columns={[
              {
                Header: "Name",
                accessor: "Name",
                Filter: ({filter, onChange}) => (
                  <input type='text' style={{textAlign:'left'}}
                         placeholder="Search Publishers"
                         value={filter ? filter.value : ''}
                             onChange={event => onChange(event.target.value)}
                  />
                ),
                Footer:(
                  <span><strong>Total</strong></span>
                ),
                getProps: () => {
                  return {
                      style: {
                          textAlign:'Left'
                      },
                  }
              },
              },
              {
                Header: "Date",
                accessor: "Date",
                Filter: ({filter, onChange}) => (
                  <input type='text' style={{textAlign:'center'}}
                         placeholder="Search Date"
                         value={filter ? filter.value : ''}
                             onChange={event => onChange(event.target.value)}
                  />
                ),  Cell:row=>(
                  <div>{ moment(row.original.Date).format("DD-MM-YYYY")}</div>
             ), 

                Footer:(
                  <span><strong></strong></span>
                )
              },
              {
                Header: "Revenue ($)",
                accessor: "Revenue",
                sortMethod: (a, b) => Number(a)-Number(b),
                Filter: ({filter, onChange}) => (
                  <input type='text' style={{textAlign:'right'}}
                         placeholder="Search Revenue"
                         value={filter ? filter.value : ''}
                             onChange={event => onChange(event.target.value)}
                  />
                ),
                Cell:row=>(
                  <div>{(nf.format(row.original.Revenue))}</div>
             ),
                Footer: columnProps => {return (
                  <span><strong>$ {columnProps.data.length > 0 ? this.computeSum(columnProps.data,"Revenue") : 0}</strong></span>
               )},
               getProps: () => {
                return {
                    style: {
                        textAlign:'Right'
                    },
                }
            }
              
              },
              {
                Header: "Impression",
                accessor: "Impression",
                sortMethod: (a, b) => Number(a)-Number(b),
                Filter: ({filter, onChange}) => (
                  <input type='text' style={{textAlign:'center'}}
                         placeholder="Search Impression"
                         value={filter ? filter.value : ''}
                             onChange={event => onChange(event.target.value)}
                  />
                ),
                Cell:row=>(
                  <div>{(nf.format(row.original.Impression))}</div>
             ),
                Footer: columnProps => {return (
                  <span><strong>{columnProps.data.length > 0 ? this.computeSum(columnProps.data,"Impression") : 0}</strong></span>
               )},
              },
              {
                Header: "eCPM",
                accessor: "eCPM",
                Filter: ({filter, onChange}) => (
                  <input type='text' style={{textAlign:'center'}}
                         placeholder="Search eCPM"
                         value={filter ? filter.value : ''}
                             onChange={event => onChange(event.target.value)}
                  />
                ),
                Footer: columnProps => {return (
                  <span><strong>{columnProps.data.length > 0 ? this.computeAvg(columnProps.data,"eCPM") : 0}</strong></span>
               )},
                
              }
            ]}
            defaultPageSize={this.state.tablePageSize}
            minRows = {1}
            defaultFilterMethod={this.filterCaseInsensitive}
            showPaginationTop 
            showPaginationBottom={false}
            className="-highlight"
          />
        </CardBody>
        <CardHeader style={{float:"right!important"}}>
        <MButton onClick ={this.downloadReport} color="secondary" variant="outlined" style={{float:"right"}}>
           Download
           </MButton>
           <MButton  onClick={() => this.openReport('/admin')}  color="secondary" variant="outlined" style={{ float: "right", marginRight:"10px" }}>
            Back
         </MButton>
        </CardHeader>
      </Card>
    </GridItem>
  </GridContainer>
  }
}
const PublisherwisereportsHOC = withStyles(styles)(Publisherwisereports);
export default connect(mapStateToProps, mapDispatchToProps)(PublisherwisereportsHOC);
