import React from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";

// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
// @material-ui/icons
import Assignment from "@material-ui/icons/Assignment";
import Dvr from "@material-ui/icons/Dvr";
import Favorite from "@material-ui/icons/Favorite";
import Close from "@material-ui/icons/Close";
// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardIcon from "components/Card/CardIcon.js";
import CardHeader from "components/Card/CardHeader.js";

import { dataTable } from "variables/paymentreportdatatable.js";

import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Hidden from "@material-ui/core/Hidden";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import customSelectStyle from "assets/jss/material-dashboard-pro-react/customSelectStyle.js";
import FormControl from "@material-ui/core/FormControl";
// material-ui icons
import Paymenticon from "@material-ui/icons/Money";
import MButton from '@material-ui/core/Button';

const styles = {
  cardIconTitle: {
    ...cardTitle,
    marginTop: "15px",
    marginBottom: "0px"
  }
};

const useStyles = makeStyles(styles);

export default function ReactTables() {
  const [data, setData] = React.useState(
    dataTable.dataRows.map((prop, key) => {
      return {
        id: key,
        Date: prop[0],
        Amount: prop[1],
        TransactionID: prop[2]
      };
    })
  );
  const classes = useStyles();
  return (
    <GridContainer>
      <GridItem lg={2}></GridItem>
      <GridItem xs={12} lg={8}>
        <Card>
          <CardHeader color="primary" icon>
          <CardIcon color="primary">
         <Paymenticon style={{color:"white"}} />
         
         </CardIcon>
            <h4 className={classes.cardIconTitle} style={{marginTop:"0px!important"}} >Payments Report</h4>
            
              <FormControl fullWidth className={classes.selectFormControl} style={{width:"30%",float:"right",paddingRight :"20px",marginTop:"-50px"}}>
              <InputLabel style={{fontSize:"14px",color:"#4e4b4b",fontWeight:"400"}}
                    htmlFor="simple-select"
                    className={classes.selectLabel}
                  >
                Select 
                  </InputLabel> 
           <Select 
             MenuProps={{
               className: classes.selectMenu
             }}
             classes={{
               select: classes.select
             }}
            
           >
             <MenuItem style={{fontSize:"14px"}}
              
               classes={{
                root: classes.selectMenuItem,
                selected: classes.selectMenuItemSelected
               }}
                value="Last 7 Days"
             >
              Last 7 Days
             </MenuItem>
             <MenuItem style={{fontSize:"14px"}}
               classes={{
                 root: classes.selectMenuItem,
                 selected: classes.selectMenuItemSelected
               }}
               value="This Month"
             >
              This Month
             </MenuItem>
             <MenuItem style={{fontSize:"14px"}}
               classes={{
                 root: classes.selectMenuItem,
                 selected: classes.selectMenuItemSelected
               }}
               value="Last Month"
             >
               Last Month
             </MenuItem>
             <MenuItem style={{fontSize:"14px"}}
               classes={{
                 root: classes.selectMenuItem,
                 selected: classes.selectMenuItemSelected
               }}
               value="Custom Date"
             >
              Custom Date
             </MenuItem>
           </Select>
         </FormControl>
          </CardHeader>
          <CardBody>
            <ReactTable
              data={data}
              filterable
              columns={[
               
                {
                  Header: "Date",
                  accessor: "Date",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Date"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                  Footer:(
                    <span><strong>Total</strong></span>
                  )

                },
                {
                  Header: "Amount",
                  accessor: "Amount",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Amount"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                  Footer:(
                    <span><strong>$9.44</strong></span>
                  )

                },
                {
                  Header: "TransactionID",
                  accessor: "TransactionID",
                  Filter: ({filter, onChange}) => (
                    <input type='text' style={{textAlign:'center'}}
                           placeholder="Search Transaction ID"
                           value={filter ? filter.value : ''}
                               onChange={event => onChange(event.target.value)}
                    />
                  ),
                  Footer:(
                    <span><strong></strong></span>
                  )

                }
                
              ]}
              defaultPageSize={5}
              showPaginationTop 
              showPaginationBottom={false}
              className="-highlight"
            />
          </CardBody>
          <CardHeader style={{float:"right!important"}}>
            <MButton color="secondary" variant="outlined" style={{float:"right"}}>
           Download
           </MButton> 
          </CardHeader>
        </Card>
      </GridItem>
      <GridItem lg={2}></GridItem>
    </GridContainer>
  );
}
