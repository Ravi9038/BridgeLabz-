import React,{Component} from "react";
// used for making the prop types of this component
import PropTypes from "prop-types";

// core components
import Button from "components/CustomButtons/Button.js";

import { withStyles,makeStyles } from "@material-ui/core/styles";
import { connect } from 'react-redux';
import { mapStateToProps, mapDispatchToProps } from '../../utils/MapStateDispatchProps.js'

import defaultImage from "assets/img/image_placeholder.jpg";
import defaultAvatar from "assets/img/placeholder.jpg";
import MButton from '@material-ui/core/Button';
// import { makeStyles } from '@material-ui/core/styles';
import styles from "assets/jss/material-dashboard-pro-react/views/dashboardStyle.js";

import axios from 'axios';
import { SERVER_URL } from "../../variables/constants";
const useStyles = makeStyles(styles);

export class ImageUpload extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fileInput : React.createRef(),
      file:null,
      imagePreviewUrl:'',
      avatar:defaultAvatar,
      addButtonProps:'',
      changeButtonProps:'', 
      removeButtonProps:''

    }
  }
  // const [file, setFile] = React.useState(null);
 
  
  // const [imagePreviewUrl, setImagePreviewUrl] = React.useState(
  //   props.avatar ? defaultAvatar : defaultImage
  // );

//  
      
componentDidMount() {
  this.setState({imagePreviewUrl:(this.state.avatar ? defaultAvatar : defaultImage)})
}



    // fileInput = React.createRef();
   handleImageChange = e => {
    e.preventDefault();
    let reader = new FileReader();
    let file = e.target.files[0];
    reader.onloadend = () => {
      this.setState({file:file})
      // setFile(file);
      this.setState({imagePreviewUrl:reader.result})
      // setImagePreviewUrl(reader.result);
    };
    let fileName=file.name;
   
    reader.readAsDataURL(file);
   
    this.props.onImageUpload.call(this,file);

    /* const formData = new FormData();
    formData.append('file', file);
    //  const USER_ID = this.props.data.id;
    // console.log(USER_ID)
    axios.post(`${SERVER_URL}/api/invoice/pdf/4`,formData).then(response => response.data)
      .then((data) => {
        console.log(data);
      }).catch((error) => {
        console.error(error);
      });
 */
  };
  // eslint-disable-next-line
   handleSubmit = e => {
    e.preventDefault();
    // file is the file/image uploaded
    // in this function you can save the image (file) on form submit
    // you have to call it yourself
  };
   handleClick = () => {
      this.state.fileInput.current.click();
  };
   handleRemove = () => {
    // setFile(null);
    this.setState({file:null});
    this.setState({imagePreviewUrl:(this.state.avatar ? defaultAvatar : defaultImage)})
    // setImagePreviewUrl(props.avatar ? defaultAvatar : defaultImage);
    this.state.fileInput.current.value = null;
    //this.setState({fileInput.current.value : null});
  };


 
  
  //  let { avatar, addButtonProps, changeButtonProps, removeButtonProps } = props;
  render(){
    const classes = this.props.classes;
  return <div className="fileinput text-center">
      <input type="file" onChange={this.handleImageChange} ref={this.state.fileInput} accept="application/pdf,image/*"/>
      <div className={"thumbnail" + (this.state.avatar ? " img-circle" : "")}>
        <embed src= {this.state.imagePreviewUrl} type="application/pdf" style={{width:"100%", height:"100%"}} />

      </div>
      <div>  
        {this.state.file === null ? (
          <MButton variant="outlined" style={{ color:" #4caf50",border: "1px solid #4caf50"}} {...this.state.addButtonProps} onClick={() => {this.handleClick()}} > 
            {this.state.avatar ? "Add Invoice" : "Upload"}
          </MButton>
        ) : (
          <span>
            <MButton variant="outlined" color="primary" {...this.state.changeButtonProps} onClick={() => this.handleClick()}>
              Change
            </MButton>
            {this.state.avatar ? <br /> : null}
            <MButton variant="outlined" color="primary" {...this.state.removeButtonProps} onClick={() => this.handleRemove()}>
              <i className="fas fa-times" /> Remove
            </MButton>
          </span>
        )}
      </div>
    </div>
  }
}

ImageUpload.propTypes = {
  avatar: PropTypes.bool,
  addButtonProps: PropTypes.object,
  changeButtonProps: PropTypes.object,
  removeButtonProps: PropTypes.object
};

const ImageUploadHOC = withStyles(styles)(ImageUpload);
export default connect(mapStateToProps, mapDispatchToProps)(ImageUploadHOC);
