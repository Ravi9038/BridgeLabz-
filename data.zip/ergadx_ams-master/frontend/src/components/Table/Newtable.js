import React from "react";
// react component for creating dynamic tables
import ReactTable from "react-table";

// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";

// core components
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import { dataTable } from "variables/general.js";

import { cardTitle } from "assets/jss/material-dashboard-pro-react.js";

const styles = {
  cardIconTitle: {
    ...cardTitle,
    marginTop: "15px",
    marginBottom: "0px"
  }
};

const useStyles = makeStyles(styles);

export default function ReactTables() {
  const [data, setData] = React.useState(
    dataTable.dataRows.map((prop, key) => {
      return {
        id: key,
        name: prop[0],
        position: prop[1],
        office: prop[2],
        age: prop[3],
        
      };
    })
  );
  const classes = useStyles();
  return (
    <GridContainer>
      <GridItem xs={12} lg={12}>
       
            <ReactTable 
              data={data}
              filterable
              columns={[
                {
                  Header: "Website Name",
                  accessor: "Website Name"
                },
                {
                  Header: "Amount",
                  accessor: "Amount"
                },
                {
                  Header: "Impressions",
                  accessor: "Impressions"
                },
                {
                  Header: "cpm",
                  accessor: "cpm"
                }
                
              ]}
              defaultPageSize={5}
              showPaginationTop
              showPaginationBottom={false}
              className="-striped -highlight"
            />
         
      </GridItem>
    </GridContainer>
  );
}
