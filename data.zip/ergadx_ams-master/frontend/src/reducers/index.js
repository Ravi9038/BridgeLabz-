import {combineReducers} from 'redux';
import UserData from './UserData';
export default combineReducers({
    UserData
});