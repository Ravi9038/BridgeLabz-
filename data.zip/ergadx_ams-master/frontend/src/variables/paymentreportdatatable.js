import React from "react";

// @material-ui/icons
import CardTravel from "@material-ui/icons/CardTravel";
import Extension from "@material-ui/icons/Extension";
import Fingerprint from "@material-ui/icons/Fingerprint";
import FlightLand from "@material-ui/icons/FlightLand";
import Build from "@material-ui/icons/Build";

// core components
import CustomDropdown from "components/CustomDropdown/CustomDropdown.js";

// ##############################
// // // data for datatables.net in DataTables view
// #############################

const dataTable = { 
  headerRow: [ "Date", "Amount", "Transcation ID"],
  footerRow: [ "Date", "Amount", "Transcation ID"],
  dataRows: [
    ["04-10-2020", "$9.44	", "131214"],
    ["05-10-2020", "$9.44	", "131215"],
    ["06-10-2020", "$9.44	", "131216"],
    ["07-10-2020", "$9.44	", "131217"],
    ["08-10-2020", "$9.44	", "131218"]
  ] 
};

export {

  // data for datatables.net in DataTables view
  dataTable
};
