import React from "react";

// @material-ui/icons
import CardTravel from "@material-ui/icons/CardTravel";
import Extension from "@material-ui/icons/Extension";
import Fingerprint from "@material-ui/icons/Fingerprint";
import FlightLand from "@material-ui/icons/FlightLand";
import Build from "@material-ui/icons/Build";

// core components
import CustomDropdown from "components/CustomDropdown/CustomDropdown.js";

// ##############################
// // // data for datatables.net in DataTables view
// #############################

const dataTable = {
  
  headerRow: ["Sites", "Date", "Revenue", "Impression", "eCPM"],
  footerRow: ["Sites", "Date", "Revenue", "Impression", "eCPM"],
  dataRows: [
    ["epapergujarathsamachar", "04-10-2020", "$9.44	", "58.4K","$0.16"],
    ["newspaper.pudari.com", "05-10-2020", "$9.44	", "58.4K","$0.16"],
    ["webmilap.com", "06-10-2020", "$9.44	", "58.4K","$0.16"],
    ["www.epaperlokmat.in", "07-10-2020", "$9.44	", "58.4K","$0.16"],
    ["epaper.heraldgoa.in", "08-10-2020", "$9.44	", "58.4K","$0.16"]
  ]
};

export {

  // data for datatables.net in DataTables view
  dataTable
};
