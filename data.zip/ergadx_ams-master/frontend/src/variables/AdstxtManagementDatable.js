import React from "react";

// @material-ui/icons
import CardTravel from "@material-ui/icons/CardTravel";
import Extension from "@material-ui/icons/Extension";
import Fingerprint from "@material-ui/icons/Fingerprint";
import FlightLand from "@material-ui/icons/FlightLand";
import Build from "@material-ui/icons/Build";

// core components
import CustomDropdown from "components/CustomDropdown/CustomDropdown.js";

// ##############################
// // // data for datatables.net in DataTables view
// #############################

const dataTable = { 
  headerRow: [ "Sl No","Staus","Domain Name", "Actions"],
  footerRow: [ "Sl No","Staus","Domain Name", "Actions"],
  dataRows: [
    ["1","Lokmat.com"],
    ["2","Udayavani.com"],
    ["3","Domain Name3"],
    ["4","Domain Name3"],
    ["5","Domain Name5"],
  ] 
};

export {

  // data for datatables.net in DataTables view
  dataTable
};
