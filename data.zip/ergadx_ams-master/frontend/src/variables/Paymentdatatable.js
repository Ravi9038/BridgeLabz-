import React from "react";


// ##############################
// // // data for datatables.net in DataTables view
// #############################
 
const dataTable = {  
  headerRow: ["Select", "Publisher Name", "Invoice Date", "Net Amount", "GST","TDS","Gross Payable","Status", 
              "Month/Year","Gross USD","Net USD","USD To INR","Net INR","Status","Action","Month","Year",
              "Currency","In INR","Action"],
  footerRow:["Select", "Publisher Name", "Invoice Date", "Net Amount", "GST","TDS","Gross Payable","Status", 
            "Month/Year","Gross USD","Net USD","USD To INR","Net INR","Status","Action","Month","Year",
            "Currency","In INR","Action"],
  dataRows: [
    ["Publisher 1",  "25-10-2020","1000000","10000","1000","11000","November","300","200","73.10","","Settled","November","2020","300","300",],
    ["Publisher 2",  "26-10-2020","1000000","10000","1100","11000","October","300","200","73.10","","Pending","October","2020","400","400",],
    ["Publisher 3",  "27-10-2020","1000000","10000","1200","11000","September","300","200","73.10","","Settled","September","2020","500","500",],
    ["Publisher 4",  "28-10-2020","1000000","10000","1300","11000","April","300","200","73.10","","Pending","April","2020","600","600",],
    ["Publisher 5", "29-10-2020","1000000","10000","1400","11000","March","300","200","73.10","","Settled","March","2019","700","700",],
    
  ] 
};

export {

  // data for datatables.net in DataTables view
  dataTable
};
