export const SERVER_URL = document.location.origin;
