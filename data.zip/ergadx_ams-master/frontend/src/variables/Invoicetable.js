import React from "react";

// @material-ui/icons
import CardTravel from "@material-ui/icons/CardTravel";
import Extension from "@material-ui/icons/Extension";
import Fingerprint from "@material-ui/icons/Fingerprint";
import FlightLand from "@material-ui/icons/FlightLand";
import Build from "@material-ui/icons/Build";

// core components
import CustomDropdown from "components/CustomDropdown/CustomDropdown.js";

// ##############################
// // // data for datatables.net in DataTables view
// #############################
 
const dataTable = { 
  headerRow: [ "S No", "Invoice Name", "Invoice Date","Net Amount (Rs.)","Tax (Rs.)","Total Amount(Rs.)","Status"],
  footerRow:  [ "S No", "Invoice Name", "Invoice Date","Net Amount (Rs.)","Tax (Rs.)","Total Amount(Rs.)","Status"],
  dataRows: [
    ["1", "Invoice1", "13-10-2020","10000","1000","10000","Paid"],
    ["2", "Invoice2", "13-10-2020","10000","1000","10000","Paid"],
    ["3", "Invoice3", "13-10-2020","10000","1000","10000","Paid"],
    ["4", "Invoice4", "13-10-2020","10000","1000","10000","Paid"],
    ["5", "Invoice5", "13-10-2020","10000","1000","10000","Paid"],
   
  ]
};

export {

  // data for datatables.net in DataTables view
  dataTable
};
