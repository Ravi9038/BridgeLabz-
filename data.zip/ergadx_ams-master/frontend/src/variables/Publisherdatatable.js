import React from "react";


// ##############################
// // // data for datatables.net in DataTables view
// #############################
  
const dataTable = { 
  headerRow: ["Sl No","Publisher Name", "Contact Person", "Contact Number", "Email ID","Actions","Level","Designation","Reporting To","Action",
              "Website Count","1M Rank","3M Rank","Life Time Rank","Action","Publisher Share","Staus","Domain Name", "Actions","Date","Particular","Debit","Credit","Balance"],
  footerRow:["Sl No","Publisher Name", "Contact Person", "Contact Number", "Email ID","Actions","Level","Designation","Reporting To","Action",
            "Website Count","1M Rank","3M Rank","Life Time Rank","Action","Publisher Share","Staus","Domain Name", "Actions","Date","Particular","Debit","Credit","Balance"],
  dataRows: [
    ["1","Lokmat", "Person 1", "9999999999","xyz@gmail.com","Level 1","Designation 1","Reporting Person1","100","10","20","30","20%","Lokmat.com","03-11-2020","Invoice No.30 Net Amount","0","50,000","50,000"],
    ["2","Lokmat", "Person 2", "8888888888","xyz@gmail.com","Level 1","Designation 1","Reporting Person1","100","10","20","30","10%","Udayavani.com","03-11-2020","Invoice No.30 GST","0","9,000","59,000"],
    ["3","Lokmat", "Person 3", "7777777777","xyz@gmail.com","Level 1","Designation 1","Reporting Person1","100","10","20","30","30%","Domain Name3","03-11-2020","Invoice No.30 Net TDS","5,000","0","54,000"],
    ["4","Lokmat", "Person 4", "6666666666","xyz@gmail.com","Level 1","Designation 1","Reporting Person1","100","10","20","30","5%","Domain Name4","03-11-2020","Payment Trans Id 12345","54,000","0","0"],
   
  ] 
};

export {

  // data for datatables.net in DataTables view
  dataTable
};
