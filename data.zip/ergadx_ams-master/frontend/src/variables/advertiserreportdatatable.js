import React from "react";

// @material-ui/icons
import CardTravel from "@material-ui/icons/CardTravel";
import Extension from "@material-ui/icons/Extension";
import Fingerprint from "@material-ui/icons/Fingerprint";
import FlightLand from "@material-ui/icons/FlightLand";
import Build from "@material-ui/icons/Build";

// core components
import CustomDropdown from "components/CustomDropdown/CustomDropdown.js";

// ##############################
// // // data for datatables.net in DataTables view
// #############################

const dataTable = {
  headerRow: ["Name", "Date", "Revenue", "Impression", "eCPM"],
  footerRow: ["Name", "Date", "Revenue", "Impression", "eCPM"],
  dataRows: [
    ["Advertiser1", "04-10-2020", "$9.44	", "58.4K","$0.16"],
    ["Advertiser2", "05-10-2020", "$9.44	", "58.4K","$0.16"],
    ["Advertiser3", "06-10-2020", "$9.44	", "58.4K","$0.16"],
    ["Advertiser4", "07-10-2020", "$9.44	", "58.4K","$0.16"],
    ["Advertiser5", "08-10-2020", "$9.44	", "58.4K","$0.16"]
  ]
};

export {

  // data for datatables.net in DataTables view
  dataTable
};
