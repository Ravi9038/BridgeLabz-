import DashboardIcon from "@material-ui/icons/Dashboard";
import Profileicon from "@material-ui/icons/Person";
import Logouticon from "@material-ui/icons/ArrowBack";
import LoginPage from "views/Pages/LoginPage.js";
import Paymenticon from "@material-ui/icons/Payment";
import Publishericon from "@material-ui/icons/Group";
import Advertisericon from "@material-ui/icons/RecordVoiceOver";
import RevenueShareIcon from "@material-ui/icons/Equalizer";
import AdsTxtMangement from "@material-ui/icons/Settings";
import Dashboard from "views/Dashboard/Dashboard.js";
import PublisherDashboard from "views/Dashboard/PublisherDashboard.js";
import PublisherDetails from "views/Publisher/PublisherDetail.js";

import Invoices from "views/Publisher/Invoices.js";
import InvoiceDashboard from "views/Publisher/InvoiceDash.js";
import Receipts from "views/Publisher/Receipts.js";
import Payments from "views/Publisher/Payments.js";
import Payment from "views/Publisher/PaymentDetails.js";
import AdvertiserDetails from "views/Publisher/AdvertiserDetails.js";
import RevenueShare from "views/Publisher/RevenueShare.js";
import AdsTxtManagement from "views/Publisher/AdsTxtManagement.js"
import Websites from "views/Publisher/Websites.js"
import Profile from "views/Publisher/Profile.js";
import Reports from "views/Publisher/Reports.js";
import AdsTxtManager from "views/Publisher/AdsTxtManager.js";
import SiteReport from "views/Reports/Sitereports.js";
import AdunitView from "views/Publisher/AdunitView.js";
import Chart from "views/Publisher/Graph.js"
import DatewiseReport from "views/Reports/Datewisereports.js";
import MediaWiseReport from "views/Reports/VideoDisplayreport.js";
import AdvertiserwiseReport from "views/Reports/Advertiserwisereports.js"
import PublisherwiseReport from "views/Reports/Publisherwisereports.js"
import PaymwntwiseReport from "views/Reports/Paymentwisereports.js"
import AdvertiserWiseReports from "views/Publisher/AdvertiserWiseReports.js"
import EditUser from "views/Publisher/EditUser.js"
import AddUser from "views/Publisher/AddUser.js"
import AdvertiserWebsiteMap from "views/Publisher/AdvertiserWebsiteMap.js"
import { Receipt } from "@material-ui/icons";

export var adminRoutes = [
  {
    path: "/login-page",
    name: "Login Page",
    rtlName: "هعذاتسجيل الدخول",
    mini: "L",
    rtlMini: "هعذا",
    invisible:true,
    component: LoginPage,
    layout: "/admin"
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    rtlName: "لوحة القيادة",
    icon: DashboardIcon,
    component: Dashboard,
    layout: "/admin"
  },
  {
    path: "/advertiser",
    name: "Advertisers",
    icon: Advertisericon,
    component: AdvertiserDetails,
    layout: "/admin"
  },
  {
    path: "/publisher",
    name: "Publishers",
    icon: Publishericon,
    component: PublisherDetails,
    layout: "/admin"
  },

  {
    path: "/invoice",
    name: "Invoice",
    icon: Receipt,
    component: InvoiceDashboard,
    layout: "/admin"
  },
  {
    path: "/receipts",
    name: "Receipts",
    icon: Receipt,
    component: Receipts,
    layout: "/admin"
  },
  
  {
    path: "/adsTxtManager",
    name: "AdsTxtManager",
    icon: Receipt,
    component: AdsTxtManager,
    layout: "/admin"
  },
  {
    path: "/reports",
    name: "Reports",
    icon: Receipt,
    component: Reports,
    layout: "/admin"
  },
 
  {
    path: "/websites",
    name: "Websites",
    icon: Receipt,
    component: Websites,
    layout: "/admin"
  },
  {
    path: "/adunitView",
    name: "AdunitView",
    icon: Receipt,
    component: AdunitView,
    layout: "/admin"
  },
 
  {
    path: "/payment",
    name: "Payments",
    icon: Paymenticon,
    component: Payment,
    layout: "/admin"
  },
  {
    name: "Logout",
    icon: Logouticon,
    layout: "/admin"
  },
  

  {
    path: "/sitereport",
    name: "Site Report",
    invisible: true,
    component: SiteReport,
    layout: "/admin"
  },
  
  {
    path: "/VideoDisplayreport",
    name: "Media Report",
    invisible: true,
    component: MediaWiseReport,
    layout: "/admin"
  },
  {
    path: "/datewisereport",
    name: "Date Wise Report",
    invisible: true,
    component: DatewiseReport,
    layout: "/admin"
  },
  {
    path: "/advertiserwisereport",
    name: "Advertiser Wise Report",
    invisible: true,
    component: AdvertiserwiseReport,
    layout: "/admin"
  },
  {
    path: "/publisherwisereport",
    name: "Publisher Wise Report",
    invisible: true,
    component: PublisherwiseReport,
    layout: "/admin"
  },

  {
    path: "/paymentwisereport",
    name: "Payment Wise Report",
    invisible: true,
    component: PaymwntwiseReport,
    layout: "/admin"
  }
  ];


export var publisherRoutes = [{
  path: "/publisher-dashboard",
  name: "Dashboard",
  rtlName: "لوحة القيادة",
  icon: DashboardIcon,
  component: PublisherDashboard,
  layout: "/admin"
},
{
  path: "/publisher-profile",
  name: "Profile",
  rtlName: "لوحة القيادة",
  icon: DashboardIcon,
  component: Profile,
  layout: "/admin"
},

{
  path: "/login-page",
  name: "Login Page",
  rtlName: "هعذاتسجيل الدخول",
  mini: "L",
  rtlMini: "هعذا",
  invisible:true,
  component: LoginPage,
  layout: "/auth"
},
{
  path: "/invoice",
  name: "Invoice",
  icon: Receipt,
  component: InvoiceDashboard,
  layout: "/admin"
},
{
  name: "Logout",
  icon: Logouticon,
  layout: "/auth"
} 

];
var dashRoutes = [
  {
    path: "/login-page",
    name: "Login Page",
    rtlName: "هعذاتسجيل الدخول",
    mini: "L",
    rtlMini: "هعذا",
    component: LoginPage,
    layout: "/auth"
  },
  {
    path: "/publisher-dashboard",
    name: "Dashboard",
    rtlName: "لوحة القيادة",
    icon: DashboardIcon,
    component: PublisherDashboard,
    layout: "/admin"
  },
  {
    path: "/publisher-profile",
    name: "Profile",
    rtlName: "لوحة القيادة",
    icon: DashboardIcon,
    component: Profile,
    layout: "/admin"
  },
  {
    path: "/sitereport",
    name: "Site Report",
    invisible: true,
    component: SiteReport,
    layout: "/admin"
  },
  {
    path: "/VideoDisplayreport",
    name: "Media Report",
    invisible: true,
    component: MediaWiseReport,
    layout: "/admin"
  },
  {
    path: "/datewisereport",
    name: "Date Wise Report",
    invisible: true,
    component: DatewiseReport,
    layout: "/admin"
  },
  {
    path: "/advertiserwisereport",
    name: "Advertiser Wise Report",
    invisible: true,
    component: AdvertiserwiseReport,
    layout: "/admin"
  },
  {
    path: "/publisherwisereport",
    name: "Publisher Wise Report",
    invisible: true,
    component: PublisherwiseReport,
    layout: "/admin"
  },
  {
    path: "/paymentwisereport",
    name: "Payment Wise Report",
    invisible: true,
    component: PaymwntwiseReport,
    layout: "/admin"
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    rtlName: "لوحة القيادة",
    icon: DashboardIcon,
    component: Dashboard,
    layout: "/admin"
  },
  {
    path: "/advertiser",
    name: "Advertisers",
    icon: Advertisericon,
    component: AdvertiserDetails,
    layout: "/admin"
  },
  {
    path: "/publisher",
    name: "Publishers",
    icon: Publishericon,
    component: PublisherDetails,
    layout: "/admin"
  },

  {
    path: "/invoice", 
    name: "Invoice",   
    icon: Receipt,
    component: InvoiceDashboard, 
    layout: "/admin"
  },
  {
    path: "/receipts", 
    name: "Receipts",
    icon: Receipt,
    component: Receipts,
    layout: "/admin"
  },
  {
    path: "/reports",
    name: "Reports",
    icon: Receipt,
    component: Reports,
    layout: "/admin"
  },
  
  {
    path: "/adsTxtManager",
    name: "AdsTxtManager",
    icon: Receipt,
    component: AdsTxtManager,
    layout: "/admin"
  },
  {
    path: "/websites",
    name: "Websites",
    icon: Receipt,
    component: Websites,
    layout: "/admin"
  },
 
  {
    path: "/adunitView",
    name: "AdunitView",
    icon: Receipt,
    component: AdunitView,
    layout: "/admin"
  },
 
  {
    path: "/payment",
    name: "Payments",
    icon: Paymenticon,
    component: Payment,
    layout: "/admin"
  },

  {
    name: "Logout",
    icon: Logouticon,
    layout: "/admin"
  } 
];
export default dashRoutes;
