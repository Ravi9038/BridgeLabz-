import React, { Component } from 'utils/node_modules/react'
import axios from 'utils/node_modules/axios';
 class Service extends Component {
     apiCall(method,postData){
       // return axios.post(Config.url+method,qs.stringify(postData), axiosConfig.headers);

        return  axios({
            method: 'post',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            url: ""+method,
            data: postData
          });
    }
}

export default Service
  