import { BorderTop } from "@material-ui/icons";
import { whiteColor } from "assets/jss/material-dashboard-pro-react";
import {
  successColor,
  tooltip,
  cardTitle,
  grayColor
} from "assets/jss/material-dashboard-pro-react.js";

import hoverCardStyle from "assets/jss/material-dashboard-pro-react/hoverCardStyle.js";

const dashboardStyle = {
  select: {
    padding: "12px"
  },
  ...hoverCardStyle,
  tooltip,
  cardTitle: {
    ...cardTitle,
    marginTop: "0px",
    marginBottom: "3px"
  },
  CustomappBar: {
    display: "flex",
    flex: " 0 0 64px",
    background: "#ebebeb",
    height: " 64px",
    borderBottom: "1px solid rgb(0 0 0 / 10%)",


  },
  CloseButton: {
    backgroundColor: "white",
    borderRadius: "30px",
    color: "black",
    width: "41px",
    height: "41px",

    minWidth: "41px",
    paddingLeft: "12px",
    paddingRight: "12px"
  },
  SliderTitle: {
    fontSize: "16px",
    paddingLeft: "30px",
    color: "black !important",
    fontWeight: "400"

  },
  headingstyle: {
    marginTop: "10px !important"
  },
  rootselect: {
    fontSize: "14px !important",
    fontWeight: "400 !important",
    textAlign: "left !important"
  },
  cardheight: {
    height: "379px !important"
  },
  backgroundcolortr: {
    backgroundColor: "#0b4abdf7",
    color: "white",
    textAlign: "right",
    fontWeight: "400"

  },
  backgroundcolorhigh: {
    backgroundColor: "#d6d4d4d1",
    color: "#4e4b4b",
    textAlign: "right",
    fontWeight: "400"

  },
  backgroundcolorSecondhigh: {
    backgroundColor: "#7c95c3",
    color: "#fff",
    textAlign: "right",
    fontWeight: "400"

  },
  backgroundcolorthirdhigh: {
    backgroundColor: "#7c95c3cf",
    color: "#fff",
    textAlign: "right",
    fontWeight: "400"

  },
  backgroundcolorfourthhigh: {
    backgroundColor: "#d6d4d4a3",
    color: "#4e4b4b",
    textAlign: "right",
    fontWeight: "400"

  },
  textright: {
    fontWeight: "400",
    textAlign: "right",
    color: "#4e4b4b",
    backgroundColor: "#cac2c230"

  },

  textcenter: {
    fontWeight: "400",
    textAlign: "center",
    color: "#4e4b4b",
    backgroundColor: "#cac2c230"

  },
  cardIconTitlecustom: {
    marginTop: "3px!important"
  },
  thead: {
    color: "#4e4b4b !important",
    fontWeight: "400!important",
  },
  tableheaderfixed: {
    position: "sticky",
    top: "0"
  },
  Tablefixed: {
    height: "330px !important"
  },
  tableheader: {
    fontSize: "15px !important"
  },
  borderfirstcol: {
    borderTop: "1px solid rgba(0,0,0,.12)",
    fontWeight: "400",
    color: "#4e4b4b"

  },
  cardIconTitle: {
    ...cardTitle,
    marginTop: "15px",
    marginBottom: "0px"
  },
  cardProductTitle: {
    ...cardTitle,
    marginTop: "0px",
    marginBottom: "3px",
    textAlign: "center"
  },
  cardCategory: {
    color: grayColor[0],
    fontSize: "14px",
    paddingTop: "10px",
    marginBottom: "0",
    marginTop: "0",
    margin: "0"
  },
  cardProductDesciprion: {
    textAlign: "center",
    color: grayColor[0]
  },
  stats: {
    color: grayColor[0],
    fontSize: "12px",
    lineHeight: "22px",
    display: "inline-flex",
    "& svg": {
      position: "relative",
      top: "4px",
      width: "16px",
      height: "16px",
      marginRight: "3px"
    },
    "& .fab,& .fas,& .far,& .fal,& .material-icons": {
      position: "relative",
      top: "4px",
      fontSize: "16px",
      marginRight: "3px"
    }
  },
  productStats: {
    paddingTop: "7px",
    paddingBottom: "7px",
    margin: "0"
  },
  successText: {
    color: successColor[0]
  },
  upArrowCardCategory: {
    width: 14,
    height: 14
  },
  underChartIcons: {
    width: "17px",
    height: "17px"
  },
  price: {
    color: "inherit",
    "& h4": {
      marginBottom: "0px",
      marginTop: "0px"
    },

  },
  rootslider: {
    '& .MuiGrid-container': {
      width: "100% !important",
      margin: "0 0px"
    },
    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "6px",
      paddingRight: "6px"
    },
    '& .MuiGrid-grid-lg-6': {
      padding: "0 3px !important"
    },
    '& .MuiGrid-grid-md-6': {
      padding: "0 3px !important"
    },
    '& .MuiDialog-paperFullScreen': {
      width: "30% !important",
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important",
      float: "right !important",
    },
    '& .MuiAppBar-positionFixed': {
      position: "relative!important",
    },
    '& .MuiDialog-scrollPaper': {
      display: "block !important"
    },
    '& .MuiAppBar-colorPrimary': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important",
      width: "30% !important"

    },
    '& .MuiAppBar-root': {
      width: "30% !important"
    }
  },
  '& .MuiToolbar-gutters': {
    marginLeft: "24px",
    marginRight: "24px"
  },
  '& .makeStyles-SliderTitle-167  ': {
    fontSize: "18px!important",

  },
  '& .MuiGrid-container': {
    paddingLeft: "6px",
    paddingRight: "6px"
  },



  '& .MuiButton-label': {
    fontSize: "0.875rem",
    fontWeight: "bold"
  },

  heading: {
    color: "black!important"
  },
  submitbutton: {
    color: " #4caf50",
    border: "1px solid #4caf50"
  },
  '& .fileinput': {
    borderRadius: "0% !important",
    width: "100% !important"
  }
};

export default dashboardStyle;
