const PublisherStyles = {
  PageCreationSlider: {
    '& a ': {
      color: " #f50057 !important"

    },

    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },

    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },
    '& .MuiPaper-root': {
      backgroundColor: "#fff!important"
    },
    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",
      boxShadow: "none!important"

    },

    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important"
    },
    '& .MuiPaper-elevation4': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important"
    },
    '&  .MuiFormLabel-root.Mui-disabled': {
      color: "#3f51b5"
    },
    '& .MuiInputBase-root.Mui-disabled ': {
      color: " #000000"

    },
    '& .MuiGrid-grid-md-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2 .MuiInputBase-input ': {

      fontSize: "14px"
    },
    '& .MuiGrid-grid-lg-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-2 .MuiInputBase-input ': {

      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-12': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-1': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-1': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-12': {
      padding: "0 5px !important"
    },


    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "10px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },

    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)",
      color: " #3f51b5"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px",
      fontSize: "14px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",

      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },


    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },

    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",
      boxShadow: "none!important"

    },

    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important"
    },
    '& .MuiPaper-elevation4': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important"
    },

  },
  rootslider: {
    '& a ': {
      color: " #f50057 !important"

    },

    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },

    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },
    '& .MuiPaper-root': {
      backgroundColor: "#fff!important"
    },
    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",
      boxShadow: "none!important"

    },

    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important"
    },
    '& .MuiPaper-elevation4': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important"
    },
    '&  .MuiFormLabel-root.Mui-disabled': {
      color: "#3f51b5"
    },
    '& .MuiInputBase-root.Mui-disabled ': {
      color: " #000000"

    },
    '& .MuiGrid-grid-md-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2 .MuiInputBase-input ': {

      fontSize: "14px"
    },
    '& .MuiGrid-grid-lg-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-2 .MuiInputBase-input ': {

      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-12': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-1': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-1': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-12': {
      padding: "0 5px !important"
    },


    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "10px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },

    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)",
      color: " #3f51b5"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px",
      fontSize: "14px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },


    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },

    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",
      boxShadow: "none!important"

    },

    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important"
    },
    '& .MuiPaper-elevation4': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important"
    },

  },
  PublisherViewSlider: {

    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "6px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },

    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)",
      color: " #3f51b5"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px",
      fontSize: "15px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },


    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },
    '& .MuiPaper-root': {
      backgroundColor: "#fff!important"
    },
    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",
      boxShadow: "none!important"

    },

    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important"
    },
    '& .MuiPaper-elevation4': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important"
    },
    '&  .MuiFormLabel-root.Mui-disabled': {
      color: "#3f51b5"
    },
    '& .MuiInputBase-root.Mui-disabled ': {
      color: " #000000"

    },
    '& .MuiGrid-grid-md-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2 .MuiInputBase-input ': {

      fontSize: "14px"
    },
    '& .MuiGrid-grid-lg-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-2 .MuiInputBase-input ': {

      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-12': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-1': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-1': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-12': {
      padding: "0 5px !important"
    },

  },
  SlnoCenter: {
    textAlign: "center!important"
  },
  CardHeading: {
    textAlign: "center",
    color: "black!important",
  },
  MainHeading: {
    textAlign: "left",
    color: "#3c4858!important",

  },
  CloseButton: {
    backgroundColor: "white",
    borderRadius: "30px",
    color: "black",
    width: "41px",
    height: "41px",

    minWidth: "41px",
    paddingLeft: "12px",
    paddingRight: "12px"
  },
  SliderTitle: {
    fontSize: "16px",
    paddingLeft: "30px",
    color: "black !important",
    fontWeight: "400"

  },
  CustomappBar: {
    display: "flex",
    flex: " 0 0 64px",
    background: "#ebebeb",
    height: " 64px",
    borderBottom: "1px solid rgb(0 0 0 / 10%)",


  },
  heading: {
    color: "black!important"
  },
  SliderBackground: {
    backgroundColor: "#dddddd!important"
  },
  TextCenter: {
    textAlign: "center"
  },
  SmallText: {
    fontSize: "12px",
    color: "#000000de",
    fontWeight: "300"
  },
  headingStyle: {
    marginBottom: "0px",
    fontSize: "1.1em",
    fontWeight: "500",
    marginTop: "25px",
  },
  root2: {

    float: "right"
  },
  checkboxroot: {
    '& .MuiSvgIcon-root': {
      width: "0.7em",
      height: "0.7em"
    },
  },
  ActionsButton: {
    '& .MuiButton-root': {
      minWidth: " 0px"
    },
    '& .MuiButton-root': {
      height: "0px"
    }

  },
  ButtonRightCard: {
    float: "right",
  },

  CreateContactslider: {

    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "6px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },

    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)",
      color: " #3f51b5"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },


    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },
    '& .MuiPaper-root': {
      backgroundColor: "#fff!important"
    },
    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",
      boxShadow: "none!important"

    },

    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important"
    },
    '& .MuiPaper-elevation4': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important"
    },
    '& .MuiDialog-container': {
      width: "40%",
      float: "right"
    }
  },
  margin: {
    paddingTop: "10px",
    fontSize: "14px",
  },
  marginSlno: {
    paddingTop: "10px",
    '& .MuiInputBase-input': {
      fontSize: "14px",
      textAlign: "center"
    }

  },
  submitbutton: {
    color: " #4caf50",
    border: "1px solid #4caf50"
  },
  CardButton: {
    textAlign: "center",
    color: "black!important",
    cursor: 'pointer',
    fontWeight: "400",
    width: "100%",
    backgroundColor: "#ffbc00",
    fontSize: "18px",
    border: "none",
    padding: "10px",
    verticalAlign: " middle",
    borderRadius: "3px"


  },
  Accordianinput: {
    '& .MuiAccordionSummary-root': {
      boxShadow: "0 2px 5px 0 rgba(0,0,0,0.16), 0 2px 10px 0 rgba(0,0,0,0.12) !important"
    },
    '& .MuiAccordionDetails-root': {
      padding: "10px 16px 10px"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-8': {
      padding: "0 5px !important",

    },
    '& .MuiGrid-grid-lg-2 .MuiInputBase-input ': {
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-2 .MuiInputBase-input ': {
      textAlign: "center"
    },

    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important",
      textAlign: "center"
    },

    '& .MuiGrid-grid-lg-8': {
      padding: "0 5px !important"
    },
    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)",
      color: " #3f51b5"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "0px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",

    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .MuiGrid-grid-lg-1': {
      padding: "0 5px !important",
      textAlign: "center"

    },
    '& .MuiGrid-grid-lg-1 .MuiInputBase-input ': {
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-1 .MuiInputBase-input ': {
      textAlign: "center"
    },

    '& .MuiGrid-grid-md-1': {
      padding: "0 5px !important",
      textAlign: "center"
    },
  },
  FloatRight: {
    float: "right"
  },
  FloatLeft: {
    float: "Left",
    '& .MuiButton-outlined': {
      padding: "4px 2px"
    }
  },
  ButtonLeftSpace: {
    paddingLeft: "10px"
  },
  Accordianinput: {
    '& .MuiAccordionSummary-root': {
      boxShadow: "0 2px 5px 0 rgba(0,0,0,0.16), 0 2px 10px 0 rgba(0,0,0,0.12) !important"
    },
    '& .MuiAccordionDetails-root': {
      padding: "10px 16px 10px"
    },

  },
  CustomCard: {
    boxShadow: "none"
  },
  dataoverlay: {
    cursor: "pointer",
    color: "black !important",
    textAlign: "center"

  },
  TextAreacustom: {
    width: "100%",
    height: "180px !important",
    fontSize: "15px",
    resize: "none",
    overflowY: "scroll !important"

  },
  OverlayCardheading: {
    textAlign: "center",
    margin: "0 0 0px",
    fontSize: "17px",
    fontWeight: "400",
  },
  InsideCardBody: {
    padding: "1px 13px"
  },
  AdvCardBody: {
    padding: " 0.9375rem 15px"
  },
  checkboxroot: {
    '& .MuiSvgIcon-root': {
      width: "0.7em",
      height: "0.7em"
    },
  },


};
export default PublisherStyles;