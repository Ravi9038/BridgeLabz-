import {
  primaryColor,
  warningColor,
  dangerColor,
  successColor,
  infoColor,
  roseColor,
  grayColor,
  cardTitle
} from "assets/jss/material-dashboard-pro-react.js";

const chartsStyle = {
  select: {
    padding: "10px",

  },
  cardTitle,
  cardCategory: {
    margin: "0",
    color: grayColor[0]
  },
  cardIconTitle: {
    ...cardTitle,
    marginTop: "15px",
    marginBottom: "0px"
  },
  legendTitle: {
    color: grayColor[0],
    margin: "10px 0 !important",
    display: "flex"
  },
  primary: {
    color: primaryColor[0]
  },
  warning: {
    color: warningColor[0]
  },
  danger: {
    color: dangerColor[0]
  },
  success: {
    color: successColor[0]
  },
  info: {
    color: infoColor[0]
  },
  rose: {
    color: roseColor[0]
  },
  gray: {
    color: grayColor[0]
  },
  cardFooter: {
    display: "block"
  },
  SelectDropdownStyle: {
    '& .MuiAutocomplete-inputRoot[class*="MuiOutlinedInput-root"] ': {
      padding: "0px"
    },
    '& .MuiInputLabel-outlined': {
      zIndex: "1",
      transform: " translate(14px, 11px) scale(1)",
      pointerEvents: "none"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink ': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiSvgIcon-fontSizeSmall': {
      display: "none"
    },
  },
  buttonstyle: {
    '& .makeStyles-button-91 ': {
      margin: "0px !important",
      height: "37px !important"
    }
  },
  GraphIdentifier: {
    '& .MuiList-root': {
      display: "inline-flex",
      width: "300px !important"
    },
    '& .MuiListItem-gutters': {
      paddingLeft: '16px',
      paddingRight: '16px',
      display: '-webkit-box',
      marginInline: '15px'
    },
  },




};

export default chartsStyle;
