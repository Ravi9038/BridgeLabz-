const Paymentstyles = {

  root2: {
    float: "right",
    Primary: {
      color: "#1976d2",
      border: "1px solid #1976d2"
    }
  },
  ButtonRightCard: {
    float: "right",
  },

  root: {
    '& .rt-th': {
      lineHeight: '1em !important'
    },
    '& .MuiFormControlLabel-label': {
      color: "black",
      fontWeight: "400",

    },

  },
  CardHeading: {
    textAlign: "center",
    color: "black!important",
  },
  MainHeading: {
    textAlign: "left",
    color: "#3c4858!important",

  },
  CloseButton: {
    backgroundColor: "white",
    borderRadius: "30px",
    color: "black",
    width: "41px",
    height: "41px",

    minWidth: "41px",
    paddingLeft: "12px",
    paddingRight: "12px"
  },
  SliderTitle: {
    fontSize: "16px",
    paddingLeft: "30px",
    color: "black !important",
    fontWeight: "400"

  },
  CustomappBar: {
    display: "flex",
    flex: " 0 0 64px",
    background: "#ebebeb",
    height: " 64px",
    borderBottom: "1px solid rgb(0 0 0 / 10%)",

  },
  heading: {
    color: "black!important",
    fontSize: "15px",
    fontWeight: "400",

  },
  headingcenter: {
    color: "black!important",
    fontSize: "15px",
    fontWeight: "400",
    textAlign: "center"
  },
  data: {
    fontSize: "15px",
    fontWeight: "200"
  },
  datacenter: {
    fontSize: "15px",
    fontWeight: "200",
    textAlign: "center !important"
  },
  dataoverlay: {
    cursor: "pointer",
    color: "black !important",
    fontSize: "15px",
    fontWeight: "200",

  },
  SliderBackground: {
    backgroundColor: "#dddddd!important"
  },
  TextCenter: {
    textAlign: "center"
  },
  SmallText: {
    fontSize: "12px",
    color: "#000000de",
    fontWeight: "300"
  },
  headingStyle: {
    marginBottom: "0px",
    fontSize: "1.1em",
    fontWeight: "500",
    marginTop: "25px",
  },
  root2: {

    float: "right"
  },
  ButtonSpace: {
    paddingLeft: "10px",
    paddingRight: "10px"
  },
  checkboxroot: {
    '& .MuiSvgIcon-root': {
      width: "0.7em",
      height: "0.7em"
    },
  },
  ActionsButton: {
    '& .MuiButton-root': {
      minWidth: " 0px"
    },
    '& .MuiButton-root': {
      height: "0px"
    }

  },
  CardBodyPadding: {
    marginTop: "20px",
    marginBottom: "30px"
  },
  HeadingRow: {
    marginTop: "10px"
  },

  margin: {
    paddingTop: "10px"
  },
  Accordianinput: {
    '& .MuiAccordionSummary-root': {
      boxShadow: "0 2px 5px 0 rgba(0,0,0,0.16), 0 2px 10px 0 rgba(0,0,0,0.12) !important"
    },
    '& .MuiAccordionDetails-root': {
      padding: "10px 16px 10px"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-8': {
      padding: "0 5px !important",

    },
    '& .MuiGrid-grid-lg-2 .MuiInputBase-input ': {
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-2 .MuiInputBase-input ': {
      textAlign: "center"
    },

    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important",
      textAlign: "center"
    },

    '& .MuiGrid-grid-lg-8': {
      padding: "0 5px !important"
    },
    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "0px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",

    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .MuiGrid-grid-lg-1': {
      padding: "0 5px !important",
      textAlign: "center"

    },
    '& .MuiGrid-grid-lg-1 .MuiInputBase-input ': {
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-1 .MuiInputBase-input ': {
      textAlign: "center"
    },

    '& .MuiGrid-grid-md-1': {
      padding: "0 5px !important",
      textAlign: "center"
    },
  },
  rootslider: {
    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },
    '& .MuiGrid-grid-md-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2 .MuiInputBase-input ': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiGrid-grid-lg-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-2 .MuiInputBase-input ': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-12': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-12': {
      padding: "0 5px !important"
    },
    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",
    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },

    '& .MuiGrid-grid-lg-1': {
      padding: "0 2px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-lg-1 .MuiInputBase-input': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-1': {
      padding: "0 2px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-1 .MuiInputBase-input': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiInputBase-input': {

      padding: " 10px 5px 10px"

    },
    '& .MuiGrid-grid-md-5': {
      padding: "0 5px !important",

    },
    '& .MuiGrid-grid-lg-5': {
      padding: "0 5px !important",

    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important",

    },
    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important",

    },
    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "2px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },
    '& .MuiFormControl-root': {
      // margin: theme.spacing(1),
      width: "100%",

    },
    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },

    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },
    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",


    },
    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important",
      width: "100%",
      boxShadow: "none!important"
    },
    '& .MuiPaper-elevation4': {
      background: "#ebebeb !important",

    },
    '& .MuiPaper-elevation24': {
      boxShadow: "none!important"
    },
    '& .MuiBackdrop-root': {
      backgroundColor: "#0000000d"
    },
  },
  ActionsButton: {
    '& .MuiCheckbox-root': {
      minWidth: " 0px",
      height: "0px"
    },


  },
  StatusButton: {
    '& .MuiButtonBase-root': {
      margin: " 1px 1px",
      padding: "0px 0px"
    },
  },
  PaidDetailsCard: {
    color: "#545353",
    fontWeight: "600"
  },
  CardHeading: {
    textAlign: "center",
    color: "black!important",
    cursor: 'pointer',

  },
  CardButton: {
    textAlign: "center",
    color: "white!important",
    cursor: 'pointer',
    fontWeight: "400",
    width: "100%",
    backgroundColor: "#8e24aa",
    fontSize: "18px",
    border: "1px solid #8e24aa",
    padding: "10px",
    verticalAlign: " middle",
    borderRadius: "3px"


  },
  ButtonHeading: {
    fontSize: " 1.25rem",
    padding: "10px 20px"

  },
  ButtonCardCustom: {
    borderRadius: "2px"
  },
  TextCenter: {
    textAlign: "center"
  },
  SmallText: {
    fontSize: "12px",
    color: "#000000de",
    fontWeight: "300"
  },
  CloseButton: {
    backgroundColor: "white",
    borderRadius: "30px",
    color: "black",
    width: "41px",
    height: "41px",

    minWidth: "41px",
    paddingLeft: "12px",
    paddingRight: "12px"
  },
  SliderTitle: {
    fontSize: "16px",
    paddingLeft: "30px",
    color: "black !important",
    fontWeight: "400"

  },
  CustomappBar: {
    display: "flex",
    flex: " 0 0 64px",
    background: "#ebebeb",
    height: " 64px",
    borderBottom: "1px solid rgb(0 0 0 / 10%)",


  },
  heading: {
    color: "black!important"
  },
  SuccessColor: {
    color: "#4caf50"
  },
  PaymentOverviewCardBody: {
    padding: "5px 7px"
  },
  margin: {
    paddingTop: "10px"
  },
  S: {
    paddingTop: "10px"
  },
  EditCurrencyrootslider: {
    '& .MuiPaper-elevation24': {
      boxShadow: "none!important"
    },
    '& .MuiGrid-container': {
      width: "100% !important",
      margin: "0 0px"
    },
    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "6px",
      paddingRight: "6px"
    },
    '& .MuiGrid-grid-lg-6': {
      padding: "0 3px !important"
    },
    '& .MuiGrid-grid-md-6': {
      padding: "0 3px !important"
    },
    '& .MuiDialog-paperFullScreen': {
      width: "30% !important",
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important",
      float: "right !important",


    },
    '& .MuiAppBar-positionFixed': {
      position: "relative!important",
    },
    '& .MuiDialog-scrollPaper': {
      display: "block !important"
    },
    '& .MuiAppBar-colorPrimary': {

      background: "#ebebeb !important",
      boxShadow: "none!important",
      width: "30% !important"

    },
    '& .MuiAppBar-root': {
      width: "100% !important",

    },
    '& .MuiBackdrop-root': {
      backgroundColor: "#0000000d"
    },
  },
  submitbutton: {
    color: " #4caf50",
    border: "1px solid #4caf50"
  },
  ReceivedAmountSlider: {

    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "6px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },

    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)",
      color: " #3f51b5"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },

    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },


    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },
    '& .MuiPaper-root': {
      backgroundColor: "#fff!important"
    },
    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",
      boxShadow: "none!important"

    },

    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important"
    },
    '& .MuiPaper-elevation4': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important"
    },
    '& .MuiDialog-container': {
      width: "30%",
      float: "right"
    }
  },
};
export default Paymentstyles;