
const AdsTxtManagementStyle = {
  root: {
    CardBodyCustomize: {
      padding: "6px 20px"
    }
  },
  ActionsButton: {
    '& .MuiButton-root': {
      minWidth: " 0px"
    },
    '& .MuiButton-root': {
      height: "0px"
    },
    '& .MuiButton-text': {
      padding: " 0px 0px"
    },
    '& .MuiButton-root': {
      minWidth: "30px"
    },
    '& .MuiButtonBase-root svg ': {
      width: "1em",
      height: "1em"
    },
    '& .MuiButtonBase-root': {
      width: "35px",
      height: "15px"
    },

  },
  dataoverlay: {
    cursor: "pointer",
    color: "black !important",
    textAlign: "center"
  },
  heading: {
    textAlign: "center",
    margin: "0 0 0px",
    fontSize: "17px",
    fontWeight: "400",
  },
  rootslider: {
    '& .MuiInputBase-root': {
      width: "100%"
    },
    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "6px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },

    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",

    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },

    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },

    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",


    },
    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important",
      width: "100%",
      boxShadow: "none!important"
    },
    '& .MuiPaper-elevation4': {
      background: "#ebebeb !important",

    },
    '& .MuiPaper-elevation24': {
      boxShadow: "none!important"
    },
    '& .MuiBackdrop-root': {
      backgroundColor: "#21212114"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "0px!important",
      marginRight: "0px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },
    '& .MuiFormControl-root': {
      //margin: theme.spacing(1),
      width: "100%",

    },
    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },
    '& .MuiGrid-grid-md-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-md-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2 .MuiInputBase-input ': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiGrid-grid-lg-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-8 .MuiInputBase-input ': {
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-2 .MuiInputBase-input ': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-12': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-10': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-11': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-6': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-5': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-4': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-3': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-2': {
      padding: "0 5px !important"
    },
    '& .MuiGrid-grid-lg-12': {
      padding: "0 5px !important"
    },
    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",
    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },

    '& .MuiGrid-grid-lg-1': {
      padding: "0 2px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-lg-1 .MuiInputBase-input': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiGrid-grid-md-1': {
      padding: "0 2px !important",
      textAlign: "center"
    },
    '& .MuiGrid-grid-md-1 .MuiInputBase-input': {
      textAlign: "center",
      fontSize: "14px"
    },
    '& .MuiInputBase-input': {
      padding: " 10px 5px 10px"

    },

  },
  TextAreacustom: {
    width: "100%",
    height: "auto",
    fontSize: "15px",
    resize: "none"

  },
  CloseButton: {
    backgroundColor: "white",
    borderRadius: "30px",
    color: "black",
    width: "41px",
    height: "41px",

    minWidth: "41px",
    paddingLeft: "12px",
    paddingRight: "12px"
  },
  SliderTitle: {
    fontSize: "16px",
    paddingLeft: "30px",
    color: "black !important",
    fontWeight: "400"

  },
  CustomappBar: {
    display: "flex",
    flex: " 0 0 64px",
    background: "#ebebeb",
    height: " 64px",
    borderBottom: "1px solid rgb(0 0 0 / 10%)",

  },
  FloatRight: {
    float: "right"
  },
  FloatLeft: {
    float: "Left"
  },
  ButtonLeftSpace: {
    paddingLeft: "10px"
  },
  Accordianinput: {
    '& .MuiAccordionSummary-root': {
      boxShadow: "0 2px 5px 0 rgba(0,0,0,0.16), 0 2px 10px 0 rgba(0,0,0,0.12) !important"
    },
    '& .MuiAccordionDetails-root': {
      padding: "10px 16px 10px"
    },

  },
  CustomCard: {
    boxShadow: "none"
  }
};


export default AdsTxtManagementStyle;
