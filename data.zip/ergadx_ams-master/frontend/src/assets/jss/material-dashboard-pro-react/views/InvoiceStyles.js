const Invoicestyles = {
  root: {
    '& .MuiFormControlLabel-root': {
      paddingTop: "6px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },
    '& .MuiFormControl-root': {
      // margin: theme.spacing(1),
      width: "100%",

    },
    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },



    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },

  },
  rootslider: {
    '& .MuiToolbar-gutters': {
      marginLeft: "24px",
      marginRight: "24px"
    },
    '& .makeStyles-SliderTitle-167  ': {
      fontSize: "18px!important"
    },
    '& .MuiFormControlLabel-root': {
      paddingTop: "6px!important",
      marginRight: "15px!important",

    },
    '& .MuiTypography-body1': {
      fontSize: "15px"
    },
    '& .MuiFormControl-root': {
      // margin: theme.spacing(1),
      width: "100%",

    },
    '& .MuiGrid-container': {
      paddingLeft: "6px",
      paddingRight: "6px"
    },

    '& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
      transform: "translate(14px, -6px) scale(0.85)"
    },
    '& .MuiInputLabel-outlined': {
      transform: "translate(14px, 14px) scale(1)",
      fontSize: "0.9rem !important"
    },
    '& .MuiOutlinedInput-input': {
      paddingTop: "10px",
      paddingBottom: "10px",
      paddingLeft: "10px",
      paddingRight: "10px"
    },
    '& .MuiFormControl-root ': {
      width: "100%",
      marginTop: "10px",
      marginBottom: "10px",
      marginLeft: "0px",
      marginRight: "0px",


    },
    '& .makeStyles-grid-166': {
      padding: "0 5px !important"
    },
    '& .MuiOutlinedInput-adornedStart': {
      paddingLeft: "10px"
    },
    '& .makeStyles-grid-167': {
      padding: "0 5px !important"
    },


    '& #document-type': {
      textAlign: "center!important"
    },
    '& .MuiButton-label': {
      fontSize: "0.875rem",
      fontWeight: "bold"
    },
    '& .MuiPaper-root': {
      backgroundColor: "#dddddd!important"
    },
    '& .MuiAppBar-positionFixed': {
      top: "0",
      left: "auto",
      right: "0",
      position: " relative!important",
      boxShadow: "none!important"

    },
    '& .MuiFormControl-root': {
      //margin: theme.spacing(1),
      width: "100%",
    },
    '& .MuiToolbar-regular': {
      minHeight: "64px!important",
      overflowX: " hidden !important"
    },
    '& .MuiDialog-paperFullScreen': {
      backgroundColor: "#dddddd!important",
      overflowX: " hidden !important"
    },
    '& .MuiPaper-elevation4': {
      borderBottom: "1px solid rgb(0 0 0 / 10%) !important",
      background: "#ebebeb !important",
      boxShadow: "none!important"
    }
  },
  root2: {
    '& > *': {
      // margin: theme.spacing(1),
      float: "right"
    },
  },
  CardHeading: {
    textAlign: "center",
    color: "black!important",
  },
  MainHeading: {
    textAlign: "left",
    color: "#3c4858!important",

  },
  CloseButton: {
    backgroundColor: "white",
    borderRadius: "30px",
    color: "black",
    width: "41px",
    height: "41px",

    minWidth: "41px",
    paddingLeft: "12px",
    paddingRight: "12px"
  },
  SliderTitle: {
    fontSize: "16px",
    paddingLeft: "30px",
    color: "black !important",
    fontWeight: "400"

  },
  CustomappBar: {
    display: "flex",
    flex: " 0 0 64px",
    background: "#ebebeb",
    height: " 64px",
    borderBottom: "1px solid rgb(0 0 0 / 10%)",


  },
  heading: {
    color: "black!important"
  },
  SliderBackground: {
    backgroundColor: "#dddddd!important"
  },
  TextCenter: {
    textAlign: "center"
  },
  SmallText: {
    fontSize: "12px",
    color: "#000000de",
    fontWeight: "300"
  }

};
export default Invoicestyles;